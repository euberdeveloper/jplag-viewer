import javax.swing.*;
import java.awt.*;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.io.BufferedReader;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.PrintWriter;
import java.net.Socket;
import java.net.UnknownHostException;

public class ClientUI  implements ClientThread{
    private JFrame frame;
    private JPanel panel;
    private JTextArea textArea = new JTextArea();
    private JTextField textField = new JTextField();
    public  Button
            sendButton = new Button("Send"),
            connectButton = new Button("Connect"),
            quitButton = new Button("quit");
    private String name;
    private Socket socket = null;
    private BufferedReader bufferedReader = null;
    private PrintWriter printWriter = null;
    private DataOutputStream streamOut = null;
    private String ip="clouddatabases.msrg.in.tum.de";
    private int port = 5551;

    public ClientUI() {
        frame = new JFrame("Client");
        frame.setSize(400, 200);
        frame.setLocationRelativeTo(null);
        frame.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);

        panel = new JPanel();
        panel.setLayout(new GridLayout(1, 2));

        panel.add(connectButton);
        panel.add(quitButton);

        Panel location = new Panel();
        location.setLayout(new BorderLayout());
        location.add("West", panel);
        location.add("Center", textField);
        location.add("East", sendButton);
        frame.setFont(new Font("Helvetica", Font.BOLD, 20));
        frame.setLayout(new BorderLayout());
        frame.add("Center", textArea);
        frame.add("South",location);
        quitButton.setEnabled(false);
        sendButton.setEnabled(false);
        frame.setVisible(true);

        quitButton.addActionListener(actionEvent -> quit());

        System.out.println(Thread.currentThread().getId());

        connectButton.addActionListener(actionEvent ->
                new Thread(() -> {
                    println("Connection to MSRG Echo server established: /131.159.52.23 / 5551");
                    try {
                        socket = new Socket(ip, port);
                        println("Connected: " + socket);
                       // open();
                        EventQueue.invokeLater(() -> {
                            sendButton.setEnabled(true);
                            connectButton.setEnabled(false);
                            quitButton.setEnabled(true);
                        });
                    } catch (UnknownHostException uhe) {
                        println("Host unknown: " + uhe.getMessage());
                    } catch (IOException ioe) {
                        println("Unexpected exception: " + ioe.getMessage());
                    }
                }).start()
        );

        sendButton.addActionListener(actionEvent -> {
            send();
            EventQueue.invokeLater(() -> textField.requestFocus());
        });

      textField.addKeyListener(new KeyAdapter() {
            @Override public void keyTyped(final KeyEvent e) {
                if (e.getKeyChar() == KeyEvent.VK_ENTER)
                    send();
            }
        });

        frame.addWindowListener(new WindowAdapter() {
            public void windowClosing(WindowEvent e) {
                frame.dispose();
            }
        });
    }

    private void quit() {
        new Thread(() -> {
            textField.setText(".quit");
            send();
            EventQueue.invokeLater(() -> {
                quitButton.setEnabled(false);
                sendButton.setEnabled(false);
                connectButton.setEnabled(true);
            });
        }).start();
    }

    private void send() {
        try {

            streamOut.writeUTF(textField.getText());
            streamOut.flush();
            EventQueue.invokeLater(() -> textField.setText(""));
        } catch (IOException ioe) {
            println("Sending error: " + ioe.getMessage());
            close();
        }
    }

    private void println(final String msg) {
        EventQueue.invokeLater(() -> textArea.append(msg + "\n"));
    }


    @Override
    public void message( final String msg) {
        if (msg.equals(".quit")) {
            println("Connection closed!");
            close();
        } else
            println(msg);
    }



    @Override
    public void close() {
        try {
            if (streamOut != null)
                streamOut.close();
            if (socket != null)
                socket.close();
        } catch (IOException ioe) {
            println("Error closing ...");
        }

    }

    @Override
    public Socket getSocket() {
        return socket;
    }

    public static void main(final String[] args) {
        final ClientUI chatGUI = new ClientUI();
    }
}
