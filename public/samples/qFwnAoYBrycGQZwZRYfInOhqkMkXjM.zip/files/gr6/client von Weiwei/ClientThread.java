public interface ClientThread {
    void message(final String msg);
    void close();
    java.net.Socket getSocket();
}
