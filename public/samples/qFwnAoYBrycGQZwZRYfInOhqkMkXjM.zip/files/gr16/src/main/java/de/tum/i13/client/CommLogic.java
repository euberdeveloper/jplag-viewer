package de.tum.i13.client;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.Socket;
import java.io.ByteArrayOutputStream;







public class CommLogic {
    private Socket client;

    /**
     * Constructor for a necessary CommLogic object
     * @throws IOException
     */
    public CommLogic() throws IOException {

    }

    /**
     *
     * @return the private variable client.
     */
    public Socket getClient(){
        return client;
    }

    /**
     *
     * @param adress Specified server address by client to be connected
     * @param portnumber Specified port number  by client to be connected
     */
    public void connect(String adress, int portnumber)  { //open client socket and get input/output streams
        try{
            client = new Socket(adress, portnumber);

        }
        catch (IOException ex){
            System.out.println("Connection to the server failed!");
        }

    }

    /**
     * Disconnect from server
     * @throws IOException
     */
    public void disconnect() throws IOException {

        if(client.isClosed()){ // checks if connection already closed
            System.out.println("Connection already closed");
        }
        else{ // otherwise do the close operation
            try{
                client.close();
                System.out.println("Disconnected");
            }
            catch (IOException ex){
                System.out.println("Connection could not be closed");
            }
        }


    }

    /**
     *
     * @param message to be send
     * @throws IOException
     */
    public void send(String message) throws IOException {
        byte[] msgBytes = message.getBytes(); //convert message to byte array
        OutputStream out = client.getOutputStream();

        out.write(msgBytes); //sends message through the output stream
        out.flush();



    }

    /**
     *
     * @return the received byte array through inputstream.
     * @throws IOException
     */
    public byte[] receive() throws IOException {

        InputStream in = client.getInputStream();
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        int read;
        while((read = in.read()) !=10){
            baos.write(read);
        }
        baos.write(read);
        byte[]recvBytes=baos.toByteArray();
        return recvBytes;
    }

}
