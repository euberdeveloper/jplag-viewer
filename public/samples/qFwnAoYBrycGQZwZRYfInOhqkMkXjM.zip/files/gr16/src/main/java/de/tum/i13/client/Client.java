package de.tum.i13.client;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.logging.Level;
import java.util.logging.Logger;

public class Client {
    private final static Logger LOGGER = Logger.getLogger(Client.class.getName());

    /**
     * Main application to be run by client. This main program can handle  unknown commands and  commands given in the
     * help text

     */

    public static void main(String[] args) throws IOException {
        CommLogic commLogic=new CommLogic();
        BufferedReader cons=new BufferedReader(new InputStreamReader(System.in));
        boolean quit=false;
        while(!quit){
            System.out.print("EchoClient> ");
            String input= cons.readLine();
            String[] tokens=input.trim().split("\\s+");
            if(tokens != null){
                if(tokens.length  == 3 && tokens[0].equals("connect")) { //connect
                    String address = tokens[1];
                    String port = tokens[2];
                    try {
                        int portNum = Integer.parseInt(port); // checks if the port argument is a valid integer
                        LOGGER.info("Connecting to  server: "+address+" at port: "+port);
                        commLogic.connect(address, portNum);
                        byte[] recvBytes=commLogic.receive();
                        String recvMesg = new String(recvBytes, "ISO_8859_1");
                        System.out.print(recvMesg);







                    }
                    catch(NumberFormatException ex){
                        System.out.println("Invalid port number!");

                    }
                }
                else if( tokens.length == 1 && tokens[0].equals("disconnect")){
                    LOGGER.info("disconnecting from server");
                    if(commLogic.getClient()==null ||(!commLogic.getClient().isConnected())){ // show error message if socket is not connected
                        System.out.println("Error! Not connected!");
                        continue;
                    }
                    commLogic.disconnect();
                    System.out.println("Connection terminated");
                }
                else if(tokens.length != 0 && tokens[0].equals("send")){
                    if(commLogic.getClient()==null ||(commLogic.getClient().isClosed())){ // show error message if socket is not connected
                        System.out.println("Error! Not connected!");
                        continue;
                    }
                    if(tokens.length==1){
                        System.out.println("You cant send an empty message!");
                        continue;
                    }

                    String message = "\r\n"; //creates an  empty message with delimeter
                    for(int i = tokens.length-1; i>0; i--){  // create message from  tokens array
                        message = tokens[i]+" "+ message ;
                    }
                    commLogic.send(message);
                    byte[] recvBytes=commLogic.receive();
                    String recvMesg = new String(recvBytes, "ISO_8859_1");
                    System.out.print(recvMesg);


                }
                else if(tokens.length == 2 && tokens[0].equals("logLevel")){ //set the requested  loglevel
                    String level=tokens[1];
                    if ("SEVERE".equals(level)) {
                        LOGGER.setLevel(Level.SEVERE);

                    } else if ("WARNING".equals(level)) {
                        LOGGER.setLevel(Level.WARNING);
                    }
                    else if ("INFO".equals(level)) {
                        LOGGER.setLevel(Level.INFO);
                    }
                    else if ("CONFIG".equals(level)) {
                        LOGGER.setLevel(Level.CONFIG);
                    }
                    else if ("FINE".equals(level)) {
                        LOGGER.setLevel(Level.FINE);
                    }
                    else if ("FINER".equals(level)) {
                        LOGGER.setLevel(Level.FINER);
                    }
                    else if ("FINEST".equals(level)) {
                        LOGGER.setLevel(Level.FINEST);
                    }

                    else{
                        System.out.println("Invalid Level");
                    }


                }
                else if(tokens.length == 1 && tokens[0].equals("quit")){
                    LOGGER.info("exiting the application");
                    System.out.println("Application exit!");
                    quit=true;
                }
                else if(tokens.length == 1 && tokens[0].equals("help")){
                    System.out.println("Available Commands:\n" +
                            "connect <address> <port> : connect specified address and port.\n" +
                            "disconnect : close the current connection\n" +
                            "send <message> : send your message to the server\n" +
                            "logLevel <level> : set the level of logging you want to see. Available levels : SEVERE,WARNING,INFO,CONFIG,FINE,FINER,FINEST\n" +
                            "quit : close the program");

                }
                else{
                    System.out.println("Unknown Command\n"+"Available Commands:\n" +
                            "connect <address> <port> : connect specified address and port.\n" +
                            "disconnect : close the current connection\n" +
                            "send <message> : send your message to the server\n" +
                            "logLevel <level> : set the level of logging you want to see. Available levels : SEVERE,WARNING,INFO,CONFIG,FINE,FINER,FINEST\n" +
                            "quit : close the program");

                }

            }

        }
    }
}
