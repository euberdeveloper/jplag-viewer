package de.tum.i13.client;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.UnknownHostException;
import java.util.concurrent.TimeUnit;
import java.util.logging.Level;
import java.util.logging.Logger;

import static de.tum.i13.client.Command.EMPTY;
import static de.tum.i13.client.Command.QUIT;
import static de.tum.i13.shared.LogSetup.setupLogging;
/**
 * EchoClient in Java.
 * Should connect to "clouddatabases.msrg.in.tum.de 5551"
 * version = Milestone
 * @author Gabit Saygutdinov, Aleksandr Minakov, Florian Messmer
 * @version 1.0

 */
public class Client {
    private final ApplicationHandler applicationHandler;
    private ConnectionHandler connectionHandler;
    private final static Logger LOGGER = Logger.getLogger(Client.class.getName());
    private String host;

    public Boolean getConnected() {
        return isConnected;
    }

    public void setConnected(Boolean connected) {
        isConnected = connected;
    }

    private Boolean isConnected;

    public String getHost() {
        return host;
    }

    public void setHost(String host) {
        this.host = host;
    }

    public int getPort() {
        return port;
    }

    public void setPort(int port) {
        this.port = port;
    }

    private int port;


    public Client() {
        this.applicationHandler = new ApplicationHandler();
        this.host = "";
        this.port = 0;
        this.isConnected = false;
    }

    /**
     * Main program.
     * @param args command line parameter
     */
    public static void main(String[] args) throws IOException {
        setupLogging("test.log");
        BufferedReader in;
        String rawInput;
        Client client = new Client();
        in = new BufferedReader(new InputStreamReader(System.in));
        outer:
        while (true) {


            System.out.print("EchoClient> ");
            LOGGER.info("Reading new user input");
            //reading input
            rawInput = in.readLine();


            try {
                LOGGER.info("Parsing user input");
                String argument = "";
                try {
                    argument = client.applicationHandler.parse(rawInput);
                } catch (NumberFormatException n) {
                    System.out.println("Could not parse your Entry for port. Please check if number format.");
                }

                do {
                    LOGGER.info("Inferring application logic from input command");
                    switch (client.applicationHandler.getCommand()) {
                        case QUIT:
                            System.out.println("Quitting the application...");
                            LOGGER.info("Checking for active connection");
                            if (client.getConnected()) {
                                client.connectionHandler.disconnect();
                            }
                            LOGGER.info("Quitting application...");
                            System.exit(0);
                            break outer;
                        case HELP:
                            System.out.println("EchoClient> This client serves as an echo client and offers the following Commands:");
                            System.out.println("EchoClient> connect <address> <port>: Connects the client to the given address and port.");
                            System.out.println("EchoClient> disconnect: Tries to disconnect from the connected server");
                            System.out.println("EchoClient> send <message>: Sends a text message to the echo server.");
                            System.out.println("EchoClient> logLevel: Sets the logger to the specified log level.");
                            System.out.println("EchoClient> help: Displays the help text");
                            System.out.println("EchoClient> quit: Terminates the active connection and exits the program.");
                            client.applicationHandler.setCommand(EMPTY);
                            continue outer;
                        case CONNECT:
                            if (!client.isConnected) {
                                client.setHost(client.applicationHandler.getHost());
                                client.setPort(client.applicationHandler.getPort());
                                LOGGER.info("EchoClient> Setting up new connection via handler.");
                                try {
                                    client.connectionHandler = new ConnectionHandler(client.getHost(), client.getPort());
                                } catch (UnknownHostException e) {
                                    System.out.println("Unknown Host. Could not connect");
                                } catch (IOException u) {
                                    System.out.println("IOException at setting up connection");
                                }
                                TimeUnit.SECONDS.sleep(1);
                                client.applicationHandler.setIsConnected(true);
                                client.setConnected(true);
                                LOGGER.info("Reading welcome message from remote.");
                                String s = "";
                                try {
                                    s = client.connectionHandler.receive();
                                } catch (IOException i) {
                                    System.out.println("IOException while reading message from remote.");
                                }
                                System.out.println(s);
                            }else{
                                System.out.println("Already connected to " +client.getHost() + client.getPort());
                            }
                            continue outer;
                        case LOGLEVEL:

                            String logLevel = argument.toLowerCase();
                            switch (logLevel) {
                                case "all":
                                    LOGGER.setLevel(Level.ALL);
                                    System.out.println("EchoClient> logLevel set to ALL");

                                    continue outer;
                                case "config":
                                    LOGGER.setLevel(Level.CONFIG);
                                    System.out.println("EchoClient> logLevel set to CONFIG");
                                    continue outer;
                                case "fine":
                                    LOGGER.setLevel(Level.FINE);
                                    System.out.println("EchoClient> logLevel set to FINE");

                                    continue outer;
                                case "finest":
                                    LOGGER.setLevel(Level.FINEST);
                                    System.out.println("EchoClient> logLevel set to FINEST");

                                    continue outer;
                                case "info":
                                    LOGGER.setLevel(Level.INFO);
                                    System.out.println("EchoClient> logLevel set to INFO");

                                    continue outer;
                                case "off":
                                    LOGGER.setLevel(Level.OFF);
                                    System.out.println("EchoClient> logLevel set to OFF");

                                    continue outer;
                                case "severe":
                                    LOGGER.setLevel(Level.SEVERE);
                                    System.out.println("EchoClient> logLevel set to SEVERE");

                                    continue outer;
                                case "warning":
                                    LOGGER.setLevel(Level.WARNING);
                                    System.out.println("EchoClient> logLevel set to WARNING");
                                    continue outer;
                                default:
                                    System.out.println("EchoClient> Illegal Argument for LogLevel. Please enter another command");
                                    continue outer;
                            }
                        case SEND:
                            if(!client.isConnected){
                                System.out.println("EchoClient> Please connect to a server first.");
                        }else {
                                LOGGER.info("Sending message");
                                try {
                                    client.connectionHandler.send(argument);
                                } catch (IOException i) {
                                    System.out.println("IOException while trying to send message");
                                } catch (NullPointerException n) {
                                    System.out.println("NullPointerException while trying to send message");
                                }
                                TimeUnit.SECONDS.sleep(1);
                                String answer = "";
                                try {
                                    answer = client.connectionHandler.receive();
                                } catch (IOException e) {
                                    System.out.println("IOException while trying to receive message.");
                                }
                                System.out.println("EchoClient> " + answer);
                            }
                            continue outer;
                        case DISCONNECT:
                            if(!client.isConnected){
                                System.out.println("EchoClient> Client is already disconnected.");
                            }else {
                                String hostDisc = client.getHost();
                                int portDisc = client.getPort();
                                LOGGER.info("Disconnecting from remote.");
                                try {
                                    client.connectionHandler.disconnect();
                                } catch (IOException | NullPointerException i) {
                                    System.out.println("Error while disconnecting.");
                                }
                                System.out.println("EchoClient> Disconnected from host " + hostDisc + " on port " + portDisc);
                                client.setConnected(false);
                                client.applicationHandler.setIsConnected(false);
                            }
                            continue outer;
                        case EMPTY:
                            continue outer;

                        default:
                            throw new IllegalStateException("EchoClient> Unexpected value: " + client.applicationHandler.getCommand());
                    }

                } while (client.applicationHandler.getCommand() != QUIT);

            } catch (Exception e) {
                LOGGER.throwing(Client.class.getName(), "main", e);
            }
        }
    }
}
