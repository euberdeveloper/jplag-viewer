package de.tum.i13.client;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.Socket;
import java.net.UnknownHostException;


/**
 * Connection Handler is created to establish  the connection
 * between client and server. Also it is responsible for
 * receiving unmarshalling as well as for sending and
 * marshalling messages
 */
public class ConnectionHandler {
    private final Socket socket;
    private final InputStream in;
    private final OutputStream out;
    private boolean isConnected;

    /**
     * The constructor gets parameters host and port and uses them to connect to the server
     * It also sets up streams needed for sending and receiving messages
     * @param host parameter host identifies host to which the client has to be connected
     * @param port identifies port
     * @throws IOException for input/output error
     * @throws UnknownHostException for incompatible host name
     */
    public ConnectionHandler(String host, int port) throws IOException, UnknownHostException{
        socket = new Socket(host, port);
        in = socket.getInputStream();
        out = socket.getOutputStream();
        isConnected = true;
    }


    /**
     * Disconnects the client from the server
     * @throws IOException for input/output error
     */
    public void disconnect() throws IOException{
        if (isConnected) {
            out.close();
            in.close();
            socket.close();
            isConnected = false;
        }
    }

    /**
     * Reads all bytes coming from server,saving them to the byte array,
     * and  then unmarshalls it to string
     * @return message as a string
     * @throws IOException for input/output error
     */
    public String receive() throws IOException {
        byte[] bytes = new byte[this.in.available()];
        for(int i = 0; i <bytes.length; i++) {
            bytes[i] = (byte) this.in.read();
        }
        StringBuilder s = new StringBuilder();
        for (byte b : bytes) {
            char c = (char) b;
            s.append(c);
        }

        return s.toString().replace("\r\n", "");
    }

    /**
     * Marshalls Sends the message the server
     * @param msg message that has to be sent to the server
     * @throws IOException for input/output error
     */
    public void send(String msg) throws IOException {
        String s = msg + "\r\n";
        out.write(marshall(s));
        out.flush();
    }

    /**
     * Marshalls an Object of type String to the byte array
     * @param s String that has to be marshalled
     * @return byte array from String
     */
    private byte[] marshall(String s) {
        return s.getBytes();
    }

}
