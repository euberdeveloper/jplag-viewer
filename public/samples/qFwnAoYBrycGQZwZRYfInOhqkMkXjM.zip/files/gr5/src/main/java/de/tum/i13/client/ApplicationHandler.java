package de.tum.i13.client;





/**
 * Application Handler class is created to read user's input from CLI
 * and to detect a right command and parse the input to the connection handler
 * to send it to a server.
 */

public class ApplicationHandler {


    private Command command;
    private String host;
    private int port;
    private boolean isConnected;

    /**
     * Constructor to create an Application Handler object to parse user's input
     */
    public ApplicationHandler() {
        isConnected = false;
        host = "";
        port = 0;
    }

    /**
     * Sets a command enum to detect a correct request
      * @param command enum
     */
    public void setCommand(Command command) {
        this.command = command;
    }

    /**
     * @return host name
     */
    public String getHost() {
        return host;
    }

    /**
     * @return port name as Integer
     */
    public int getPort() {
        return port;
    }

    public Command getCommand() {
        return command;
    }

    /**
     * Method to detect avoid double connection to NOT change host and port in this object
     *
     * @param in boolean variable to set a connection to true or false
     */
    public void setIsConnected(boolean in) {
        isConnected = in;
    }


    /**
     * Method to parse user's input and detect a command to set an enum for a Client object to do the right step.
     * The output is also saved as a String which the Client object then receives.
     *
     * @param input as user's input from command line
     * @return parsed input to send to the server (e.g. message) or post/host
     * @throws NumberFormatException for incompatible port description
     *
     * For enums description
     * @see Command class
     */
    public String parse(String input) throws NumberFormatException {

        String output = null;
        String[] cleanInput;
        cleanInput = input.trim().split("\\s+");
        cleanInput[0]=cleanInput[0].toLowerCase();

        if (cleanInput[0].equals("connect")) {
            command = Command.CONNECT;
            if (!isConnected) {
                host = cleanInput[1];
                port = Integer.parseInt(cleanInput[2]);
            }
            output = input.replaceFirst("connect", " ").trim();

        } else if (cleanInput[0].equals("disconnect")) {
            command = Command.DISCONNECT;
        } else if (cleanInput[0].equals("send")) {
            command = Command.SEND;
            output = input.replaceFirst("send", " ").trim();
        } else if (cleanInput[0].equals("loglevel")) {
            command = Command.LOGLEVEL;
            output = cleanInput[1];

        } else if (cleanInput[0].equals("help")) {
            command = Command.HELP;
        } else if (cleanInput[0].equals("quit")) {
            command = Command.QUIT;
        } else {
            command = Command.HELP;
        }
        return output;
    }


}
