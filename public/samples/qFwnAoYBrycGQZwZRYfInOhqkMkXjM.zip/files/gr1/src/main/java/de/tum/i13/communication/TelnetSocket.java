package de.tum.i13.communication;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.InetSocketAddress;
import java.net.Socket;

import static de.tum.i13.shared.Constants.MESSAGE_DELIMITER;
import static de.tum.i13.shared.Constants.TELNET_CHARSET;

/**
 * <h1>TelnetSocket is an implementation of the {@link TelnetClient} contract interface.</h1>
 * This class allows the user to interact with an telnet server in a streamlined way.
 *
 * @see Socket
 * @see InputStream
 * @see OutputStream
 */
public class TelnetSocket implements TelnetClient {

    // the socket timeout after the user will be notified of an unreachable server connection
    private static final int SOCKET_TIMEOUT = 5 * 1000;
    // the currently connected server host, used for printing purposes
    private String host;
    // the socket client used for the connection
    // a null client will be used to indicate no connection
    private Socket client;
    // the streams of the socket
    private InputStream in;
    private OutputStream out;

    @Override
    public void connect(String host, int port) throws IOException, ReestablishConnectionException {
        if (client != null) {
            // connection was already established
            throw new ReestablishConnectionException();
        }
        try {
            // establish socket connection and retrieve the streams for further use
            // use the timeout for the connection process as well so the program won`t
            // become unresponsive
            client = new Socket();
            client.connect(new InetSocketAddress(host, port), SOCKET_TIMEOUT);
            // sets the read timeout to 5 seconds
            client.setSoTimeout(SOCKET_TIMEOUT);
            in = client.getInputStream();
            out = client.getOutputStream();
            // save the string representation of the connection for later
            this.host = String.format("%s:%d", client.getInetAddress().getHostAddress(), client.getPort());
        } catch (Exception e) {
            // clean up for further connection attempts
            client = null;
            in = null;
            out = null;
            this.host = "";
            throw e;
        }
    }

    @Override
    public String readMessage() throws IOException, UnestablishedConnectionException {
        if (client == null) {
            // no connection, abort
            throw new UnestablishedConnectionException();
        }
        // read a message from the input stream
        byte[] res = read();
        // convert the message to ISO_8859_1 charset and strip the delimiter postfix
        return new String(res, TELNET_CHARSET).replace("\r\n", "");
    }

    @Override
    public void writeMessage(String message) throws UnestablishedConnectionException, IOException {
        if (client == null) {
            // no connection, abort
            throw new UnestablishedConnectionException();
        }
        // append the delimiter
        message = message + new String(MESSAGE_DELIMITER, TELNET_CHARSET);
        // get the bytes for ISO_8859_1
        this.write(message.getBytes(TELNET_CHARSET));
    }

    @Override
    public void disconnect() throws UnestablishedConnectionException, IOException {
        if (client == null) {
            // no connection, abort
            throw new UnestablishedConnectionException();
        }
        // close the streams
        try {
            //  contrary to the example shown in Milestone1.pdf,
            //  closing the in- and output streams of the sockets specifically is not needed,
            //  as closing the socket implicitly closes the underlying streams as well.
            client.close();
        } finally {
            // clean up for garbage collection and further connectivity checks
            client = null;
            in = null;
            out = null;
            host = "";
        }
    }

    @Override
    public String toString() {
        // used for current connection printouts
        return this.host;
    }


    /**
     * Reads a message as specified by the our simple telnet protocol from the input stream.
     * In order to detect the end of the message the stream ist checked for the message delimiter {@link de.tum.i13.shared.Constants#MESSAGE_DELIMITER}.
     *
     * @return      the received message
     * @throws IOException  exceptions thrown by {@link InputStream#read()}
     */
    private byte[] read() throws IOException {
        // the message gets temporally stored in a buffered stream until we reach the delimiter
        ByteArrayOutputStream buf = new ByteArrayOutputStream();
        // the current end sequence of our message gets stored for further checks
        byte[] endSequence = new byte[]{0x00, 0x00};
        int result = in.read();
        while (result != -1) {
            buf.write((byte) result);
            // shift the end sequence to conform to our current message
            // todo: maybe simply use bit shift and comparisons ? - Sven
            endSequence[0] = endSequence[1];
            endSequence[1] = (byte) result;
            // check for our delimiter to end reading from the stream
            if (endSequence[0] == MESSAGE_DELIMITER[0] && endSequence[1] == MESSAGE_DELIMITER[1]) {
                break;
            }
            result = in.read();
        }
        return buf.toByteArray();
    }

    // convenience methode for output writing
    private void write(byte[] message) throws IOException {
        out.write(message);
        out.flush();
    }
}
