package de.tum.i13.communication;

import java.net.SocketException;

/**
 * <h1>Exception used to indicate the unavailability of the current {@link java.net.Socket} connection.</h1>
 * This Exception should be used to notify the user to initialize
 * a connection before performing read/write operations on the socket.
 */
public class UnestablishedConnectionException extends SocketException {
}
