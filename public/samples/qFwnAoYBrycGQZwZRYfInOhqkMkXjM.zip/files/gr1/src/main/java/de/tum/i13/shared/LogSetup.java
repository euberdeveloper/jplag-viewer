package de.tum.i13.shared;

import java.io.IOException;
import java.util.logging.*;


/**
 * <h1>LogSetup is a utility class handling interactions with the underlying {@link LogManager}.</h1>
 * This class provides convenient methods for log initialisation and changing the level of the applications logs.
 */
public class LogSetup {

    /**
     * Initialises the logging of the system including setting the logs output format,
     * initial log level and logging to a file.
     *
     * @param logfile   the name of the log-file
     */
    public static void setupLogging(String logfile) {
        Logger logger = LogManager.getLogManager().getLogger("");
        // set the output format of the logger
        System.setProperty("java.util.logging.SimpleFormatter.format",
                "%1$tY-%1$tm-%1$td %1$tH:%1$tM:%1$tS.%1$tL %4$-7s [%3$s] %5$s %6$s%n");
        // initialize file logging
        FileHandler fileHandler = null;
        try {
            fileHandler = new FileHandler(logfile, true);
        } catch (IOException e) {
            e.printStackTrace();
        }
        fileHandler.setFormatter(new SimpleFormatter());
        logger.addHandler(fileHandler);

        // set the initial log level for all log handlers
        for (Handler h : logger.getHandlers()) {
            h.setLevel(Level.ALL);
        }
        logger.setLevel(Level.ALL);
    }

    /**
     * Changes the current log of the {@link Logger}.
     * The log level prior to method execution will be returned for user notice.
     *
     * @param level     the desired new log level
     * @return          the log level prior to method execution, null if argument was null
     */
    public static Level changeLogLevel(Level level) {
        Logger logger = LogManager.getLogManager().getLogger("");
        if (level == null) {
            logger.warning("Unable to change log level, provided level is not valid");
            return null;
        }
        // save the current log level for later
        Level currentLevel = logger.getLevel();

        // set log level for all log handlers
        for (Handler h : logger.getHandlers()) {
            h.setLevel(level);
        }
        logger.setLevel(level);

        return currentLevel;
    }
}
