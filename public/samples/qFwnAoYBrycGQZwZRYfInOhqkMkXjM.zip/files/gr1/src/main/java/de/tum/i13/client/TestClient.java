package de.tum.i13.client;

import de.tum.i13.communication.ReestablishConnectionException;
import de.tum.i13.communication.TelnetClient;
import de.tum.i13.communication.TelnetSocket;
import de.tum.i13.communication.UnestablishedConnectionException;
import de.tum.i13.shared.Constants;
import de.tum.i13.shared.LogSetup;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.SocketTimeoutException;
import java.net.UnknownHostException;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.stream.Collectors;
import java.util.stream.Stream;

/**
 * This client program is the entry point for an echo telnet CLI-program.
 *
 * The UI as well as error reporting is done here.
 */
public class TestClient {

    private final static Logger LOGGER = Logger.getLogger(TestClient.class.getName());
    private final static String TAG = TestClient.class.getName();

    public static void main(String[] args) {
        LogSetup.setupLogging("test.log");
        LOGGER.info("Starting CLI");
        // init the telnet client
        TelnetClient client = new TelnetSocket();
        // init the CLI
        BufferedReader cons = new BufferedReader(new
                InputStreamReader(System.in));
        boolean quit = false;
        while (!quit) {
            displayPrompt();
            String input = null;
            try {
                input = cons.readLine();
            } catch (IOException e) {
                displayMessage(Constants.ERROR_INPUT_EXCEPTION);
                LOGGER.throwing(TAG, "main", e);
                disconnect(client, true);
                return;
            }
            LOGGER.finest("INPUT: " + input);
            // split the user input so we can process the command tokens
            String[] tokens = input.trim().split("\\s+");
            // match the commands and execute them
            switch (tokens[0]) {
                case "connect":
                    if (tokens.length != 3) {
                        LOGGER.warning("invalid argument number");
                        displayMessage(String.format(Constants.ERROR_INVALID_NUMBER_ARGUMENTS, Constants.COMMAND_CONNECT));
                        break;
                    }
                    int port = 0;
                    try {
                        port = Integer.parseInt(tokens[2]);
                    } catch (NumberFormatException e) {
                        LOGGER.throwing(TAG, "main", e);
                        displayMessage(Constants.ERROR_INVALID_ARGUMENT_PORT);
                        break;
                    }
                    connect(client, tokens[1], port);
                    break;
                case "disconnect":
                    disconnect(client, false);
                    break;
                case "send":
                    if (tokens.length == 1) {
                        LOGGER.warning("invalid argument number");
                        displayMessage(String.format(Constants.ERROR_INVALID_NUMBER_ARGUMENTS, Constants.COMMAND_SEND));
                        break;
                    }
                    sendMessage(client, Stream.of(tokens).skip(1).collect(Collectors.joining(" ")));
                    break;
                case "logLevel":
                    if (tokens.length != 2) {
                        LOGGER.warning("invalid argument number");
                        displayMessage(String.format(Constants.ERROR_INVALID_NUMBER_ARGUMENTS, Constants.COMMAND_LOG_LEVEL));
                        break;
                    }
                    setLogLevel(tokens[1]);
                    break;
                case "help":
                    displayMessage(Constants.HELP_TEXT);
                    break;
                case "quit":
                    // the silent argument will prevent the CLI to output an error message
                    // if no connection is established right now
                    disconnect(client, true);
                    quit = true;
                    displayMessage("Exiting...");
                    break;
                default:
                    displayMessage(Constants.ERROR_UNKNOWN_COMMAND);
                    displayMessage(Constants.HELP_TEXT);
            }
        }
        LOGGER.info("Exiting CLI");
    }


    private static void connect(TelnetClient client, String address, int port) {
        try {
            // try to connect the client and display the connection response
            client.connect(address, port);
            LOGGER.info("connection successful");
            readMessage(client);
        } catch (Exception e) {
            // handle the various types of exceptions by presenting them in a meaningful way to the user
            LOGGER.throwing(TAG, "connect", e);
            if (e instanceof ReestablishConnectionException) {
                displayMessage(String.format(Constants.ERROR_RECONNECT, Constants.COMMAND_DISCONNECT));
            } else if (e instanceof UnknownHostException) {
                displayMessage(String.format(Constants.ERROR_UNKNOWN_HOST, address, port));
            } else if (e instanceof IllegalArgumentException) {
                displayMessage(Constants.ERROR_PORT_OUT_OF_RANGE);
            } else if (e instanceof SecurityException) {
                displayMessage(Constants.ERROR_OPERATION_PERMITTED);
            } else if (e instanceof SocketTimeoutException) {
                displayMessage(Constants.ERROR_SOCKET_TIMEOUT);
            } else {
                displayMessage(Constants.ERROR_I_O_EXCEPTION);
            }
        }
    }

    private static void readMessage(TelnetClient client) {
        try {
            // read message from the socked and display it
            String message = client.readMessage();
            LOGGER.info("Received message: " + message);
            displayMessage(message);
        } catch (Exception e) {
            // handle the various types of exceptions by presenting them in a meaningful way to the user
            LOGGER.throwing(TAG, "readMessage", e);
            if (e instanceof UnestablishedConnectionException) {
                displayMessage(String.format(Constants.ERROR_NO_CONNECTION, Constants.COMMAND_CONNECT));
            } else if (e instanceof SocketTimeoutException) {
                displayMessage(Constants.ERROR_SOCKET_TIMEOUT);
            } else {
                displayMessage(Constants.ERROR_I_O_EXCEPTION);
            }
        }
    }

    private static void sendMessage(TelnetClient client, String message) {
        try {
            // send a message and display the echo
            LOGGER.info("Sending message: " + message);
            client.writeMessage(message);
            readMessage(client);
        } catch (Exception e) {
            // handle the various types of exceptions by presenting them in a meaningful way to the user
            LOGGER.throwing(TAG, "sendMessage", e);
            if (e instanceof UnestablishedConnectionException) {
                displayMessage(String.format(Constants.ERROR_NO_CONNECTION, Constants.COMMAND_CONNECT));
            } else {
                displayMessage(Constants.ERROR_I_O_EXCEPTION);
            }
        }
    }

    private static void disconnect(TelnetClient client, boolean silent) {
        try {
            // disconnect the client
            client.disconnect();
            displayMessage(String.format("Connection terminated: /%s", client.toString()));
        } catch (Exception e) {
            // if the operation is silent,
            // eg: at program exit, dont show the UnestablishedConnectionException as the user might not be connected
            if (e instanceof UnestablishedConnectionException) {
                if (silent) {
                    return;
                }
                LOGGER.throwing(TAG, "disconnect", e);
                displayMessage(String.format(Constants.ERROR_NO_CONNECTION, Constants.COMMAND_CONNECT));
            } else {
                LOGGER.throwing(TAG, "disconnect", e);
                displayMessage(Constants.ERROR_I_O_EXCEPTION);
            }
        }
    }

    private static void setLogLevel(String level) {
        // check if the input is valid
        Level logLevel = null;
        if (Constants.LOG_LEVELS.containsKey(level)) {
            logLevel = Constants.LOG_LEVELS.get(level);
        }
        if (logLevel == null) {
            // no valid loglevel was provided
            LOGGER.warning("invalid log level");
            displayMessage(String.format(Constants.ERROR_INVALID_LOG_LEVEL, String.join(" | ", Constants.LOG_LEVELS.keySet())));
            return;
        }
        // change the current log level and retrieve the old one
        Level old = LogSetup.changeLogLevel(logLevel);
        displayMessage(String.format("Log-level set from %s to %s", old.getName(), logLevel.getName()));
    }

    private static void displayMessage(String message) {
        LOGGER.finest("OUTPUT: " + message);
        message = "EchoClient> " + message;
        System.out.println(message);
    }

    private static void displayPrompt() {
        String message = "EchoClient> ";
        System.out.print(message);
    }
}
