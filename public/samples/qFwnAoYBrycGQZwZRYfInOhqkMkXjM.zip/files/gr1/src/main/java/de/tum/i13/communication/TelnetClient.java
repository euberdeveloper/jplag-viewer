package de.tum.i13.communication;

import de.tum.i13.shared.Constants;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.Socket;
import java.net.SocketAddress;

/**
 * <h1>TelnetClient is the contract interface for telnet socket interaction.</h1>
 * This interface defines the needed methods to communicate with a telnet backend server.
 */
public interface TelnetClient {

    /**
     * Establishes a connection to the specified host and port utilizing socket connections.
     *
     * @param host      ip address or host name, if null connection to local loop back
     * @param port      desired port of the connection
     * @throws IOException                      exceptions thrown by initializing the {@link Socket}
     * @throws ReestablishConnectionException   exception indication the attempted reconnection
     *
     * @see Socket#Socket(String, int)
     * @see Socket#connect(SocketAddress, int)
     */
    void connect(String host, int port) throws IOException, ReestablishConnectionException;

    /**
     * Reads a message delimited by {@link Constants#MESSAGE_DELIMITER}
     * and parses it using the charset {@link Constants#TELNET_CHARSET}.
     *
     * @return      the message send by the server
     * @throws IOException                          exceptions thrown by reading from the {@link Socket}s input stream
     * @throws UnestablishedConnectionException     exception indication no connection was established prior to reading
     *
     * @see InputStream#read()
     */
    String readMessage() throws IOException, UnestablishedConnectionException;


    /**
     * Sends a message to the server.
     * Prior to sending the {@link Constants#MESSAGE_DELIMITER} gets appended and the message is
     * converted to an byte array using the charset {@link Constants#TELNET_CHARSET}.
     *
     * @param message       message send to the server
     * @throws UnestablishedConnectionException     exception indication no connection was established prior to writing
     * @throws IOException                          exceptions thrown by writing from the {@link Socket}s output stream
     *
     * @see OutputStream#write(byte[])
     */
    void writeMessage(String message) throws UnestablishedConnectionException, IOException;


    /**
     * Closed the socket connection and performs a clean up for further connection attempts.
     *
     * @throws UnestablishedConnectionException     exception indication no connection was established prior to disconnecting
     * @throws IOException                          exceptions thrown by {@link Socket#close()}
     *
     * @see Socket#close()
     */
    void disconnect() throws UnestablishedConnectionException, IOException;
}
