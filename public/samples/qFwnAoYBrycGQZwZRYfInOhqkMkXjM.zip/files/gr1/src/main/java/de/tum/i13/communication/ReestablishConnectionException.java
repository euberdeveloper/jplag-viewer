package de.tum.i13.communication;

import java.net.SocketException;

/**
 * <h1>Exception used to indicate an attempted reconnect on a already connected {@link java.net.Socket}.</h1>
 * This Exception should be used to notify the user to close the connection before attempting to reconnect.
 */
public class ReestablishConnectionException extends SocketException {
}
