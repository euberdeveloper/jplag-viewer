package de.tum.i13.client;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.net.Socket;
import java.net.UnknownHostException;
import java.util.logging.Level;
import java.util.logging.Logger;


public class Client {
	private static BufferedReader in = new BufferedReader(new InputStreamReader(System.in));
	static Logger log= Logger.getLogger(Client.class.getName());
	
	
	
	public static String readString() {
	    try {
	      return in.readLine();
	    } catch (IOException e) {
	      throw new Error(e);
	    }
	  }
	 public static String askString(String prompt) {
		    System.out.print(prompt);
		    return readString();
		  }
	 public static String ask(String prompt) {
		    return askString(prompt);
		  }

  public static void main(String[] args) throws UnknownHostException, IOException {
	  //variables
	  boolean exit= false;
	  int port = 0;
	  PrintWriter out = null;
	  InputStreamReader ins = null;
	  BufferedReader bf = null;
	  Socket socket = null;
	  String adress = null;
	  String command ="";
	  CommInterface communicate = new Communication( command , out , bf);
	  
	  
   try {
	  
	  while(!exit)
	  {
		  //the commando line on which we write the input
		  command = ask("EchoClient> ");
		  //splits the string into Table of Strings(words)
		  String[] tokens = command.trim().split("\\s");
		  communicate.setCommand(command);
		  communicate.setBf(bf);
		  communicate.setOut(out);
		  
		  //establishing the connection if we write for example 'connect clouddatabases.msrg.in.tum.de 5551'
		  if (tokens.length==3 && tokens[0].equals("connect") && socket==null)
	  		{ 
			  port= Integer.parseInt(tokens[2]);
			  adress = tokens[1];
			  try {
			  socket = new Socket(adress , port);
			  }catch (Exception e) {
				System.out.println("cannot connect to the given server");
			}
			  out = new PrintWriter(new OutputStreamWriter(socket.getOutputStream()));
			  
			  	//prints the server response	
			  	ins = new InputStreamReader(socket.getInputStream());
				bf = new BufferedReader(ins);
				
				String input= bf.readLine();
			  	System.out.println("EchoClient> " + input);
	     
	  		}
		  else if(tokens.length==3 && tokens[0].equals("connect") && socket!=null)
		  {
			  System.out.println("there is already an established connection with a server ");
		  }
    	
    	
		  else if(tokens!=null && socket!=null) {
    	 
		  // the help function which displays the function which the client can use
    	 
    	 if(tokens.length == 2 && tokens[0].equals("help"))
    	 {
    		 
    		 communicate.help();
    		 
    	 }
    	 
    	 //changing the loglevel
    	 else if (tokens.length >= 2 && tokens[0].equals("logLevel")) {
    		 
    		 communicate.logLevel();
             
    	 }
    	
    	//sending the message to the server
    	 else if(tokens.length>=2 && tokens[0].equals("send"))
    	 {
    		communicate.send();
    	 }
    	 
    	 //disconnecting from the server without exiting the programm
    	 else if(tokens.length==1 && tokens[0].equals("disconnect"))
    	 {
    		 System.out.println("connection terminated: " + socket.getInetAddress() + " / " + port);
    		 socket.close();
    		 socket = null;
    	 }
    	 
    	 //tearing down connection with the server and exit the programm
    	 else if (tokens.length==1 && tokens[0].equals("quit"))
      	{
    	  System.out.println("EchoClient> Application exit!");
    	  exit=true;
      	}
      	
      	
      	else {
      		
      		System.out.println("Help Syntax: <help> <command>\n" + "commands : <connect> , <send> , <disconnect> " +
						", <logLevel> , <quit>");
      	}
    }
     //notify the client that there is no connection with the server yet
     else if (tokens!=null && socket == null)
     {
    	 System.out.println("EchoClient> Error! Not connected!");
     }
    }
    
  } catch(Exception e)
   {
	  System.out.println("error occured");
	  out.close();
	  in.close();
	  socket.close();
   }
  
  }
}


