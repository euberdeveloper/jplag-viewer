package de.tum.i13.client;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.net.Socket;
import java.net.UnknownHostException;
import java.util.logging.Level;
import java.util.logging.Logger;
public class Communication implements CommInterface {

	
	private String command="";
	private PrintWriter out = null;
	private BufferedReader bf = null;
	static Logger log= Logger.getLogger(Client.class.getName());
	private String previous = "Nothing";
	
	public Communication(String command, PrintWriter out, BufferedReader bf) {
		
		this.command=command;
		this.bf=bf;
		this.out=out;
		

	}
	
	public String getPrevious() {
		return previous;
	}
	
	public void setPrevious(String previous) {
		this.previous = previous;
	}
	
	public BufferedReader getBf() {
		return bf;
	}
	
	public String getCommand() {
		return command;
	}
	
	public PrintWriter getOut() {
		return out;
	}
	
	
	@Override
	public void setBf(BufferedReader bf) {
		this.bf = bf;
	}
	
    @Override
	public void setCommand(String command) {
		this.command = command;
	}
	
    @Override
	public void setOut(PrintWriter out) {
		this.out = out;
	}
	
	public static Logger getLog() {
		return log;
	}
	
	public static void setLog(Logger log) {
		Communication.log = log;
	}
	
	 // the help function which displays the function which the client can use

	@Override
	public void help() {
		
		String[] tokens = command.trim().split("\\s");
		if (tokens[1].equals("send")) {
			
			System.out.println("Syntax: <send> <textmessage>\n" + "will send the given message to the"
		 			+ "currently connected echo server");
		}
	 
		else if(tokens[1].equals("disconnect"))
		{
			System.out.println("Syntax: <disconnect>\n" + "will disconnect from the connected server");
		}
	 
		else if(tokens[1].equals("logLevel"))
		{
			System.out.println("Syntax: <logLevel> <level>\n" + "will set the logger to the specified log level");
		}
	 
		else if(tokens[1].equals("quit"))
		{
			System.out.println("Syntax: <quit>\n" + "Tears down the active connection to the server"
				 			+" and exits the program");
		}
	 
		else if(tokens[1].equals("connect"))
		{
			System.out.println("Syntax: <connect> <adress> <port>\n" + "establish a connection to the echo server"
				 			+"based on the given server adress and the port number of the echo service");
		}
		else {
			System.out.println("Help Syntax: <help> <command>\n" + "commands : <connect> , <send> , <disconnect> " +
						", <logLevel> , <quit>");
		}
		
	}
	
	//the method which allows sending message to the server
	
	@Override
	public void send() throws IOException {

		String message = command.substring(5);
		out.println(message);
		out.flush();

		String input = bf.readLine();
		System.out.println("EchoClient> " + input);

	}

	
	 //changing the loglevel
	@Override
	public void logLevel() throws IOException {

		String levelMessage = command.substring(9);
		
        // levels
        if (levelMessage.equals("FINEST") || levelMessage.equals("FINER") || levelMessage.equals("FINE")
                || levelMessage.equals("CONFIG") || levelMessage.equals("INFO")
                || levelMessage.equals("WARNING") || levelMessage.equals("SEVERE")) {
            out.println(levelMessage);
            out.flush();
            String input = bf.readLine();
            if (levelMessage.equals("FINEST")) {
                log.setLevel(Level.FINEST);
            }
            if (levelMessage.equals("FINER")) {
                log.setLevel(Level.FINER);
            }
            if (levelMessage.equals("FINE")) {
                log.setLevel(Level.FINE);
            }
            if (levelMessage.equals("CONFIG")) {
                log.setLevel(Level.CONFIG);
            }
            if (levelMessage.equals("INFO")) {
                log.setLevel(Level.INFO);
            }
            if (levelMessage.equals("WARNING")) {
                log.setLevel(Level.WARNING);
            }
            if (levelMessage.equals("SEVERE")) {
           	 
                log.setLevel(Level.SEVERE);
            }
            	System.out.println("EchoClient> loglevel set from " + previous + " to " + input);
            	setPrevious(input);
            
            
        } else {
            System.out.println(
                    "Syntax: <connect> <adress> <port>\n" + "establish a connection to the echo server"
                            + "based on the given server adress and the port number of the echo service");
        }
		
	}

}
