package de.tum.i13.client;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.PrintWriter;

public interface CommInterface {
	
	
	public void send() throws IOException;
	
	public void help();
	
	public void logLevel() throws IOException;
	
	public void setBf(BufferedReader bf);
	public void setCommand(String command);
	public void setOut(PrintWriter out);
	

}
