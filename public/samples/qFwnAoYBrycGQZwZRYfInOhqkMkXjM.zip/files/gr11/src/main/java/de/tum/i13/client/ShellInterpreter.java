package de.tum.i13.client;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Arrays;
import java.util.Comparator;
import java.util.Map;
import java.util.NoSuchElementException;
import java.util.logging.Logger;

import de.tum.i13.client.commands.*;

/**
 * Handles user input and interpretes as commands, as well as prints 
 * @author Christoph Poeppelbaum
 *
 */
public class ShellInterpreter
{
	private static final Logger _logger = Logger.getLogger(ShellInterpreter.class.getName());
	private static final String Prompt = "EchoClient> ";
	private static boolean _requestShutdown = false;
	
	private CommandFactory _commandFactory;
	

	public ShellInterpreter(CommandFactory commandFactory)
	{
		_commandFactory = commandFactory;
		
		//adding commands which functionally belong to the ShellInterpreter itself
		_commandFactory.addCommand(new HelpCommand(this));
		_commandFactory.addCommand(new QuitCommand(this));
	}

	/**
	 * runs till user quits or the stop method is called
	 * @throws IOException exception from BufferedReader.ReadLine
	 */
	public void run() throws IOException
	{
		_logger.info("shellinterpreter startet");
		
		BufferedReader input;
		input = new BufferedReader(new InputStreamReader(System.in));

		while (!_requestShutdown)
		{
			try
			{
				String[] tokens = readConsoleLine(input);
				ICommand command = _commandFactory.getCommand(tokens[0]);
				String[] commandArgs = new String[tokens.length - 1];
				System.arraycopy(tokens, 1, commandArgs, 0, commandArgs.length);
				
				String response = command.execute(commandArgs);
				if(response != null)
				{
					writeConsoleLine(response);
				}
			}
			catch(NoSuchElementException ex) //no command with this name was found, so print help text
			{
				writeConsoleLine(ex.getMessage());
				writeConsoleLine(help());
			}
			catch(ApplicationRuntimeException ex)
			{
				writeConsoleLine("error: " + ex.getMessage());
				
				_logger.warning(ex.getMessage());
			}
		}
	}
	
	private void writeConsoleLine(String message)
	{
		String line = Prompt + message;
		_logger.fine(line);
		System.out.println(line);
	}

	private String[] readConsoleLine(BufferedReader input) throws IOException
	{
		System.out.print(Prompt);
		String line = input.readLine();
		_logger.fine(Prompt + line);
		return line.trim().split("\\s+");
	}
	
	
	/**
	 * Stops the blocking executing of the shell interpreter
	 */
	public void stop()
	{
		_requestShutdown = true;
		
		_logger.info("shellinterpreter stopped");
	}
	
	/*
	 * @return text for help command
	 */
	public String help()
	{
		String helptext =  "\n========== Help ==========\n";
		
		ICommand[] commands= _commandFactory.getAvailableCommands();
		Arrays.sort(commands, new Comparator<ICommand>()
		{
			@Override
			public int compare(ICommand o1, ICommand o2)
			{
				return String.CASE_INSENSITIVE_ORDER.compare(o1.getCommandName(), o2.getCommandName());
			}
		});
		
		for (ICommand command : commands)  
		{
			helptext += command.getCommandName() + " - " + command.getDescription() + "\n";
			if(command.getArguments()!= null) {
				for (Map.Entry<String,String> argument : command.getArguments().entrySet()) {
					helptext+= "\t" + argument.getKey() + " - " + argument.getValue() + "\n";
				}
			}
		}
		helptext += "=========================";
		
		_logger.info("showing helptext");
		
		return helptext;
	}
}
