package de.tum.i13.client;

import java.util.logging.Logger;

import org.apache.commons.lang3.exception.ExceptionUtils;

import de.tum.i13.client.commands.*;
import de.tum.i13.client.connection.ConnectionManager;
import static de.tum.i13.shared.LogSetup.setupLogging;

public class TestClient
{

	private final static Logger _logger = Logger.getLogger(TestClient.class.getName());

	/**
	 * Entry point of the application
	 * 
	 * @param args Console arguments (ignored atm)
	 */
	public static void main(String[] args)
	{
		setupLogging("test.log");

		_logger.info("starting application");

		CommandFactory commandFactory = new CommandFactory();
		ConnectionManager connectionManager = new ConnectionManager();
		
		commandFactory.addCommand(new ConnectToSocketCommand(connectionManager));
		commandFactory.addCommand(new DisconnectCommand(connectionManager));
		commandFactory.addCommand(new SendCommand(connectionManager));
		commandFactory.addCommand(new LogLevelCommand(_logger));

		ShellInterpreter shellInterpreter = new ShellInterpreter(commandFactory);

		try
		{
			shellInterpreter.run(); // blocks till user quits or fatal error

			if (connectionManager.isConnected())
			{
				connectionManager.disconnect();
			}
		}
		catch (Throwable ex) // any fatal error shall be logged
		{
			_logger.severe(ExceptionUtils.getStackTrace(ex));
		}

		_logger.info("application was terminated");
	}
}
