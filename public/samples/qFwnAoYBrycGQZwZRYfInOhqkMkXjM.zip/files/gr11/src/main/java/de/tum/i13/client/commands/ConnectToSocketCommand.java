package de.tum.i13.client.commands;

import java.util.Map;

import de.tum.i13.client.connection.ConnectionManager;
import de.tum.i13.client.connection.SocketConnection;
import de.tum.i13.client.ApplicationRuntimeException;

/**
 * Command to connect to a socket via address and port
 * @author Christoph Poeppelbaum
 *
 */
public class ConnectToSocketCommand extends CommandBase
{
	private Map<String, String> _arguments;
	private ConnectionManager _context;
	
	public ConnectToSocketCommand(ConnectionManager context)
	{
		_context = context;
		
		_arguments = Map.of(
				"address", "Hostname or IP address of the echo server.",
				"port", "The port of the echo service on the respective server."
				);
	}

	@Override
	public String getCommandName()
	{
		return "connect";
	}
	
	@Override
	public String getDescription() 
	{
		return "Tries to establish a connection to the server based on the given address of the echo server and the port number";
	}
	
	@Override
	public Map<String, String> getArguments()
	{
		return _arguments;
	}

	@Override
	protected String executeWithCheckedCountOfArgs(String[] args) throws ApplicationRuntimeException
	{
		String address = args[0];
		int port;
		
		try
		{
			port = Integer.parseInt(args[1]);
		}
		catch(NumberFormatException ex)
		{
			throw new ApplicationRuntimeException("argument 'port' has to be a number");
		}
		
		SocketConnection socketConnection = new SocketConnection(address, port);

		return _context.connect(socketConnection);
	}

}
