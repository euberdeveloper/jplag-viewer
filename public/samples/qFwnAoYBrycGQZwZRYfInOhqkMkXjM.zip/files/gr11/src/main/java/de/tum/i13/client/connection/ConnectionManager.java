package de.tum.i13.client.connection;

import java.util.logging.Logger;

import de.tum.i13.client.ApplicationRuntimeException;

/**
 * High level connection handler. This enforces basic checks
 * and provides a convenient methods for sending and receiving Strings
 * @author Christoph Poeppelbaum
 *
 */
public class ConnectionManager implements IConnectionManager
{
	private static final Logger _logger = Logger.getLogger(ConnectionManager.class.getName());
	private IConnection _connection;
	private boolean _connected;
	
	@Override
	public String connect(IConnection connection) throws ApplicationRuntimeException
	{
		if(_connected)
		{
			
			throw new ApplicationRuntimeException("Already connected");
		}
		
		_connection = connection;
		
		_connection.open();
		
		_connected = true;
		
		byte[] buffer = _connection.receive();
		
		_logger.info("Server Welcoming message received.");
		
		String serverwelcome = unmarshall(buffer);
		
		return serverwelcome;
	}

	@Override
	public void disconnect() throws ApplicationRuntimeException
	{
		if(!_connected)
		{
			
			throw new ApplicationRuntimeException("Not connected");
		}
		
		_connection.close();
		_connected = false;
		
		_logger.info("Disconnected.");
		
		System.out.println(String.format("EchoClient> Disconnected from Server"));
	}
	
	
	@Override
	public String send(String message) throws ApplicationRuntimeException
	{
		if(!_connected)
		{
			
			throw new ApplicationRuntimeException("Sending not possible without connection.");
		}
		
		message = message + "\r\n";
		byte [] messageByte = message.getBytes();
		
		_connection.send(messageByte);
		
		_logger.info("Message sent.");
		
		byte[] answer = _connection.receive();
		
		_logger.info("Answer received.");
		
		String answerString = unmarshall(answer);
		
		return answerString;
		
	}
	
	/** 
	 * Converts a byte array to a String
	 * @param message Byte Array that contains message
	 * @return message converted from byte array to a String
	 */
	private String unmarshall(byte[] message) {
		
		String answerString = "";
		char x;
		
		for(int i = 0; i < message.length; i++) {
			x = (char) message[i];
			answerString = answerString + x;
		}
		
		_logger.info("Message converted from byte array to String.");
		
		return answerString;
	}

	@Override
	public boolean isConnected()
	{
		return _connected;
	}

}
