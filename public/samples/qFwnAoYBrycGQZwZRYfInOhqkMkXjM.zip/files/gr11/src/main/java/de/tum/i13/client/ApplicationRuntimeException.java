package de.tum.i13.client;

/**
 * Our custom Exception class which represents non fatal user input errors
 * @author Christoph Poeppelbaum
 *
 */
public class ApplicationRuntimeException extends Exception
{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public ApplicationRuntimeException(String message)
	{
		super(message);
	}
}
