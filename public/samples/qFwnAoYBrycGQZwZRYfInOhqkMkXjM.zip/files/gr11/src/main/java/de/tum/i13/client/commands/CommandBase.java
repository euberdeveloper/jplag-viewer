package de.tum.i13.client.commands;

import java.util.logging.Logger;

import de.tum.i13.client.ApplicationRuntimeException;

/**
 * Command base class which checks count of arguments and will throw ApplicationRuntimeException if check failed.
 * Also provides a context for any inheriting command to to something with.
 * @author Christoph Poeppelbaum
 *
 */
public abstract class CommandBase implements ICommand
{
	private static final Logger _logger = Logger.getLogger(CommandBase.class.getName());
	
	/**
	 * Checks count of arguments and throws ApplicationRuntimeException if wrong number of arguments
	 * @param args Contract: args is never null
	 * @throws ApplicationRuntimeException if wrong number of arguments
	 */
	@Override
	public String execute(String[] args) throws ApplicationRuntimeException
	{
		_logger.info(String.format("Command '%s' called with parameters '%s'.", getCommandName(), String.join(", ", args)));
		
		//enforce contracts
		assert args != null; //empty arguments are represented by array of size 0
		assert getArguments() == null || getArguments().size() != 0; //if no arguments needed, return value has to be null. Else may not be of size 0.
				
		if (getArguments() == null && args.length != 0)
		{
			throw new ApplicationRuntimeException(String.format("Too many arguments. None needed"));
		}
		
		if (getArguments() != null && //true if parameters are required by this command
				(args == null || args.length != getArguments().size())) //if required, check if any args are given and assert count
		{
			throw new ApplicationRuntimeException(String.format("Wrong number of arguments. These are needed: %s",
					String.join(", ", getArguments().keySet())));
		}
		
		return executeWithCheckedCountOfArgs(args);
	}
	
	/**
	 * When this method is called the arguments are checked. Now actually call the implementation of the inheriting class.
	 * @param args checked arguments
	 * @return Success response message
	 * @throws ApplicationRuntimeException
	 */
	abstract protected String executeWithCheckedCountOfArgs(String[] args) throws ApplicationRuntimeException;
}
