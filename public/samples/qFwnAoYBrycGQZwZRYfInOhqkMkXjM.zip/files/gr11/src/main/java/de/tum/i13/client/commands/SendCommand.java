package de.tum.i13.client.commands;

import java.util.Map;

import de.tum.i13.client.ApplicationRuntimeException;
import de.tum.i13.client.connection.ConnectionManager;

/**
 * Command to send a message to the server
 * @author Wen Qing Wei
 *
 */
public class SendCommand extends CommandBase
{
	private ConnectionManager _context;
	private Map<String, String> _arguments;

	public SendCommand(ConnectionManager context) 
	{
		_context = context;
		_arguments = Map.of("message","text message that will be sent to the server");
	}

	@Override
	public String getCommandName() 
	{
		return "send";
	}

	@Override
	public String getDescription() 
	{
		return "Sending a text message to the echo server according to the communication protocol";
	}

	@Override
	public Map<String, String> getArguments() 
	{
		return _arguments;
	}

	@Override
	protected String executeWithCheckedCountOfArgs(String[] args) throws ApplicationRuntimeException 
	{
		return _context.send(args[0]);
	}

}
