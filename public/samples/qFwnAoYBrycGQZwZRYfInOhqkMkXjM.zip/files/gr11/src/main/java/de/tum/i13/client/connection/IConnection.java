package de.tum.i13.client.connection;

import de.tum.i13.client.ApplicationRuntimeException;

/**
 * Low level connection handler
 * @author Christoph Poeppelbaum
 *
 */
public interface IConnection
{
	/**
	 * Initializes the connection for sending and receiving
	 * @throws ApplicationRuntimeException If the connection could not be opened for any reason
	 */
	void open() throws ApplicationRuntimeException;
	
	/**
	 * Tears down the connection
	 * @throws ApplicationRuntimeException If the connection could not be closed for any reason
	 */
	void close() throws ApplicationRuntimeException;
	
	/**
	 * Sends a message through the connection
	 * @param message Byte representation to send
	 * @throws ApplicationRuntimeException If the message was not send successful
	 */
	void send(byte[] message) throws ApplicationRuntimeException;
	
	/**
	 * Receives a message from the connection
	 * @return Byte representation of message received
	 * @throws ApplicationRuntimeException If there was an error while receiving
	 */
	byte[] receive() throws ApplicationRuntimeException;
}
