package de.tum.i13.client.connection;

import de.tum.i13.client.ApplicationRuntimeException;

/**
 * High level connection handler. This enforces basic checks
 * and provides a convenient methods for sending and receiving Strings
 * @author Christoph Poeppelbaum
 *
 */
public interface IConnectionManager
{
	/**
	 * Here we can inject any class, handling a connection, even a stub for unit testing
	 * @param connection A low level connection handler
	 * @return welcome message from server
	 * @throws ApplicationRuntimeException when already a connection is open
	 */
	String connect(IConnection connection) throws ApplicationRuntimeException;
	
	/**
	 * Indicates if a connection is open
	 * @return true if connection is open
	 */
	boolean isConnected();

	/**
	 * Tears down the connection
	 * @throws ApplicationRuntimeException when no connection is open
	 */
	void disconnect() throws ApplicationRuntimeException;

	/**
	 * Sends a message through the connection
	 * @param message Message to send
	 * @return The reply from connection end point
	 * @throws ApplicationRuntimeException when no connection is open or IO exception
	 */
	String send(String message) throws ApplicationRuntimeException;
}
