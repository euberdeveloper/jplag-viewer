package de.tum.i13.client;

import java.util.HashMap;
import java.util.Map;
import java.util.NoSuchElementException;

import de.tum.i13.client.commands.ICommand;

/**
 * Stores all available commands and either returns all available
 * or one corresponding by a string (or throws ApplicationRuntimeException if not found).
 * @author Christoph Poeppelbaum
 *
 */
public class CommandFactory
{
	private Map<String, ICommand> _availableCommands;

	public CommandFactory()
	{
		_availableCommands = new HashMap<String, ICommand>();
	}

	/**
	 * Add a command which will then be found by the getCommand method or getAvailableCommands
	 * @param command Command to store
	 */
	public void addCommand(ICommand command)
	{
		_availableCommands.put(command.getCommandName().toLowerCase(), command);
	}
	
	/**
	 * Retrieve list of all available (previously stored) commands
	 * @return list of all available commands
	 */
	public ICommand[] getAvailableCommands()
	{
		return _availableCommands.values().toArray(new ICommand[0]);
	}
	
	/**
	 * Get specified command by name
	 * @param name Name to search for within available commands
	 * @return Specified command
	 * @throws ApplicationRuntimeException If command was not found
	 */
	public ICommand getCommand(String name) throws ApplicationRuntimeException
	{
		if (_availableCommands.containsKey(name.toLowerCase()))
		{
			return _availableCommands.get(name.toLowerCase());
		}
		else
		{
			throw new NoSuchElementException(String.format("command '%s' not found", name));
		}
	}
}
