package de.tum.i13.client.commands;

import java.util.Map;

import de.tum.i13.client.ApplicationRuntimeException;

/**
 * Minimal interface for a command which can be executed via command line
 * @author Christoph Poeppelbaum
 *
 */
public interface ICommand
{
	/**
	 * The name by which this command may be found
	 * @return name of this command
	 */
	String getCommandName();
	
	/**
	 * This executes a specified method.
	 * @param args Needed arguments for the method this command is calling.
	 * @return Response message or null
	 * @throws ApplicationRuntimeException If arguments are not sufficient or thrown by the method this command is calling.
	 */
	String execute(String[] args) throws ApplicationRuntimeException;
	
	/**
	 * Description of the given command
	 * @return description of the command
	 */
	
	String getDescription();
	
	/**
	 * A list of parameter names this command needs. These names are for printing or logging purposes.
	 * The size of this list also determines how many arguments are needed. Contract: Returns null if no argument needed.
	 * @return pairs of parameter name and helpText 
	 */
	Map<String, String> getArguments();
}
