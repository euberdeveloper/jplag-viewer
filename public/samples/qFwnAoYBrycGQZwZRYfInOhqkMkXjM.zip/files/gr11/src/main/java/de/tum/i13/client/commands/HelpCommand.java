package de.tum.i13.client.commands;

import java.util.Map;

import de.tum.i13.client.ApplicationRuntimeException;
import de.tum.i13.client.ShellInterpreter;

/**
 * Command to print the help text
 * @author Christoph Poeppelbaum
 *
 */
public class HelpCommand extends CommandBase
{
	private ShellInterpreter _context;
	
	public HelpCommand(ShellInterpreter context)
	{
		_context = context;
	}
	
	@Override
	public String getDescription() 
	{
		return "Shows this text";
	}

	@Override
	public Map<String, String> getArguments()
	{
		return null; //no arguments needed
	}

	@Override
	public String getCommandName()
	{
		return "help";
	}
	
	@Override
	protected String executeWithCheckedCountOfArgs(String[] args) throws ApplicationRuntimeException
	{
		return _context.help();
	}

}
