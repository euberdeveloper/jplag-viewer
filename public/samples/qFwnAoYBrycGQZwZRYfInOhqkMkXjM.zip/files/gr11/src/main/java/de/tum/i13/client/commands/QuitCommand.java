package de.tum.i13.client.commands;

import java.util.Map;

import de.tum.i13.client.ApplicationRuntimeException;
import de.tum.i13.client.ShellInterpreter;

/**
 * Command to quit the program
 * @author Christoph Poeppelbaum
 *
 */
public class QuitCommand extends CommandBase
{
	private ShellInterpreter _context;
	
	public QuitCommand(ShellInterpreter context)
	{
		_context = context;
	}

	@Override
	public String getCommandName()
	{
		return "quit";
	}
	
	@Override
	public String getDescription() 
	{
		return "Tears down the active connection to the server and exits the program execution";
	}
	
	@Override
	public Map<String, String> getArguments()
	{
		return null; //no arguments needed
	}

	@Override
	protected String executeWithCheckedCountOfArgs(String[] args) throws ApplicationRuntimeException
	{
		_context.stop();
		return "invoking shutdown";
	}

}
