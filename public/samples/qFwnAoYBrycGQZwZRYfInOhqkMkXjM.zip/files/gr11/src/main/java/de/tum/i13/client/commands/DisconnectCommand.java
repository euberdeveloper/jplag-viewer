package de.tum.i13.client.commands;

import java.util.Map;

import de.tum.i13.client.ApplicationRuntimeException;
import de.tum.i13.client.connection.ConnectionManager;

/**
 * Command to disconnect the client from the server
 * @author Wen Qing Wei
 *
 */
public class DisconnectCommand extends CommandBase
{
	private ConnectionManager _context;
	
	public DisconnectCommand(ConnectionManager context) 
	{
		_context = context;
	}

	@Override
	public String getCommandName() 
	{
		return "disconnect";
	}

	@Override
	public String getDescription() 
	{
		return "Trying to disconnect from the server";
	}

	@Override
	public Map<String, String> getArguments() 
	{
		return null; //no arguments for this command needed
	}

	@Override
	protected String executeWithCheckedCountOfArgs(String[] args) throws ApplicationRuntimeException 
	{
		 _context.disconnect();
		 
		 return null;
	}
	

}
