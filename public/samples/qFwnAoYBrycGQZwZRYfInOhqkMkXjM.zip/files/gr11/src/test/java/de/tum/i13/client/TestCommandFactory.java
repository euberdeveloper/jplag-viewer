package de.tum.i13.client;

import org.junit.jupiter.api.*;

import static org.junit.jupiter.api.Assertions.*;

import de.tum.i13.client.commands.*;

import java.util.Map;
import java.util.NoSuchElementException;

public class TestCommandFactory
{
	private CommandFactory _sut;

	private class TestCommand extends CommandBase
	{
		@Override
		public String getCommandName()
		{
			return "TestCommand";
		}

		@Override
		public String getDescription()
		{
			return "TestDescription";
		}

		@Override
		public Map<String, String> getArguments()
		{
			return null;
		}

		@Override
		protected String executeWithCheckedCountOfArgs(String[] args) throws ApplicationRuntimeException
		{
			return null;
		}

	}

	@BeforeEach
	public void initialize()
	{
		_sut = new CommandFactory();
		_sut.addCommand(new TestCommand());
	}

	@AfterEach
	public void teardown()
	{

	}

	@Test
	public void CommandFactory_RequestingUnknownCommand_ThrowsException()
	{
		Exception exception = assertThrows(NoSuchElementException.class, () -> {
			_sut.getCommand("fubar");
		});

		String actualMessage = exception.getMessage();

		assertTrue(actualMessage.contains("command"));
		assertTrue(actualMessage.contains("not found"));
	}

	@Test
    public void CommandFactory_RequestingKnownCommand_RetrievesCommand() throws ApplicationRuntimeException
    {
		ICommand command = _sut.getCommand("TestCommand");
		assertTrue(command instanceof TestCommand);
    }
	
	@Test
    public void CommandFactory_RequestingKnownCommandWithWrongLowerCasing_RetrievesCommand() throws ApplicationRuntimeException
    {
		ICommand command = _sut.getCommand("testcommand");
		assertTrue(command instanceof TestCommand);
    }
}
