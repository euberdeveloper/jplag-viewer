package de.tum.i13.shared;

/**
 * Class for shared constant values.
 * 
 * @author Gruppe 17
 *
 *         10.11.2020
 *
 */
public class Constants {
	/**
	 * Encoding for telnet.
	 */
	public static final String TELNET_ENCODING = "ISO-8859-1";

	/**
	 * Commands the user can issue.
	 */
	public static final String QUIT_COMMAND = "quit";
	public static final String CONNECT_COMMAND = "connect";
	public static final String DISCONNECT_COMMAND = "disconnect";
	public static final String SEND_COMMAND = "send";
	public static final String HELP_COMMAND = "help";
	public static final String LOGLEVEL_COMMAND = "logLevel";
}
