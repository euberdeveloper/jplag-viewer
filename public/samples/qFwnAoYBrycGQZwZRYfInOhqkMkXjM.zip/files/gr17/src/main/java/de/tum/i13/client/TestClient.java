package de.tum.i13.client;

import static de.tum.i13.shared.LogSetup.setupLogging;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.util.logging.Handler;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 * The Main class that starts the application.
 * 
 * @author Marc Engelmann
 *
 *         08.11.2020
 *
 */
public class TestClient {

	private final static Logger LOGGER = Logger.getLogger(TestClient.class.getName());

	/**
	 * The BufferedReader used to read the user input from the command line.
	 */
	private static BufferedReader scanner = new BufferedReader(new InputStreamReader(System.in));

	/**
	 * The main method contains the main loop. Any uncaught exceptions will be
	 * logged here.
	 * <P>
	 * 10.11.2020
	 *
	 * @param args
	 *        the parameters passed when starting the application over the command
	 *        line. Currently, any argument will be ignored.
	 */
	public static void main(String[] args) {
		setupLogging("test.log");
		try {
			while (Application.isRunning()) {
				System.out.print(Application.BASE);
				String command = scanner.readLine();
				Application.executeCommand(command);
			}
		} catch (Exception e) {
			LOGGER.log(Level.SEVERE, String.format("Uncaught Exception! %s from %s", e.toString(), e.getCause()));
		} finally {
			for (Handler h : LOGGER.getHandlers()) {
				h.close();
			}
		}
	}
}
