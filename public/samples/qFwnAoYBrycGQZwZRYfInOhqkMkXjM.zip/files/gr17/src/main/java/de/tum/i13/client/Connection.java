package de.tum.i13.client;

import java.io.IOException;

/**
 * Client side interface for communicating with a server.
 */
public interface Connection {

	/**
	 * Connects to the specified host and port.
	 * <P>
	 * 06.11.2020
	 *
	 * @param host
	 *        destination host name or IP address
	 * @param port
	 *        destination port number
	 * @throws IOException
	 *         in case of an error during the connection process
	 */
	public void connect(String host, int port) throws IOException;

	/**
	 * Disconnects from the currently connected host.
	 * <P>
	 * 06.11.2020
	 *
	 * @throws IOException
	 *         in case of an error during disconnecting from the host
	 */
	public void disconnect() throws IOException;

	/**
	 * Returns the host name of the current connection.
	 * <P>
	 * 07.11.2020
	 *
	 * @return the host name
	 */
	public String getHost();

	/**
	 * Returns the port number of the current connection.
	 * <P>
	 * 07.11.2020
	 *
	 * @return the port number
	 */
	public int getPort();

	/**
	 * Receives an unspecified amount of bytes from the server.
	 * <P>
	 * 06.11.2020
	 *
	 * @return the received bytes.
	 * @throws IOException
	 *         in case of an Error during receiving the message
	 */
	public byte[] receive() throws IOException;

	/**
	 * Sends the specified message to the currently connected socket.
	 * <P>
	 * 06.11.2020
	 *
	 * @param msg
	 *        the message to be sent
	 * @throws IOException
	 *         in case of an Error during sending of the message
	 */
	public void send(byte[] msg) throws IOException;

}
