package de.tum.i13.client;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.Socket;

/**
 * The object responsible for the communication with the server.
 * 
 * @author Gruppe 17
 *
 *         09.11.2020
 *
 */
public class ConnectionManager implements Connection {

	/**
	 * The maximum number of bytes that can be received at once.
	 */
	private static final int MAX_BUFFER_SIZE = 128000;

	/**
	 * The socket used to connect to the specified Server.
	 */
	private Socket socket;

	/**
	 * The input stream from which to read.
	 */
	private InputStream in;

	/**
	 * The output stream to write to.
	 */
	private OutputStream out;

	@Override
	public void connect(String host, int port) throws IOException {
		socket = new Socket(host, port);
		in = socket.getInputStream();
		out = socket.getOutputStream();
	}

	@Override
	public void disconnect() throws IOException {
		if (in != null) {
			in.close();
		}
		if (out != null) {
			out.close();
		}
		if (socket != null) {
			socket.close();
		}
	}

	@Override
	public String getHost() {
		if (socket == null) {
			return null;
		}
		return socket.getInetAddress().toString();
	}

	@Override
	public int getPort() {
		if (socket == null) {
			return -1;
		}
		return socket.getPort();
	}

	@Override
	public byte[] receive() throws IOException {
		byte[] buff = new byte[MAX_BUFFER_SIZE];
		int numBytes = in.read(buff);
		if (numBytes == -1) {
			return null;
		}
		byte[] result = new byte[numBytes];
		for (int i = 0; i < numBytes; i++) {
			result[i] = buff[i];
		}
		return result;
	}

	@Override
	public void send(byte[] msg) throws IOException {
		if (out != null) {
			out.write(msg);
			out.flush();
		}
	}
}
