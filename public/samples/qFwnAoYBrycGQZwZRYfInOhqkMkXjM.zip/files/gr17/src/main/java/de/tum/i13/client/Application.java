package de.tum.i13.client;

import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.util.logging.Level;
import java.util.logging.Logger;

import de.tum.i13.shared.Constants;

/**
 * The application logic is implemented in this class. It uses an object of a
 * class that implements the Connection-Interface (here: ConnectionManager.java)
 * for communication with a server.
 * 
 * @author Gruppe 17
 *
 *         08.11.2020
 *
 */
public class Application {

	/**
	 * The string that precedes any line in the console.
	 */
	public static final String BASE = "EchoClient> ";

	/**
	 * The Connection Object used to communicate with the Server.
	 */
	private static Connection conn = null;

	/**
	 * The Logger object is declared here again for ease of access.
	 */
	private final static Logger LOGGER = Logger.getLogger(TestClient.class.getName());
	/**
	 * Flag whether the application is currently running or not.
	 */
	private static boolean isRunning = true;

	/**
	 * This method is executed when the logLevel command is issued. If the user
	 * inputs an invalid log level he will be notified and the log level doesn't
	 * change.
	 * <P>
	 * 07.11.2020
	 *
	 * @param tokens
	 *        the tokenized input from the user (including both the command and the
	 *        arguments)
	 */
	private static void adjustLogLevel(String[] tokens) {
		if (tokens.length != 2) {
			invalidInput(String.format(" for %s, incorrect number of arguments. Expected 1 but got %d",
					Constants.LOGLEVEL_COMMAND, tokens.length - 1), tokens);
			return;
		}
		try {
			Level previous = LOGGER.getLevel();
			// In case of receiving the log level failing, the parent logger is checked and
			// if still no log level can be determined, it is assumed the level was
			// Level.ALL
			if (previous == null) {
				previous = LOGGER.getParent().getLevel();
			}
			if (previous == null) {
				previous = Level.ALL;
			}
			LOGGER.setLevel(Level.parse(tokens[1]));
			String output = String.format("Log level set from %s to %s", previous.toString(), tokens[1]);
			LOGGER.info(output);
			printToConsole(output);
		} catch (IllegalArgumentException e) {
			invalidInput(String.format(" for %s, argument %s is invalid", Constants.LOGLEVEL_COMMAND, tokens[1]),
					tokens);
		}
	}

	/**
	 * This method splits the input read from the command line into tokens and
	 * checks if the first token is a valid command. If yes, it passes the entire
	 * input to the respective method where error handling concerning the rest of
	 * the input is performed.
	 * <P>
	 * 06.11.2020
	 *
	 * @param command
	 *        the input from the user (including both the command and the arguments)
	 */
	public static void executeCommand(String command) {
		// Skip blank input lines (common CLI feature)
		if (command.isBlank()) {
			return;
		}
		// Remove unnecessary spaces
		String[] tokens = sanitize(command.split(" "));
		switch (tokens[0]) {
		case Constants.CONNECT_COMMAND:
			executeConnect(tokens);
			break;
		case Constants.DISCONNECT_COMMAND:
			executeDisconnect(tokens);
			break;
		case Constants.SEND_COMMAND:
			executeSend(command);
			break;
		case Constants.HELP_COMMAND:
			printHelp(tokens);
			break;
		case Constants.LOGLEVEL_COMMAND:
			adjustLogLevel(tokens);
			break;
		case Constants.QUIT_COMMAND:
			quit();
			break;
		default:
			printToConsole("Error! Unknown command: " + String.join(" ", tokens));
			printHelp();
		}
	}

	/**
	 * This method is executed when the connect command is issued. If an established
	 * connection already exists, it is terminated automatically before the new one
	 * is established.
	 * <P>
	 * 07.11.2020
	 *
	 * @param tokens
	 *        the tokenized input from the user (including both the command and the
	 *        arguments)
	 */
	private static void executeConnect(String[] tokens) {
		if (tokens.length != 3) {
			invalidInput(String.format(" for %s, incorrect number of arguments. Expected 2 but got %d",
					Constants.CONNECT_COMMAND, tokens.length - 1), tokens);
			return;
		}
		if (conn != null) {
			executeDisconnect();
		}
		try {
			int port = Integer.parseInt(tokens[2]);
			conn = new ConnectionManager();
			conn.connect(tokens[1], port);
			byte[] answer = conn.receive();

			if (answer == null) {
				throw new IOException(String.format("No answer received from %s:%s", tokens[1], tokens[2]));
			}

			String recvMsg = new String(answer, Constants.TELNET_ENCODING).stripTrailing();
			LOGGER.info(String.format("Connection established to %s:%s; received message %s", tokens[1], tokens[2],
					recvMsg));
			printToConsole(recvMsg);
		} catch (NumberFormatException e) {
			invalidInput(String.format(" for %s, portnumber %s is invalid", Constants.CONNECT_COMMAND, tokens[2]),
					tokens);
			conn = null;
		} catch (IOException e) {
			String output = String.format("Error! Unable to connect to %s:%s", tokens[1], tokens[2]);
			LOGGER.warning(output + "; " + e.toString());
			printToConsole(output);
			conn = null;
		}
	}

	/**
	 * As other methods need the disconnect method as well, this method simulates a
	 * valid execution of the disconnect command from the user. This eliminates the
	 * need of adding the confusing argument, which consists of an array with just
	 * one element, where the disconnect method is called internally.
	 * <P>
	 * 08.11.2020
	 *
	 */
	private static void executeDisconnect() {
		executeDisconnect(new String[] { Constants.DISCONNECT_COMMAND });
	}

	/**
	 * This method is executed when the disconnect command is issued. If there is no
	 * current connection to terminate the user gets notified.
	 * <P>
	 * 07.11.2020
	 *
	 * @param tokens
	 *        the tokenized input from the user (including both the command and the
	 *        arguments)
	 */
	private static void executeDisconnect(String[] tokens) {
		if (tokens.length != 1) {
			invalidInput(String.format(" for %s, incorrect number of arguments. Expected 0 but got %d",
					Constants.DISCONNECT_COMMAND, tokens.length - 1), tokens);
			return;
		}
		if (conn == null) {
			LOGGER.warning("Tried to disconnect, but no connection was established beforehand.");
			printToConsole("No established connection to terminate.");
			return;
		}

		try {
			conn.disconnect();
		} catch (IOException e) {
			String output = "Error during disconnect";
			LOGGER.warning(output + "; " + e.toString());
			printToConsole(output);
			return;
		}
		// For consistency, the format for the server stays host:port, unlike the
		// example in the assignment (host / port)
		String output = String.format("Connection terminated %s:%d", conn.getHost(), conn.getPort());
		LOGGER.info(output);
		printToConsole(output);

		conn = null;
	}

	/**
	 * This method is executed when the send command is issued. It sends the
	 * specified message to the currently connected server and waits for a reply. If
	 * no connection is established or the sending or the receiving of the message
	 * fails, the user is notified. The message is defined as everything after
	 * arbitrary whitespace, followed by "send " with one space after it.
	 * <P>
	 * 08.11.2020
	 *
	 * @param command
	 *        the input from the user (including both the command and the message)
	 */
	private static void executeSend(String command) {
		command = command.stripLeading();
		// message must be at least one character long + 4 char "send" + one space as
		// separator
		if (command.length() < 6) {
			invalidInput(
					String.format(" for %s, the message must be at least one character long", Constants.SEND_COMMAND),
					new String[] { command });
			return;
		}
		if (conn == null) {
			LOGGER.warning("Tried to send message without established connection.");
			printToConsole("Error! Not connected!");
			return;
		}
		try {
			command += "\r\n";
			// The first five characters of the command consist of "send" and a single space
			// " " separating the command "send" from the message
			byte[] message = command.substring(5).getBytes(Constants.TELNET_ENCODING);
			conn.send(message);
			LOGGER.info("Message sent succesfully");
		} catch (UnsupportedEncodingException e) {
			invalidInput(String.format(" for %s, the message contains invalid characters for the encoding %s",
					Constants.SEND_COMMAND, Constants.TELNET_ENCODING), new String[] { command });
			return;
		} catch (IOException e) {
			String output = String.format(
					"Error! Unable to send the message to %s:%d, possibly the connection broke down", conn.getHost(),
					conn.getPort());
			LOGGER.warning(output + "; " + e.toString());
			printToConsole(output);
			return;
		}

		// Execute only if the sending was successful.
		try {
			byte[] answer = conn.receive();
			if (answer == null) {
				throw new IOException(String.format("No answer received from %s:%d", conn.getHost(), conn.getPort()));
			}
			String recvMsg = new String(answer, Constants.TELNET_ENCODING);
			// remove carriage return
			printToConsole(recvMsg.substring(0, recvMsg.length() - 2));
			LOGGER.info("Successfully received echo message.");
		} catch (IOException e) {
			String output = String.format(
					"Error! Unable to recieve response from %s:%d although the sending was successful", conn.getHost(),
					conn.getPort());
			LOGGER.warning(output + "; " + e.toString());
			printToConsole(output);
		}

	}

	/**
	 * Whenever the user tries to issue an invalid command or a valid command with
	 * invalid arguments this method informs the user and prints the help message.
	 * <P>
	 * 08.11.2020
	 *
	 * @param extraMsg
	 *        more information concerning the invalid input
	 * @param tokens
	 *        the tokenized input from the user (including both the command and the
	 *        arguments)
	 */
	private static void invalidInput(String extraMsg, String[] tokens) {
		String output = String.format("Error! Invalid input%s, input was: %s", extraMsg, String.join(" ", tokens));
		LOGGER.warning(output);
		printToConsole(output);
		printHelp();
	}

	/**
	 * Returns whether the application is still running. Once the user issues the
	 * quit command this method returns false
	 * <P>
	 * 08.11.2020
	 *
	 * @return true if and only if the application hasn't been terminated yet by the
	 *         user.
	 */
	public static boolean isRunning() {
		return isRunning;
	}

	/**
	 * As other methods need the printHelp method as well, this method simulates a
	 * valid execution of the help command from the user. This eliminates the need
	 * of adding the confusing argument, which consists of an array with just one
	 * element (the valid help command), where the printHelp method is called
	 * internally.
	 * <P>
	 * 08.11.2020
	 *
	 */
	private static void printHelp() {
		printHelp(new String[] { Constants.HELP_COMMAND });
	}

	/**
	 * This method prints a help message to the console with a detailed description
	 * of all valid commands the user can issue.
	 * <P>
	 * 08.11.2020
	 *
	 */
	private static void printHelp(String[] tokens) {
		if (tokens.length != 1) {
			invalidInput(String.format(" for %s, incorrect number of arguments. Expected 0 but got %d",
					Constants.HELP_COMMAND, tokens.length - 1), tokens);
			return;
		}
		printToConsole("---------------Help---------------");
		printToConsole(
				"Connect to an echo server and send messages. Every message you send will be echoed back to you.");
		printToConsole("List of commands:");
		printToConsole(String.format(
				"\t%s <hostname> <port> : connects to the specified host and port. If a connection was already established, it is terminated before connecting to the specified host",
				Constants.CONNECT_COMMAND));
		printToConsole(String.format("\t%s : terminates the current connection", Constants.DISCONNECT_COMMAND));
		printToConsole(String.format(
				"\t%s <msg> : Sends the specified message to the currently connected host. The message must be at least one character long",
				Constants.SEND_COMMAND));
		printToConsole(String.format("\t%s : displays this message", Constants.HELP_COMMAND));
		printToConsole(String.format(
				"\t%s <loglevel> : changes the log level to the specified one. Valid options are SEVERE, WARNING, INFO, CONFIG, FINE, FINER, FINEST and ALL",
				Constants.LOGLEVEL_COMMAND));
		printToConsole(String.format("\t%s : Terminates any current connection and exits the program execution",
				Constants.QUIT_COMMAND));
		printToConsole("----------------------------------");
	}

	/**
	 * This method prints a message to the console with the preceding EchoClient>
	 * <P>
	 * 08.11.2020
	 *
	 * @param msg
	 *        the message that should be shown on screen
	 */
	private static void printToConsole(String msg) {
		System.out.println(BASE + msg);
	}

	/**
	 * This method terminates any active connection and exits the program execution.
	 * <P>
	 * 08.11.2020
	 */
	private static void quit() {
		if (conn != null) {
			executeDisconnect();
		}
		LOGGER.info("Exited application succesfully.");
		printToConsole("Application exit!");

		isRunning = false;
	}

	/**
	 * This method removes excess spaces between arguments, that are represented by
	 * empty Strings once the input is tokenized. Therefore, any command can be
	 * issued with as much spaces as the user (accidentally) puts between arguments
	 * or before the command. An exception to this rule is the send command, where
	 * every character after the first "send " (with a single space) is considered
	 * part of the message. However, spaces before the send command will still be
	 * ignored. This is only done for the sake of the application being as user
	 * friendly as possible.
	 * <P>
	 * 08.11.2020
	 *
	 * @param tokens
	 *        the tokenized input from the user
	 * @return the tokens without any empty strings
	 */
	private static String[] sanitize(String[] tokens) {
		int numNonEmptyArgs = 0;
		for (String s : tokens) {
			if (s != null && !s.equals("")) {
				numNonEmptyArgs++;
			}
		}
		String[] result = new String[numNonEmptyArgs];
		numNonEmptyArgs = 0;
		for (String s : tokens) {
			if (s != null && !s.equals("")) {
				result[numNonEmptyArgs++] = s;
			}
		}
		return result;
	}
}
