package de.tum.i13.client;


import static de.tum.i13.shared.LogSetup.setupLogging;

import java.io.IOException;

/**
 * The main class of the project cdb-20-21 gr12, it creates a simple connection to a server and can
 * send and receive messages.
 *
 * @author Nikita Charushnikov, Ridvan Acilan, Sebastian Waetzold
 * @version Milestone 1
 */
public class Client {

  /**
   * The name of the used log file during execution.
   */
  private static final String LOG_FILE_NAME = "test.log";

  /**
   * Initializes the command line interface and an instance of {@link Connection}.
   */
  public static void main(String[] args) throws IOException {
    setupLogging(LOG_FILE_NAME);
    ConnectionInterface connection = new Connection();
    Application application = new Application(connection);
    application.run();
  }
}
