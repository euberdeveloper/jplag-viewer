package de.tum.i13.client;

import java.io.IOException;

public interface ConnectionInterface {

  int getPort();

  String getHost();

  boolean isConnected();

  void connect(int port, String host) throws IOException;

  void close() throws IOException;

  void send(byte[] message) throws IOException;

  byte[] receive() throws IOException;


}
