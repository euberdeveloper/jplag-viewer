package de.tum.i13.client;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.Socket;
import java.util.ArrayList;
/**
 * Implementation of the {@link ConnectionInterface}.
 */
public class Connection implements ConnectionInterface {

  private Socket socket;
  private InputStream input;
  private OutputStream output;

  private boolean isConnected = false;
  private String host;
  private int port;

  /**
   * @return returns the used port.
   */
  public int getPort() {
    return port;
  }

  /**
   * @return returns the ip address of the connected server.
   */
  public String getHost() {
    return host;
  }

  /**
   * Connects to a server.
   *
   * @param port used port at the server.
   * @param host ip address of the server.
   * @throws IOException will be thrown if the socket is unable to initialise.
   */
  public void connect(int port, String host) throws IOException {
    this.port = port;
    this.host = host;
    this.socket = new Socket(host, port);
    this.input = this.socket.getInputStream();
    this.output = this.socket.getOutputStream();
    this.isConnected = true;
  }

  /**
   * Closes the connection to a server.
   *
   * @throws IOException will be thrown if the program is unable to disconnect.
   */
  public void close() throws IOException {
    this.isConnected = false;
    this.input.close();
    this.output.close();
    this.socket.close();
  }

  /**
   * Validates if the client has a connection to a server.
   *
   * @return returns true if its connected, vice versa.
   */
  public boolean isConnected() {
    return isConnected;
  }

  /**
   * Sends a message to the server.
   *
   * @param message byte array of the message.
   * @throws IOException will be thrown if the message cannot be sent.
   */
  public void send(byte[] message) throws IOException {
    for (byte msgByte : message) {
      this.output.write(msgByte);
      this.output.flush();
    }
  }

  /**
   * Receives a message from the server.
   *
   * @return returns the received message.
   * @throws IOException will be thrown if incoming message cannot be reat.
   */
  public byte[] receive() throws IOException {
    ArrayList<Byte> message = new ArrayList<>();

    byte lastByte = '\0';
    while (true) {
      byte byteMsg = (byte) input.read();
      if (lastByte == '\r' && byteMsg == '\n') {
        message.remove(message.size() - 1);
        break;
      }
      message.add(byteMsg);
      lastByte = byteMsg;
    }

    byte[] result = new byte[message.size()];
    for (int i = 0; i < message.size(); i++) {
      result[i] = message.get(i);
    }
    return result;
  }
}
