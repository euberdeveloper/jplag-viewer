package de.tum.i13.client;

import de.tum.i13.shared.Constants;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 * Implementation of the application logic defined in Milestone 1. Creates a command line interface
 * and waits/executes commands.
 */

public class Application {

  /**
   * Final constants used in the command line interface.
   */
  private final static Logger LOGGER = Logger.getLogger(Application.class.getName());
  private final static String PREFIX = "EchoClient> ";

  private final ConnectionInterface connection;

  public Application(ConnectionInterface connection) {
    this.connection = connection;
  }

  /**
   * Waits for an input by the user and executes after every finished command.
   *
   * @throws IOException will be thrown if the input line cannot be read.
   */
  public void run() throws IOException {
    BufferedReader cons = new BufferedReader(new InputStreamReader(System.in));

    boolean quit = false;
    while (!quit) {
      System.out.print(PREFIX);
      String input = cons.readLine();
      String[] cmd = input.trim().split("\\s+");
      quit = runCommand(connection, cmd);
    }
  }

  /**
   * Waits for a command and executes it.
   * @param conn used to parse the connection to the different commands.
   * @param cmd input command and arguments by the user.
   * @return returns true if user executes command quit.
   */
  public boolean runCommand(ConnectionInterface conn, String[] cmd) {
    if (cmd.length == 0) {
      printHelp();
    }
    switch (cmd[0]) {
      case "connect":
        handleConnect(conn, cmd);
        break;
      case "disconnect":
        if (cmd.length == 1) {
          handleDisconnect(conn);
        } else {
          printHelp();
        }
        break;
      case "send":
        handleSend(conn, cmd);
        break;
      case "logLevel":
        handleLogLevel(cmd);
        break;
      case "quit":
        return handleQuit(conn);
      default:
        printHelp();
    }
    return false;
  }

  /**
   * Changes the log level.
   *
   * @param cmd user input (command and arguments).
   */

  private void handleLogLevel(String[] cmd) {
    if (cmd.length == 2) {
      Level loglevel;
      try {
        loglevel = Level.parse(cmd[1]);
      } catch (IllegalArgumentException e) {
        printHelp();
        return;
      }
      Level currentLevel = LOGGER.getLevel();
      String message = "loglevel set from " + currentLevel + " to " + loglevel;
      System.out.println(message);
      LOGGER.info(message);
      LOGGER.setLevel(loglevel);
    } else {
      printHelp();
    }
  }

  /**
   * Shuts down the program and closes the connection to a server if needed.
   *
   * @param conn uses connection validation
   * @return returns true to prevent the application from waiting for more commands.
   */
  private boolean handleQuit(ConnectionInterface conn) {
    if (conn.isConnected()) {
      handleDisconnect(conn);
    }
    String info = "Application exit!";
    LOGGER.info(info);
    System.out.println(info);
    return true;
  }

  /**
   * Sends a message to a connected server and waits for response.
   *
   * @param conn uses connection validation and messaging methods.
   * @param cmd  the message sent to the server
   */
  private void handleSend(ConnectionInterface conn, String[] cmd) {
    if (cmd.length > 1) {
      StringBuilder sb = new StringBuilder();
      for (int i = 1; i < cmd.length - 1; i++) {
        sb.append(cmd[i]).append(" ");
      }
      sb.append(cmd[cmd.length - 1]);
      try {
        if (conn.isConnected()) {
          LOGGER.info(cmd[0] + " " + sb.toString());
          byte[] sendingMessage = (sb.toString() + "\r\n").getBytes();
          if (sendingMessage.length <= 128000) {
            conn.send((sb.toString() + "\r\n").getBytes());
            String message = new String(conn.receive(), Constants.TELNET_ENCODING);
            LOGGER.info(message);
            System.out.println(message);
          } else {
            String error = "Error! Server only supports a message length of 128 KByte!";
            LOGGER.severe(error);
            System.out.println(error);
          }
        } else {
          String error = "Error! Not connected!";
          LOGGER.warning(error);
          System.out.println(error);
        }
      } catch (IOException e) {
        String error = "Error! Fail to send the message.";
        LOGGER.severe(error);
        System.out.println(error);
      }
    } else {
      printHelp();
    }
  }

  /**
   * Disconnects from the server.
   *
   * @param conn method uses the interface to disconnect.
   */
  private void handleDisconnect(ConnectionInterface conn) {
    try {
      if (conn.isConnected()) {
        conn.close();
        String message = "Connection terminated: " + conn.getHost() + " / " + conn.getPort();
        LOGGER.info(message);
        System.out.println(message);
      } else {
        String error = "Error! Not connected!";
        LOGGER.warning(error);
        System.out.println(error);
      }
    } catch (IOException e) {
      String error = "Error! Failed to disconnect!";
      LOGGER.severe(error);
      System.out.println(error);
    }
  }

  /**
   * Executed by the command "connect" and tries to establish a connection to a server.
   *
   * @param conn brings needed methods e.g. connecting to a server
   * @param cmd  contains ip address and port.
   */
  private void handleConnect(ConnectionInterface conn, String[] cmd) {
    if (cmd.length == 3) {
      try {
        if (!conn.isConnected()) {
          LOGGER
              .info("Connecting to server with  host: " + cmd[1] + ", port: " + cmd[2]);
          conn.connect(Integer.parseInt(cmd[2]), cmd[1]);
          String message = new String(conn.receive(), Constants.TELNET_ENCODING);
          LOGGER.info(message);
          System.out.println(message);
        } else {
          String error = "Error! Already connected!";
          LOGGER.warning(error);
          System.out.println(error);
        }
      } catch (NumberFormatException | IOException e) {
        String error = "Connection to " + cmd[1] + " " + cmd[2] + " failed";
        LOGGER.severe(error);
        System.out.println(error);
      }
    } else {
      printHelp();
    }
  }

  /**
   * Shows the user all the available commands accepted by this program.
   */
  private void printHelp() {
    LOGGER.info("Printing help");
    System.out.println("Usage:\n"
        + "connect <address> <port> - Tries to establish a TCP- connection to the echo server based "
        + "on the given server address and the port number of the echo service.\n"
        + "disconnect - Tries to disconnect from the connected server.\n"
        + "send <message> - Sends a text message to the echo server according to the communication protocol.\n"
        + "logLevel <level> - Sets the logger to the specified log level.\n"
        + "help - Shows this help page.\n"
        + "quit - Tears down the active connection to the server and exits the program execution.");
  }
}
