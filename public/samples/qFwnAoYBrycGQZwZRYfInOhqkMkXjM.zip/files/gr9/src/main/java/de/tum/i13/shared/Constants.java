package de.tum.i13.shared;

public class Constants {

	public static final String TELNET_ENCODING = "ISO-8859-1"; // encoding for telnet
	/**
	 * HELP_REPLY is the message that is displayed to the user when he types help,
	 * it describes what can be done in the program
	 * 
	 */
	public static final String HELP_REPLY = "The client should type one these commands :\n* connect <address> <port>: "
			+ "in order to get connected to the server with the given address and port. \n"
			+ "* disconnect: in order to disconnect from the server.\n"
			+ "* send <message>: in order to send a message.\n* logLevel <level> in order to dynamically set the level of the logger\n(the possible levels are: ALL, CONFIG, FINE, FINEST, INFO, OFF,"
			+ " SEVERE, WARNING)\n* quit: in order to stop the connection with the server.";

}