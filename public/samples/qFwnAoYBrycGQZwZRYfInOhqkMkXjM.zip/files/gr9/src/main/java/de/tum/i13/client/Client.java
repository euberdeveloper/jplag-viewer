package de.tum.i13.client;

import java.io.*;
import java.net.*;


/**
 * Client class that will establish the connection to the server
 *
 * @author gr9
 *
 */
public class Client {
	public Socket client;
	private String errorMsg = "";

	boolean isConnected = false;

	/**
	 * The connect method tries to establish a connection between the client and the
	 * echo server and throws
	 *
	 * @param host, port
	 * @return the error message if there is one.
	 */
	public String connect(String host, String port) {
		try {
			this.client = new Socket(host, Integer.parseInt(port));
		} catch (NumberFormatException e) {
			errorMsg = "This is not a port.";
		} catch (UnknownHostException e) {
			errorMsg = "Unknown IP address.";
		} catch (IOException e) {
			errorMsg = "Connection failed.";
		} finally {
			isConnected = errorMsg.equals("");
		}
		return errorMsg;
	}

	/**
	 * The disconnect method tries to disconnect the client from the echo server and
	 * catches the exception if there is one
	 *
	 * @return the error message if there is one.
	 */
	public String disconnect() {
		try {
			client.getOutputStream().flush();
			client.close();
		} catch (IOException e) {
			errorMsg = "unsuccessful";
		}
		return errorMsg;
	}

}