package de.tum.i13.client;

import java.io.*;
import java.net.*;
import java.util.logging.Level;

/**
 * A communicator class to get the input from the user and communicate with the
 * server
 *
 * @author gr9
 *
 */
public class Communicator {
	private static boolean quit = false;
	private InputStream in;
	private OutputStream out;

	public Communicator() {
	}

	/**
	 * run methods that communicate with the user and the server
	 *
	 * @throws IOException when the user gives a wrong input or when he is trying to
	 *                     send something after closing the connection to the server
	 */
	public void run() throws IOException {
		Parser parser = new Parser();
		byte[] response = null;
		try {
			BufferedReader input = new BufferedReader(new InputStreamReader(System.in));
			parser.setLevel(Level.FINE);
			while (!quit) {
				System.out.print("EchoClass> ");
				String message = input.readLine();
				String reply = parser.parse(message);

				if (parser.getNeedsReply()) {
					Socket client = parser.getClient();
					in = client.getInputStream();
					out = client.getOutputStream();
					if (message.substring(0, 5).equals("send ")) {
						message = message.substring(5) + "\r\n";
						send(message.getBytes("ISO-8859-1"));
					}
					response = new String(receive(), "ISO-8859-1").getBytes("UTF-8");
					System.out.println(new String(response));
					parser.setNeedReply(false);
				} else {
					System.out.println(reply);
				}
			}
		} catch (IOException ie) {
			ie.printStackTrace();
			System.out.println("Please check your request. Warning: " + ie);
		}
	}

	/**
	 * method to get out of the while loop
	 */
	public void setQuit(boolean quit) {
		this.quit = quit;
	}

	/**
	 * Method to handle the data that should be sent to the server
	 */
	public void send(byte[] arr) {
		try {
			out.write(arr, 0, arr.length);
			out.flush();
		} catch (IOException ie) {
			ie.printStackTrace();
			System.out.println("Warning: " + ie);
		}
	}

	/**
	 *
	 * the receive method handles the message received from the server
	 *
	 * @return the message as an array of bytes
	 *
	 */
	public byte[] receive() throws IOException {
		byte[] msg = new byte[1024];
		int x = 0;
		int i = this.in.read();
		while (i != '\r') {
			msg[x] = (byte) i;
			x++;
			if (x == -1)
				throw new IOException("Input error, please try again.");
			i = this.in.read();
		}
		return msg;
	}

	/**
	 * main method which is being run
	 */
	public static void main(String[] args) throws IOException {
		Communicator communicator = new Communicator();
		communicator.run();
	}
}