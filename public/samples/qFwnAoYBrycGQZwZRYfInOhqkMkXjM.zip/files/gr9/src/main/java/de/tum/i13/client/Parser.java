package de.tum.i13.client;

import java.io.*;
import java.net.*;
import java.util.logging.Level;
import java.util.logging.Logger;

import de.tum.i13.shared.Constants;

/**
 * Parser class to handle the commands and is linked to the Client class to
 * establish the connection to the server
 *
 * @author gr9
 *
 */
public class Parser {
	// getting an instance of Communicator
	private final Communicator streamer = new Communicator();
	// getting an instance of Client
	private final Client client = new Client();
	private final Logger logger = Logger.getLogger(Communicator.class.getName());
	private Level level;
	/**
	 * the needReply variable lets us know if we need a reply from the server or not
	 *
	 */
	private static boolean NeedReply = false;

	public Parser() {
	}

	/**
	 * the method setLevel sets the logger level with the parameter
	 *
	 * @param level the user input
	 *
	 * @author gr9
	 *
	 */
	public void setLevel(Level level) {
		this.level = level;
		this.logger.setLevel(level);
	}

	/**
	 * the method getNeedsReply returns the value of the variable NeedReply
	 *
	 * @author gr9
	 *
	 */
	public boolean getNeedsReply() {
		return NeedReply;
	}

	public void setNeedReply(boolean Nr) {
		NeedReply = Nr;
	}

	/**
	 * the parse method handles the input given from the user and split its
	 * components and handle the command and structure the reply back to the user
	 *
	 * @param msg the user input
	 * @return a message that should be displayed to the user
	 * @throws IOException
	 * @throws ConnectException when there is a problem while connection to the
	 *                          server
	 */
	public String parse(String msg) throws IOException, ConnectException {
		String reply = "";
		String[] tokens = msg.trim().split("\\s");

		if (tokens[0].equals("send")) {
			if (this.getClient().isClosed()) {
				reply = "Error! Not connected!";
				// logger.log(Level.SEVERE, "Not connected! Please, connect and try again.");
			} else {
				this.setNeedReply(true);
			}

		} else if (tokens[0].equals("quit")) {
			streamer.setQuit(true);
			reply = "Application exit, have a nice day!";

		} else if (tokens[0].equals("connect") && tokens.length == 3) {
			String connectReply = client.connect(tokens[1], tokens[2]);
			if (connectReply.equals("")){
				this.setNeedReply(true);
			}
			else {
				reply = connectReply;
			}

		} else if (tokens[0].equals("disconnect") && (tokens.length == 1)) {
			String disconnectReply = client.disconnect();
			if (disconnectReply.equals("unsuccessful")){
				reply = "Disconnection unsuccefull";
			}
			else{
				logger.log(level, "Connection terminated: ");
				reply = "Connection terminated: " + getClient().getInetAddress().getHostAddress().toString() + " / "
						+ Integer.toString(getClient().getPort());
			}

		} else if (tokens[0].equals("logLevel")) {
			level = Level.parse(tokens[1]);
			String previous = logger.getLevel().toString();
			String n = level.toString();
			logger.setLevel(level);
			reply = "loglevel set from " + previous + " to " + n;

		} else if (tokens[0].equals("help") && tokens.length == 1) {
			reply = Constants.HELP_REPLY;

		} else {
			logger.log(Level.WARNING, "Please check your request and try again.");
			reply = Constants.HELP_REPLY;
		}
		return reply;
	}

	/**
	 * getter method for the client
	 */
	public Socket getClient() {
		return this.client.client;
	}

}