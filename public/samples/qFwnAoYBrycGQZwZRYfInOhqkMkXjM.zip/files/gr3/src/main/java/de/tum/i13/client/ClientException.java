package de.tum.i13.client;

/**
 * An exception that is thrown whenever there is a problem with the client. This could also be because the client was
 * given a wrong host or port. Other examples include messages that are too large or calling disconnect() before
 * connect(), among others.
 */
public class ClientException extends Exception {

    public ClientException(String s) {
        super(s);
    }
}
