package de.tum.i13.cli.commands;

public class CliHelpCommand {

    /**
     * Shows the help command specific to the given parameters. In general, either a command is expected as parameters,
     * otherwise a general help is shown
     * @param parameters the command to show help for, or it shows general help for empty or unknown command
     */
    public static void showHelp(String parameters) {
        switch (parameters) {
            case "connect":
                System.out.println("Syntax: connect <address> <port> \n Tries to establish a TCP- connection to " +
                        "the echo server based on the given server address and the port number of the echo " +
                        "service.\nParameters:\nAddress: Hostname or IP address of the echo server.\n " +
                        "Port: The port of the echo service on the respective server.");
                break;
            case "disconnect":
                System.out.println("Tries to disconnect "
                        + "from the connected "
                        + "server.");
                break;
            case "send":
                System.out.println("Syntax: send <message> \n Tries to establish a Sends a text message to the " +
                        "echo server according to the communication protocol.\n Parameters:\n message: Sequence " +
                        "of ISO8859-1 coded characters that correspond to the application specific protocol.");
                break;
            case "logLevel":
                System.out.println("Syntax: send <message> \n Sets the logger to the specified log level \n" +
                        "Parameters:\n level: One of the following log levels: (SEVERE | WARNING | " +
                        "INFO | FINE | FINER | FINEST | ALL | CONFIG | OFF)");
                break;
            case "quit":
                System.out.println(
                        "Tears down the active connection to the server and exits the program execution.");
                break;
            default:
                System.out.println("Syntax: help <command>\n" +
                        "Possible commands are: connect, disconnect, send, logLevel, help, quit");
                break;
        }
    }
}
