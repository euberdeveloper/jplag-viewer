package de.tum.i13.client;

import java.io.*;
import java.net.*;
import java.nio.ByteBuffer;
import java.nio.charset.StandardCharsets;

/**
 * The main client that connects and disconnects to the server, as well as sends and receives messages to and from it.
 */
public class Client {

    private final int MAX_MESSAGE_SIZE = 128_000; // bytes ( = 128 KByte)
    private final int MAX_MESSAGE_CONTENT_SIZE = MAX_MESSAGE_SIZE - 2; // due to "\r\n" at the end

    private Socket socket;

    private InputStream in;
    private OutputStream out;

    public Client() {
    }

    /**
     * Tries to establish a connection to the given host with the given port.
     * @throws ClientException is thrown whenever there is a problem when establishing the connection, for instance when
     *                         the host could not be resolved
     */
    public void connect(String host, int port) throws ClientException {
        if (isCurrentlyConnected())
            throw new ClientException("Connection already established. Disconnect first if you want a new connection.");

        try {
            socket = new Socket();
            socket.connect(new InetSocketAddress(host, port), 10_000);
            out = socket.getOutputStream();
            in = socket.getInputStream();
        } catch (Exception e) {
            throw new ClientException("There was an error when establishing the connection. Please verify the host " +
                    "and the port and try again.");
        }
    }

    /**
     * Returns the remote address of the current connection, if a connection is present.
     * @throws ClientException if no connection is currently established
     */
    public String getRemoteAddress() throws ClientException {
        if (!isCurrentlyConnected())
            throw new ClientException("There is no connection currently established.");

        return socket.getRemoteSocketAddress().toString();
    }

    /**
     * Disconnects the current connection, if one is established.
     * @throws ClientException is thrown when either there is no connection established, or when there was an error when
     *                         disconnecting
     */
    public void disconnect() throws ClientException {
        if (!isCurrentlyConnected())
            throw new ClientException("There is no connection currently established, so disconnecting doesn't make " +
                    "any sense.");

        try {
            out.close();
            in.close();
            socket.close();
        } catch (IOException e) {
            throw new ClientException("There was an error when disconnecting. Please try again.");
        }
    }

    /**
     * Sends a message to the connected host. It expects the message to not yet have the final delimiters set, i.e.
     * the message as it is given should not contain the string sequence "\r\n". If it does, the echo server will return
     * just the part leading up to this sequence.
     * @param message the content of the message that is to be sent to the echo server
     * @throws ClientException if there is no connection established, or the message content is empty or too large - a
     *                         message is too large if it is > 128.000 bytes, thus the message content can be up to
     *                         127.998 bytes large
     */
    public void sendMessage(String message) throws ClientException {
        if (!isCurrentlyConnected())
            throw new ClientException("There is no connection currently established, so sending a message doesn't " +
                    "make any sense.");
        if (message.isEmpty() || message.length() > MAX_MESSAGE_CONTENT_SIZE || message.equals("\r\n"))
            throw new ClientException("The content of the message must be of length 0 < message.length <= " +
                    MAX_MESSAGE_CONTENT_SIZE + ".");

        try {
            String fullMessage = message.concat("\r\n");
            sendRaw(fullMessage.getBytes());
        } catch (IOException e) {
            throw new ClientException("Sending of the message failed. Please try again.");
        }
    }

    /**
     * Sends the bytes as is to the echo server, whereby it doesn't check for any problems
     * @throws IOException if an I/O error occurs
     */
    private void sendRaw(byte[] bytes) throws IOException {
        out.write(bytes);
        out.flush();
    }

    /**
     * Blocks until it receives a message from the echo server, then returns it.
     * @throws ClientException if no connection is established, or if there was I/O error when receiving the message
     */
    public String receiveMessage() throws ClientException {
        if (!isCurrentlyConnected())
            throw new ClientException("There is no connection currently established, so receiving a message doesn't " +
                    "make any sense.");

        final byte[] receivedBytes;
        try {
            receivedBytes = receive();
            return new String(receivedBytes, StandardCharsets.ISO_8859_1);
        } catch (IOException e) {
            throw new ClientException("There was an error when receiving the message. If this error happens again " +
                    "please check with the log files.");
        }
    }

    /**
     * Receives a message byte byte, which is then saved in a ByteBuffer. The end result is returned in a byte array
     * of the size of the message that was received, which includes the final sequence "\r\n"
     * @throws IOException if an I/O error occurs when receiving
     */
    private byte[] receive() throws IOException {
        ByteBuffer buffer = ByteBuffer.allocate(MAX_MESSAGE_SIZE);
        int messageSize = 0;

        do {
            buffer.put((byte) in.read());
            messageSize++;
        } while (!isMessageFinished(buffer));

        buffer.position(0);
        byte[] result = new byte[messageSize-2];
        buffer.get(result, 0, messageSize-2);

        return result;
    }

    /**
     * Returns true if the message that is contained in the given ByteBuffer is finished, false otherwise.
     */
    private boolean isMessageFinished(ByteBuffer buffer) {
        int currentPosition = buffer.position();
        if (buffer.position() < 2)
            return false;

        return buffer.get(currentPosition - 2) == '\r' &&
                buffer.get(currentPosition - 1) == '\n';
    }

    /**
     * Returns true if there is currently a connection established, false otherwise.
     */
    public boolean isCurrentlyConnected() {
        return socket != null &&
                socket.isConnected() &&
                !socket.isClosed();
    }
}
