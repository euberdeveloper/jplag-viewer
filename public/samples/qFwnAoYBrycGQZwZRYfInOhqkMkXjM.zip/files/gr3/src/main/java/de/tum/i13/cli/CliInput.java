package de.tum.i13.cli;

/**
 * A wrapper for the CLI input. Its main purpose is to parse the CLI input and hold a feasible data structure for
 * the parsed command and parameters.
 */
public class CliInput {

    public String command;
    public String parameters = "";

    public CliInput(String input) throws CliException {
        if (input.isEmpty())
            throw new CliException("Please enter a valid command. Use help <command> for more informations.");

        int positionOfFirstWhitespace = input.indexOf(' ');

        if (positionOfFirstWhitespace == -1) {
            this.command = input;
        } else {
            this.command = input.substring(0, positionOfFirstWhitespace);
            this.parameters = input.substring(positionOfFirstWhitespace + 1);
        }
    }
}
