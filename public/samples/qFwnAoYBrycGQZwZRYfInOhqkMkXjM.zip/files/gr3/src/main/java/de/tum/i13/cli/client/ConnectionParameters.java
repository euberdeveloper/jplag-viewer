package de.tum.i13.cli.client;

import de.tum.i13.cli.CliException;

/**
 * A wrapper for the connection parameters. Its main purpose is parsing the parameters and to create a data structure
 * that holds them.
 */
public class ConnectionParameters {

    private final String PARSE_ERROR_MESSAGE =
            "Expected two parameters: 'connect <address> <port>'. <port> is expected to be a number";

    public String address;
    public int port;

    public ConnectionParameters(String allParameters) throws CliException {
        String[] splitParameters = allParameters.split("\\s+");

        if (splitParameters.length < 2)
            throw new CliException(PARSE_ERROR_MESSAGE);

        this.address = splitParameters[0];

        try {
            this.port = Integer.parseInt(splitParameters[1]);
        } catch (NumberFormatException e) {
            throw new CliException(PARSE_ERROR_MESSAGE);
        }
    }

}
