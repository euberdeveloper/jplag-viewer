package de.tum.i13.cli.client;

import de.tum.i13.cli.CliException;
import de.tum.i13.client.Client;
import de.tum.i13.client.ClientException;

/**
 * The class that handles logic between the CLI and the Client. Often this is the case for printing informational
 * messages to the user of the CLI, but also to handle the echo behavior directly (i.e. reading after sending) and
 * disconnecting before quitting the CLI.
 */
public class CliClient {

    private final Client client;

    public CliClient() {
        client = new Client();
    }

    public void connect(String allParameters) throws CliException, ClientException {
        ConnectionParameters parameters = new ConnectionParameters(allParameters);
        client.connect(parameters.address, parameters.port);
        System.out.println(client.receiveMessage());
    }

    public void disconnect() throws ClientException {
        String remoteAddress = client.getRemoteAddress();
        client.disconnect();
        System.out.println("Connection terminated: " + remoteAddress);
    }

    public void handleEcho(String parameters) throws ClientException {
        client.sendMessage(parameters);
        System.out.println(client.receiveMessage());
    }

    public void quit() throws ClientException {
        if (this.client.isCurrentlyConnected()) {
            this.disconnect();
        }
        System.out.println("Application exit.");
    }

    public boolean iscurrentlyConnected() {
		return this.client.isCurrentlyConnected();
	}

}
