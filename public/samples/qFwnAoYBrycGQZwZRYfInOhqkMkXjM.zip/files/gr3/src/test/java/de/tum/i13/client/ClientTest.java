package de.tum.i13.client;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.util.Arrays;

import static org.junit.jupiter.api.Assertions.*;

class ClientTest {

    private Client underTest;

    private final String correctHost = "clouddatabases.msrg.in.tum.de";
    private final int correctPort = 5551;

    @BeforeEach
    public void setUp() {
        this.underTest = new Client();
    }

    @Test
    public void testDisconnectAfterAlreadyDisconnected() throws ClientException {
        underTest.connect(correctHost, correctPort);
        underTest.disconnect();
        assertThrows(ClientException.class, () -> underTest.disconnect());
    }

    @Test
    public void testSendingOfTooLargeMessage() throws ClientException {
        char[] chars = new char[127_999];
        Arrays.fill(chars, 'a');
        String message = new String(chars);

        underTest.connect(correctHost, correctPort);
        underTest.receiveMessage();

        assertThrows(ClientException.class, () -> underTest.sendMessage(message));
    }

    @Test
    public void testSendingOfLargeButInLimitsMessageWorks() throws ClientException {
        char[] chars = new char[127_998];
        Arrays.fill(chars, 'a');
        String message = new String(chars);

        underTest.connect(correctHost, correctPort);
        underTest.receiveMessage();

        underTest.sendMessage(message);
        String receivedMessage = underTest.receiveMessage();

        assertEquals(message , receivedMessage);
    }

    @Test
    public void testEchoRoundtrip() throws ClientException {
        Client client = new Client();
        assertFalse(client.isCurrentlyConnected());

        client.connect(correctHost, correctPort);

        assertTrue(client.isCurrentlyConnected());

        String expectedMessage = "Connection to MSRG Echo server established: /131.159.52.61:5551";
        assertEquals(expectedMessage, client.receiveMessage());

        String message = "Hi Server!";
        client.sendMessage(message);
        assertEquals(message , client.receiveMessage());

        assertTrue(client.isCurrentlyConnected());

        client.disconnect();
        assertFalse(client.isCurrentlyConnected());
    }

}