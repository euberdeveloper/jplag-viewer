package de.tum.i13.cli;

import de.tum.i13.cli.client.CliClient;
import de.tum.i13.client.ClientException;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Disabled;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class CliClientTest {

    CliClient underTest = new CliClient();

    final String correctParameters = "clouddatabases.msrg.in.tum.de 5551";

    @BeforeEach
    public void setUp() {
        underTest = new CliClient();
    }

    @Test
    public void testEchoWithoutStartedConnection() {
        assertThrows(ClientException.class, () -> underTest.handleEcho("hello echo"));
    }

    @Test
    @Disabled // disabled because it takes quite long
    public void testConnectionThrowsExceptionWithWrongPort() {
        final String parametersWithWrongPort = "clouddatabases.msrg.in.tum.de 1000";
        assertThrows(ClientException.class, () -> underTest.connect(parametersWithWrongPort));
    }

    @Test
    @Disabled // disabled because it takes quite long
    public void testConnectionThrowsExceptionWithWrongHost() {
        final String parametersWithWrongPort = "clouddatabases.msrg.in.tum.at 5551";
        assertThrows(ClientException.class, () -> underTest.connect(parametersWithWrongPort));
    }

    @Test
    public void testConnectionThrowsExceptionWithPortOutOfRange() {
        final String parametersWithWrongPort = "clouddatabases.msrg.in.tum.de -1";
        assertThrows(ClientException.class, () -> underTest.connect(parametersWithWrongPort));
    }

    @Test
    public void testConnectionWhenAlreadyConnected() throws CliException, ClientException {
        underTest.connect(correctParameters);
        assertThrows(ClientException.class, () -> underTest.connect(correctParameters));
    }

    @Test
    public void testDisconnectFailsWhenAlreadyDisconnected() throws CliException, ClientException {
        underTest.connect(correctParameters);
        underTest.disconnect();
        assertThrows(ClientException.class, () -> underTest.disconnect());
    }

    @Test
    public void testSimpleRoundtripDoesNotThrowAnyException() {
        assertDoesNotThrow(() -> {
            underTest.connect(correctParameters);
            underTest.handleEcho("hallo echo");
            underTest.handleEcho("echo again");
            underTest.disconnect();
        });
    }

    @Test
    public void testDisconnectionBeforeQuitting() throws CliException, ClientException {
    	underTest.connect(correctParameters);
    	assertTrue(underTest.iscurrentlyConnected());
    	underTest.quit();
    	assertFalse(underTest.iscurrentlyConnected());
    } 

    @Test
    public void testQuittingWhileDisconnectedWorks() throws CliException, ClientException {
    	assertDoesNotThrow(() -> {
    	  assertFalse(underTest.iscurrentlyConnected());
    	  underTest.quit();
    	  assertFalse(underTest.iscurrentlyConnected());
    	});
    }

}