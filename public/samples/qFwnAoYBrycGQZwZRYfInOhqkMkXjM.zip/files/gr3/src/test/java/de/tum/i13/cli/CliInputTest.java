package de.tum.i13.cli;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class CliInputTest {

    @Test
    public void testCliInputConstructorWithValidArguments1() throws CliException {
        String command = "connect";
        String parameters = "clouddatabases.msrg.in.tum.de 5551";
        String wholeInput = command + " " + parameters;

        CliInput input = new CliInput(wholeInput);

        assertEquals(command, input.command);
        assertEquals(parameters, input.parameters);
    }

    @Test
    public void testCliInputConstructorWithValidArguments2() throws CliException {
        String wholeInput = "help";

        CliInput input = new CliInput(wholeInput);

        assertEquals(wholeInput, input.command);
        assertTrue(input.parameters.isEmpty());
    }


    @Test
    public void testCliInputConstructorWithWrongArguments() {
        assertThrows(CliException.class, () -> new CliInput(""));
    }
}