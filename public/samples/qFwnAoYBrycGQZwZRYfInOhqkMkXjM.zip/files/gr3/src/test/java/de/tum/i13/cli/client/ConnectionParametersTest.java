package de.tum.i13.cli.client;

import de.tum.i13.cli.CliException;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class ConnectionParametersTest {

    @Test
    public void testConnectionParametersParsing() throws CliException {
        String address = "clouddatabases.msrg.in.tum.de";
        int port = 5551;
        String allParameters = address + " " + port;

        ConnectionParameters parameters = new ConnectionParameters(allParameters);

        assertEquals(address, parameters.address);
        assertEquals(port, parameters.port);
    }
}