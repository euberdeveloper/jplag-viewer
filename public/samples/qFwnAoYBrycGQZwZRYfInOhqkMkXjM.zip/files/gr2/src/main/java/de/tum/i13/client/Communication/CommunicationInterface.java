package de.tum.i13.client.Communication;


public interface CommunicationInterface {


    boolean connect(String address, int port);
    boolean disconnect();
    boolean send(byte[] data);
    byte[] receive();
    String getServerIP();
    int getServerPort();



}
