package de.tum.i13.shared;

public class Constants {
	public static final String TELNET_ENCODING = "ISO-8859-1"; // encoding for telnet
	public static final String helpText = "Possible commands:\nconnect <address> <port>\ndisconnect\n" +
			"send <message>\nlogLevel <level>\nhelp\nquit\nAnything else will return no results.";
}
