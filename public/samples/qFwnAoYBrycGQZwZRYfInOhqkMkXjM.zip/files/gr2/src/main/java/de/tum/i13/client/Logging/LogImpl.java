package de.tum.i13.client.Logging;

import de.tum.i13.client.Client;

import java.util.logging.Level;
import java.util.logging.Logger;

import static de.tum.i13.shared.LogSetup.setupLogging;

/**
 * LogImpl is used to implement the LoggingInterface
 */

public class LogImpl implements LoggingInterface {
    private final static Logger LOGGER = Logger.getLogger(Client.class.getName());
    private Level logLevel = Level.ALL;

    public LogImpl() {
        setupLogging("client.log");
    }



    /**
     * insert String that will be outputted
     * @param message
     */
    public void log(String message) {
        LOGGER.log(logLevel, message);
    }

    /**
     * changes the current log level to the new;
     * returns the old one to be able to print the confirmation message
     * @param newLevel
     * @return Level old logLevel
     */
    public Level changeLogLevel(Level newLevel) {
        Level retValue = logLevel;
        logLevel = newLevel;
        return retValue;
    }

    /**
     * reads the String to decide which Level is asked for;
     * then changes the Level;
     * @param input
     * @return old Level
     */
    public Level changeLogLevel(String input) {
        Level newLevel=null;
        if (input.endsWith("FINE")) {
            newLevel = Level.FINE;
        } else if (input.endsWith("ALL")) {
            newLevel = Level.ALL;
        } else if (input.endsWith("CONFIG")) {
            newLevel = Level.CONFIG;
        } else if (input.endsWith("FINEST")) {
            newLevel = Level.FINEST;
        } else if (input.endsWith("INFO")) {
            newLevel = Level.INFO;
        } else if (input.endsWith("OFF")) {
            newLevel = Level.OFF;
        } else if (input.endsWith("SEVERE")) {
            newLevel = Level.SEVERE;
        } else if (input.endsWith("WARNING")) {
            newLevel = Level.WARNING;
        } else {
            log("Invalid level: Loglevel will not be changed.");
            return null;
        }
        Level retValue = logLevel;
        logLevel = newLevel;
        return retValue;
    }

    /**
     * getter for current Level
     * @return current Level
     */
    @Override
    public Level getLevel() {
        return logLevel;
    }
}
