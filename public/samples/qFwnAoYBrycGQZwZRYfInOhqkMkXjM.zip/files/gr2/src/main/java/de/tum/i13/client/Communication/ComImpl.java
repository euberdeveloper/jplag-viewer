package de.tum.i13.client.Communication;

import de.tum.i13.client.Logging.LoggingInterface;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.Socket;

public class ComImpl implements CommunicationInterface {


    private Socket socket = null;
    private InputStream inputStream = null;
    private OutputStream outputStream = null;
    private final LoggingInterface logger;

    public ComImpl(LoggingInterface logger){
        this.logger=logger;
    }


    /**
	 * establishes a connection to the given server and Port returns whether the
	 * connection was established successfully
	 * 
	 * @return boolean for testing
	 */
    @Override
    public boolean connect(String address, int port) {
        if (socket == null) {
            try {
                socket = new Socket(address, port);
                logger.log("Connection to server " + address +" "+port+" established");

                return true;
            } catch (IOException e) {
                e.printStackTrace();
                logger.log("Connection could not be established.");
                return false;
            }
        }
        logger.log("Connection already exists.");
        return false;
    }


    /**
	 * Disconnects form the server, if the connection exists
	 * 
	 * @return boolean for testing
	 */
    @Override
    public boolean disconnect() {
        if (socket != null) {
            try {
                socket.close();
                if(inputStream!=null)
                {
                    inputStream.close();
                    inputStream=null;
                }
                if (outputStream!=null)
                {
                    outputStream.close();
                    outputStream=null;
                }
                socket=null;
                logger.log("Disconnecting was successful.");
                return true;
            } catch (IOException e) {
                logger.log("Disconnecting caused an unexpected error.");
                socket =null;
                return false;
            }
        }
        logger.log("The connection does not exists. Disconnecting is therefore not possible.");
        return false;

    }

    /**
	 * sends a given Byte array to the server Returns whether the transmission was
	 * successful (true) or not (false)
	 * 
	 * @return boolean for testing
	 */
    @Override
    public boolean send(byte[] data) {
        try {
            if (outputStream==null) {
                outputStream = socket.getOutputStream();
            }
            outputStream.write(data);
            outputStream.flush();
            logger.log("Data was successfully send to the server.");
            return true;
        } catch (IOException e) {
            logger.log("Sending caused an error, the data was not transmitted to the server.");
            e.printStackTrace();
            return false;
        }

    }

    /**
	 * returns a byte array containing a single line send by the server
	 * 
	 * @return boolean for testing
	 */
    @Override
    public byte[] receive() {
        byte[] data = new byte[128000];
        try {
           if(inputStream==null){
               inputStream = socket.getInputStream();
           }

            logger.log("Data was successfully received from the server.");
            inputStream.read(data);
            return data;

        } catch (IOException e) {
            logger.log("Receiving caused an error, no data was received from the server.");
            e.printStackTrace();
            return null;
        }
    }

    /**
	 * gets Server IP
	 * 
	 * @return ServerIP
	 */
    @Override
    public String getServerIP() {
        return socket.getInetAddress().getHostAddress();
    }

    /**
	 * gets Serverport
	 * 
	 * @return Serverport
	 */
    @Override
    public int getServerPort() {
        return socket.getPort();
    }
}
