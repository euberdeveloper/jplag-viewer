package de.tum.i13.client;

import de.tum.i13.client.Communication.ComImpl;
import de.tum.i13.client.Logging.LogImpl;
import de.tum.i13.client.Logging.LoggingInterface;

import java.util.logging.Level;

import static de.tum.i13.shared.Constants.helpText;

/*
connect clouddatabases.msrg.in.tum.de 5551
 */


/**
 * The class Client provides the main functionalities
 */

public class Client {


    private final ComImpl communicator;
    private final CommandLineInterface commandLine;
    private final LoggingInterface logger;
    private boolean stop;
    private boolean connected = false;


    public static void main(String[] args) {
        new Client();
    }

    public Client() {
        logger = new LogImpl();
        logger.log("Program started.");

        commandLine = new CommandLineInterface(logger);
        communicator = new ComImpl(logger);
        stop = false;

        while (!stop) {
            evaluateInput(commandLine.read());
        }
    }


    /**
     * This methods handles the Input and than calls needed methods
     *
     * @param input as a String
     * @since v.1 (9.11.2020)
     */
    private void evaluateInput(String input) {
        //searches for spaces
        int space = input.indexOf(' ');
        if (space != -1) {
            String cmd = input.substring(0, space);
            if (cmd.equals("connect")) {
                String addressPort = input.substring(space + 1);
                String address = addressPort.substring(0, addressPort.indexOf(' '));
                int port = Integer.parseInt(addressPort.substring(addressPort.indexOf(' ') + 1));
                if (communicator.connect(address, port)) {
                    commandLine.write(byteArrayToString(communicator.receive()));
                    connected = true;
                }

            } else if (cmd.equals("send")) {
                if (connected) {
                    sendData(input.substring(space + 1));
                } else {
                    logger.log("Send was called, but client was not connected to any server.");
                    commandLine.write("Error! Not connected!");
                }
            } else if (cmd.equals("logLevel")) {
                changeLevel(input.substring(space + 1));
            } else {
                commandLine.write("Unknown command\n" + helpText);
                logger.log("Unknown command entered.");
            }
        } else {
            if (input.equals("disconnect")) {

                if (connected) {
                    int port = communicator.getServerPort();
                    String ipServer = communicator.getServerIP();
                    if (communicator.disconnect()) {
                        commandLine.write("Connection terminated: " + ipServer + " / " + port);
                        logger.log("Connection terminated: " + ipServer + " / " + port);
                        connected = false;
                    } else {
                        commandLine.write("An Error occurred: Disconnecting was not possible.");
                    }

                } else {
                    logger.log("Disconnect was called, but client was not connected to any server.");
                    commandLine.write("Error! Not connected!");
                }
            } else if (input.equals("help")) {
                commandLine.write(helpText);
                logger.log("help was called.");
            } else if (input.equals("quit")) {
                commandLine.write("Application exit!");
                communicator.disconnect();
                logger.log("Application Exited");
                stop = true;
            } else {
                commandLine.write("Unknown command\n" + helpText);
                logger.log("Unknown command entered.");
            }
        }
    }


    /**
     * Is changing the logLevel to given String input
     *
     * @param input (the level it should change to)
     * @since v.1 (9.11.2020)
     */
    private void changeLevel(String input) {
        Level helper = logger.changeLogLevel(input);
        if (helper == null) {
            commandLine.write("Invalid Log Level entered. Valid Options: ALL; CONFIG; FINE; FINEST; INFO; OFF; SEVERE; WARNING");
            logger.log("Invalid Log Level entered.");
        } else {
            commandLine.write("logLevel set from " + helper.toString() + " to " + logger.getLevel().toString());
            logger.log("logLevel set from " + helper.toString() + " to " + logger.getLevel().toString());
        }

    }


    /**
     * prepares the String to send as Byte Array and sends it;
     * also takes care message to the CommandLineInterface
     *
     * @param data (as String)
     * @since v.1 (9.11.2020)
     */
    private void sendData(String data) {
        if (data.length() == 0) {
            commandLine.write("No message was entered.");
            logger.log("No message was entered.");
        }
        if (communicator.send(this.stringToByteArray(data))) {
            logger.log("Sent to server: " + data);
            String recv = byteArrayToString(communicator.receive());

            if (recv != null) {
                logger.log("Received from server: " + recv);
                commandLine.write(recv);
            } else {
                logger.log("Nothing received from the server.");
                commandLine.write("Nothing received from the server.");
            }
        }
    }


    /**
     * converts Input (given as byte array) to a String
     *
     * @param data
     * @return String input
     * @since v.1 (9.11.2020)
     */
    private static String byteArrayToString(byte[] data) {
        String retValue = "";
        if (data == null)
            return null;
        for (int i = 0; i < data.length; i++) {
            if (data[i] == '\r' && i < data.length - 1) {
                if (data[i + 1] == '\n') {
                    break;
                }
            }
            retValue = retValue + (char) data[i];
        }
        return retValue;
    }


    /**
     * Converts a String to a Byte array and adds the linefeed
     *
     * @param data (for sending back to client as String)
     * @return Byte array with added linefeed
     * @since v.1 (9.11.2020)
     */
    private static byte[] stringToByteArray(String data) {
        return (data + "\r\n").getBytes();
    }
}
