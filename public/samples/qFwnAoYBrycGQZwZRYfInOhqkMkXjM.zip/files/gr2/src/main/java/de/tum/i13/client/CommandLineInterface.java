package de.tum.i13.client;

import de.tum.i13.client.Logging.LogImpl;
import de.tum.i13.client.Logging.LoggingInterface;
import org.beryx.textio.TextIO;
import org.beryx.textio.TextIoFactory;

import java.util.logging.Logger;

/*
 * <!-- Command Line Interface -->
        <dependency>
            <groupId>org.beryx</groupId>
            <artifactId>text-io</artifactId>
            <version>3.4.1</version>
        </dependency>
        <dependency>
            <groupId>io.ratpack</groupId>
            <artifactId>ratpack-core</artifactId>
            <version>1.5.1</version>
        </dependency>
        <dependency>
            <groupId>io.ratpack</groupId>
            <artifactId>ratpack-session</artifactId>
            <version>1.5.1</version>
        </dependency>
        <!-- Command Line Interface -->
 */

/**
 * Creates and handles the CommandLineInterface visible for the user.
 */

public class CommandLineInterface {
    private TextIO textIO = TextIoFactory.getTextIO();
    private final static Logger LOGGER = Logger.getLogger(Client.class.getName());
    private LoggingInterface logger;

    public CommandLineInterface(LoggingInterface logger) {
        this.logger = logger;
    }

    //creates Command-line Interface using String

    /**
     * creates CommandLineInterface; sets max length; writes "EchoClient> "; reads everything behind
     * @return the String which was read
     */
    public String read() {
        String input = textIO.newStringInputReader()
                .withMaxLength(127998 + 5)
                .read("EchoClient>");
        return input;
    }


    /**
     * displays String to User
     * @param str (String to be displayed)
     */
    public void write(String str) {
        textIO.getTextTerminal().println("EchoClient> "+str);
    }


    /**
     * stops the CommandLineInterface
     */
    public void stop() {
        textIO.dispose();
    }

}
