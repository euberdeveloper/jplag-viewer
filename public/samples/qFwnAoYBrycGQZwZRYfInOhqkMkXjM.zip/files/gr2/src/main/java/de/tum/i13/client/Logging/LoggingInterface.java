package de.tum.i13.client.Logging;

import java.util.logging.Level;


/**
 * defines the Logging
 */

public interface LoggingInterface {


    void log(String message);


    /**
     * both methods change the current log level to the new
     * -> returns the old one to be able to print the confirmation message
     */
    Level changeLogLevel(Level newLevel);
    Level changeLogLevel(String input);

    Level getLevel();
}
