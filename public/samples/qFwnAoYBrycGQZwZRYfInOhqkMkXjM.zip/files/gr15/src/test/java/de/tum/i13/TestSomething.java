package de.tum.i13;

import de.tum.i13.client.Client;
import org.junit.jupiter.api.Test;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.PrintStream;

import static org.junit.jupiter.api.Assertions.assertEquals;

public class TestSomething { //Classname has to start with Test

    @Test
    public void testDoubleConnection() {
        String input =
                "connect clouddatabases.msrg.in.tum.de 5551\n" +
                        "send test\n" +
                        "connect clouddatabases.msrg.in.tum.de 5551\n" +
                        "connect clouddatabases.msrg.in.tum.de 5551\n" +
                        "disconnect\n" +
                        "send test\n" +
                        "quit";
        InputStream in = new ByteArrayInputStream(input.getBytes());
        System.setIn(in);
        Client.main(null);
    }

    @Test
    public void testDoubleDisconnect() {
        String input =
                "connect clouddatabases.msrg.in.tum.de 5551\n" +
                        "send test\n" +
                        "connect clouddatabases.msrg.in.tum.de 5551\n" +
                        "disconnect\n" +
                        "disconnect\n" +
                        "send test\n" +
                        "quit";
        InputStream in = new ByteArrayInputStream(input.getBytes());
        System.setIn(in);
        Client.main(null);
    }

    @Test // Test if program throws errors when confronted with the chinese navy seals copypasta and emojis
    public void testNonAscii() {
        String input =
                "connect clouddatabases.msrg.in.tum.de 5551\n" +
                        "send 他妈的， 你刚刚对我说什么废话? 我应让你知道我是毕业海豹部队班的优等生，参与无数基地组织 \uD83D\uDE02\uD83D\uDE02\n" +
                        "quit";
        InputStream in = new ByteArrayInputStream(input.getBytes());
        System.setIn(in);
        Client.main(null);
    }

    @Test // Test if program throws exception if message is 128k characters
    public void testMessage128K() {
        String input = "connect clouddatabases.msrg.in.tum.de 5551\nsend ";
        for (int i = 0; i < 127998; i++) {
            input += "A"; // AAAAAAAAA
        }
        input += "\nquit";
        InputStream in = new ByteArrayInputStream(input.getBytes());
        System.setIn(in);
        Client.main(null);
    }

    @Test // Test if program works with a message that exceeds 128K
    public void testMessageMoreThan128K() {
        String input = "connect clouddatabases.msrg.in.tum.de 5551\nsend ";
        for (int i = 0; i < 130000; i++) {
            input += "A"; // more AAAAAAAAA
        }
        input += "\nquit";
        InputStream in = new ByteArrayInputStream(input.getBytes());
        System.setIn(in);
        Client.main(null);
    }

    @Test
    public void testSendGenericMessage() {
        PrintStream console = System.out;
        ByteArrayOutputStream bytes = new ByteArrayOutputStream();
        System.setOut(new PrintStream(bytes));
        String input = "connect clouddatabases.msrg.in.tum.de 5551\nsend test";
        input += "\nquit";
        InputStream in = new ByteArrayInputStream(input.getBytes());
        System.setIn(in);
        Client.main(null);
        System.setOut(console);
        String actualOutput = bytes.toString();
        int testIndex = actualOutput.indexOf("test");
        String actualMessage = actualOutput.substring(testIndex, testIndex + 4);
        assertEquals("test", actualMessage);
    }
}
