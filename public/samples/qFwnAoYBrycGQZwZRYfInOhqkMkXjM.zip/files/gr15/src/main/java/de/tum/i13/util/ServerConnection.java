package de.tum.i13.util;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.Socket;
import java.net.UnknownHostException;

/**
 * Class containing the TCP-Server connection tools like the socket, and input-output streams.
 * Also handles the reading and writing from the EchoServer
 */
public class ServerConnection {

    boolean isConnected = false;
    private Socket clientSocket;
    private InputStream inputStream;
    private OutputStream outputStream;

    ServerConnection() {
        clientSocket = new Socket();
    }

    /**
     * Connects to a TCP-server and opens the input and output streams
     *
     * @param address IP address of the server
     * @param port    number of the port
     * @throws UnknownHostException if an unknown or invalid IP address/port is passed
     * @throws IOException          if an I/O error occurs when creating the streams, or if the socket is not connected
     */
    void connect(String address, int port) throws UnknownHostException, IOException {
        clientSocket = new Socket(address, port);
        isConnected = true;
        inputStream = clientSocket.getInputStream();
        outputStream = clientSocket.getOutputStream();
    }

    /**
     * Disconnects from the server, closes the streams
     * and sets the isConnected flag to false
     */
    void disconnect() throws IOException {
        isConnected = false;
        inputStream.close();
        outputStream.close();
        clientSocket.close();
    }

    /**
     * Sends byte-encoded message to server via the sockets' outputstream
     *
     * @param encodedMessage message as a byte array
     * @throws IOException If an error occurs while writing to the output stream
     */
    void write(byte[] encodedMessage) throws IOException {
        outputStream.write(encodedMessage);
        outputStream.flush();
    }

    /**
     * Receives messages from sockets' inputStream
     *
     * @return the String the server returned (truncated the last char)
     * @throws IOException If an error occurs while reading from the stream
     */
    String read() throws IOException {
        boolean isCarrRet = false;
        int currByte;
        StringBuilder message = new StringBuilder();
        while ((currByte = inputStream.read()) != 10 && !isCarrRet) {
            message.append((char) currByte);
            isCarrRet = currByte == 13;
        }
        return message.substring(0, message.length() - 1);
    }

    public String getServerName() {
        return clientSocket.getInetAddress().toString();
    }

    public int getServerPort() {
        return clientSocket.getPort();
    }
}
