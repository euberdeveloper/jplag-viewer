package de.tum.i13.util;

import de.tum.i13.client.Client;

import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;

import static de.tum.i13.shared.LogSetup.setupLogging;

/**
 * The CommandHandler is responsible for all application logic. The user interacts with the CommandHandler which
 * parses the user's CLI input and executes the commands or prints a warning on invalid input.
 * Server interaction is processed and passed on to the ServerConnection object.
 * The actual connection socket and streams are located in ServerConnection class.
 */
public class CommandHandler {
    private final static Logger LOGGER = Logger.getLogger(Client.class.getName());
    private final ServerConnection serverConnection;

    public CommandHandler() {
        this.serverConnection = new ServerConnection();
        LOGGER.setLevel(setupLogging("test.log").getLevel());
    }

    /**
     * A string array is returned as a single string separated by separator.
     *
     * @param words     This is the string array of single words
     * @param separator This is the separator between each element of words
     * @return A single string of each element of words separated by separator
     */
    static String convertStrArrayToStr(String[] words, String separator) {
        if (words.length == 0) {
            return "";
        }
        if (words.length == 1) {
            return words[0];
        }
        StringBuilder str = new StringBuilder(words[0]);
        for (int i = 1; i < words.length; i++) {
            str.append(separator).append(words[i]);
        }
        return str.toString();
    }

    /**
     * Attempts to connect to the requested Server and waits an acknowledgement.
     *
     * @param address Internet address of the requested Server
     * @param port    port number
     */
    private void connect(String address, int port) {
        if (serverConnection.isConnected) {
            LOGGER.warning("Client is already connected to a server.");
            System.err.println("EchoClient> You are already connected to a server.");
        } else {
            try {
                serverConnection.connect(address, port);
                String connectionOutput = serverConnection.read();
                LOGGER.info("Client connected to " + address + ":" + port);
                System.out.println("EchoClient> " + connectionOutput);
            } catch (java.net.UnknownHostException e) {
                LOGGER.info("Connection failed: Host unknown");
                System.err.println("EchoClient> Connection failed: Unknown host");
            } catch (IOException err) {
                LOGGER.info("Connection failed: I/O error");
                System.err.println("EchoClient> Connection failed: I/O error");
            }
        }
    }

    /**
     * Closes the connection to the server and handles possible errors
     */
    private void disconnect() {
        if (serverConnection.isConnected) {
            LOGGER.info("The client terminated the connection with: " + serverConnection.getServerName() +
                    ":" + serverConnection.getServerPort());
            System.out.println("EchoClient> Connection terminated: " + serverConnection.getServerName() +
                    ":" + serverConnection.getServerPort());
            try {
                serverConnection.disconnect();
                System.out.println("EchoClient> Disconnected from server");
            } catch (IOException e) {
                LOGGER.warning("Exception occurred while disconnecting from server.");
            }
            serverConnection.isConnected = false;
        } else {
            LOGGER.warning("Client can't disconnect from the server because they aren't connected.");
            System.err.println("EchoClient> You cannot disconnect because you are not connected to a server.");
        }
    }

    /**
     * Sets the new log level of the logger.
     * The new log level is given by the client as a parameter when calling logLevel in the command line.
     *
     * @param level the new log level
     */
    private void setLogLevel(Level level) {
        LOGGER.info("Setting LOGGER.level to " + level.getName());
        System.out.println("EchoClient> logLevel set from " + LOGGER.getLevel() + " to " + level.getName());
        LOGGER.setLevel(level);
    }

    /**
     * The help method outputs to the user the commands he can call in the terminal, and the correct way of calling them.
     * This method is called whenever the client gives a false command, or when he calls the method itself.
     */
    private void help() {
        System.out.println(
                "\tconnect <address> <port>: Connect to address using port\n" +
                        "\tdisconnect: Disconnect from the connected server\n" +
                        "\tsend <message>: Send a text message to the server\n" +
                        "\tlogLevel <level>: Sets the logger level to the specified level. Valid logger levels are " +
                        "{ALL | SEVERE | WARNING | INFO | CONFIG | FINE | FINER | FINEST | OFF}\n" +
                        "\thelp: Display a list of commands\n" +
                        "\tquit: Disconnect from the server and exit the application");
    }

    /**
     * Sends a message to the connected server.
     * Checks for messages that exceed 128kb or contain non-ASCII characters.
     * The server-response is received and printed out.
     *
     * @param message string to be sent to the server
     */
    private void send(String message) {
        if (!serverConnection.isConnected) {
            LOGGER.warning("The client tried to send a message to the server while he was not connected.");
            System.err.println("EchoClient> You can't send a message to the server as you are not connected.");
            return;
        }
        LOGGER.info("The client sent the message: " + message);
        message += "\r\n";
        byte[] encodedMessage = message.getBytes();
        if (encodedMessage.length > 128000) {
            LOGGER.warning("Message too long: User tried to sent message length " + encodedMessage.length);
            System.err.println("EchoClient> Message is too long. May not exceed 128,000 characters");
            return;
        }
        if (message.length() != encodedMessage.length) {
            LOGGER.warning("Non-ASCII characters: User tried to send message including non-ASCII characters");
            System.err.println("EchoClient> Message includes non-ASCII characters");
            return;
        }
        try {
            serverConnection.write(encodedMessage);
        } catch (IOException e) {
            LOGGER.warning("The message couldn't be sent to the server.");
            System.err.println("EchoClient> The message could not be sent to the server. Please check your internet connection");
        }
        try {
            String output = serverConnection.read();
            LOGGER.info("Server responded with: " + output);
            System.out.println("EchoClient> " + output);
        } catch (IOException e) {
            LOGGER.warning("The user couldn't read from server.");
            System.err.println("EchoClient> The message could not be received from the server. Please check your internet connection");
        }
    }

    /**
     * Print out unknown command message and help message when an invalid command is entered.
     *
     * @param command the command the user tried to enter
     */
    private void unknownCommand(String command) {
        System.err.println("\"" + command + "\" is not a valid command. List of valid commands:");
        help();
    }

    /**
     * Parses the input passed by the user as a string array and accepts valid connect, disconnect,
     * send, logLevel, help, and quit commands.
     * Also checks for empty arguments.
     *
     * @param args User input as string array
     */
    public void parseArgs(String[] args) {
        switch (args[0]) {
            case "connect":
                if (args.length != 3) {
                    LOGGER.warning("False number of attributes provided.");
                    System.err.println("EchoClient> You have provided a false number of arguments. See help.");
                } else {
                    try {
                        connect(args[1], Integer.parseInt(args[2]));
                    } catch (NumberFormatException e) {
                        LOGGER.warning("Invalid port number: User did not enter a number as a port");
                        System.err.println("EchoClient> Invalid port number entered");
                    }
                }
                break;
            case "disconnect":
                if (args.length != 1) {
                    LOGGER.warning("Disconnect called with extra args");
                    System.err.println("EchoClient> Disconnect called with extra args. See help");
                    help();
                } else {
                    disconnect();
                }
                break;
            case "send":
                if (args.length == 1) { // This also catches the case the user entered "send     " (whitespaces),
                    // figured that shouldn't be valid
                    LOGGER.warning("Empty message: User tried to send an empty message");
                    System.err.println("EchoClient> No message specified. See help:");
                    help();
                } else {
                    // New array for message
                    String[] argsCut = new String[args.length - 1];
                    // Copy everything but command
                    System.arraycopy(args, 1, argsCut, 0, argsCut.length);
                    String message = convertStrArrayToStr(argsCut, " ");
                    send(message);
                }
                break;
            case "logLevel":
                if (args.length != 2) {
                    LOGGER.warning("User provided the wrong number of logLevel arguments");
                    System.err.println("EchoClient> Invalid use of logLevel: \n\t" + // may get printed after new "EchoClient>" prompt for some reason
                            "logLevel {ALL | SEVERE | WARNING | INFO | CONFIG | FINE | FINER | FINEST | OFF}");
                } else {
                    try {
                        setLogLevel(Level.parse(args[1]));
                    } catch (IllegalArgumentException e) {
                        LOGGER.warning("Invalid logging level entered");
                        System.err.println("EchoClient> " + args[1] + " is not a valid logger level. " +
                                "Valid logger levels are {ALL | SEVERE | WARNING | INFO | CONFIG | FINE | FINER | FINEST | OFF}");
                    }
                }
                break;
            case "help": // Also gets entered in cases of "help me", but that's not a bug, that's a feature
                help();
                break;
            case "quit": // Also gets entered in cases of "quit outta here"
                if (serverConnection.isConnected) {
                    disconnect();
                }
                LOGGER.info("Quitting application");
                break;
            default:
                unknownCommand(args[0]);
        }
    }
}
