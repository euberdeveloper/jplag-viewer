package de.tum.i13.client;

import de.tum.i13.util.CommandHandler;

import java.util.Scanner;

public class Client {
    /**
     * The entry point of application. User Commands will be read,
     * parsed and passed to the command handlers
     *
     * @param args the input arguments the user gives in the terminal (None are configured)
     */
    public static void main(String[] args) {
        CommandHandler commandHandler = new CommandHandler();
        Scanner scanner = new Scanner(System.in);
        String input;
        String[] splitIn; // saves the individual words entered to the CLI
        do {
            System.out.print("EchoClient> ");
            input = scanner.nextLine();
            splitIn = input.split(" ");
            commandHandler.parseArgs(splitIn);
        } while (!splitIn[0].equals("quit"));
        System.out.println("Application exit!");
    }
}
