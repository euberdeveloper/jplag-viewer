package de.tum.i13.command;

import java.io.IOException;
import java.io.UnsupportedEncodingException;

import de.tum.i13.client.DatabaseConnector;
import de.tum.i13.shared.Constants;

import java.util.logging.Handler;
import java.util.logging.Level;
import java.util.logging.LogManager;
import java.util.logging.Logger;

/**
 * The different functionalities of the echo client application are specified in
 * this class. The class Parser uses the helper class Commands to execute user's
 * command requests.
 * 
 * @author gr4
 */
public class Commands {

	private static final Logger LOGGER = Logger.getLogger(Commands.class.getName());
	private DatabaseConnector connector = new DatabaseConnector(); // Controls a socket-based communication

	/**
	 * Connects the client to the server and creates an output to notify the user
	 * about the status of the connection.
	 * 
	 * @param hostAddress: The address of the host server.
	 * @param port: An Integer representing the port, to which the client wishes to
	 *        connect.
	 */
	public void connect(String hostAddress, int port) {

		LOGGER.info("Connect command executed.");
		if (port < 0 || port > 65535) {// invalid port
			LOGGER.warning("Port " + port + " is out of range.");
			System.out.println("EchoClient> Error: Invalid port.");
			return;
		}

		if (connector.connect(hostAddress, port)) { // tries to connect to the server
			LOGGER.info("Connecting to server: " + hostAddress + port);
			try {
				byte[] confirmationMessageInBytes = connector.receive();
				LOGGER.info("Confirmation message received.");
				if (confirmationMessageInBytes != null) {
					String confirmationMessage = new String(confirmationMessageInBytes, Constants.TELNET_ENCODING);
					System.out.println("EchoClient> " + confirmationMessage); // Successful connection
				} else {
					LOGGER.info("Error in connection. The confirmation got lost.");
					System.out.println("EchoClient> Error! connection lost.");
					return;
				}
			} catch (UnsupportedEncodingException e) {
				LOGGER.warning("There seems to be a problem with encoding byte[] to String.");
				e.printStackTrace();
				System.out.println("EchoClient> Error! could not encode echo reply.");
				return;
			}

		} else
			System.out.println("EchoClient> Error: Failed to connect."); // The connection could not be established.
	}

	/**
	 * Tries to disconnect from the echo server. It also notifies the user about the
	 * status of the disconnection.
	 */
	public void disconnect() {
		LOGGER.info("Disconnect command executed.");
		if (connector.disconnect()) {
			LOGGER.info("Disconnecting from server");
			System.out.println("EchoClient> You have been successfully disconnected from the server.");
		} else
			System.out.println("EchoClient>  Error: You are not connected.");
	}

	/**
	 * Provides a list of acceptable commands
	 */
	public void help() {
		LOGGER.info("Help command executed.");
		System.out.println(
				"The echo client is used to connect to an echo server. Please refer to the following available commands:");
		System.out.println("connect <host> <port>:   Establishes a TCP connection to the specified address.");
		System.out.println("disconnect:              Disconnects from a server.");
		System.out.println("help <command>:          Shows the application and the syntax of <command>.");
		System.out.println("logLevel <level>:        Sets the logger to the specified log level. ");
		System.out.println("quit:                    Tears down the active connection to the server.");
		System.out.println("send <message>:          Sends a text message to the echo server. ");
	}

	/**
	 * Provides for each command its syntax and purpose.
	 * 
	 * @param command: A string representing the command, for which more detail is
	 *        wished.
	 */
	public void help(String command) {
		LOGGER.info("Help command executed.");
		System.out.print("EchoClient> ");

		switch (command) {
		case "connect":
			System.out.println("connect <host> <port>:   Establishes a TCP connection to the specified address. "
					+ "In case of success a confirmation is displayed.");
			break;
		case "disconnect":
			System.out.println(
					"disconnect:   Disconnects from a server. " + "In case of success a confirmation is displayed.");
			break;
		case "help":
			System.out.println("help:   Shows the intended usage of the client application and"
					+ " describes its set of commands.");
			System.out.println("help <command>:  Shows the application and the syntax of <command>.");
			break;
		case "logLevel":
			System.out.println("logLevel <level>:   Sets the logger to the specified log level. "
					+ "In case of success a confirmation is displayed.");
			break;
		case "quit":
			System.out.println(
					"quit:   Tears down the active connection to the server and" + " exits the program execution.");
			break;
		case "send":
			System.out.println(
					"send <message>:   Sends a text message to the echo server. " + "Recives the same message back.");
			break;
		default:
			System.out.println("Error! Command cannot be resolved.");
			System.out.println(
					"The echo client is used to connect to an echo server. Please refer to the following available commands:");
			System.out.println("connect <host> <port>:   Establishes a TCP connection to the specified address.");
			System.out.println("disconnect:              Disconnects from a server.");
			System.out.println("help <command>:          Shows the application and the syntax of <command>.");
			System.out.println("logLevel <level>:        Sets the logger to the specified log level. ");
			System.out.println("quit:                    Tears down the active connection to the server.");
			System.out.println("send <message>:          Sends a text message to the echo server. ");
			System.out.println();
			break;
		}
	}

	/**
	 * Sets the log level to level and prints out a confirmation message.
	 * 
	 * @param level: The new log level
	 */
	public void logLevel(String level) {
		Logger newLogger = LogManager.getLogManager().getLogger("");
		String prevLevel = Logger.getLogger("").getLevel().getName();

		// Set the log level
		switch (level) {
		case "ALL":
			newLogger.setLevel(Level.ALL);
			break;
		case "OFF":
			newLogger.setLevel(Level.OFF);
			break;
		case "SEVERE":
			newLogger.setLevel(Level.SEVERE);
			break;
		case "WARNING":
			newLogger.setLevel(Level.WARNING);
			break;
		case "INFO":
			newLogger.setLevel(Level.INFO);
			break;
		case "CONFIG":
			newLogger.setLevel(Level.CONFIG);
			break;
		case "FINE":
			newLogger.setLevel(Level.FINE);
			break;
		case "FINER":
			newLogger.setLevel(Level.FINER);
			break;
		case "FINEST":
			newLogger.setLevel(Level.FINEST);
			break;
		default:
			LOGGER.warning("Invalid level argument.");
			System.out.println("EchoClient> Error: " + level + " is not a valid log level.");
			return;
		}
		// Set up handler level
		for (Handler handler : newLogger.getHandlers()) {
			handler.setLevel(newLogger.getLevel());
		}

		System.out.println("EchoClient> loglevel set from " + prevLevel + " to " + level.toUpperCase());
	}

	/**
	 * Tears down the active connection to the server and exits the program
	 * execution.
	 */
	public void quit() {
		LOGGER.info("quit command executed.");
		if (connector.isConnected())
			connector.disconnect();
		System.out.println("EchoClient> You quit the program.");
	}

	/**
	 * The command send will send a message to an echo server and display the
	 * server's response.
	 * 
	 * @param text: A String, which will be sent to the echo server.
	 */
	public void send(String text) {
		LOGGER.info("send command executed.");
		// Encode according to ISO-8859-1
		try {

			byte[] messageInBytes = text.getBytes(Constants.TELNET_ENCODING);

			if (messageInBytes.length > 128000) {
				LOGGER.warning("Message too big.");
				System.out.println("EchoClient> Error! Message too large.");
				return;
			}

			// Send the message
			if (connector.send(messageInBytes)) {

				// Echo Reply
				byte[] echoReplyInBytes = connector.receive();

				if (echoReplyInBytes == null) { // Empty response
					LOGGER.warning("Could not receive echo reply because the client is not connected.");
					System.out.println("EchoClient> Error: You are not connected.");
					return;
				}

				if (echoReplyInBytes.length > 128000) { // 128KB
					LOGGER.warning("Message too big.");
					return;
				}

				// Encode according to ISO-8859-1
				String echoReply = new String(echoReplyInBytes, Constants.TELNET_ENCODING);
				LOGGER.info("Echo reply has been encoded in String.");
				System.out.println("EchoClient> " + echoReply);
			} else {
				LOGGER.warning("Failed to send the message.");
				System.out.println("EchoClient> Error! could not sent the message.");
			}
		} catch (UnsupportedEncodingException e) {
			e.printStackTrace();
			LOGGER.warning("There seems to be a problem with encoding.");
			System.out.println("EchoClient> Error! Wrong message format.");
			return;
		}
	}

	/**
	 * Creates an output, when the command is undefined.
	 */
	public void miscellaneous() {
		LOGGER.info("Undefined command executed.");
		System.out.print("EchoClient> ");
		System.out.println("Error! Command cannot be resolved.");
		System.out.println(
				"The echo client is used to connect to an echo server. Please refer to the following available commands:");
		System.out.println("connect <host> <port>:   Establishes a TCP connection to the specified address.");
		System.out.println("disconnect:              Disconnects from a server.");
		System.out.println("help <command>:          Shows the application and the syntax of <command>.");
		System.out.println("logLevel <level>:        Sets the logger to the specified log level. ");
		System.out.println("quit:                    Tears down the active connection to the server.");
		System.out.println("send <message>:          Sends a text message to the echo server. ");
	}
}
