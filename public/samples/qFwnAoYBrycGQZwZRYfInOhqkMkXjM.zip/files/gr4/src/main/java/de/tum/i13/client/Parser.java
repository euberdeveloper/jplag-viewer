package de.tum.i13.client;

import de.tum.i13.command.Commands;

import java.util.logging.Logger;

/**
 * The Parser class is used by the shell to parse the user input, recognize the
 * intended command and call the corresponding method.
 *
 * @author gr4
 */
public class Parser {

	private static final Logger LOGGER = Logger.getLogger(Parser.class.getName());
	private boolean terminated = false;
	Commands commands = new Commands();

	/**
	 * Splits the user input into tokens, identifies what command is executed and
	 * calls the corresponding methods
	 *
	 * @param line input of the console
	 */
	public void parse(String line) {

		String[] tokens = line.trim().split("\\s+");

		switch (tokens[0]) {
		case "connect":
			parseConnect(tokens);
			break;
		case "disconnect":
			commands.disconnect();
			break;
		case "send":
			parseSend(tokens);
			break;
		case "logLevel":
			parseLogLevel(tokens);
			break;
		case "help":
			if (tokens.length <= 1)
				commands.help();
			else
				commands.help(tokens[1]);
			break;
		case "quit":
			commands.quit();
			terminated = true;
			break;
		default:
			commands.miscellaneous();
			break;
		}
	}

	/**
	 * Parses the input of the console and executes the connect command
	 *
	 * @param args input of the console split into an array of tokens
	 */
	private void parseConnect(String[] args) {
		// the connect command needs two arguments: address and port
		if (args.length <= 2) {
			LOGGER.warning("User didn't enter required address and port arguments.");
			System.out.println("EchoClient> Error: connect needs address and port arguments!");
			return;
		}

		// the port argument must be parsed to integer and might throw a
		// NumberFormatException
		try {
			String address = args[1];
			int port = Integer.parseInt(args[2]);

			commands.connect(address, port);
		} catch (NumberFormatException nfe) {
			LOGGER.warning("Entered port argument is not an integer.");
			System.out.println("EchoClient> Error: The port argument must be an integer!");
		}
	}

	/**
	 * Parses the input of the console and executes the send command
	 *
	 * @param args input of the console split into an array of tokens
	 */
	private void parseSend(String[] args) {
		// the send command needs a message argument
		if (args.length <= 1) {
			LOGGER.warning("User didn't enter required message argument.");
			System.out.println("EchoClient> Error: send needs a message argument!");
			return;
		}

		/*
		 * the tokens need to be recombined to build the message the server expects the
		 * message to end with "\r\n"
		 */
		StringBuilder message = new StringBuilder(args[1]);
		for (int i = 2; i < args.length; i++) {
			message.append(" ").append(args[i]);
		}
		message.append("\r\n");

		commands.send(message.toString());
	}

	/**
	 * Parses the input of the console and executes the logLevel command
	 *
	 * @param args input of the console split into an array of tokens
	 */
	private void parseLogLevel(String[] args) {
		// the logLevel command needs a level argument
		if (args.length <= 1) {
			LOGGER.warning("User didn't enter required level argument.");
			System.out.println("EchoClient> Error: logLevel needs a level argument!");
			return;
		}

		String level = args[1].toUpperCase();

		commands.logLevel(level);
	}

	/**
	 * Returns true if the shell was terminated by the quit command, false otherwise
	 *
	 * @return true if quit command has been executed
	 */
	public boolean isTerminated() {
		return terminated;
	}
}
