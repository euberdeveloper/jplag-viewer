package de.tum.i13.client;

import de.tum.i13.shared.LogSetup;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.logging.*;

/**
 * The Shell class acts as a command line interface for the user. The user input
 * is parsed with the help of the Parser class.
 *
 * @author gr4
 */
public class Shell {
	// connect clouddatabases.msrg.in.tum.de 5551
	private static final Logger LOGGER = Logger.getLogger(Shell.class.getName());

	public static void main(String[] args) {
		try {
			BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));
			Parser parser = new Parser();

			LogSetup.setupLogging("EchoClient.log");
			LOGGER.info("Starting EchoClient");
			LOGGER.setLevel(Level.ALL);

			// loop until the quit command is called
			while (!parser.isTerminated()) {
				// print out prompt and read the user input from the console
				System.out.print("EchoClient> ");
				String line = reader.readLine();

				if (line == null || line.length() == 0) {
					continue;
				} else {
					LOGGER.info("Received user input: " + line);
				}

				parser.parse(line);
			}
		} catch (Exception e) {
			LOGGER.warning("IO problem in shell class.");
			LOGGER.throwing(Shell.class.getName(), "main", e);
		}
	}
}
