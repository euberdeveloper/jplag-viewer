package de.tum.i13.client;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.UnsupportedEncodingException;
import java.net.Socket;
import java.nio.charset.Charset;
import java.util.StringTokenizer;
import java.util.logging.Level;
import java.util.logging.Logger;

public class CommunicationInterface {

    public static Logger getLOGGER() {
        return LOGGER;
    }

    private final static Logger LOGGER = Logger.getLogger(TestClient.class.getName());

    public InputStream getIn() {
        return in;
    }

    public OutputStream getOut() {
        return out;
    }

    public Socket getSocket() {
        return socket;
    }

    private InputStream in;
    private OutputStream out;
    private Socket socket = new Socket();

    public String establishConnection(String address, int port) {
        LOGGER.info("Creating a new Socket");
        try {
            if(socket.isConnected()) {
                throw new Error("Socket is already connected!");
            }
            socket = new Socket(address, port);
            LOGGER.info("Connecting to server");
            in = socket.getInputStream();
            out = socket.getOutputStream();
            LOGGER.info("Getting the outputstream and inputstream");
            String received = receiveMessage();
            return received;
        } catch (IOException | Error e) {
            e.printStackTrace();
        }
        return "";
    }

    public void disconnect() {
        if (socket.isConnected()) {
            try {
                LOGGER.info("Disconnecting from " + socket.getInetAddress());
                in.close();
                out.close();
                socket.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

    public String receiveMessage() {
        String received = "";
        try {
            //int size = in.available();
            //System.out.println(size);
            byte[] rec = new byte[128000];
            int i = 0;
            int value = 0;
            do {
                value = in.read();
                if (value == -1) {
                    break;
                }
                rec[i] = (byte) value; //convert integer to byte
                i++;
            } while (value != 10); //10 is the last integer sent, but it's not -1, probably because in ISO-8859-1?
            LOGGER.info("Received " + i + " byte from the server.");
            byte[] subArray = new byte[i];
            System.arraycopy(rec, 0, subArray, 0, i);
            received = new String(subArray, "ISO-8859-1"); //decode ISO-8859-1
        } catch (IOException e) {
            LOGGER.severe(e.toString());
            e.printStackTrace();
        }
        LOGGER.info("Received message: " + received);
        return received;
    }

    public int sendMessage(String message, Charset charsetName) {
        if (!socket.isConnected()) {
            LOGGER.severe("Socket not connected.");
            return -1;
        }
        if (socket.isClosed()) {
            LOGGER.severe("Socket is closed.");
            return -1;
        }

        byte[] encoded = new byte[0];
        try {
            encoded = message.getBytes(charsetName); //encode to desired ISO-8859-1
            out.write(encoded);
            out.flush();
            LOGGER.info("Message sent to:" + socket.getInetAddress() + ":" + socket.getPort());
        } catch (IOException e) {
            LOGGER.severe(e.toString());
            e.printStackTrace();
        }
        return 1;
    }

    public void changeLogLevel(String level) {
        switch (level) {
            case("ALL"): LOGGER.setLevel(Level.ALL); break;
            case("CONFIG"): LOGGER.setLevel(Level.CONFIG); break;
            case("FINE"): LOGGER.setLevel(Level.FINE); break;
            case("FINEST"): LOGGER.setLevel(Level.FINEST); break;
            case("INFO"): LOGGER.setLevel(Level.INFO); break;
            case("OFF"): LOGGER.setLevel(Level.OFF); break;
            case("SEVERE"): LOGGER.setLevel(Level.SEVERE); break;
            case("WARNING"): LOGGER.setLevel(Level.WARNING); break;
            default:
                LOGGER.warning("Unknown log level.");
                break;
        }
    }

}
