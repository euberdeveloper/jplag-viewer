package de.tum.i13.client;

import java.io.*;
import java.net.Socket;
import java.util.Scanner;
import java.util.logging.Logger;

import static de.tum.i13.shared.LogSetup.setupLogging;

public class TestClient {

    //connect clouddatabases.msrg.in.tum.de 5551
    public static void main(String[] args) throws InterruptedException {
        InputHandler ih = new InputHandler();
        Thread thread = new Thread(ih);
        thread.start();
        thread.join();
    }
}
