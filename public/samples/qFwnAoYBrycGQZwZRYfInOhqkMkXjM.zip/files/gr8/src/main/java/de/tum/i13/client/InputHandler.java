package de.tum.i13.client;

import java.util.Scanner;
import java.util.StringTokenizer;

import static de.tum.i13.shared.LogSetup.setupLogging;

public class InputHandler implements Runnable {

    TestClientAdapter communicationInterface;

    @Override
    public void run() {
        setupLogging("test.log");
        communicationInterface = new TestClientAdapter();

        Scanner scanner = new Scanner(System.in);
        String input;
        do {
            System.out.print("EchoClient> ");
            input = scanner.nextLine();
            String[] inputSplitted = input.split(" ");
            String command = inputSplitted[0];
            switch (command) {
                case "connect":
                    String response = communicationInterface.establishConnection(inputSplitted);
                    if (response == null) {
                        break;
                    }
                    System.out.print(response);
                    break;
                case "disconnect":
                    communicationInterface.disconnect();
                    break;
                case "logLevel":
                    communicationInterface.changeLogLevel(inputSplitted);
                    break;
                case "help":
                    printHelp();
                    break;
                case "send":

                    int ret = communicationInterface.sendMessage(inputSplitted);
                    if (ret == 1) {
                        String received = communicationInterface.receiveMessage();
                        System.out.print(received);
                    }
                    break;
                case "quit":
                    communicationInterface.disconnect();
                    break;
                default:
                    CommunicationInterface.getLOGGER().warning("Wrong command, try to use the help command");
                    printHelp();
                    break;
            }
        } while (!input.trim().equals("quit"));
    }

    private void printHelp() {
        String out = "This is the client side logic for an echo server.\nTo use this client connect to a server using the connect" +
                "command. Then send your messages using the send command.\n\n";

        out += "LIST OF COMMANDS:\n";
        out += "- connect <address> <port> : Command used to connect to an echo server.\n" +
                "- disconnect : disconnects from a server if a connections has been established.\n" +
                "- send <message> : Sends a message to the echo server if a connection exists.\n" +
                "- logLevel [level] :  Sets the log level. Options are (ALL | CONFIG | FINE | FINEST | INFO| OFF | SEVERE | WARNING).\n" +
                "- quit : Disconnects from the server and stops the client.\n";
        System.out.println(out);
    }
}
