package de.tum.i13.client;

import java.nio.charset.StandardCharsets;
import java.util.logging.Level;

public class TestClientAdapter extends CommunicationInterface{

    public String establishConnection(String[] parameters) {
        if (parameters.length - 1 != 2) {
            CommunicationInterface.getLOGGER().warning("connect command got wrong amount of parameters: got (" + (parameters.length - 1) + "), expected (2). Please try again");
            return null;
        }
        String address = parameters[1];

        int port;
        try {
            CommunicationInterface.getLOGGER().warning("Please specify a number for the port.");
            port = Integer.parseInt(parameters[2]);
        } catch (NumberFormatException e) {
            return null;
        }
        return super.establishConnection(address, port);
    }

    public int sendMessage(String[] input) {
        if (input.length < 2) {
            CommunicationInterface.getLOGGER().severe("Message is missing.");
            return -1;
        }
        StringBuilder message = new StringBuilder();
        for (int i = 1; i < input.length; i++) {
            message.append(input[i]);
            if(i + 1 != input.length) {
                message.append(" ");
            }

        }
        CommunicationInterface.getLOGGER().info("Trying to send message: " + message);
        message.append("\r\n");
        if (message.length() > 128000) {//is less than this due to encapsulation, check how many letters possible
            CommunicationInterface.getLOGGER().warning("Message is too long");
        }

        return super.sendMessage(message.toString(), StandardCharsets.ISO_8859_1);
    }

    public void changeLogLevel(String[] input) {
        if(input.length != 2) {
            CommunicationInterface.getLOGGER().severe("Wrong number of parameters given to logLevel");
            System.out.println("Wrong number of parameters. Refer to help.");
        }
        String level = input[1];
        super.changeLogLevel(level);
    }
}
