package de.tum.i13;

import de.tum.i13.client.CommunicationInterface;
import org.junit.jupiter.api.*;

import java.nio.charset.StandardCharsets;
import java.util.logging.Level;

public class TestCommunicationInterface {

    CommunicationInterface communicationInterface;

    @BeforeEach
    public void initialize() {
        communicationInterface = new CommunicationInterface();
        //communicationInterface.changeLogLevel("OFF");
    }

    @AfterEach
    public void destruct() {
        communicationInterface.disconnect();
    }

    @Test
    public void testEstablishConnection() {
        communicationInterface.establishConnection("clouddatabases.msrg.in.tum.de", 5551);
        Assertions.assertTrue(communicationInterface.getSocket().isConnected(), "Socket Connection");
    }

    @Test
    public void testDisconnect() {
        testEstablishConnection();
        communicationInterface.disconnect();
        Assertions.assertTrue(communicationInterface.getSocket().isClosed(), "Socket Disconnection");
    }

    @Test
    public void testSendAndReceive() {
        testEstablishConnection();
        int ret = communicationInterface.sendMessage("123456 Hi\r\n", StandardCharsets.ISO_8859_1);
        if(ret == 1) {
            String receive = communicationInterface.receiveMessage();
            Assertions.assertEquals("123456 Hi\r\n", receive);
        }
    }
}
