package de.tum.i13.client;


import java.io.IOException;
import java.net.Socket;
import java.util.Arrays;
import java.util.logging.Level;

import static de.tum.i13.shared.Constants.TELNET_ENCODING;

public class ClientService {
    public final String hostName;

    private final String port;
    private Socket socket;
    private final int MAX_MESSAGE_SZ = 128 * 1024;

    /**
     * The client service constructor.
     * @param hostName The name of the host
     * @param port The port.
     */
    public ClientService(String hostName, String port) {
        this.hostName = hostName;
        this.port = port;
    }

    /**
     * Establishes a connection (creates a socket) using the current instance's <b>hostName</b> and <b>port </b>
     * or throws and exception upon failure.
     * @param timeout The amount of time before the connection attempt times out in milliseconds.
     * @throws IOException  signals that an I/O exception of some sort has occurred.
     * @throws NumberFormatException signals that parsing the port to an int has failed.
     */
    public void connect(int timeout) throws IOException, NumberFormatException {
        this.socket = new Socket(this.hostName, Integer.parseInt(this.port));
        this.socket.setSoTimeout(1000 * timeout);
    }

    /**
     * closes the socket (disconnects from server).
     * @throws IOException Signals that an I/O exception of some sort has occurred.
     */
    public void close() throws IOException {
        this.socket.close();
    }

    /**
     * Checks whether or not the client is connected to the server.
     * @return <b> true </b> if it is connected and <b> false </b> otherwise.
     */
    public boolean isConnected() {
        return this.socket != null && !this.socket.isClosed();
    }

    /**
     * Parses the input stream received from the server (the socket) into a string.
     * @return The servers response as a String
     * @throws IOException Signals that an I/O exception of some sort has occurred.
     */
    public String readSocketToString() throws IOException {
        byte[] bytes = new byte[MAX_MESSAGE_SZ];
        int readBytes = this.socket.getInputStream().read(bytes);
        return new String(Arrays.copyOfRange(bytes, 0, readBytes), TELNET_ENCODING);
    }

    /**
     * Encodes the string message to telnet encoding (ISO-8859-1) to be sent to the server
     * @param data The message to be sent as a string.
     * @throws IOException Signals that an I/O exception of some sort has occurred.
     */
    public void writeStringToSocket(String data) throws IOException {
        String fullData = data + "\r\n";
        byte[] bytes = fullData.getBytes(TELNET_ENCODING);
        if (bytes.length > MAX_MESSAGE_SZ) {
            System.out.println("::TODO/ WARNING");
        }
        this.socket.getOutputStream().write(bytes);
        this.socket.getOutputStream().flush();
    }

    /**
     * A getter for the host name.
     * @return an instance's hostname
     */
     public String getHostName() {
        return hostName;
    }

    /**
     * A getter for the port.
     * @return an instance's port.
     */
    public String getPort() {
        return port;
    }

}
