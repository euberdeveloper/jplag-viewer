package de.tum.i13.client;

import java.io.IOException;
import java.util.HashMap;
import java.util.logging.Level;

import static de.tum.i13.shared.Constants.CLI_PREFIX;
import static de.tum.i13.shared.LogSetup.setupLogging;

public class ClientController {
    public HashMap<String, String> commandsHelp;
    private ClientService clientService;
    private Level logLevel;

    public ClientController() {
        logLevel = Level.INFO;
        fillCommandsMap();
    }

    /**
     * Initializes a hash map that maps <b>commands</b> to their relevant <b>messages</b>.
     */
    private void fillCommandsMap() {
        commandsHelp = new HashMap<>();
        commandsHelp.put("connect", "connect <address> - <port>. Tries to establish a TCP-connection to the echo server based on the given server address and the port number of the echo service.");
        commandsHelp.put("disconnect", "disconnect Tries to disconnect from the connected server.");
        commandsHelp.put("send", "send <message>. Sends a text message to the echo server according to the communication protocol.");
        commandsHelp.put("logLevel", "logLevel <level>. Sets the logger to the specified log level (level: One of the following log levels:(SEVERE | WARNING | ... | FINEST).");
        commandsHelp.put("help", "prints this message.");
        commandsHelp.put("quit", "Tears down the active connection to the server and exits the program execution.");
    }

    /**
     * Establishes a connection to the server if one is does not already exist.
     * @param host The host name to connect to.
     * @param port The port on the host to connect to.
     * @throws IOException  signals that an I/O exception of some sort has occurred
     */
    public void connectCommand(String host, String port) throws IOException {
        if (isSocketConnected()) {
            System.out.println(CLI_PREFIX + "ERROR! Socket Already connected!");
            return;
        }
        clientService = new ClientService(host, port);
        clientService.connect(10);
        System.out.print(CLI_PREFIX + clientService.readSocketToString());
    }

    /**
     * Tries to disconnect from the connected server.
     * @throws IOException signals that an I/O exception of some sort has occurred.
     */
    public void disconnectCommand() throws IOException {
        if (!isSocketConnected()) {
            System.out.println(CLI_PREFIX + "ERROR! Socket not connected!");
            return;
        }
        clientService.close();
        System.out.println(CLI_PREFIX + "Connection terminated: " + clientService.getHostName() + " / " + clientService.getPort());
    }

    /**
     * Sends a message to the server.
     * @param msgArray an array of strings (words that form a sentence), representing a single message to be sent.
     * @throws IOException signals that an I/O exception of some sort has occurred.
     */
    public void sendMessageCommand(String[] msgArray) throws IOException {
        if (!isSocketConnected()) {
            System.out.println(CLI_PREFIX + "ERROR! Socket not connected!");
            return;
        }
        String message = String.join(" ", msgArray);
        clientService.writeStringToSocket(message);
    }

    /**
     * Receives and prints the response message from the server.
     * @throws IOException
     */
    public void receiveMessageCommand() throws IOException {
        if (!isSocketConnected()) {
            return;
        }
        String message = clientService.readSocketToString();
        System.out.print(CLI_PREFIX + message);
    }

    /**
     * Sets the logger to the specified log level.
     * @param newlogLevel
     */
    public void setLogLevelCommand(Level newlogLevel) {
        System.out.println(CLI_PREFIX + "LogLevel Changed from " + logLevel + " to " + newlogLevel);
        logLevel = newlogLevel;
        setupLogging("client.log", logLevel);
    }

    /**
     * Shows the intended usage of the client application and describes its set of commands.
     */
    public void showHelpCommand() {
        System.out.println(CLI_PREFIX + "Available Commands");
        for (String key : commandsHelp.keySet()) {
            System.out.println(key + ": " + commandsHelp.get(key));
        }
    }

    /**
     * The default method to get called upon a user inputting an unknown command.
     * This prints and error to the user informing them that they entered an unknown command.
     */
    public void unknownCommand() {
        System.out.println(CLI_PREFIX + "ERROR! Unknown command!");
    }

    /**
     * Prints a confirmation for the user that they successfully quit the program.
     */
    public void quitCommand() {
        System.out.println(CLI_PREFIX + "Application exit!");
    }

    /**
     * Checks whether or not a socket is instantiated and is connected to the server (host:port).
     * @return <b>true</b> if a socket is instantiated and is connected to the server and <b>false</b> otherwise.
     */
    private boolean isSocketConnected() {
        return clientService != null && clientService.isConnected();
    }
}
