package de.tum.i13.shared;

public class Constants {
	public static final String TELNET_ENCODING = "ISO-8859-1"; // encoding for telnet
	public static final String CLI_PREFIX = "EchoClient> "; // prefix for cli
}
