package de.tum.i13.client;

import de.tum.i13.client.exceptions.InvalidNumberOfArgumentsException;

import java.io.IOException;
import java.util.Arrays;
import java.util.Scanner;
import java.util.logging.Level;
import java.util.logging.Logger;

import static de.tum.i13.shared.LogSetup.setupLogging;


public class Main {

    private final static Logger LOGGER = Logger.getLogger(Main.class.getName());

    /**
     * matches and runs the command if it is within the list of commands and prints the output.
     * Prints and error message and the help message otherwise (in case of an unknown command).
     * @param command The command to be executed (e.g. connect, send, disconnect, etc...).
     * @param tokens an array of strings that follow the command in the cLI. (e.g connect <token1> <token2>).
     * @param clientController an instance of the controller class with methods to be invoked according to the commands.
     *                         (handles the different commands via different functions).
     * @return The value for the quirt command. <b>true</b> if a user enter "quit" <b>false</b> otherwise.
     * @throws IOException signals that an I/O exception of some sort has occurred.
     */
    private static boolean selectCommand(String command, String[] tokens, ClientController clientController) throws IOException {
         switch (command) {
                case "connect":
                    if (tokens.length < 3) {
                        throw new InvalidNumberOfArgumentsException(2, tokens.length - 1);
                    }
                    clientController.connectCommand(tokens[1], tokens[2]);
                    break;

                case "disconnect":
                    clientController.disconnectCommand();
                    break;

                case "send":
                    if (tokens.length < 2) {
                        throw new InvalidNumberOfArgumentsException(1, tokens.length - 1);
                    }
                    String[] msgArray = Arrays.copyOfRange(tokens, 1, tokens.length);
                    clientController.sendMessageCommand(msgArray);
                    clientController.receiveMessageCommand();
                    break;

                case "logLevel":
                    if (tokens.length < 2) {
                        throw new InvalidNumberOfArgumentsException(1, 0);
                    }
                    clientController.setLogLevelCommand(Level.parse(tokens[1]));
                    break;

                case "help":
                    clientController.showHelpCommand();
                    break;

                case "quit":
                    clientController.quitCommand();
                    return true;

                default:
                    clientController.unknownCommand();
                    clientController.showHelpCommand();
                    break;
            }
            return false;
    }

    /**
     * Starts the cli and keeps it up until the user enters the "quit" command.
     */
    private static void startCLI() {
        boolean quit = false;
        Scanner scanner = new Scanner(System.in);
        ClientController clientController = new ClientController();

        while (!quit) {
            System.out.print("EchoClient> ");
            String input = scanner.nextLine();
            String[] tokens = input.trim().split("\\s+");
            String command = tokens[0];
            try {
                quit = selectCommand(command, tokens, clientController);
            } catch (Exception e) {
                LOGGER.warning(e.getMessage());
            }

        }
        scanner.close();
    }

    public static void main(String[] args) {
        setupLogging("client.log", Level.INFO);
        startCLI();
    }
}
