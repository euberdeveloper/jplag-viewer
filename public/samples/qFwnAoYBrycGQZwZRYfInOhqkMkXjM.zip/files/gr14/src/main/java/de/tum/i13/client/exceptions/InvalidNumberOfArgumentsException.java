package de.tum.i13.client.exceptions;

public class InvalidNumberOfArgumentsException extends RuntimeException {
    public InvalidNumberOfArgumentsException(int expectedArguments, int suppliedArguments) {
        super(String.format("Incorrect Number of arguments supplied. Expected %d got %d", expectedArguments, suppliedArguments));
    }
}
