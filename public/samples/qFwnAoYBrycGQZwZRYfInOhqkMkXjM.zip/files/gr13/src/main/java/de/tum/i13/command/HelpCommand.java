package de.tum.i13.command;

import de.tum.i13.client.ClientCLI;
import de.tum.i13.client.ClientLib;
import de.tum.i13.customExceptions.NotEnoughArgumentsException;
import java.util.logging.Logger;

/** The type Log level command. */
public class HelpCommand extends Command {
  private final String HELP_INFO =
      "\n connect <address> <port>: establish a connection \n disconnect: disconnect an established connection \n send <message>: to send a message \n logLevel <level>: to set the logger to the specified log level \n help: show help info \n quit: to teardown the active connection to the server and exits the program execution";

  /**
   * Instantiates a new Help command.
   *
   * @param clientCLI active CLI instance
   * @param client client
   * @param logger logger for logging errors and info
   * @param numArgs number of arguments provided
   * @param ignoreSpace boolean for ignoring whitespace
   */
  public HelpCommand(
      ClientCLI clientCLI, ClientLib client, Logger logger, int numArgs, boolean ignoreSpace) {
    super(clientCLI, client, logger, numArgs, ignoreSpace);
  }

  public void process(String[] arguments)
      throws NotEnoughArgumentsException, IllegalArgumentException {

    this.verifyArgsNo(arguments);
    logger.info(HELP_INFO);
    clientCLI.messageCLI(HELP_INFO, true);
  }
}
