package de.tum.i13.command;

import de.tum.i13.client.ClientCLI;
import de.tum.i13.client.ClientLib;
import de.tum.i13.customExceptions.NotEnoughArgumentsException;
import java.io.IOException;
import java.util.logging.Logger;

/** Command abstract acts as a template for CLI commands. */
public abstract class Command {

  /** Number of arguments */
  protected int numArgs;

  /** If true, spaces will be ignore between arguments */
  protected boolean spaceIgnored;

  /** Instance of the CLI class */
  protected ClientCLI clientCLI;

  /** Instance of the Client class */
  protected ClientLib client;

  /** The Logger. */
  protected Logger logger;

  /**
   * Instantiates a new Command.
   *
   * @param clientCLI active CLI instance
   * @param client client
   * @param logger logger for logging errors and info
   * @param numArgs number of arguments provided
   * @param ignoreSpace boolean for ignoring whitespace
   */
  public Command(
      ClientCLI clientCLI, ClientLib client, Logger logger, int numArgs, boolean ignoreSpace) {
    this.clientCLI = clientCLI;
    this.client = client;
    this.logger = logger;
    this.numArgs = numArgs;
    this.spaceIgnored = ignoreSpace;
  }

  /**
   * Gets num args.
   *
   * @return the num args
   */
  public int getNumArgs() {
    return numArgs;
  }

  /**
   * Sets num args.
   *
   * @param numArgs the num args
   */
  public void setNumArgs(int numArgs) {
    this.numArgs = numArgs;
  }

  /**
   * Is space ignored boolean.
   *
   * @return the boolean
   */
  public boolean isSpaceIgnored() {
    return spaceIgnored;
  }

  /**
   * Sets space ignored.
   *
   * @param spaceIgnored the space ignored
   */
  public void setSpaceIgnored(boolean spaceIgnored) {
    this.spaceIgnored = spaceIgnored;
  }

  /**
   * Gets client cli.
   *
   * @return the client cli
   */
  public ClientCLI getClientCLI() {
    return clientCLI;
  }

  /**
   * Sets client cli.
   *
   * @param clientCLI the client cli
   */
  public void setClientCLI(ClientCLI clientCLI) {
    this.clientCLI = clientCLI;
  }

  /**
   * Gets client.
   *
   * @return the client
   */
  public ClientLib getClient() {
    return client;
  }

  /**
   * Sets client.
   *
   * @param client the client
   */
  public void setClient(ClientLib client) {
    this.client = client;
  }

  /**
   * Verifies if the arguments given match the `numArgs` attribute.
   *
   * @param arguments Array of string arguments
   * @throws NotEnoughArgumentsException not enough arguments exception
   */
  public void verifyArgsNo(String[] arguments) throws NotEnoughArgumentsException {
    boolean exactNo = arguments != null && arguments.length == this.getNumArgs();
    if (!exactNo)
      throw new NotEnoughArgumentsException(
          " this command expect " + this.getNumArgs() + " arguments");
  }

  /**
   * Verify arguments and run command.
   *
   * @param arguments Array of string arguments
   * @throws NotEnoughArgumentsException not enough arguments exception
   * @throws IOException IO exception
   */
  public abstract void process(String[] arguments) throws NotEnoughArgumentsException, IOException;
}
