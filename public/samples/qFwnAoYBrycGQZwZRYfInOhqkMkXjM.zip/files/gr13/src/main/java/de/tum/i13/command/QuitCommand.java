package de.tum.i13.command;

import de.tum.i13.client.ClientCLI;
import de.tum.i13.client.ClientLib;
import de.tum.i13.customExceptions.NotEnoughArgumentsException;
import java.io.IOException;
import java.util.logging.Logger;

/** The type Log level command. */
public class QuitCommand extends Command {

  /**
   * Instantiates a new Quit command.
   *
   * @param clientCLI active CLI instance
   * @param client client
   * @param logger logger for logging errors and info
   * @param numArgs number of arguments provided
   * @param ignoreSpace boolean for ignoring whitespace
   */
  public QuitCommand(
      ClientCLI clientCLI, ClientLib client, Logger logger, int numArgs, boolean ignoreSpace) {
    super(clientCLI, client, logger, numArgs, ignoreSpace);
  }

  public void process(String[] arguments)
      throws IllegalArgumentException, IOException, NotEnoughArgumentsException {
    this.verifyArgsNo(arguments);
    client.disconnect();
    logger.fine("Application exit!");
    clientCLI.messageCLI("Application exit!", true);
    clientCLI.stop();
  }
}
