package de.tum.i13.client;

import static de.tum.i13.shared.LogSetup.setupLogging;

import de.tum.i13.command.Command;
import de.tum.i13.command.ConnectCommand;
import de.tum.i13.command.DisconnectCommand;
import de.tum.i13.command.HelpCommand;
import de.tum.i13.command.LogLevelCommand;
import de.tum.i13.command.QuitCommand;
import de.tum.i13.command.SendCommand;
import de.tum.i13.customExceptions.NotEnoughArgumentsException;
import java.io.IOException;
import java.io.PrintWriter;
import java.net.SocketTimeoutException;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;
import java.util.logging.Logger;

/** The type Client cli. */
public class ClientCLI {
  /** Delimiter accepted by client CLI. */
  public final String DELIMITER = "\r\n";

  private final Scanner SC = new Scanner(System.in);
  private final PrintWriter PW = new PrintWriter(System.out);
  private final Logger logger;
  /** variable to determine the state of the CLI. */
  boolean quit;

  private Map<String, Command> commands;

  /** Instantiates a new Client cli. */
  public ClientCLI() {
    ClientLib client = new ClientLib(5000);
    quit = false;
    logger = Logger.getLogger(ClientCLI.class.getName());
    // init commands in a map
    commands = new HashMap<>();
    commands.put("connect", new ConnectCommand(this, client, logger, 2, false));
    commands.put("disconnect", new DisconnectCommand(this, client, logger, 0, false));
    commands.put("logLevel", new LogLevelCommand(this, client, logger, 1, false));
    commands.put("send", new SendCommand(this, client, logger, 1, true));
    commands.put("help", new HelpCommand(this, client, logger, 0, false));
    commands.put("quit", new QuitCommand(this, client, logger, 0, false));
  }

  /**
   * messageCLI: prints a message to the console
   *
   * @param msg message to be printed to the client
   * @param hasDelimiter determine whether we should add message delimiter or not
   */
  public void messageCLI(String msg, boolean hasDelimiter) {
    PW.print("EchoClient> " + msg + (hasDelimiter ? this.DELIMITER : ""));
    PW.flush();
  }

  /**
   * Split arguments into a list of strings
   *
   * @param ignoreSpaces whether we should ignore spaces and return the whole param
   * @param args the args
   * @return string [ ] list of arguments
   */
  public String[] splitArgs(boolean ignoreSpaces, String args) {
    if (args == null || args.equals("")) return new String[0];
    if (ignoreSpaces) {
      return new String[] {args};
    } else {

      return args.split("\\s+");
    }
  }

  /** Stop the CLI from running */
  public void stop() {
    this.quit = true;
  }

  /** Start CLI */
  public void start() {
    // disable logger spamming console
    setupLogging(ClientCLI.class.getName(), "test.log");

    logger.info("Creating a new Socket");
    String userIn;
    while (!quit) {
      userIn = SC.nextLine();
      if (userIn == null) {
        break;
      }
      try {
        // split user input to 2
        String[] split = userIn.split(" ", 2);
        String command = split[0];
        String arguments = split.length > 1 ? split[1] : null;
        String[] argumentList;
        if (commands.containsKey(command)) {
          Command c = commands.get(command);
          argumentList = this.splitArgs(c.isSpaceIgnored(), arguments);
          c.process(argumentList);

        } else {
          logger.info("Unknown command");
          messageCLI("unknown Command", true);
          Command c = commands.get("help");
          argumentList = this.splitArgs(c.isSpaceIgnored(), null);
          c.process(argumentList);
        }

      } catch (SocketTimeoutException e) {

        messageCLI("Message timed out", true);
        logger.severe(e.getClass().getSimpleName() + " - " + Arrays.toString(e.getStackTrace()));

      } catch (NotEnoughArgumentsException e) {

        messageCLI("Invalid number of args," + e.getMessage() + ", refer to <help>", true);
        logger.severe("," + Arrays.toString(e.getStackTrace()));

      } catch (IllegalArgumentException e) {

        messageCLI("Invalid Argument," + e.getMessage() + ", refer to  <help>", true);
        logger.severe("Invalid Argument value," + Arrays.toString(e.getStackTrace()));

      } catch (SecurityException e) {

        messageCLI("Security Error: " + e.getMessage(), true);
        logger.severe("Error:" + e.getClass().getSimpleName() + Arrays.toString(e.getStackTrace()));

      } catch (IOException e) {

        messageCLI("Error Sending message or establishing connection: " + e.getMessage(), true);
        logger.severe("Error:" + e.getClass().getSimpleName() + Arrays.toString(e.getStackTrace()));

      } catch (Exception e) {

        messageCLI("Unknown Error:" + e.getMessage(), true);
        logger.throwing(ClientCLI.class.getName(), "main", e);
      }
    }
    PW.close();
    SC.close();
  }
}
