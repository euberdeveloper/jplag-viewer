package de.tum.i13.command;

import de.tum.i13.client.ClientCLI;
import de.tum.i13.client.ClientLib;
import de.tum.i13.customExceptions.NotEnoughArgumentsException;
import java.io.IOException;
import java.util.logging.Logger;

/** The type Connect command. */
public class ConnectCommand extends Command {

  /**
   * Instantiates a new Connect command.
   *
   * @param clientCLI active CLI instance
   * @param client client
   * @param logger logger for logging errors and info
   * @param numArgs number of arguments provided
   * @param ignoreSpace boolean for ignoring whitespace
   */
  public ConnectCommand(
      ClientCLI clientCLI, ClientLib client, Logger logger, int numArgs, boolean ignoreSpace) {
    super(clientCLI, client, logger, numArgs, ignoreSpace);
  }

  /**
   * Instantiate connection between `client` and server given by the first element of the
   * `arguments` input array and port given by the second element.
   *
   * @param arguments Array of string arguments
   * @throws IOException IO exception
   * @throws SecurityException security exception
   * @throws IllegalArgumentException illegal argument exception
   */
  public void connect(String[] arguments)
      throws IOException, SecurityException, IllegalArgumentException {

    String host = arguments[0];
    int port = Integer.parseInt(arguments[1]);

    if (client.isConnected()) {
      host = client.getHost();
      port = client.getPort();
      logger.warning("Client already connected to " + host + " / " + port);
      clientCLI.messageCLI("Client already connected to " + host + " / " + port, true);
    } else {
      client.connect(host, port);
      client.initIO();
      String response = new String(client.receive());
      logger.fine(response);
      clientCLI.messageCLI(response, false);
    }
  }

  public void process(String[] arguments) throws NotEnoughArgumentsException, IOException {
    this.verifyArgsNo(arguments);
    this.connect(arguments);
  }
}
