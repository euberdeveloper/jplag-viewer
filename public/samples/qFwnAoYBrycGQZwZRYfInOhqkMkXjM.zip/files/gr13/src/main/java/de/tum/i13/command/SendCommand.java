package de.tum.i13.command;

import de.tum.i13.client.ClientCLI;
import de.tum.i13.client.ClientLib;
import de.tum.i13.customExceptions.NotEnoughArgumentsException;
import java.io.IOException;
import java.util.logging.Logger;

/** The type Log level command. */
public class SendCommand extends Command {

  /**
   * Instantiates a new Send command.
   *
   * @param clientCLI active CLI instance
   * @param client client
   * @param logger logger for logging errors and info
   * @param numArgs number of arguments provided
   * @param ignoreSpace boolean for ignoring whitespace
   */
  public SendCommand(
      ClientCLI clientCLI, ClientLib client, Logger logger, int numArgs, boolean ignoreSpace) {
    super(clientCLI, client, logger, numArgs, ignoreSpace);
  }

  /**
   * Sends the string `message` to the server, and then waits for a reply which it prints back out
   * to the user.
   *
   * @param message message sent by the user
   * @throws IOException io exception
   */
  public void sendReceive(String message) throws IOException {
    if (!client.isConnected()) {
      logger.info("Error! Not connected!");
      clientCLI.messageCLI("Error! Not connected!", true);
    } else {
      String fullMessage = message + clientCLI.DELIMITER;
      client.send(fullMessage.getBytes());
      String response = new String(client.receive());
      logger.fine(response);
      clientCLI.messageCLI(response, false);
    }
  }

  public void process(String[] arguments)
      throws NotEnoughArgumentsException, IllegalArgumentException, IOException {
    this.verifyArgsNo(arguments);
    this.sendReceive(arguments[0]);
  }
}
