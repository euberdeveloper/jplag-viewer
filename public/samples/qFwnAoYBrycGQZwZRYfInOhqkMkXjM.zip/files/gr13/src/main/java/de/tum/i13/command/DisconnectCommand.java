package de.tum.i13.command;

import de.tum.i13.client.ClientCLI;
import de.tum.i13.client.ClientLib;
import de.tum.i13.customExceptions.NotEnoughArgumentsException;
import java.io.IOException;
import java.util.logging.Logger;

/** The type Disconnect command. */
public class DisconnectCommand extends Command {

  /**
   * Instantiates a new Disconnect command.
   *
   * @param clientCLI active CLI instance
   * @param client client
   * @param logger logger for logging errors and info
   * @param numArgs number of arguments provided
   * @param ignoreSpace boolean for ignoring whitespace
   */
  public DisconnectCommand(
      ClientCLI clientCLI, ClientLib client, Logger logger, int numArgs, boolean ignoreSpace) {
    super(clientCLI, client, logger, numArgs, ignoreSpace);
  }

  /**
   * Disconnects client from active server connection if any.
   *
   * @throws IOException IO exception
   */
  public void disconnect() throws IOException {
    if (!client.isConnected()) {
      logger.warning("Client already disconnected!");
      clientCLI.messageCLI("Client already disconnected!", true);
    } else {
      String host = client.getHost();
      int port = client.getPort();
      client.disconnect();
      logger.warning("Connection terminated: " + host + " / " + port);
      clientCLI.messageCLI("Connection terminated: " + host + " / " + port, true);
    }
  }

  public void process(String[] arguments) throws NotEnoughArgumentsException, IOException {
    this.verifyArgsNo(arguments);
    this.disconnect();
  }
}
