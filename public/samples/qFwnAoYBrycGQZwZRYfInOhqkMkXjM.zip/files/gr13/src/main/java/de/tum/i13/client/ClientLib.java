package de.tum.i13.client;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.InetSocketAddress;
import java.net.Socket;
import java.util.ArrayList;

/** The type Client lib. */
public class ClientLib {

  private int timeout;
  private Socket socket;
  private InputStream in;
  private OutputStream out;

  /**
   * Instantiates a new Client lib.
   *
   * @param timeout set timeout for the socket connection and all its functions
   */
  ClientLib(int timeout) {
    this.timeout = timeout;
  }
  /**
   * S Instantiate a socket connection to address and port and set timeout to the socket
   *
   * @param address the address of remote socket
   * @param port the port of remote socket
   * @throws IOException If socket connection is not successful
   * @throws SecurityException if security violation occurred
   * @throws IllegalArgumentException if arguments are not valid
   */
  public void connect(String address, int port)
      throws IOException, SecurityException, IllegalArgumentException {
    if (this.isConnected()) {
      return;
    }
    socket = new Socket();
    socket.connect(new InetSocketAddress(address, port), timeout);
    socket.setSoTimeout(timeout);
  }

  /**
   * Init io streams for the current socket
   *
   * @throws IOException if streams are not present or in non blocking mode
   */
  public void initIO() throws IOException {
    in = socket.getInputStream();
    out = socket.getOutputStream();
  }

  /**
   * check whether the socket is open client side only
   *
   * @return state of client socket
   */
  public boolean isConnected() {

    return socket != null && !socket.isClosed() && socket.isConnected();
  }

  /**
   * Send a stream of bytes to socket stream
   *
   * @param bytes message in bytes
   * @throws IOException if IO error occurred
   */
  public void send(byte[] bytes) throws IOException {
    out.write(bytes);
    out.flush();
  }

  /**
   * Gets the host name from the connected socket.
   *
   * @return host name
   */
  public String getHost() {
    return socket.getInetAddress().getHostAddress();
  }

  /**
   * Gets the port from the connected socket.
   *
   * @return port
   */
  public int getPort() {
    return socket.getPort();
  }

  /**
   * receive a stream of bytes and return that stream as an Array of bytes
   *
   * @return array of received bytes
   * @throws IOException IO exception
   */
  public byte[] receive() throws IOException {
    // Maximal message capacity
    ArrayList<Byte> acc = new ArrayList<>(128000);
    while (acc.size() < 2 || (acc.get(acc.size() - 2) != '\r' && acc.get(acc.size() - 1) != '\n')) {
      acc.add((byte) in.read());
    }
    byte[] message = new byte[acc.size()];
    for (int i = 0; i < acc.size(); i++) {
      message[i] = acc.get(i);
    }
    return message;
  }

  /**
   * Close the socket connection as well as the input and output streams.
   *
   * @throws IOException IO exception
   */
  public void disconnect() throws IOException {
    if (!this.isConnected()) {
      return;
    }
    in.close();
    out.close();
    socket.close();
  }
}
