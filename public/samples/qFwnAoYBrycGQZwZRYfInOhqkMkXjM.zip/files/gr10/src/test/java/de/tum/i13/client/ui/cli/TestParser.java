package de.tum.i13.client.ui.cli;

import de.tum.i13.logic.*;
import de.tum.i13.shared.exceptions.ArgumentsException;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.util.Arrays;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

public class TestParser {

    private Parser parser;

    @BeforeEach
    public void setup() {
        this.parser = new Parser();
    }

    @Test
    public void testParseTokensNull() {
        Command command = null;
        try {
            this.parser.parse(null);
        } catch (ArgumentsException e) {
            fail(e);
        }
        assertNull(command);
    }

    @Test
    public void testParseTokensEmpty() {
        List<String> tokens = Arrays.asList("", "");
        Command command = null;
        try {
            this.parser.parse(tokens);
        } catch (ArgumentsException e) {
            fail(e);
        }
        assertNull(command);
    }

    @Test
    public void testParseForConnectCorrect() {
        List<String> tokens = Arrays.asList("connect", "host 42");
        Command command = null;
        try {
            command = this.parser.parse(tokens);
        } catch (ArgumentsException e) {
            fail(e);
        }

        assertNotNull(command);
        assertEquals(ConnectCommand.class, command.getClass());
        ConnectCommand connectCommand = (ConnectCommand) command;
        assertEquals("host", connectCommand.getHostname());
        assertEquals(42, connectCommand.getPort());
    }

    @Test
    public void testParseForConnectNoArguments() {
        List<String> tokens = Arrays.asList("connect");

        ArgumentsException thrown = assertThrows(ArgumentsException.class, () -> this.parser.parse(tokens));
        assertTrue(thrown.getMessage().contains("No arguments specified"));
    }

    @Test
    public void testParseForConnectEmptyArguments() {
        List<String> tokens = Arrays.asList("connect", "");

        ArgumentsException thrown = assertThrows(ArgumentsException.class, () -> this.parser.parse(tokens));
        assertTrue(thrown.getMessage().contains("Connect takes exactly two arguments"));
    }

    @Test
    public void testParseForConnectUnknownPort() {
        List<String> tokens = Arrays.asList("connect", "host port");

        ArgumentsException thrown = assertThrows(ArgumentsException.class, () -> this.parser.parse(tokens));
        assertTrue(thrown.getMessage().contains("Second argument of connect command must be a port number"));
    }

    @Test
    public void testParseDisconnectCorrect() {
        List<String> tokens = Arrays.asList("disconnect");
        Command command = null;
        try {
            command = this.parser.parse(tokens);
        } catch (ArgumentsException e) {
            fail(e);
        }

        assertNotNull(command);
        assertEquals(DisconnectCommand.class, command.getClass());
    }

    @Test
    public void testParseDisconnectWithArguments() {
        List<String> tokens = Arrays.asList("disconnect", "args");

        ArgumentsException thrown = assertThrows(ArgumentsException.class, () -> this.parser.parse(tokens));
        assertTrue(thrown.getMessage().contains("Disconnect doesn't take any arguments"));
    }

    @Test
    public void testParseSendCorrect() {
        String message = "message  from    user  with  blanks\n\n";
        List<String> tokens = Arrays.asList("send", message);
        Command command = null;
        try {
            command = this.parser.parse(tokens);
        } catch (ArgumentsException e) {
            fail(e);
        }

        assertNotNull(command);
        assertEquals(SendCommand.class, command.getClass());
        assertEquals(message, ((SendCommand) command).getMessage());
    }

    @Test
    public void testParseSendNoMessage() {
        List<String> tokens = Arrays.asList("send");

        ArgumentsException thrown = assertThrows(ArgumentsException.class, () -> this.parser.parse(tokens));
        assertTrue(thrown.getMessage().contains("A message to send must be specified"));
    }

    @Test
    public void testParseHelpCorrect() {
        List<String> tokens = Arrays.asList("help");
        Command command = null;
        try {
            command = this.parser.parse(tokens);
        } catch (ArgumentsException e) {
            fail(e);
        }
        assertNotNull(command);
        assertEquals(HelpCommand.class, command.getClass());
    }

    @Test
    public void testParseHelpArguments() {
        List<String> tokens = Arrays.asList("help", "asdf asd");
        ArgumentsException thrown = assertThrows(ArgumentsException.class, () -> this.parser.parse(tokens));
        assertTrue(thrown.getMessage().contains("Too many arguments"));
    }

    @Test
    public void testLogLevelCommandCorrect() {
        List<String> tokens = Arrays.asList("logLevel", "FINEST");
        Command command = null;
        try {
            command = this.parser.parse(tokens);
        } catch (ArgumentsException e) {
            fail(e);
        }
        assertNotNull(command);
        assertEquals(LogLevelCommand.class, command.getClass());
        assertEquals(((LogLevelCommand) command).getLogLevel().getName(), "FINEST");
    }

    @Test
    public void testLogLevelTooManyArguments() {
        List<String> tokens = Arrays.asList("logLevel", "FINEST SEVERE");
        ArgumentsException thrown = assertThrows(ArgumentsException.class, () -> this.parser.parse(tokens));
        assertTrue(thrown.getMessage().contains("Unspecified logLevel. Only ( ALL | CONFIG | FINE | FINEST | INFO| OFF |\n" + "SEVERE | WARNING ) are allowed."));
    }

    @Test
    public void testLogLevelNoArguments() {
        List<String> tokens = Arrays.asList("logLevel");
        ArgumentsException thrown = assertThrows(ArgumentsException.class, () -> this.parser.parse(tokens));
        assertTrue(thrown.getMessage().contains("Illegal number of arguments specified"));
    }

    @Test
    public void testLogLevelUnkownArguments() {
        List<String> tokens = Arrays.asList("logLevel", "Hello");
        ArgumentsException thrown = assertThrows(ArgumentsException.class, () -> this.parser.parse(tokens));
        assertTrue(thrown.getMessage().contains("Unspecified logLevel. Only ( ALL | CONFIG | FINE | FINEST | INFO| OFF |\n" + "SEVERE | WARNING ) are allowed."));
    }

    @Test
    public void testQuitCommandCorrect() {
        List<String> tokens = Arrays.asList("quit");
        Command command = null;
        try {
            command = parser.parse(tokens);
        } catch (ArgumentsException e) {
            fail(e);
        }

        assertNotNull(command);
        assertEquals(command.getClass(), QuitCommand.class);
    }

    @Test
    public void testQuitCommandTooManyArguments() {
        List<String> tokens = Arrays.asList("quit", "now");
        ArgumentsException thrown = assertThrows(ArgumentsException.class, () -> this.parser.parse(tokens));
        assertTrue(thrown.getMessage().contains("Too many arguments"));
    }


}
