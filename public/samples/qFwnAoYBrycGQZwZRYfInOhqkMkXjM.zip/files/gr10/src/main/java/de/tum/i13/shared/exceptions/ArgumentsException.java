package de.tum.i13.shared.exceptions;

public class ArgumentsException extends Exception {

    public ArgumentsException(String errorMessage) {
        super(errorMessage);
    }

    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append(this.getClass().getSimpleName());
        if(this.getMessage() != null) {
            sb.append(": ");
            sb.append(this.getMessage());
        }
        return sb.toString();
    }

}
