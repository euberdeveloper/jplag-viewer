package de.tum.i13.logic;

import de.tum.i13.client.Visitor;
import java.util.List;

public class HelpCommand extends Command{

    public static final String helpString =

            String.format("These are the supported commands:")
            + String.format("\n%-30s%s", "connect address port","Establish a TCP-Connection to the echo server")
            + String.format("\n%-30s%s", "disconnect","Disconnect from the connected server")
            + String.format("\n%-30s%s", "send message","Send a text message to the echo server")
            + String.format("\n%-30s%s", "logLevel level","Set the logger to the specified log level")
            + String.format("\n%-30s%s", "help","Display this help message")
            + String.format("\n%-30s%s", "quit","Tear down the connection and close the application")
            + String.format("\n%-30s%s", "anything else","Display help message");


    private List<String> tokens;

    public HelpCommand(List<String> tokens) {
        this.tokens = tokens;
    }

    public HelpCommand() {}

    @Override
    public String execute(Visitor visitor) {
        return visitor.execute(this);
    }

    /**
     * Method to create the appropriate help text depending on whether the help command is called or an unknown command
     * is given by the user
     *
     * @return The appropriate help text as String
     */

    public String getHelpMessage() {
        StringBuilder sb = new StringBuilder();
        if(tokens != null) {
            for (String s : tokens) {
                sb.append(s + " ");
            }
            sb.append(": Unknown command\n");
        }

        sb.append(helpString);
        return sb.toString();
    }
}
