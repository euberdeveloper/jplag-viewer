package de.tum.i13.client;

import de.tum.i13.logic.*;

public interface Visitor {
    String execute(ConnectCommand connectCommand) throws Exception;

    String execute(DisconnectCommand disconnectCommand) throws Exception;

    String execute(HelpCommand helpCommand);

    String execute(LogLevelCommand logLevelCommand);

    String execute(QuitCommand quitCommand) throws Exception;

    String execute(SendCommand sendCommand) throws Exception;
}
