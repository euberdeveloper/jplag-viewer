package de.tum.i13.logic;

import de.tum.i13.client.Visitor;

import java.util.List;

public class QuitCommand extends Command{

    @Override
    public String execute(Visitor visitor) throws Exception {
        return visitor.execute(this);
    }

}
