package de.tum.i13.logic;

import de.tum.i13.client.Visitor;

import java.util.List;

public class ConnectCommand extends Command {

    private String hostName;
    private int port;

    public ConnectCommand(String hostName, int port) {
        this.hostName = hostName;
        this.port = port;
    }

    public String getHostname() {
        return hostName;
    }

    public int getPort() {
        return port;
    }

    @Override
    public String execute(Visitor visitor) throws Exception {
        return visitor.execute(this);
    }

}
