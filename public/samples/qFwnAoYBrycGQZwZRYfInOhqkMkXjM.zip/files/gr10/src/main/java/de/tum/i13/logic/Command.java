package de.tum.i13.logic;

import de.tum.i13.client.Visitor;

public abstract class Command {

  public abstract String execute(Visitor visitor) throws Exception;

}
