package de.tum.i13.logic;

import de.tum.i13.client.Visitor;

import java.util.List;

public class SendCommand extends Command {

    private String message;

    public SendCommand(String message) {
        this.message = message;
    }

    public String getMessage() {
        return message;
    }

    @Override
    public String execute(Visitor visitor) throws Exception {
        return visitor.execute(this);
    }

}
