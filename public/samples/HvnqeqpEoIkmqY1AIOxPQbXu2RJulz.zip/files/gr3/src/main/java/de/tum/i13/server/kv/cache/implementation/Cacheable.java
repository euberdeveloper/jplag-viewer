package de.tum.i13.server.kv.cache.implementation;

import de.tum.i13.server.kv.cache.KvEntry;

import java.util.Iterator;
import java.util.Optional;

public interface Cacheable {

    Optional<KvEntry> put(String key, String value);

    Optional<String> get(String key);

    boolean delete(String key);

    boolean contains(String key);
    
    Iterator<KvEntry> iterator();
}
