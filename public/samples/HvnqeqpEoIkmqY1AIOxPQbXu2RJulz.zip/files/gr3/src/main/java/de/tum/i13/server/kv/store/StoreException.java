package de.tum.i13.server.kv.store;

public class StoreException extends Exception {
    public StoreException(String message) {
        super(message);
    }
}
