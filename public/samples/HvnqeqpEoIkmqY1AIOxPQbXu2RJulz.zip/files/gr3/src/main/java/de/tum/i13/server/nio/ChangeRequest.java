package de.tum.i13.server.nio;

import java.nio.channels.SelectionKey;

public class ChangeRequest {

    public SelectionKey selectionKey;
    public int operation;

    public ChangeRequest(SelectionKey selectionKey, int operation) {
        this.selectionKey = selectionKey;
        this.operation = operation;
    }
}