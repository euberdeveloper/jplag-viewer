package de.tum.i13.server.kv.cache;

/**
 * A wrapper for the Key-Value parameters. Its main purpose is to represent the
 * Key & the Value and to create a data structure that holds them on the server
 * side.
 */
public class KvEntry {
    public String key = "";
    public String value;

    public KvEntry(String key, String value) {
        this.key = key;
        this.value = value;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o)
            return true;
        if (o == null || getClass() != o.getClass())
            return false;

        KvEntry kvEntry = (KvEntry) o;
        return key.equals(kvEntry.key) && value.equals(kvEntry.value);
    }
}
