package de.tum.i13.shared;

import picocli.CommandLine;

import java.io.IOException;
import java.net.InetSocketAddress;
import java.nio.file.Files;
import java.nio.file.Path;

/**
 * The config that is created out of the command line options that are given, or set to the defaults as specified in
 * each annotation.
 */
public class Config {
    @CommandLine.Option(names = "-p", description = "sets the port of the server", defaultValue = "5153")
    public int port;

    // Note: In our project, we will bind to localhost only
    @CommandLine.Option(names = "-a", description = "which address the server should listen to",
            defaultValue = "127.0.0.1")
    public String listenAddress;

    @CommandLine.Option(names = "-s", description = "Cache displacement strategy, FIFO, LRU, LFU", defaultValue = "FIFO")
    public String cachingStrategy;

    @CommandLine.Option(names = "-b", description = "bootstrap broker where clients and other brokers connect " +
            "first to retrieve configuration, port and ip, e.g., 192.168.1.1:5153",
            defaultValue = "clouddatabases.i13.in.tum.de:5153")
    public InetSocketAddress bootstrapBrokerAddress;

    @CommandLine.Option(names = "-c", description = "Size of the cache, e.g., 100 keys", defaultValue = "100")
    public int cacheSize;


    @CommandLine.Option(names = "-d", description = "Directory for files", defaultValue = "data/")
    public Path dataDir;

    @CommandLine.Option(names = "-l", description = "Logfile", defaultValue = "server.log")
    public Path logfile;

    @CommandLine.Option(names = "-ll", description = "Log level", defaultValue = "INFO")
    public String logLevel;

    @CommandLine.Option(names = "-h", description = "Displays help", usageHelp = true)
    public boolean showHelp;

    public static Config parseCommandlineArgs(String[] args) {
        Config config = new Config();
        CommandLine.ParseResult parseResult =
                new CommandLine(config)
                        .registerConverter(InetSocketAddress.class, new InetSocketAddressTypeConverter())
                        .parseArgs(args);

        if (!Files.exists(config.dataDir)) {
            try {
                Files.createDirectory(config.dataDir);
            } catch (IOException e) {
                System.out.println("Could not create directory");
                e.printStackTrace();
                System.exit(-1);
            }
        }

        if (!parseResult.errors().isEmpty()) {
            for (Exception ex : parseResult.errors()) {
                ex.printStackTrace();
            }

            CommandLine.usage(new Config(), System.out);
            System.exit(-1);
        }

        return config;
    }

    @Override
    public String toString() {
        return "Config{" + "port=" + port + ", listenaddr='" + listenAddress + '\'' + ", bootstrap=" +
                bootstrapBrokerAddress + ", dataDir=" + dataDir + ", logfile=" + logfile + ", cachingStrategy=" +
                cachingStrategy + ", usagehelp=" + showHelp + '}';
    }
}
