package de.tum.i13.client.cli.client;

import de.tum.i13.client.cli.CliException;
import de.tum.i13.client.communication.ClientException;
import de.tum.i13.client.communication.KvClient;
import de.tum.i13.shared.message.MessageException;

/**
 * The class that handles logic between the CLI and the Client. Often this is
 * the case for printing informational messages to the user of the CLI, but also
 * to handle the echo behavior directly (i.e. reading after sending) and
 * disconnecting before quitting the CLI.
 */
public class CliClient {

    private final KvClient client;

    public CliClient() {
        client = new KvClient();
    }

    public void connect(String allParameters) throws CliException, ClientException {
        ConnectionParameters parameters = new ConnectionParameters(allParameters);
        client.connect(parameters.address, parameters.port);
        System.out.println(client.receiveMessage());
    }

    public void disconnect() throws ClientException {
        String remoteAddress = client.getRemoteAddress();
        client.disconnect();
        System.out.println("Connection terminated: " + remoteAddress);
    }

    public void quit() throws ClientException {
        if (this.client.isCurrentlyConnected()) {
            this.disconnect();
        }
        System.out.println("Application exit.");
    }

    public void put(String allParameters) throws ClientException, MessageException {
        KvParameters kvParameters = new KvParameters(allParameters);
        final String bareResponse = client.put(kvParameters.key, kvParameters.value);
        KvStoreResponse response = new KvStoreResponse(bareResponse);

        if (response.operationSuccessful) {
            System.out.println("SUCCESS");
        } else {
            System.out.println("ERROR");
        }
    }

    public void get(String parameters) throws ClientException, MessageException {
        KvParameters kvParameters = new KvParameters(parameters);
        String bareResponse = client.get(kvParameters.key);
        KvStoreResponse response = new KvStoreResponse(bareResponse);

        if (response.operationSuccessful) {
            System.out.println(response.value);
        } else {
            System.out.println("ERROR");
        }
    }
}
