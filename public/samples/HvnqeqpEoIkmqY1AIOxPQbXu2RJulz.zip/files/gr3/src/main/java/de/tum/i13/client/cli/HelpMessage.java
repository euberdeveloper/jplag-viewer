package de.tum.i13.client.cli;

public class HelpMessage {
    public static void printHelp() {
        System.out.println(
                "Available commands:");
        System.out.println(
                "connect <address> <port> - Tries to establish a TCP- connection to the echo server based "
                        + "on the given server address and the port number of the echo service.");
        System.out.println(
                "disconnect - Tries to disconnect from the connected server.");
        System.out.println(
                "put <key> <value> - Set the value for the given key on the server.");
        System.out.println("get <key> - Get the value for the given key from the server.");
        System.out.println(
                "logLevel <level> - Sets the logger to the specified log level (ALL | DEBUG | INFO | "
                        + "WARN | ERROR | FATAL | OFF)");
        System.out.println(
                "help - Display this help");
        System.out.println(
                "quit - Tears down the active connection to the server and exits the program execution.");
    }
}
