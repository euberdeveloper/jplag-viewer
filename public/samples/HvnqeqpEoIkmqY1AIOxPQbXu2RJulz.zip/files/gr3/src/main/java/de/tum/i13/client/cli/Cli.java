package de.tum.i13.client.cli;


import de.tum.i13.client.cli.client.CliClient;
import de.tum.i13.client.communication.ClientException;
import de.tum.i13.shared.LogSetup;
import de.tum.i13.shared.message.MessageException;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.nio.file.Path;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 * The main wrapper for the CLI functionality.
 */
public class Cli {

    private final static Logger log = Logger.getLogger(Cli.class.getName());

    private CliClient cliClient;

    public static void main(String[] args) {
        LogSetup.setupLogging(Path.of("all.log"), "INFO");
        new Cli().runCliApplication();
    }

    /**
     * The main runner for the CLI application. Maintains the main loop of the CLI until the input for quitting was
     * given by the user.
     */
    private void runCliApplication() {
        cliClient = new CliClient();

        BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));
        boolean isQuitting = false;

        while (!isQuitting) {
            isQuitting = handleInput(reader);
        }
    }

    /**
     * Handles a single input from the user.
     * @param reader where to read the next input from
     * @return true, if the application should, false otherwise
     */
    private boolean handleInput(BufferedReader reader) {
        try {
            System.out.print("KVClient> ");
            return handleCommand(new CliInput(reader.readLine()));
        } catch (ClientException | MessageException e) {
            System.out.println(e.getMessage());
            return false;
        } catch (CliException e) {
            HelpMessage.printHelp();
            return false;
        } catch (IOException e) {
            System.out.println("There was an error when reading the input. Please try again.");
            return false;
        }
    }

    /**
     * Handles the command that was given in an input.
     * @return true, if the application should, false otherwise
     */
    private boolean handleCommand(CliInput input) throws CliException, ClientException, MessageException {
        boolean isQuitting = false;

        switch (input.command) {
            case "connect":
                cliClient.connect(input.parameters);
                break;
            case "disconnect":
                cliClient.disconnect();
                break;
            case "put":
                cliClient.put(input.parameters);
                break;
            case "get":
                cliClient.get(input.parameters);
                break;
            case "logLevel":
                setLogLevel(input);
                break;
            case "quit":
                cliClient.quit();
                isQuitting = true;
                break;
            default:
                HelpMessage.printHelp();
                break;
        }

        return isQuitting;
    }

    /**
     * Parses the log level from the input and sets it, if parsing was successful.
     */
    private void setLogLevel(CliInput input) throws CliException {
        try {
            Level previousLevel = log.getLevel();
            log.setLevel(Level.parse(input.parameters));
            System.out.println("Log level set from " + previousLevel + " to " + log.getLevel());
        } catch (IllegalArgumentException e) {
            throw new CliException("This log level does not exist.");
        }
    }
}


