package de.tum.i13.shared.message;

/**
 * A bare message between a client and a server consists of a command, a key, and potentially a value.
 * Note that this class is responsible for the KV communication, not for (dis-)connecting.
 */
public class BareMessage {

    private final String wholeInput;
    public String command;
    public String key;
    public String value;

    public BareMessage(String input) throws MessageException {
        if (input.contains("\r\n"))
            input = input.substring(0, input.indexOf("\r\n"));
        this.wholeInput = input;

        String[] inputs = input.split(" ", 3);

        if (inputs.length < 2)
            throw new MessageException("Input was wrong: needs to be given at least a command and a key");

        this.command = inputs[0];
        this.key = inputs[1];
        this.value = inputs.length > 2 ? inputs[2] : "";
    }

    @Override
    public String toString() {
        return wholeInput;
    }
}
