package de.tum.i13.server.nio;

public class ServerException extends Exception {
    public ServerException(String message) {
        super(message);
    }
}
