package de.tum.i13.shared.message;

/**
 * An exception that should happen when there was an error in the communication between the client and the server, in
 * particular in the communication format.
 */
public class MessageException extends Exception {
    public MessageException(String message) {
        super(message);
    }
}
