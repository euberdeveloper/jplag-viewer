package de.tum.i13.server.kv;

/**
 * enums that represents the answer of the server after a GET,PUT or DELETE
 * request.
 */
public enum StatusType {
    GET, GET_ERROR, GET_SUCCESS, PUT, PUT_SUCCESS, PUT_UPDATE, // implies PUT_SUCCESS
    PUT_ERROR, DELETE, DELETE_SUCCESS, DELETE_ERROR
}
