package de.tum.i13.server.kv.cache;

import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.Map;

public class MaxSizeLinkedHashMap<K, Integer> extends LinkedHashMap<K, Integer> {

    private final int MAX_ENTRIES;

    public MaxSizeLinkedHashMap(int size) {
        this.MAX_ENTRIES = size;
    }

    @Override
    protected boolean removeEldestEntry(Map.Entry<K, Integer> eldest) {
        return size() > MAX_ENTRIES;
    }

    public boolean maxSizeReached() {
        return MAX_ENTRIES == size();
    }

    public K getLastKey() {
        Iterator<java.util.Map.Entry<K, Integer>> iterator = entrySet().iterator();
        K lastKey = iterator.next().getKey();
        while (iterator.hasNext()) {
            lastKey = iterator.next().getKey();
        }
        return lastKey;
    }

    public Integer getLastValue() {
        Iterator<java.util.Map.Entry<K, Integer>> iterator = entrySet().iterator();
        Integer lastValue = iterator.next().getValue();
        while (iterator.hasNext()) {
            lastValue = iterator.next().getValue();
        }
        return lastValue;
    }
}
