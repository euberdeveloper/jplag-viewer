package de.tum.i13.server.threadperconnection;

import de.tum.i13.shared.CommandProcessor;
import de.tum.i13.shared.Constants;

import java.io.*;
import java.net.Socket;

public class ConnectionHandleThread extends Thread {

    private final CommandProcessor commandProcessor;
    private final Socket clientSocket;

    public ConnectionHandleThread(CommandProcessor commandProcessor, Socket clientSocket) {
        this.commandProcessor = commandProcessor;
        this.clientSocket = clientSocket;
    }

    @Override
    public void run() {
        try {
            runEchoClientLogic();
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }

    private void runEchoClientLogic() throws IOException {
        BufferedReader in = new BufferedReader(
                new InputStreamReader(clientSocket.getInputStream(), Constants.TELNET_ENCODING));
        PrintWriter out = new PrintWriter(
                new OutputStreamWriter(clientSocket.getOutputStream(), Constants.TELNET_ENCODING));

        String line;
        while ((line = in.readLine()) != null) {
            String res = commandProcessor.process(line);
            sendMessage(out, res);
        }
    }

    private void sendMessage(PrintWriter out, String res) {
        out.write(res);
        out.flush();
    }
}
