package de.tum.i13.client.cli.client;

import de.tum.i13.client.communication.ClientException;

/**
 * A wrapper for the Key-Value parameters. Its main purpose is parsing the Key &
 * the Value and to create a data structure that holds them.
 */
public class KvParameters {

    public String key;
    public String value;

    public KvParameters(String allParameters) throws ClientException {
        String[] parameters = allParameters.split(" ", 2);

        if (parameters.length < 1)
            throw new ClientException("No key was given.");

        this.key = parameters[0];
        this.value = parameters.length >= 2 ? parameters[1] : "";

        System.out.println(value);
        if (!isJustBase64AndWhitespace())
            throw new ClientException("value can only contain base64 characters and whitespace");
    }

    private boolean isJustBase64AndWhitespace() {
        return this.value.matches("[A-Za-z0-9 +/]*");
    }

}
