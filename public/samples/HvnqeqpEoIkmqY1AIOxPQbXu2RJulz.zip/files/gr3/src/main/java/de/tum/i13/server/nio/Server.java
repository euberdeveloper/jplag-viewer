package de.tum.i13.server.nio;

import de.tum.i13.server.kv.cache.CacheException;
import de.tum.i13.server.kv.cache.CacheManager;
import de.tum.i13.server.kv.commandprocessor.KvCommandProcessor;
import de.tum.i13.server.kv.store.StoreException;
import de.tum.i13.shared.Config;

import java.io.IOException;
import java.rmi.ServerException;
import java.util.logging.Logger;

/**
 * This class is responsible for setting up a server and starting it, as well as for setting a shutdown hook that
 * gets called when this server shuts down gracefully.
 */
public class Server {

    public static Logger log = Logger.getLogger(Server.class.getName());

    private final Config config;

    private final SimpleNioServer nioServer;

    public Server(Config config) throws StoreException, CacheException {
        this.config = config;

        CacheManager cacheManager =
                new CacheManager(config.cachingStrategy, config.cacheSize, config.dataDir + "/store.csv");
        Runtime.getRuntime().addShutdownHook(new Thread(() -> {
            log.info("Gracefully shutting down...");
            cacheManager.persistCacheData();
        }));

        this.nioServer = new SimpleNioServer(new KvCommandProcessor(cacheManager));
    }

    public void start() throws ServerException {
        log.info("Starting server...");

        try {
            nioServer.bindSockets(config.listenAddress, config.port);
            nioServer.start();
            log.info("Server started");
        } catch (IOException e) {
            throw new ServerException(String.format("There was an error when starting the server: %s", e.getMessage()));
        }
    }
}
