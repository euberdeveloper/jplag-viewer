package de.tum.i13.server.kv.cache;

/**
 * An exception that is thrown whenever there is a problem directly with the
 * Cache. Common problems include for example a wrong add into the cache.
 */
public class CacheException extends Exception {
    public CacheException(String message) {
        super(message);
    }
}
