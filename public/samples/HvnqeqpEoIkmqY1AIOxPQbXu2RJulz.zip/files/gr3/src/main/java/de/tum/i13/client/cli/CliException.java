package de.tum.i13.client.cli;

/**
 * An exception that is thrown whenever there is a problem directly with the
 * CLI. Common problems include for example a wrong command or wrong parameters.
 */
public class CliException extends Exception {

    public CliException(String s) {
        super(s);
    }
}
