package de.tum.i13.shared;

import java.net.InetAddress;
import java.net.InetSocketAddress;

/**
 * An interface for a class that processes a given command. In our case, this will most likely be a KV update command,
 * i.e. a PUT, GET, or DELETE.
 */
public interface CommandProcessor {

    /**
     * Process the command on the server site. The returned string is also the response that the client will receive.
     */
    String process(String command);

    /**
     * Gets called when a new client connection was accepted. Returns the response to the client.
     */
    String connectionAccepted(InetSocketAddress address, InetSocketAddress remoteAddress);

    /**
     * Gets called when a client connection was closed.
     */
    void connectionClosed(InetAddress address);
}
