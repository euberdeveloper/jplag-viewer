package de.tum.i13.server.kv;

/**
 * A message that represents key-value-status data on the server Side. it also
 * contains a statustype which is the response of the server to a request.
 */
public class KvMessage implements Transmittable {

    private final String key;
    private final String value;
    private final StatusType status;

    public KvMessage(String key, String value, StatusType status) {
        this.key = key;
        this.value = value;
        this.status = status;
    }

    @Override
    public String getKey() {
        return key;
    }

    @Override
    public String getValue() {
        return value;
    }

    @Override
    public StatusType getStatus() {
        return status;
    }

    @Override
    public boolean isSuccessful() {
        return this.status == StatusType.DELETE_SUCCESS || this.status == StatusType.PUT_SUCCESS
                || this.status == StatusType.GET_SUCCESS;
    }

    @Override
    public String toString() {
        return "KvMessage{" + "key='" + key + '\'' + ", value='" + value + '\'' + ", status=" + status + '}';
    }
}
