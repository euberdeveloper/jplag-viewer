package de.tum.i13.shared;

/**
 * Constants that are potentially used several times in the project.
 */
public class Constants {
	public static final String TELNET_ENCODING = "ISO-8859-1"; // encoding for telnet
}
