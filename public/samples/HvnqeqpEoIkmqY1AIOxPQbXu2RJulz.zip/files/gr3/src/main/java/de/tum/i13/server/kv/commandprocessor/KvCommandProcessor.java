package de.tum.i13.server.kv.commandprocessor;

import de.tum.i13.server.kv.Storable;
import de.tum.i13.server.kv.Transmittable;
import de.tum.i13.shared.CommandProcessor;
import de.tum.i13.shared.message.BareMessage;
import de.tum.i13.shared.message.MessageException;

import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.util.logging.Logger;

/**
 * Processes commands for the KV operations, i.e. PUT, GET, DELETE.
 */
public class KvCommandProcessor implements CommandProcessor {

    private final Logger log = Logger.getLogger(KvCommandProcessor.class.getName());

    private final Storable kvStore;

    public KvCommandProcessor(Storable kvStore) {
        this.kvStore = kvStore;
    }

    @Override
    public String process(String wholeInput) {
        log.info(String.format("Processing input: %s", wholeInput));
        try {
            return asMessage(handleInput(new BareMessage(wholeInput)));
        } catch (MessageException e) {
            return asMessage(wrongInput(wholeInput, e.getMessage()));
        }
    }

    private String handleInput(BareMessage bareMessage) {
        switch (bareMessage.command) {
            case "put": {
                Transmittable response = this.kvStore.put(bareMessage.key, bareMessage.value);
                switch (response.getStatus()) {
                    case PUT_SUCCESS: return String.format("put_success %s", response.getKey());
                    case PUT_UPDATE: return String.format("put_update %s", response.getKey());
                    case PUT_ERROR: return String.format("put_error %s %s", response.getKey(), response.getValue());
                    case DELETE_SUCCESS: return String.format("delete_success %s", response.getKey());
                    case DELETE_ERROR: return String.format("delete_error %s", response.getKey());
                }
                break;
            }
            case "get": {
                Transmittable response = this.kvStore.get(bareMessage.key);
                switch (response.getStatus()) {
                    case GET_SUCCESS: return String.format("get_success %s %s", response.getKey(), response.getValue());
                    case GET_ERROR: return String.format("get_error %s", response.getKey());
                }
                break;
            }
            case "delete": {
                Transmittable response = this.kvStore.delete(bareMessage.key);
                switch (response.getStatus()) {
                    case DELETE_SUCCESS: return String.format("delete_success %s", response.getKey());
                    case DELETE_ERROR: return String.format("delete_error %s", response.getKey());
                }
                break;
            }
            default: {
                return wrongInput(String.format("%s %s %s", bareMessage.command, bareMessage.key, bareMessage.value), "");
            }
        }

        log.severe(String.format(
                "This should not happen. It should have returned before. Input was: %s", bareMessage));
        return "wrong_input";
    }

    private String wrongInput(String wholeInput, String exceptionMessage) {
        log.warning(
                String.format("An error occurred while parsing the input '%s': %s", wholeInput, exceptionMessage));
        return String.format("error %s", exceptionMessage);
    }

    @Override
    public String connectionAccepted(InetSocketAddress address, InetSocketAddress remoteAddress) {
        log.info(String.format("Connection accepted from client %s", address));
        return asMessage(String.format("Connected to %s", remoteAddress));
    }

    @Override
    public void connectionClosed(InetAddress address) {
        log.info(String.format("Connection closed to client %s ", address));
    }

    private String asMessage(String content) {
        return content + "\r\n";
    }
}
