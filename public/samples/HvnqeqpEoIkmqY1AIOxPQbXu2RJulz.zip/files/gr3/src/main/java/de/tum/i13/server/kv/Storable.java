package de.tum.i13.server.kv;

/**
 * This interface stores basic functions for something that is storable, that could be a cache as well as a file store,
 * for example.
 */
public interface Storable {

    /**
     * Inserts a key-value pair into the KVServer.
     *
     * @param key   the key that identifies the given value.
     * @param value the value that is indexed by the given key.
     * @return a message that confirms the insertion of the tuple or an error.
     * @throws Exception if put command cannot be executed (e.g. not connected to any
     *                   KV server).
     */
    public Transmittable put(String key, String value);

    /**
     * Retrieves the value for a given key from the KVServer.
     *
     * @param key the key that identifies the value.
     * @return the value, which is indexed by the given key.
     * @throws Exception if put command cannot be executed (e.g. not connected to any
     *                   KV server).
     */
    public Transmittable get(String key);

    Transmittable delete(String key);

}
