package de.tum.i13.server.nio;

import de.tum.i13.server.kv.cache.CacheException;
import de.tum.i13.server.kv.store.StoreException;
import de.tum.i13.shared.Config;

import java.rmi.ServerException;
import java.util.logging.Logger;

import static de.tum.i13.shared.Config.parseCommandlineArgs;
import static de.tum.i13.shared.LogSetup.setupLogging;

/**
 * The main starter method for the server. Creates a new Server with the given config and starts it.
 */
public class StartSimpleNioServer {

    public static Logger log = Logger.getLogger(StartSimpleNioServer.class.getName());

    public static void main(String[] args) {
        Config config = parseCommandlineArgs(args); // Do not change this
        log.info("Config: " + config.toString());

        setupLogging(config.logfile, config.logLevel);

        try {
            new Server(config).start();
        } catch (ServerException e) {
            log.severe(String.format("Server could not start: %s", e.getMessage()));
            log.severe("Shutting down...");
        } catch (StoreException e) {
            log.severe(String.format("Store could not be created: %s", e.getMessage()));
            log.severe("Shutting down...");
        } catch (CacheException e) {
            log.severe(String.format("There was a problem with the cache: %s", e.getMessage()));
            log.severe("Shutting down...");
        }
    }
}
