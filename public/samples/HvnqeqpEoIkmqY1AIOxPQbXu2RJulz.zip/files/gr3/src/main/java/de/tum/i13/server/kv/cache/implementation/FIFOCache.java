package de.tum.i13.server.kv.cache.implementation;

import java.util.Iterator;
import java.util.LinkedList;
import java.util.Optional;
import java.util.logging.Logger;

import de.tum.i13.server.kv.cache.KvEntry;

/**
 * Represents the servers cache that is managed according to the FIFO strategy
 *
 */
public class FIFOCache extends LinkedList<KvEntry> implements Cacheable {

    private final Logger log = Logger.getLogger(FIFOCache.class.getName());

    private final int cacheSize;

    public FIFOCache(int cacheSize) {
        this.cacheSize = cacheSize;
    }

    /**
     * Puts the given key and value into the FIFO cache. If the cache is not full
     * yet (before putting the new entry), then no entry is displaced and
     * Optional.empty() is returned. Otherwise, the displace entry is returned.
     * 
     * @return the displaced entry, or Optional.empty() if no entr was displaced
     */
    public Optional<KvEntry> put(String key, String value) {
        if (this.size() >= this.cacheSize) {
            super.add(new KvEntry(key, value));
            return Optional.of(super.removeFirst());
        } else {
            super.add(new KvEntry(key, value));
            return Optional.empty();
        }
    }

    /**
     * Returns Optional.empty() if the cache does not contain the key, or if the
     * value of the contained key is empty (i.e. an empty string, which means that
     * this entry was deleted). Returns Optional.of(value) otherwise.
     */
    public Optional<String> get(String key) {
        Iterator<KvEntry> iterator = super.descendingIterator();
        while (iterator.hasNext()) {
            KvEntry entry = iterator.next();

            if (key.equals(entry.key)) {
                return getOptionalOfValue(entry.value);
            }
        }

        return Optional.empty();
    }

    private Optional<String> getOptionalOfValue(String value) {
        if (value.isEmpty()) {
            return Optional.empty();
        } else {
            return Optional.of(value);
        }
    }

    @Override
    public boolean delete(String key) {
        return this.removeIf(kvEntry -> key.equals(kvEntry.key));
    }

    @Override
    public boolean contains(String key) {
        return this.stream().anyMatch(kvEntry -> key.equals(kvEntry.key));
    }
}
