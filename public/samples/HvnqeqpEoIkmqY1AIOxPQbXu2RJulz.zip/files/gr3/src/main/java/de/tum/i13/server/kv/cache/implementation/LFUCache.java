package de.tum.i13.server.kv.cache.implementation;

import java.util.Iterator;
import java.util.LinkedHashSet;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Optional;
import java.util.Set;

import de.tum.i13.server.kv.cache.KvEntry;
import de.tum.i13.server.kv.cache.MaxSizeLinkedHashMap;

/**
 * Represents the servers cache that is managed according to the LFU strategy
 *
 */
public class LFUCache implements Cacheable {

    private final Set<KvEntry> cache;
    private final MaxSizeLinkedHashMap<String, Integer> frequencyCache;
    private final int capacity;

    public LFUCache(int capacity) {
        this.capacity = capacity;
        this.cache = new LinkedHashSet<>(capacity);
        this.frequencyCache = new MaxSizeLinkedHashMap<String, Integer>(capacity);
    }

    @Override
    public boolean delete(String key) {
        if (this.frequencyCache.containsKey(key)) {
            this.cache.removeIf(kvEntry -> key.equals(kvEntry.key));
        }
        return this.frequencyCache.remove(key, this.frequencyCache.get(key));
    }

    @Override
    public Optional<KvEntry> put(String key, String value) {
        Optional<KvEntry> displacedEntry = Optional.empty();

        // get will update the frequency if it the key already exists
        if (this.get(key).isEmpty()) {
            if (cache.size() == capacity) {
                // removeLeastFrequentEntry will also remove the frequency of the Entry
                KvEntry removedEntry = removeLeastFrequentEntry();
                displacedEntry = Optional.of(removedEntry);
            }
            this.cache.add(new KvEntry(key, value));
            this.frequencyCache.put(key, 1);
        }

        return displacedEntry;
    }

    private KvEntry removeLeastFrequentEntry() {
        Iterator<Map.Entry<String, Integer>> iterator = this.frequencyCache.entrySet().iterator();
        Entry<String, Integer> entry = iterator.next();
        int leastFrequency = entry.getValue();
        String key = entry.getKey();
        while (iterator.hasNext()) {
            entry = iterator.next();
            if (leastFrequency > entry.getValue()) {
                leastFrequency = entry.getValue();
                key = entry.getKey();
            }
        }
        KvEntry removedEntry = new KvEntry(key, this.get(key).get());
        String finalKey = key;
        this.cache.removeIf(kvEntry -> finalKey.equals(kvEntry.key));
        this.frequencyCache.remove(key);
        return removedEntry;
    }

    @Override
    public Optional<String> get(String key) {
        Optional<KvEntry> cachedEntry = this.cache.stream()
                .filter(kvEntry -> kvEntry.key.equals(key) && !kvEntry.value.isEmpty()).findFirst();
        if (cachedEntry.isPresent()) {
            this.frequencyCache.put(key, this.frequencyCache.get(key) + 1);
        }
        return cachedEntry.map(kvEntry -> kvEntry.value);
    }

    @Override
    public Iterator<KvEntry> iterator() {
        return this.cache.iterator();
    }

    @Override
    public boolean contains(String key) {
        return this.cache.stream().anyMatch(kvEntry -> key.equals(kvEntry.key));
    }

}