package de.tum.i13.server.kv.cache.implementation;

import java.util.Iterator;
import java.util.LinkedHashSet;
import java.util.Optional;
import java.util.Set;

import de.tum.i13.server.kv.cache.KvEntry;

/**
 * Represents the servers cache that is managed according to the LRU strategy.
 */
public class LRUCache implements Cacheable {

    private final Set<KvEntry> cache;

    private final int capacity;

    public LRUCache(int capacity) {
        this.capacity = capacity;
        cache = new LinkedHashSet<>(capacity);
    }

    @Override
    public Optional<KvEntry> put(String key, String value) {
        Optional<KvEntry> displacedEntry = Optional.empty();

        // the method call this.get(key) will already push the KvEntry ahead if it
        // exists
        if (this.get(key).isEmpty()) {
            if (cache.size() == capacity) {
                KvEntry removedEntry = removeMostUnusedEntry();
                displacedEntry = Optional.of(removedEntry);
            }

            this.cache.add(new KvEntry(key, value));
        }

        return displacedEntry;
    }

    private KvEntry removeMostUnusedEntry() {
        KvEntry removedEntry = cache.iterator().next();
        this.cache.remove(removedEntry);
        return removedEntry;
    }

    @Override
    public Optional<String> get(String key) {
        Optional<KvEntry> cachedEntry = this.cache.stream()
                .filter(kvEntry -> kvEntry.key.equals(key) && !kvEntry.value.isEmpty()).findFirst();

        cachedEntry.ifPresent(this::pushEntryAhead);

        return cachedEntry.map(kvEntry -> kvEntry.value);
    }

    private void pushEntryAhead(KvEntry kvEntry) {
        this.cache.remove(kvEntry);
        this.cache.add(kvEntry);
    }

    @Override
    public Iterator<KvEntry> iterator() {
        return this.cache.iterator();
    }

    @Override
    public boolean delete(String key) {
        return this.cache.removeIf(kvEntry -> key.equals(kvEntry.key));
    }

    @Override
    public boolean contains(String key) {
        return this.cache.stream().anyMatch(kvEntry -> key.equals(kvEntry.key));
    }
}
