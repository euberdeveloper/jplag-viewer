package de.tum.i13.server.kv.store;

import de.tum.i13.server.kv.KvMessage;
import de.tum.i13.server.kv.Storable;
import de.tum.i13.server.kv.Transmittable;

import java.util.logging.Logger;

import static de.tum.i13.server.kv.StatusType.*;

public class PersistentKvStore implements Storable {

    private Logger log = Logger.getLogger(PersistentKvStore.class.getName());

    private final FileKvStore store;

    /**
     * Creates a new file store with the given filename if it doesn't exist yet.
     * @throws StoreException if there was a problem with creating the new file
     */
    public PersistentKvStore(String fileName) throws StoreException {
        this.store = new FileKvStore(fileName);
    }

    @Override
    public Transmittable put(String key, String value) {
        if (value == null || value.trim().isEmpty()) {
            return delete(key);
        }

        log.info(String.format("put %s %s", key, value));

        try {
            boolean updated = store.put(key, value);
            return new KvMessage(key, value, updated ? PUT_UPDATE : PUT_SUCCESS);
        } catch (StoreException e) {
            return new KvMessage(key, value, PUT_ERROR);
        }
    }

    @Override
    public Transmittable delete(String key) {
        log.info(String.format("delete %s", key));

        try {
            String oldValue = store.delete(key);
            return new KvMessage(key, oldValue, DELETE_SUCCESS);
        } catch (StoreException e) {
            return new KvMessage(key, "", DELETE_ERROR);
        }
    }

    @Override
    public Transmittable get(String key) {
        try {
            String value = store.get(key);
            return new KvMessage(key, value, GET_SUCCESS);
        } catch (StoreException e) {
            return new KvMessage(key, "", GET_ERROR);
        }
    }
}
