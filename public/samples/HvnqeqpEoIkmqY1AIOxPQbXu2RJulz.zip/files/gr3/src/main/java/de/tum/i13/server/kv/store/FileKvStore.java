package de.tum.i13.server.kv.store;

import java.io.*;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.HashMap;
import java.util.Optional;
import java.util.function.Supplier;
import java.util.logging.Logger;

public class FileKvStore {

    private final Logger log = Logger.getLogger(FileKvStore.class.getName());

    /**
     * The delimiter that is used in the file to mark the space between a key and a value. Whitespace is the perfect
     * candidate for this, since it is delimiting key and value in the first place. A semicolon on the other hand
     * can be part of the key, which would distort the store if it was used as a delimiter.
     */
    static final String DELIMITER = " ";

    private final int MAX_BYTES_KEY = 20;
    private final int MAX_BYTES_VALUE = 120;
    private final int MAX_BYTES_LINE = MAX_BYTES_KEY + MAX_BYTES_VALUE + 2; // + 2 for DELIMITER and '\n'

    private final File store;

    /**
     * Creates (or keeps, if it already exists) a file where the data is stored.
     *
     * @throws StoreException if there is a problem creating the new file or reading the existing file
     */
    public FileKvStore(String fileName) throws StoreException {
        this.store = new File(fileName);
        try {
            createStoreFileIfNecessary(fileName);
        } catch (IOException e) {
            throw new StoreException(
                    String.format("there was an error when creating the new file %s: %s",
                            store.getAbsolutePath(), e.getMessage()));
        }
    }

    /**
     * This creates a new file if and only if one doesn't exist already - otherwise it just keeps the existing file.
     * This also creates non-existent directories for the store, if needed.
     *
     * @param storeFileName the full path to the store file
     * @throws IOException
     */
    private void createStoreFileIfNecessary(String storeFileName) throws IOException {
        log.info(String.format("Creating or accessing store file: %s", store.getPath()));
        if (storeFileName.contains("/")) {
            String pathToStore = storeFileName.substring(0, storeFileName.lastIndexOf('/'));
            File directoryOfStore = new File(pathToStore);
            if (!directoryOfStore.exists()) {
                directoryOfStore.mkdirs();
            }
        }
        store.createNewFile();
    }

    /**
     * @return true, if it was updated, and false, if it was just added
     * @throws StoreException
     */
    public boolean put(String key, String value) throws StoreException {
        log.info(String.format("put() called with key '%s' and value '%s'", key, value));
        if (key.contains(DELIMITER))
            throw new StoreException(String.format("key must not contain delimiter '%s'", DELIMITER));

        String newLine = key + DELIMITER + value + "\n";
        Optional<String> oldValue = rewriteFileAndReplaceLineWithKey(key, () -> newLine);
        if (oldValue.isEmpty()) {
            appendAtEndOfFileStore(newLine);
        }

        return oldValue.isPresent();
    }

    private void appendAtEndOfFileStore(String s) throws StoreException {
        try {
            FileWriter writer = new FileWriter(store, true);
            writer.append(s);
            writer.flush();
        } catch (IOException e) {
            throw new StoreException(
                    String.format("there was a problem with the file store: %s", store.getAbsolutePath()));
        }
    }

    /**
     * Deletes the entry that has the given key. Returns the value that was set to it before deleting.
     *
     * @return the value that was set to the given key, before deleting
     */
    public String delete(String key) throws StoreException {
        Optional<String> valueOfDeletedKey = rewriteFileAndReplaceLineWithKey(key, () -> "");
        return valueOfDeletedKey.orElseThrow(() ->
                new StoreException(String.format("key '%s' was not found in the store", key)));
    }

    private Optional<String> rewriteFileAndReplaceLineWithKey(String key, Supplier<String> f) throws StoreException {
        try {
            StringBuilder newStore = new StringBuilder((int) store.length());

            BufferedReader reader = new BufferedReader(new FileReader(store));
            Optional<String> valueOfDeletedKey = Optional.empty();
            String line;
            while ((line = reader.readLine()) != null) {
                if (line.startsWith(key)) {
                    valueOfDeletedKey = Optional.of(line.substring(line.indexOf(DELIMITER) + 1));
                    newStore.append(f.get());
                } else {
                    newStore.append(line).append('\n');
                }
            }


            FileWriter writer = new FileWriter(store);
            writer.write(newStore.toString());
            writer.flush();

            return valueOfDeletedKey;
        } catch (IOException e) {
            throw new StoreException(
                    String.format("there was a problem with the file store: %s\n%s", store.getAbsolutePath(), e.getMessage()));
        }
    }

    /**
     * Returns the value that is stored in the file store for this key.
     * @throws StoreException if no key was found in the file store
     */
    public String get(String key) throws StoreException {
        log.info(String.format("get() called with key '%s'", key));
        String value = createHashMapFromFileStore().get(key);

        if (value == null) {
            throw new StoreException(String.format("key '%s' was not found in store", key));
        } else {
            return value;
        }
    }

    private HashMap<String, String> createHashMapFromFileStore() throws StoreException {
        BufferedReader reader = getReader();
        HashMap<String, String> result = new HashMap<>();
        reader.lines().forEach(line -> {
            int positionOfDelimiter = line.indexOf(DELIMITER);
            result.put(line.substring(0, positionOfDelimiter),
                    line.substring(positionOfDelimiter + 1));
        });
        return result;
    }

    private BufferedReader getReader() throws StoreException {
        try {
            return new BufferedReader(new FileReader(store));
        } catch (FileNotFoundException e) {
            throw new StoreException(
                    String.format("error when reading: store file was not found: %s", store.getAbsolutePath()));
        }
    }

    /**
     * Dumps the store, i.e. deletes the file of the store and creates the file anew.
     * @throws StoreException if there was an I/O error while deleting or creating the store
     */
    void dumpStore() throws StoreException {
        try {
            long lineCount = Files.lines(Path.of(store.getAbsolutePath())).count();
            log.info(String.format("Resetting store by dumping %s lines from the store.", lineCount));

            Files.delete(Path.of(store.getAbsolutePath()));
            store.createNewFile();
        } catch (IOException e) {
            throw new StoreException(String.format("store could not be dumped: %s", e.getMessage()));
        }
    }

    @Override
    public String toString() {
        try {
            return "FileKvStore{" +
                    createHashMapFromFileStore() +
                    '}';
        } catch (StoreException e) {
            e.printStackTrace();
            return null;
        }
    }
}
