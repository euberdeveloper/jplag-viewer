package de.tum.i13.client.cli.client;

import de.tum.i13.shared.message.BareMessage;
import de.tum.i13.shared.message.MessageException;

/**
 * This class represents the result of the storage for example : success,
 * update..
 */
public class KvStoreResponse {

    public final boolean operationSuccessful;
    public final String value;

    public KvStoreResponse(String response) throws MessageException {
        BareMessage message = new BareMessage(response);
        this.operationSuccessful = message.command.contains("success") || message.command.contains("update");
        this.value = message.value;
    }
}
