package de.tum.i13.server.kv.cache;

import static de.tum.i13.server.kv.StatusType.DELETE_SUCCESS;
import static de.tum.i13.server.kv.StatusType.GET_SUCCESS;
import static de.tum.i13.server.kv.StatusType.PUT_SUCCESS;
import static de.tum.i13.server.kv.StatusType.PUT_UPDATE;

import java.util.Optional;
import java.util.logging.Logger;

import de.tum.i13.server.kv.KvMessage;
import de.tum.i13.server.kv.StatusType;
import de.tum.i13.server.kv.Storable;
import de.tum.i13.server.kv.Transmittable;
import de.tum.i13.server.kv.cache.implementation.Cacheable;
import de.tum.i13.server.kv.cache.implementation.FIFOCache;
import de.tum.i13.server.kv.cache.implementation.LFUCache;
import de.tum.i13.server.kv.cache.implementation.LRUCache;
import de.tum.i13.server.kv.store.PersistentKvStore;
import de.tum.i13.server.kv.store.StoreException;

/**
 * Manages the cache according to the given cache strategy.
 */
public class CacheManager implements Storable {

    private final Logger log = Logger.getLogger(CacheManager.class.getName());

    private final Cacheable cache;
    private final PersistentKvStore kvStore;

    public CacheManager(String cachingStrategy, int capacity, String storeFileName)
            throws StoreException, CacheException {
        this.cache = getCache(cachingStrategy, capacity);
        this.kvStore = new PersistentKvStore(storeFileName);
    }

    private Cacheable getCache(String cachingStrategy, int cacheSize) throws CacheException {
        cachingStrategy = cachingStrategy.toLowerCase();
        switch (cachingStrategy) {
        case "fifo":
            return new FIFOCache(cacheSize);
        case "lru":
            return new LRUCache(cacheSize);
        case "lfu":
            return new LFUCache(cacheSize);
        default:
            throw new CacheException(String.format("caching strategy not recognized: %s", cachingStrategy));
        }
    }

    /**
     * We have a bit of a problem here, because we cannot be sure for which
     * operation to return the resulted state of. That is: the cache operation
     * should always be successful, so we should return SUCCESS for that. However,
     * if the cache is full we need to displace an element, and that could fail.
     * What should we do then?
     *
     * We decided that this method will return the "worst case result", in the
     * following order: - if there was something displaced (i.e. something to be
     * persisted to the file store), return the result of that - this will return
     * that result whether it was successful or not - our main point here is that
     * any possible error will be returned - if nothing was displaced, return
     * PUT_SUCCESS or DELETE_SUCCESS, depending on whether value was empty or not
     */
    @Override
    public Transmittable put(String key, String value) {
        boolean alreadyContained = this.cache.contains(key);
        if (alreadyContained) {
            this.cache.delete(key);
        }
        Optional<KvEntry> displacedEntry = this.cache.put(key, value);

        return displacedEntry.map(kvEntry -> kvStore.put(kvEntry.key, kvEntry.value)).orElseGet(() -> {
            StatusType status;
            if (value.isEmpty()) {
                status = DELETE_SUCCESS;
            } else if (alreadyContained) {
                status = PUT_UPDATE;
            } else {
                status = PUT_SUCCESS;
            }
            return new KvMessage(key, value, status);
        });
    }

    @Override
    public Transmittable delete(String key) {
        boolean wasDeleted = this.cache.delete(key);

        if (!wasDeleted) {
            return kvStore.delete(key);
        } else {
            return new KvMessage(key, "", DELETE_SUCCESS);
        }
    }

    /**
     * Returns GET_SUCCESS when the key is either found in the cache or in the file
     * store. Returns GET_ERROR otherwise.
     */
    @Override
    public Transmittable get(String key) {
        Optional<String> cachedValue = this.cache.get(key);

        return cachedValue.map(value -> (Transmittable) new KvMessage(key, value, GET_SUCCESS)).orElseGet(() -> {
            Transmittable response = kvStore.get(key);
            if (response.isSuccessful()) {
                this.put(response.getKey(), response.getValue());
            }
            return response;
        });
    }

    public void persistCacheData() {
        log.info("Persisting cache data...");

        this.cache.iterator().forEachRemaining(kvEntry -> kvStore.put(kvEntry.key, kvEntry.value));
    }
}
