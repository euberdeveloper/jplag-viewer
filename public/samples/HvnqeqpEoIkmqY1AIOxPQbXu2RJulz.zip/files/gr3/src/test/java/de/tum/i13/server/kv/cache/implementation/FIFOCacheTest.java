package de.tum.i13.server.kv.cache.implementation;

import de.tum.i13.server.kv.cache.KvEntry;
import org.junit.jupiter.api.Test;

import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;

class FIFOCacheTest {

    @Test
    void put() {
        FIFOCache cache = new FIFOCache(100);

        Optional<KvEntry> displaced = cache.put("k_special", "v_special");
        assertTrue(displaced.isEmpty());
        for (int i = 0; i < 99; i++) {
            displaced = cache.put("k", "v");
            assertTrue(displaced.isEmpty());
        }

        assertEquals(100, cache.size());
        assertTrue(cache.contains(new KvEntry("k_special", "v_special")));

        displaced = cache.put("k_new", "v_new");
        assertFalse(cache.contains(new KvEntry("k_special", "v_special")));
        assertTrue(displaced.isPresent() &&
                displaced.get().equals(new KvEntry("k_special", "v_special")));
    }

    @Test
    void get() {
        FIFOCache cache = new FIFOCache(100);

        for (int i = 0; i < 100; i++) {
            cache.put("k" + i, "v" + i);
        }

        assertEquals(Optional.of("v0"), cache.get("k0"));
        assertEquals(Optional.of("v99"), cache.get("k99"));
        assertEquals(Optional.of("v42"), cache.get("k42"));
        assertEquals(Optional.empty(), cache.get("k100"));
    }

    @Test
    public void testChangingValues() {
        FIFOCache cache = new FIFOCache(5);

        for (int i = 0; i < 5; i++) {
            cache.put("k", "v" + i);
            assertEquals(Optional.of("v" + i), cache.get("k"));
        }
    }

    @Test
    public void testDeletedValueDoesntReturnAnEmptyString() {
        FIFOCache cache = new FIFOCache(5);

        cache.put("k", "v");
        cache.put("k", "");

        assertEquals(Optional.empty(), cache.get("k"));
    }

    @Test
    public void delete() {
        FIFOCache cache = new FIFOCache(100);

        for (int i = 0; i < 100; i++) {
            if (i != 42)
                cache.put("k" + i, "v" + i);
        }

        assertEquals(Optional.of("v0"), cache.get("k0"));
        assertEquals(Optional.of("v99"), cache.get("k99"));
        assertEquals(Optional.empty(), cache.get("k42"));
        assertEquals(Optional.empty(), cache.get("k100"));
        assertEquals(99, cache.size());
    }
}