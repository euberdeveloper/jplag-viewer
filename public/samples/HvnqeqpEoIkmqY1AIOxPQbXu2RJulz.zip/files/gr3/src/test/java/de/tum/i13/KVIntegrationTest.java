package de.tum.i13;

import de.tum.i13.client.communication.ClientException;
import de.tum.i13.client.communication.KvClient;
import de.tum.i13.server.nio.StartSimpleNioServer;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

public class KVIntegrationTest {

    public final Integer port = 5158;
    private final String host = "127.0.0.1";

    @Test
    public void smallStressTest() throws InterruptedException, ClientException {
        Thread serverThread = startServerThread();

        initializeKvStoreAtServer();

        for (int tCount = 0; tCount < 2; tCount++) {
            startNewClientThread(tCount);
        }

        Thread.sleep(5000);
        serverThread.interrupt();
    }

    private void startNewClientThread(int waitBeforeConnecting) {
        new Thread(() -> connectANewClient(waitBeforeConnecting)).start();
    }

    private Thread startServerThread() throws InterruptedException {
        Thread serverThread = new Thread(() -> StartSimpleNioServer.main(new String[]{"-p", port.toString()}));
        serverThread.start();

        // wait for server to be up
        Thread.sleep(2000);
        return serverThread;
    }

    private void initializeKvStoreAtServer() throws ClientException {
        KvClient client = new KvClient();
        client.connect(host, port);
        client.receiveMessage();
        client.put("k0", "v0");
        client.put("k1", "v1");
        client.disconnect();
    }

    private void connectANewClient(final int waitBeforeConnection) {
        try {
            Thread.sleep(waitBeforeConnection * 100);

            for (int i = 0; i < 100; i++) {
                KvClient client = new KvClient();
                client.connect(host, port);
                client.receiveMessage();
                Assertions.assertEquals(
                        String.format("get_success k%s v%s", waitBeforeConnection, waitBeforeConnection),
                        client.get("k" + waitBeforeConnection));
                client.disconnect();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
