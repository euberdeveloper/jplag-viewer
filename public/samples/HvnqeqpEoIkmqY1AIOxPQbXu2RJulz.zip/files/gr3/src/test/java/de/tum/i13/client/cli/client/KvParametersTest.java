package de.tum.i13.client.cli.client;

import de.tum.i13.client.communication.ClientException;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class KvParametersTest {

    @Test
    void containsMoreThanBase64WithWhitespace() {
        assertDoesNotThrow(() -> {
            new KvParameters("key test");
            new KvParameters("k 01239870192835");
            new KvParameters("k asfdASDF+/      ");
        });

        assertThrows(ClientException.class, () -> new KvParameters("k but&no"));
        assertThrows(ClientException.class, () -> new KvParameters("k but\tno"));
        assertThrows(ClientException.class, () -> new KvParameters("k but<>>no"));
    }
}