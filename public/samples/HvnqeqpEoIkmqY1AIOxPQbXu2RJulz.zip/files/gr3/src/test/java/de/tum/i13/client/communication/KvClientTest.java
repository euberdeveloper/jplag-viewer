package de.tum.i13.client.communication;

import de.tum.i13.server.kv.cache.CacheException;
import de.tum.i13.server.kv.store.StoreException;
import de.tum.i13.server.nio.Server;
import de.tum.i13.shared.Config;
import org.junit.jupiter.api.*;

import java.io.IOException;
import java.nio.file.Path;

import static org.junit.jupiter.api.Assertions.assertEquals;

/**
 * This test was used when the server consisted simply of a file store. Now that the server has a cache manager set up
 * before the file store, this test cannot be used in the same way still.
 * For now, this test is kept here to probably be updated in the near future. Otherwise it would need to be deleted.
 */
@Disabled
class KvClientTest {

    private static final String host = "127.0.0.1";
    private static final int port = 5157;
    private static Path testDataDirectoryPath = Path.of("test_data/");
    private static Server server;

    private final KvClient client = new KvClient();

    @BeforeAll
    public static void startServer() throws InterruptedException, StoreException, CacheException {
        Config config = new Config();
        config.logfile = Path.of("kvclient_test.log");
        config.listenAddress = host;
        config.port = port;
        config.dataDir = testDataDirectoryPath;

        server = new Server(config);

        new Thread(() -> {
            try {
                server.start();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }).start();

        // This should be more than enough to get the server to the state where it accepts clients
        Thread.sleep(500);
    }

    @BeforeEach
    public void connectClient() throws ClientException {
        client.connect(host, port);
        client.receiveMessage();
    }

    @AfterEach
    public void disconnectClientAndResetStore() throws StoreException, ClientException {
        client.disconnect();
        // This method doesn't exist anymore. For more information, see the comment on top of this test class.
//        server.dumpStore();
    }

    @Test
    public void testPutAndGet() throws ClientException {
        client.put("k", "v");
        client.put("k", "v");
        assertEquals("get_success k v", client.get("k"));
    }

    @Test
    public void testPutAndDelete() throws ClientException {
        assertEquals("put_success k0", client.put("k0", "v0"));
        assertEquals("put_success k1", client.put("k1", "v1"));
        assertEquals("get_success k0 v0", client.get("k0"));
        assertEquals("get_success k1 v1", client.get("k1"));

        assertEquals("put_updated k0", client.put("k0", "v0_new"));
        assertEquals("get_success k0 v0_new", client.get("k0"));

        assertEquals("delete_success k1", client.put("k1", ""));
        assertEquals("get_error k1", client.get("k1"));
    }
}