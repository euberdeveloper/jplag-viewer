package de.tum.i13;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;

import org.junit.jupiter.api.Disabled;
import org.junit.jupiter.api.Test;

import de.tum.i13.server.kv.cache.MaxSizeLinkedHashMap;

class TestMaxSizeLinkedHashMap {

    private MaxSizeLinkedHashMap map;

    @Test
    public void testMaxSizeNeverOverpassed() {
        this.map = new MaxSizeLinkedHashMap(5);
        map.put("key1", "value1");
        map.put("key2", "value2");
        map.put("key3", "value3");
        map.put("key4", "value4");
        map.put("key5", "value5");
        map.put("key6", "value6");
        map.put("key7", "value7");
        map.put("key8", "value8");
        assertTrue(map.maxSizeReached());
        assertEquals(map.entrySet().size(), 5);
    }

    @Test
    public void testRemoveEldestEntry() {
        this.map = new MaxSizeLinkedHashMap(5);
        map.put("key1", "value1");
        map.put("key2", "value2");
        map.put("key3", "value3");
        map.put("key4", "value4");
        map.put("key5", "value5");
        assertTrue(map.maxSizeReached());
        assertEquals(map.get("key1"), "value1");
        map.put("key6", "value6");
        assertEquals(map.get("key1"), null);
    }

    @Test
    public void testUpdateValue() {
        this.map = new MaxSizeLinkedHashMap(5);
        map.put("key1", "value1");
        map.put("key2", "value2");
        map.put("key3", "value3");
        map.put("key4", "value4");
        assertFalse(map.maxSizeReached());
        assertEquals(map.get("key1"), "value1");
        map.put("key1", "123");
        assertEquals(map.get("key1"), "123");
        assertEquals(map.entrySet().size(), 4);
    }

    @Test
    public void testRemoveKey() {
        this.map = new MaxSizeLinkedHashMap(5);
        map.put("key1", "value1");
        map.put("key2", "value2");
        map.put("key3", "value3");
        map.put("key4", "value4");
        assertEquals(map.entrySet().size(), 4);
        map.remove("key1");
        assertEquals(map.entrySet().size(), 3);
        assertEquals(map.get("key1"), null);
    }

    @Disabled
    @Test
    public void testAddingMultipleElementsOfTheSameType() {
        this.map = new MaxSizeLinkedHashMap<>(5);

        for (int i = 0; i < 5; i++) {
            map.put("k", "v");
        }

        /* Error: For MaxSizeLinkedHashMap to be used for the FIFO implementation, this should give back 5, as we put 5
         * elements into the cache --> and the FIFO cache would not check for whether some of this object is already
         * contained or not - it would simply add it!
         * We leave this (disabled) test just here to demonstrate that.
         */
        assertEquals(5, map.size());
    }

}