package de.tum.i13.server.kv.store;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class FileKvStoreTest {

    private final FileKvStore store;

    FileKvStoreTest() throws StoreException {
        store = new FileKvStore("store.csv");
    }

    @AfterEach
    public void dumpStore() throws StoreException {
        store.dumpStore();
    }

    @Test
    public void testSingleWriteAndRead() throws StoreException {
        store.put("key1", "value1");
        store.put("k2", "v2");

        System.out.println(store.toString());

        assertEquals("value1", store.get("key1"));
    }

    @Test
    public void testStrangeKeyNamesWork() throws StoreException {
        final String strangeKey = "strange;key";
        final String value = "v";

        store.put(strangeKey, value);
        assertEquals(value, store.get(strangeKey));
    }

    @Test
    public void testKeyAndValueWithDelimiter() throws StoreException {
        final String keyWithDelimiter = "key_with" + FileKvStore.DELIMITER + "delimiter";
        assertThrows(StoreException.class, () -> store.put(keyWithDelimiter, "anyValue"));

        final String correctKey = "k";
        final String valueWithDelimiter = "value_with" + FileKvStore.DELIMITER + "delimiter";
        assertDoesNotThrow(() -> store.put(correctKey, valueWithDelimiter));
        assertEquals(valueWithDelimiter, store.get(correctKey));
    }

    @Test
    public void testDumpingWorks() throws StoreException {
        final String key = "k1";
        final String newValue = "v1_new";

        store.put(key, "v1");
        store.dumpStore();
        store.put(key, newValue);

        assertEquals(newValue, store.get(key));
    }

    @Test
    public void testUpdateOfKey() throws StoreException {
        String key = "k";
        String initialValue = "v";
        String updatedValue = "v_updated";

        boolean updated = store.put(key, initialValue);
        assertEquals(initialValue, store.get(key));
        assertFalse(updated);

        updated = store.put(key, updatedValue);
        assertEquals(updatedValue, store.get(key));
        assertTrue(updated);
    }

    @Test
    public void testDeletionOfKey() throws StoreException {
        for (int i = 0; i < 100; i++) {
            store.put("k" + i, "v" + i);
        }

        assertEquals("v42", store.delete("k42"));
        assertEquals("v99", store.delete("k99"));

        assertThrows(StoreException.class, () -> store.get("k42"));
        assertThrows(StoreException.class, () -> store.get("k99"));

        for (int i = 0; i < 100; i++) {
            if (i != 42 && i != 99)
                assertEquals("v" + i, store.get("k" + i));
        }
    }

}