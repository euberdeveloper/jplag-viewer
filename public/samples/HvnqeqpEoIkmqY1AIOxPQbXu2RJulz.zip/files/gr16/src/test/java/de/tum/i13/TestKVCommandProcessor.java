package de.tum.i13;

import de.tum.i13.server.kv.KVCommandProcessor;
import de.tum.i13.server.kv.KVStore;
import de.tum.i13.server.kv.KVStorer;

import org.junit.jupiter.api.Test;
import org.mockito.Mock;

import de.tum.i13.shared.Config;


import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;


public class TestKVCommandProcessor {

    @Test
    public void correctParsingOfPut() throws Exception {
        KVStorer kv = mock(KVStorer.class);
        KVCommandProcessor kvcp = new KVCommandProcessor(kv,"INFO");
        kvcp.process("put key hello\r\n");
        verify(kv).put("key", "hello");
    }
    
    @Test
    public void correctParsingOfGet() throws Exception {
        KVStorer kv = mock(KVStorer.class);
        KVCommandProcessor kvcp = new KVCommandProcessor(kv,"INFO");
        kvcp.process("get key\r\n");
        verify(kv).get("key");
    }
    @Test
    public void correctParsingOfDelete() throws Exception {
        KVStorer kv = mock(KVStorer.class);
        KVCommandProcessor kvcp = new KVCommandProcessor(kv,"INFO");
        kvcp.process("delete key \r\n");
        verify(kv).delete("key");
    }



}