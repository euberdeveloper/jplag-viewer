package de.tum.i13;

import de.tum.i13.server.kv.FIFOMap;
import de.tum.i13.server.kv.LFUMap;
import de.tum.i13.server.kv.LRUMap;
import org.junit.jupiter.api.Test;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;

import static org.junit.jupiter.api.Assertions.assertEquals;

public class CacheStrategyTest {

    Path path = Paths.get("FIFOtestdata/");
    Path path1 = Paths.get("LRUtestdata/");
    Path path2 = Paths.get("LFUtestdata/");
    @Test public void FifoTest(){
    	if(!Files.exists(path)) {
            try {
                Files.createDirectory(path);
            } catch (IOException e) {
                System.out.println("Could not create directory");
                e.printStackTrace();
                System.exit(-1);
            }
        }
        FIFOMap fifo=new FIFOMap(3,path);
        fifo.put("foo","bar");
        fifo.put("apple","orange");
        fifo.put("number","42");
        fifo.put("hello","bye");
        String val=fifo.get("foo");
        assertEquals(val,null,"Removed correct val from fifo map"); // the first inserted kv pair  should have been removed
    }
    @Test public void LRUTest(){
    	if(!Files.exists(path1)) {
            try {
                Files.createDirectory(path1);
            } catch (IOException e) {
                System.out.println("Could not create directory");
                e.printStackTrace();
                System.exit(-1);
            }
        }
        LRUMap lru=new LRUMap(3,path1);
        lru.put("foo","bar");
        lru.put("apple","orange");
        lru.put("number","42");
        lru.get("foo");
        lru.get("apple");
        lru.get("foo");
        lru.put("coffee","tea");
        String val=lru.get("number");
        assertEquals(val,null,"Removed correct val from lru map"); //the least recently used kv pair  should have been remove
    }
    @Test public void LFUTest(){
    	if(!Files.exists(path2)) {
            try {
                Files.createDirectory(path2);
            } catch (IOException e) {
                System.out.println("Could not create directory");
                e.printStackTrace();
                System.exit(-1);
            }
        }
        LFUMap lfu=new LFUMap(3,path2);
        lfu.put("foo","bar");
        lfu.put("apple","orange");
        lfu.put("number","42");
        lfu.get("number");
        lfu.get("foo");
        lfu.get("foo");
        lfu.get("foo");
        lfu.get("foo");
        lfu.get("apple");
        lfu.get("apple");
        lfu.get("apple");
        lfu.put("coffee","tea");
        String val=lfu.get("number");
        assertEquals(val,null,"Removed correct val from lfu map");//the least frequently used kv pair number 42 should have been removed

    }
}
