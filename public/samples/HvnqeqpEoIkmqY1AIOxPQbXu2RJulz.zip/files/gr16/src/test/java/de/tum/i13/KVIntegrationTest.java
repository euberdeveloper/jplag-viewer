package de.tum.i13;

import org.junit.jupiter.api.Test;

import java.io.*;
import java.net.InetSocketAddress;
import java.net.Socket;

import static org.hamcrest.CoreMatchers.*;
import static org.hamcrest.MatcherAssert.assertThat;

public class KVIntegrationTest {

    public static Integer port = 5153;

    public String doRequest(Socket s) throws IOException {
        BufferedReader input = new BufferedReader(new InputStreamReader(s.getInputStream()));
        String res = input.readLine();
        return res;
    }

    public String disconnect(Socket s) throws IOException {
        PrintWriter output = new PrintWriter(s.getOutputStream());
        BufferedReader input = new BufferedReader(new InputStreamReader(s.getInputStream()));

        output.write("disconnect" + "\r\n");
        output.flush();

        String res = input.readLine();
        return res;
    }

    @Test
    public void connectTest() throws InterruptedException, IOException {
        Thread th = new Thread() {
            @Override
            public void run() {
                try {
                    de.tum.i13.server.nio.StartSimpleNioServer.main(new String[]{"-p" + port.toString()});
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        };
        th.start(); // started the server
        Thread.sleep(2000);

        Socket s = new Socket();
        s.connect(new InetSocketAddress("127.0.0.1", port));
        assertThat(doRequest(s), is(equalTo("Connection to KVStore server established: /127.0.0.1:5153")));
        s.close();

    }

   
}
