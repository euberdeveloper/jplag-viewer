package de.tum.i13.server.kv;

import java.util.HashMap;
import java.util.TreeMap;
import java.util.concurrent.Semaphore;

import de.tum.i13.shared.Config;

public class KVStorer implements KVStore {
	private Config cfg;
	private CacheStrategy cacheStrategy;
	private Semaphore semaphore;
	public KVStorer(Config cfg) {
		this.cfg=cfg;
		String temp = cfg.cacheStrategy;
		switch (temp) {
		
		case "FIFO" : this.cacheStrategy = new CacheStrategy (new FIFOMap(cfg.cacheSize,cfg.dataDir) ,cfg);break;
		case "LRU"  : this.cacheStrategy = new CacheStrategy (new LRUMap(cfg.cacheSize,cfg.dataDir),cfg);break;
		case "LFU"  : this.cacheStrategy = new CacheStrategy (new LFUMap (cfg.cacheSize,cfg.dataDir) ,cfg);break;
		default : this.cacheStrategy= new CacheStrategy(new FIFOMap(cfg.cacheSize,cfg.dataDir),cfg);break;
		}
		semaphore = new Semaphore (1);



	}
    @Override
	public  KVMessage put(String key, String value) throws Exception {
		
		// TODO Auto-generated method stub
    	semaphore.acquire();
		KVMessage result = cacheStrategy.put(key, value);
		semaphore.release();
		return result;
    	}
    

	@Override
	public KVMessage get(String key) throws Exception {
		// TODO Auto-generated method stub
		return cacheStrategy.get(key);
	}

	@Override
	public KVMessage delete(String key) throws Exception {
		semaphore.acquire();
		KVMessage result = cacheStrategy.put(key, null);
		semaphore.release();
		return result;
	}
	

	@Override
	public void disconnect() throws Exception{
		this.cacheStrategy.writeAll();
	}


}
