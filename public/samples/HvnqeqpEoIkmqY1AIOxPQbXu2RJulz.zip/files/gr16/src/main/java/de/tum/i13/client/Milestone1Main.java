package de.tum.i13.client;

import de.tum.i13.server.nio.StartSimpleNioServer;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.nio.file.Paths;
import java.util.Base64;
import java.util.logging.Level;
import java.util.logging.Logger;
import static de.tum.i13.shared.LogSetup.setupLogging;


public class Milestone1Main {
    public static Logger logger = Logger.getLogger(Milestone1Main.class.getName());
    public static void main(String[] args) throws IOException {
        BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));
        setupLogging(Paths.get("client.log"));

        ActiveConnection activeConnection = null;
        for(;;) {
            System.out.print("KVClient> ");
            String line = reader.readLine();
            String[] command = line.split(" ");
            //System.out.print("command:");
            //System.out.println(line);
            switch (command[0]) {
                case "connect": activeConnection = buildconnection(command); break;
                case "disconnect": closeConnection(activeConnection); break;
                case "help": printHelp(); break;
                case "get" : get(activeConnection,command);break;
                case "put" : put (activeConnection,command);break;
                case "quit": printKVLine("Application exit!");logger.info("Application exit!"); return;
                case "delete": delete(activeConnection,command);break;
                case "logLevel":setLogLevel(command);break;
                default: printKVLine("error given command not recognized");logger.warning("error given command not recognized");
            }
        }
    }

    private static void printHelp() {
        System.out.println("Available commands:");
        System.out.println("connect <address> <port> - Tries to establish a TCP- connection to the KV Server based on the given server address and the port number of the Key Value service.");
        System.out.println("disconnect - Tries to disconnect from the connected server.");
        System.out.println("logLevel <level> - Sets the logger to the specified log level (ALL | DEBUG | INFO | WARN | ERROR | FATAL | OFF)");
        System.out.println("help - Display this help");
        System.out.println("quit - Tears down the active connection to the server and exits the program execution.");
        System.out.println("put <key> <value> - Inserts the key value pair if key exists already then key is updated ");
        System.out.println("delete <key> - Given key and its value are deleted ");
        System.out.println("get <key> - Returns the value of a given key if the key already exists");

      
    }

    private static void printKVLine(String msg) {
        System.out.println("KVClient> " + msg);
    }
    
    private static void get (ActiveConnection activeConnection , String[] command) {
    	 if(activeConnection == null) {
             printKVLine("Error! Not connected!");
             logger.warning("Error! Not connected!");

             return;
         }
    	 if (command.length == 2) {
    	 String cmd = command[0] + " " + encodeInBase64(command[1]) ; // only encodes key in Base64
    	 activeConnection.write(cmd);
    	 try {
    	    String msg=activeConnection.readline();
    	    String [] msgarray = msg.split(" ");
    	    if (msgarray.length>2) {
    	    	String decodedKey= decodeInBase64(msgarray [1]);
    	    	String vl = decodeInBase64 (msgarray[2]);
    	    	for(int i=3;i<command.length;i++) {
    	     		vl = vl + " " +  decodeInBase64(command[i]); //decodes remaining part of the value
    	     	}
                printKVLine(msgarray[0] +" " +decodedKey +" " + vl);
    	    	logger.info(msgarray[0] +" " +decodedKey +" " + vl);

    	    } else {
             	printKVLine (msgarray[0] + " " + decodeInBase64(msgarray[1]));
             	logger.info(msgarray[0] + " " + decodeInBase64(msgarray[1]));
    	    }
         } catch (IOException e) {
             printKVLine("Error! Not connected!");
             logger.warning("Error! Not connected!");
         }
    } else {
    	printKVLine ("Unknown command");
    	logger.warning("Unknown command");
    }
    }
    
    private static void put (ActiveConnection activeConnection , String[] command) {
    	 if(activeConnection == null) {
             printKVLine("Error! Not connected!");
             logger.warning("Error! Not connected!");
             return;
         }
    	 //if (command.length ==3 ) {
    	 String vl = encodeInBase64(command[2]);
     	for(int i=3;i<command.length;i++) {
     		vl = vl + " " +  encodeInBase64(command[i]);
     	}


             String encodedKey=encodeInBase64(command[1]);//encodes key in Base
        	 String cmd = command[0] + " " + encodedKey + " " + vl;
        	 activeConnection.write(cmd);
        	
        	 try {
        		 
        		 String msg = activeConnection.readline() ;
        		 String [] msgarray = msg.split(" ");
        		 if (msgarray.length==2) {
        			 printKVLine (msgarray[0] + " " + decodeInBase64(msgarray[1]));
        			 logger.info(msgarray[0] + " " + decodeInBase64(msgarray[1]));
        		 }else {
        			 String putkey = decodeInBase64(msgarray[1]);
        			 String value = decodeInBase64(msgarray[2]);
        			 for (int i=3 ; i<msgarray.length;i++) {
        				 value += " "+ decodeInBase64(msgarray[i]);
        			 }
                     printKVLine(msgarray[0] + putkey + value);
        			 logger.info(msgarray[0] + putkey + value);

        		 }
             } catch (IOException e) {
                 printKVLine("Error! Not connected!");
                 logger.warning("Error! Not connected!");
             }
    	 //} else {
    	//printKVLine ("Unknown command");
    	 //}
    }
    
    private static void delete (ActiveConnection activeConnection , String[] command) {
    	 if(activeConnection == null) {
             printKVLine("Error! Not connected!");
             logger.warning("Error! Not connected!");
             return;
         }
    	 if (command.length == 2) {
    	     String encodedKey=encodeInBase64(command[1]);//encodes key in Base64
    	 String cmd = command[0] + " " + encodedKey ;
    	 activeConnection.write(cmd);
    	 try {
    		 String msg =  activeConnection.readline();
    		 String []msgarray = msg.split(" "); //removes whitespaces to prevent decoding whitespace
    		 String deletekey = decodeInBase64 (msgarray[1]);
             printKVLine(msgarray[0]+ " "+ deletekey);
             logger.info(msgarray[0]+ " "+ deletekey);
         } catch (IOException e) {
             printKVLine("Error! Not connected!");
             logger.warning("Error! Not connected!");
         }
    } else {
    	printKVLine ("Unknown command");
    	logger.warning("Unknown command");
    }
    }
    	
    

    private static void closeConnection(ActiveConnection activeConnection) {
        if(activeConnection != null) {
            try {
                activeConnection.close();
                printKVLine("Disconnected!");
                logger.info("Disconnected!");
            } catch (Exception e) {
                //e.printStackTrace();
                //TODO: handle gracefully
                activeConnection = null;
            }
        }
    }

    /*private static void sendmessage(ActiveConnection activeConnection, String[] command, String line) {
        if(activeConnection == null) {
            printKVLine("Error! Not connected!");
            return;
        }
        int firstSpace = line.indexOf(" ");
        if(firstSpace == -1 || firstSpace + 1 >= line.length()) {
            printKVLine("Error! Nothing to send!");
            return;
        }

        String cmd = line.substring(firstSpace + 1);
        activeConnection.write(cmd);

        try {
            printKVLine(activeConnection.readline());
        } catch (IOException e) {
            printKVLine("Error! Not connected!");
        }
    }*/

    private static ActiveConnection buildconnection(String[] command) {
        if(command.length == 3){
            try {
                EchoConnectionBuilder kvcb = new EchoConnectionBuilder(command[1], Integer.parseInt(command[2]));
                ActiveConnection ac = kvcb.connect();
               String confirmation = ac.readline();
                printKVLine(confirmation);
                logger.info(confirmation);

                return ac;
            } catch (Exception e) {
                //Todo: separate between could not connect, unknown host and invalid port
                printKVLine("Could not connect to server");
                logger.info("Connected to KVStore Server");
            }
        }
        return null;
    }
    private static String encodeInBase64(String msg){  //function for encoding the data in Base64
        return Base64.getEncoder().withoutPadding().encodeToString(msg.getBytes());



    }
    private static  String decodeInBase64(String msg){ //function for decoding the data in Base64
        byte [] decodedBytes=Base64.getDecoder().decode(msg.getBytes());
        return new String(decodedBytes);

    }
    private static void setLogLevel(String []command){
        if(command.length==2) {
            String level = command[1];

            if ("SEVERE".equals(level)) {
                logger.setLevel(Level.SEVERE);

            } else if ("WARNING".equals(level)) {
                logger.setLevel(Level.WARNING);
            } else if ("INFO".equals(level)) {
                logger.setLevel(Level.INFO);
            } else if ("CONFIG".equals(level)) {
                logger.setLevel(Level.CONFIG);
            } else if ("FINE".equals(level)) {
                logger.setLevel(Level.FINE);
            } else if ("FINER".equals(level)) {
                logger.setLevel(Level.FINER);
            } else if ("FINEST".equals(level)) {
                logger.setLevel(Level.FINEST);
            } else {
                printKVLine("Invalid Level");
                logger.warning("Invalid Level");
            }
        }
        else{
           printKVLine("unknown command");
           logger.warning("unknown command");
        }

    }
}