package de.tum.i13.server.kv;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.nio.file.Path;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Set;
import java.util.logging.Logger;

public class CacheMap extends LinkedHashMap<String, String> {
	Path dataDir;
	public static Logger logger = Logger.getLogger(CacheMap.class.getName());
	
	
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	public CacheMap(int size,Path dataDir) {
		super(size);
		this.dataDir = dataDir;
	}
	@Override
	public String put(String key,String value) {
		return super.put(key, value);
	}
	
	@Override
	public String get(Object key) {
		return super.get(key);
	}
	
	public void writeAll() { //iterates over every KV pair in the cache and calls writeToFile for each
		Iterator<Map.Entry<String, String>> iterator = this.entrySet().iterator();
		while(iterator.hasNext()) {
			Map.Entry<String, String> entry = iterator.next();
			String key = entry.getKey();
			String value = entry.getValue();
		    this.writeToFile(key, value);

		}
	}
	
	protected void writeToFile(String key, String value) { //writes every existing KV in to a separate file for quick access and manipulation
		File file = new File(this.dataDir.toString() + "\\" + key + ".txt");
		if(value == null) { //if KV pair is deleted delete the file if it exists
			if(file.exists()) {
				file.delete();
			}
			return;
		}
		//create or update the file
		try {
			      FileWriter myWriter = new FileWriter(this.dataDir.toString() + "\\" + key + ".txt");
			      myWriter.write(value);
			      myWriter.close();
			      logger.info("Successfully wrote to the file");
			    } catch (IOException e) {
			      System.out.println("Disk insertion failed!");
			      e.printStackTrace();
			}			  
	}
}
