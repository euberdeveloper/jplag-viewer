package de.tum.i13.server.kv;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Scanner;

import de.tum.i13.shared.Config;

public class CacheStrategy {
	private int maxSize;
	private File dataFile;
	private Config cfg;
    private CacheMap queue;
    public CacheMap getQueue(){
        return this.queue;
    }
    
    public CacheStrategy (CacheMap map,Config cfg) {
    	this.cfg=cfg;
		this.maxSize = cfg.cacheSize;
		this.queue = map;
		this.cfg = cfg;
	}
    
    public KVMessage put(String key, String value) {
    	KVMessage resultmsg = new KVMessager();
    	boolean alreadyDeleted = false;
    	boolean delete = false;
    	boolean found = false;
    	if(value == null) {
    		delete = true;
    	}
    	for(String queueKey : queue.keySet()) {
    		if(queueKey.equals(key)) {
    			found = true;
    		}
    	}
    	if(found) {
    		if(queue.get(key) == null) {
				alreadyDeleted = true;
			}
    	}
    	if(!found) {
        	File readFile = new File(cfg.dataDir.toString() + "\\" + key + ".txt") ;
        	if(readFile.exists()) {
        		found = true;
        	}
    	}
		resultmsg.setKey(key);
		resultmsg.setValue(value);
    	if(found) {
    		if(delete) {
    			if(alreadyDeleted) {
    				resultmsg.setStatus(KVMessage.StatusType.DELETE_ERROR);
    			} else {
    		    	queue.put(key, value);
        			resultmsg.setStatus(KVMessage.StatusType.DELETE_SUCCESS);
    			}
    		}else {
    	    	queue.put(key, value);
    	    	if(alreadyDeleted) {
        			resultmsg.setStatus(KVMessage.StatusType.PUT_SUCCESS);
    	    	} else {
        			resultmsg.setStatus(KVMessage.StatusType.PUT_UPDATE);
    	    	}
    		}
    	} else {
    		if(delete) {
    			resultmsg.setStatus(KVMessage.StatusType.DELETE_ERROR);
    		}else  {
    	    	queue.put(key, value);
    			resultmsg.setStatus(KVMessage.StatusType.PUT_SUCCESS);
    		}
    	}
    	return resultmsg;
    }
    	// TODO Auto-generated method stub

    public KVMessage get(String key) {
    	KVMessage resultmsg = new KVMessager();
    	for(String queueKey : queue.keySet()) {
    		if(queueKey.equals(key)){
    			String value = queue.get(key);
    			if(value == null) {
    				resultmsg.setKey(key);
    				resultmsg.setStatus(KVMessage.StatusType.GET_ERROR);
    				return resultmsg;
    			}
    			resultmsg.setKey(key);	
    			resultmsg.setValue(value);
    			resultmsg.setStatus(KVMessage.StatusType.GET_SUCCESS);
    			return resultmsg;
    		}
    			
    	}
    	// TODO Auto-generated method stub
    	try {

    		 File readFile = new File(cfg.dataDir.toString() + "\\" + key + ".txt") ;
    		 if(readFile.exists()) {
    			 Scanner reader = new Scanner(readFile);
       	      while (reader.hasNextLine()) {
       	        String data = reader.nextLine();
       	        resultmsg.setKey(key);
       	        resultmsg.setValue(data);
       	        resultmsg.setStatus(KVMessage.StatusType.GET_SUCCESS);
       	        reader.close();
       	        queue.put(key,data);
       	        return resultmsg;
         	      

       	      }
       	       reader.close();
       	      
       	      
    		  } else {
    			 resultmsg.setStatus(KVMessage.StatusType.GET_ERROR);
    			 resultmsg.setKey(key);
    	          return resultmsg;
    		  }
    	      
    	} catch (FileNotFoundException e) {
    	      System.out.println("An error occurred.");
    	      e.printStackTrace();
    	}
    	resultmsg.setStatus(KVMessage.StatusType.GET_ERROR);
    	resultmsg.setKey(key);
        return resultmsg;
    }
    	
    public KVMessage delete (String key) { //nulls the value for delete

    	return put(key,null);
    }

    public void writeAll() { //method for block write to the disk
    	// TODO Auto-generated method stub
    	this.queue.writeAll();

    }
}
