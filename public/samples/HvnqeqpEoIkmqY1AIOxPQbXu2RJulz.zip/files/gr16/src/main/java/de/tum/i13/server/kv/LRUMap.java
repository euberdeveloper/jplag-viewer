package de.tum.i13.server.kv;

import java.nio.file.Path;
import java.util.Iterator;
import java.util.Map;


public class LRUMap extends CacheMap{

private int size;
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public LRUMap(int size, Path dataDir) {
		super(size + 1,dataDir);
		this.size = size;
		
	}
	
	@Override
	public String put(String key,String value) {
		if(super.containsKey(key)) {
			super.remove(key);
		}
		String returnString = super.put(key, value);
		if(super.size() > this.size) {
			removeOldest();
		}
		return returnString;
		
	}
	
	@Override
	public String get(Object key) {
		String value = super.get(key);
		if(value != null) { //deleted items shouldn't be kept in the cache longer than necessary
			this.put(key.toString(), value);
		}
		return value;
	}
	
	private void removeOldest() { //removes the least recently used key
	Iterator<Map.Entry<String, String>> iterator = this.entrySet().iterator();
        if (iterator.hasNext()){
        	Map.Entry<String, String> removedEntry = iterator.next();
        	String removedKey = removedEntry.getKey();
        	String removedValue = removedEntry.getValue();
        	super.writeToFile(removedKey, removedValue);
            super.remove(removedKey);
        }
		
	}
	
}
