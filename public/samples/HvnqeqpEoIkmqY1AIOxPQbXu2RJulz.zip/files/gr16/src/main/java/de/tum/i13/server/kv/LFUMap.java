package de.tum.i13.server.kv;

import java.nio.file.Path;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.Map;


public class LFUMap extends CacheMap{

	private int size;
	private LinkedHashMap<String,Integer> frequency; //map which cointains each key's access frequency
	private int min;
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	public LFUMap(int size,Path dataDir) {
		super(size + 1,dataDir);
		this.size = size;
		this.frequency = new LinkedHashMap<String,Integer>();
		this.min = 1;
		
	}
	
	@Override
	public String put(String key,String value) {		
		if(super.size()+1 > this.size) {
			removeOldest();
		}
		if(super.containsKey(key)) {
			int fr = frequency.get(key);
			frequency.put(key, fr+1);
		}else {
			
			frequency.put(key, 1);
			this.min = 1;
		}
		String returnString = super.put(key, value);
		return returnString;
		
	}
	
	@Override
	public String get(Object key) {
		String value = super.get(key);
		if(value != null) { //increases the frequency of existing pairs
			int fr = frequency.get(key);
			frequency.put(key.toString(), fr+1);
		}
		return value;
	}
	
	private void removeOldest() { // the key-value pair with the least access frequency will be removed
		Iterator<Map.Entry<String, Integer>> iterator = this.frequency.entrySet().iterator();
		String keyToRemove = null;
		boolean quit = false;
		while(!quit) {
			while(iterator.hasNext()){
				Map.Entry<String, Integer> removedEntry = iterator.next();
				if(removedEntry.getValue() == this.min) {
					keyToRemove = removedEntry.getKey();
					quit = true;
					break;
				}
			}
		   iterator = this.frequency.entrySet().iterator();
           this.min++;
		}
    	String valueToRemove  =super.remove(keyToRemove);
    	super.writeToFile(keyToRemove, valueToRemove);
    	this.frequency.remove(keyToRemove);
       
		
        
        
	}

}
