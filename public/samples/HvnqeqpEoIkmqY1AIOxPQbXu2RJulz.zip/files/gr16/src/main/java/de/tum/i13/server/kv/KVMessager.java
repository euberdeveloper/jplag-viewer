package de.tum.i13.server.kv;

public class KVMessager implements KVMessage{
	private String key;
	private String value;
	private StatusType status;
	

	@Override
	public String getKey() {
		// TODO Auto-generated method stub
		return key;
	}

	@Override
	public String getValue() {
		// TODO Auto-generated method stub
		return value;
	}

	@Override
	public StatusType getStatus() {
		// TODO Auto-generated method stub
		return status;
	}
	
	public void setKey(String key) {
		this.key=key;
	}
	public void setValue(String value) {
		this.value=value;
	}
	public void setStatus (StatusType status) {
		this.status=status;
	}

}
