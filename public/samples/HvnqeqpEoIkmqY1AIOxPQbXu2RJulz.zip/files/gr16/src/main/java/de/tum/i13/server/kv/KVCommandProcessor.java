package de.tum.i13.server.kv;

import de.tum.i13.server.echo.EchoLogic;
import de.tum.i13.shared.CommandProcessor;
import de.tum.i13.shared.Config;

import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.util.logging.Level;
import java.util.logging.Logger;

public class KVCommandProcessor implements CommandProcessor {
    private KVStore kvStore;
    public static Logger logger = Logger.getLogger(KVCommandProcessor.class.getName());
    
    public KVCommandProcessor(KVStore kvStore , String loglevel) {
    	switch(loglevel){
			case "INFO":logger.setLevel(Level.INFO);break;
			case "SEVERE":logger.setLevel(Level.SEVERE);break;
			case "ALL":logger.setLevel(Level.ALL);break;
			case "FINE":logger.setLevel(Level.FINE);break;
			case "FINER":logger.setLevel(Level.FINER);break;
			case "CONFIG":logger.setLevel(Level.CONFIG);break;
			case "OFF":logger.setLevel(Level.OFF);break;
			case "WARNING":logger.setLevel(Level.WARNING);break;

				// this constructor enables access to Config object.
		}
        this.kvStore = kvStore;
    }
 

    @Override
    public String process(String command) {
        //TODO
        //Parse message "put message", call kvstore.put
    	 String[] commandArray = command.split(" ");
    	 logger.info("received command: " + command.trim());
    	 KVMessage value ; 
    	 
    	 String s = commandArray[commandArray.length-1];
    	 commandArray[commandArray.length-1] = s.substring(0, s.length() - 2);
         //Let the magic happen here
    	 switch (commandArray[0]) {
    	 
    	 case "put" : 
         
        try {
        	String vl = commandArray[2];
        	for(int i=3;i<commandArray.length;i++) {
        		vl = vl + " " + commandArray[i];
        	}
            KVMessage putmsg =  this.kvStore.put(commandArray [1], vl);
            KVMessage.StatusType status =  putmsg.getStatus();
            switch (status ) {
            case PUT_SUCCESS : logger.info("Key value pair successfully inserted");return "put_success " + putmsg.getKey() + "\r\n";
            case PUT_UPDATE  : logger.info("Value to given key updated");return "put_update " + putmsg.getKey() + "\r\n" ;
            case PUT_ERROR   :logger.info("Put request not successful"); return "put_error " + putmsg.getKey() + " " + putmsg.getValue() + "\r\n" ;
			default:
				break; 
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    	 case "get" : 
    		 try {
    	            value = this.kvStore.get(commandArray [1]);
    	            if (KVMessage.StatusType.GET_ERROR ==  value.getStatus()) {
                        logger.info("Key not found");
    	            	return "get_error " + value.getKey() + "\r\n" ;
    	            } else {
    	            	return "get_success " + value.getKey() + " " + value.getValue() + "\r\n";
    	            }
    	        } catch (Exception e) {
    	            e.printStackTrace();
    	        }
    		 break;
    		 
    	 case "delete" : 
    		 try {
 	            value = this.kvStore.delete(commandArray[1]);
 	            
 	            if (KVMessage.StatusType.DELETE_ERROR ==  value.getStatus()) {
                    logger.info("Deletion could not be done");
 	            	return "delete_error " + value.getKey() + "\r\n" ;
 	            } else {
                    logger.info("Deletion successful");
 	            	return "delete_success " + value.getKey() + "\r\n" ;
 	            }
 	        } catch (Exception e) {
 	            return e.toString() +  "\r\n";
 	        }
    		
    	 
    	
    	 }
        return "error given command not recognized\r\n";
    }

    @Override
    public String connectionAccepted(InetSocketAddress address, InetSocketAddress remoteAddress) {
    	 logger.info("new connection: " + remoteAddress.toString());

         return "Connection to KVStore server established: " + address.toString() + "\r\n";
     
        
    }

    @Override
    public void connectionClosed(InetAddress address) {
    	try {
			this.kvStore.disconnect();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
        //TODO
        logger.info("connection closed: " + address.toString());

    }
}
