package de.tum.i13.server.kv;

import java.nio.file.Path;
import java.util.Iterator;
import java.util.Map;


public class FIFOMap extends CacheMap{

	private int size;
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public FIFOMap(int size, Path dataDir) {
		super(size + 1,dataDir);
		this.size = size;
		
	}
	
	@Override
	public String put(String key,String value) {
		String returnString = super.put(key, value);
		if(super.size() > this.size) {
			removeOldest();
		}
		return returnString;
		
	}
	
	private void removeOldest() {
		Iterator<Map.Entry<String, String>> iterator = this.entrySet().iterator();
        if (iterator.hasNext()){
        	Map.Entry<String, String> removedEntry = iterator.next();
        	String removedKey = removedEntry.getKey();
        	String removedValue = removedEntry.getValue();
        	super.writeToFile(removedKey, removedValue);
            super.remove(removedKey);
        }
		
	}
	
}
