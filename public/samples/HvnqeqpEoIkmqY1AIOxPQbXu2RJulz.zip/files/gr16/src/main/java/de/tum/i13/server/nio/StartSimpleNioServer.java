package de.tum.i13.server.nio;

import de.tum.i13.server.echo.EchoLogic;
import de.tum.i13.server.kv.KVCommandProcessor;
import de.tum.i13.server.kv.KVStorer;
import de.tum.i13.shared.CommandProcessor;
import de.tum.i13.shared.Config;

import java.io.IOException;
import java.util.logging.Logger;

import static de.tum.i13.shared.Config.parseCommandlineArgs;
import static de.tum.i13.shared.LogSetup.setupLogging;

public class StartSimpleNioServer {

    public static Logger logger = Logger.getLogger(StartSimpleNioServer.class.getName());

    public static void main(String[] args) throws IOException {
        Config cfg = parseCommandlineArgs(args);  //Do not change this
        setupLogging(cfg.logfile);
        logger.info("Config: " + cfg.toString());

        logger.info("starting server");
        KVStorer kvstore = new KVStorer (cfg);

        ShutdownSave shutdownSave = new ShutdownSave(kvstore);
        Runtime.getRuntime().addShutdownHook(shutdownSave);
        
        //Replace with your Key Value command processor
        CommandProcessor kvLogic = new  KVCommandProcessor(kvstore,cfg.logLevel);
        SimpleNioServer sn = new SimpleNioServer(kvLogic);
        sn.bindSockets(cfg.listenaddr, cfg.port);
        sn.start();
        
        
    }
   //shutdown thread to save cached changes
    private static class ShutdownSave extends Thread {
    	
    	private KVStorer kvstore;
    	
    	public ShutdownSave(KVStorer kvstore) {
    		this.kvstore = kvstore;
    	}
    	
    	@Override
    	public void run() {
    		logger.info("stopping server");
    		try {
				this.kvstore.disconnect();
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
    	}
       }
    
}
