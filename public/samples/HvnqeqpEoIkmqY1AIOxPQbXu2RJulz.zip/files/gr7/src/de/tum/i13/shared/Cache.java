package de.tum.i13.shared;

import de.tum.i13.server.kv.KVMessage;

public interface Cache {

    
    void put(String key, String value);
 
    void delete(String key);
 
    Object get(String key);
 
    void clear();
    
    KVMessage getMessage();
	
}
