package de.tum.i13.server.kv;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.Socket;

import de.tum.i13.server.kv.KVMessage.StatusType;
import de.tum.i13.shared.Cache;
import de.tum.i13.shared.InMemoryCache;

public class ClientConnection implements Runnable {

	private final Socket clientSocket;
    Boolean isOpen;
    private KVStore kVStore = new KVStoreImpl();
    private Cache cache = new InMemoryCache();
	
	public ClientConnection(Socket clientSocket) {
		
		this.clientSocket=clientSocket;
		this.isOpen=true;
	
	}
	
	@Override
	public void run() {
		
		PrintWriter output = null;
	    BufferedReader input = null;
	    
	    try {
	    	output = new PrintWriter(clientSocket.getOutputStream());
			input = new BufferedReader(new InputStreamReader(clientSocket.getInputStream()));
			
			output.println("you are connected to the storage server : " + clientSocket.getInetAddress() + " " + clientSocket.getPort());
			output.flush();
			
			
			while(isOpen)
			{
				try {
						//parses the message sent from the client
						String line = input.readLine();
						String[] command = line.split(" ");
		            	String keySearch = command[1];
		            	String valueSearch = command[2];
		            	
		            	//the client use the command put
						if(command[0].equals("put"))
						{
							try {
								//calls the put method to store the key value pair
								//and verify if the key is successfuly stored or not
								
								kVStore.put(keySearch, valueSearch);
								
								//put the key-value pair in Memory cache
								
								cache.put(keySearch, valueSearch);
								KVMessage kvMessage = cache.getMessage();
								
								if(kvMessage.getStatus().equals(StatusType.PUT_ERROR)){
								output.println(kvMessage.getStatus() +" "+kvMessage.getKey()+" "+kvMessage.getValue());
								output.flush();
								}
								else
								output.println(kvMessage.getStatus() +" "+kvMessage.getKey());
								output.flush();
								
							} catch (Exception e) {
								e.printStackTrace();
							}
						}
						//the client uses the command get
						else if (command[0].equals("get"))
						{
							try {
								//calls the method to search and get the wanted key
								//and verifies if the key actually exists in the stored pairs
								
								//gets the key from the in memory cache
								cache.get(keySearch);
								KVMessage kvMessage = cache.getMessage();
								
								if(kvMessage.getStatus().equals(StatusType.GET_ERROR)) {
									output.println(kvMessage.getStatus()+" "+kvMessage.getKey()+" : key not found");
									output.flush();
								
								}
								else
									output.println(kvMessage.getStatus()+" "+kvMessage.getKey()+" "+kvMessage.getValue());
									output.flush();
								
								
							} catch (Exception e) {
								e.printStackTrace();
							}
							
							
							
						}
						
						else if(command[0].equals("delete"))
						{
							try {
								//calls the delete method to search for the given key
								//and verify if the key exists to delete the pair
								kVStore.delete(keySearch);
								
								//delete the key from the in memory cache
								cache.delete(keySearch);
								KVMessage kvMessage = cache.getMessage();
								if(kvMessage.getStatus().equals(StatusType.DELETE_ERROR)) {
									output.println(kvMessage.getStatus()+" "+kvMessage.getKey()+" : key not found");
									output.flush();
								
								}
								else
									output.println(kvMessage.getStatus()+" "+kvMessage.getKey()+" "+kvMessage.getValue());
									output.flush();
								
								
							} catch (Exception e) {
								e.printStackTrace();
							}
							
						}
						
					
					} catch (IOException ioe) { isOpen = false;}

			}
			
	    	
	    	
	    	
	    } 
	    catch (IOException e) {
	    	
			e.printStackTrace();
		
	    } finally {
	    	
	    	try {
	    		if(output != null) {
	    			output.close();
	    		}
	    		
	    		if(input != null) {
	    			input.close();
	    		}
	    	} catch(IOException e)
	    	{
	    		e.printStackTrace();
	    	}
	    	
	    }
	    
	    
		
	}


	public Socket getClientSocket() {
		return clientSocket;
	}

	
}
