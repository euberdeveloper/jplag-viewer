package de.tum.i13.server.kv;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardOpenOption;
import java.util.List;

import de.tum.i13.server.kv.KVMessage.StatusType;

public class KVStoreImpl implements KVStore{
	
	
	static List<String> keyValuePairs=null;
	
	private Path path = Paths.get("data/storage.txt");
	
	static final String NEW_LINE = System.lineSeparator();
	
	KVMessage returnMessage;

	@Override
	public KVMessage put(String key, String value) throws Exception {
	
		try {
		
			readFile(path); 
			if(keyValuePairs.size()!=0) {
				
	        	for(int i=0 ; i<keyValuePairs.size() ; i++)
	        	{ 
	        		//parse the key_value Pair
	        		String[] content = keyValuePairs.get(i).split(" ");
	            	String keySearch = content[0];
	            	String valueSearch = content[1];
	        	
	        		if (key.equals(keySearch))
	        		{
	        			//replace the value of the found key and overwrite the file with the updated value
	            		keyValuePairs.set(i, key+" "+value);
	            		OverwriteFile(path, "");
	            		for(int j= 0 ; j<keyValuePairs.size() ; j++)
	            		{
	            			writeFile(path, keyValuePairs.get(j)+ NEW_LINE);
	            			returnMessage = new KVMessageImpl(key, value, StatusType.PUT_UPDATE);
	            			return returnMessage;
	            			
	            		}
	            		
	        		}
	        		
	        	}
	        	writeFile(path, key+" "+ value + NEW_LINE);
				returnMessage = new KVMessageImpl(key, value, StatusType.PUT_SUCCESS);
				return returnMessage;
	        	
			}
			else {	
				writeFile(path, key+" "+ value + NEW_LINE);
				returnMessage = new KVMessageImpl(key, value, StatusType.PUT_SUCCESS);
				return returnMessage;
			}
		
		
		} catch(Exception e) {returnMessage = new KVMessageImpl(key, value, StatusType.PUT_ERROR);
									return returnMessage;}
		
		
		
	}

	@Override
	public KVMessage get(String key) throws Exception {
		
		
		readFile(path);
		if(keyValuePairs.size()!=0)
		{
			for(int i=0 ; i<keyValuePairs.size() ; i++)
			{ 
				//parse the key_value Pair
				String[] content = keyValuePairs.get(i).split(" ");
            	String keySearch = content[0];
            	String valueSearch = content[1];
				if (key.equals(keySearch))
				{
					//if the key is found we deliver the value of the given key
					returnMessage = new KVMessageImpl(key, valueSearch, StatusType.GET_SUCCESS);
					return returnMessage;
        		
				}
    		
			}
			returnMessage = new KVMessageImpl(key, "", StatusType.GET_ERROR);
			return returnMessage;
		}
		returnMessage = new KVMessageImpl(key, "", StatusType.GET_ERROR);
		return returnMessage;
		
		
	}
	
	@Override
	public KVMessage delete(String key) throws Exception {


		readFile(path);
		if(keyValuePairs.size()!=0)
		{
			for(int i=0 ; i<keyValuePairs.size() ; i++)
			{ 
				//parse the key_value Pair
				String[] content = keyValuePairs.get(i).split(" ");
            	String keySearch = content[0];
            	String valueSearch = content[1];
				if (key.equals(keySearch))
				{
					//if the key is found we delete the key-value pair entry and overwrite with the updated file
					keyValuePairs.remove(i);
					OverwriteFile(path, "");
					for(int j= 0 ; j<keyValuePairs.size() ; j++)
            		{
						
            			writeFile(path, keyValuePairs.get(j)+ NEW_LINE);
            			returnMessage = new KVMessageImpl(key, valueSearch, StatusType.DELETE_SUCCESS);
    					return returnMessage;
            			
            		}
					
        		
				}
    		
			}
			returnMessage = new KVMessageImpl(key, "", StatusType.DELETE_ERROR);
			return returnMessage;
		}
		returnMessage = new KVMessageImpl(key, "", StatusType.DELETE_ERROR);
		return returnMessage;
		
		
		
	}
	
	//reads the file on the disk
	private static void readFile(Path path)  throws IOException {
    
    	keyValuePairs = Files.readAllLines(path);

	}
	
	//write the file 
	private static void writeFile(Path path, String content)
            throws IOException {

    // if the file does not exist, create and write in it.
    // if the file exists, add data to the file.
    Files.write(path, content.getBytes(StandardCharsets.UTF_8),
    		StandardOpenOption.CREATE, StandardOpenOption.APPEND);

	}
	
	//to update the key value pairs
	private static void OverwriteFile(Path path, String content)
            throws IOException{
    	
    	Files.write(path, content.getBytes(StandardCharsets.UTF_8));
    	
    }


	
	
	public Path getPath() {
		return path;
	}

	public void setPath(Path path) {
		this.path = path;
	}

	

}
