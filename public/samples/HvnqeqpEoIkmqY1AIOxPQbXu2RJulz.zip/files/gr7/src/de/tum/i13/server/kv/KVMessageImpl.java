package de.tum.i13.server.kv;

import java.io.IOException;

public class KVMessageImpl implements KVMessage{
	
	StatusType statustype;
	String key;
	String value;
	
	public KVMessageImpl(String key , String value , StatusType statustype) {
		
		this.key=key;
		this.value=value;
		this.statustype=statustype;
		
	}

	@Override
	public String getKey() {
		return key;
	}

	@Override
	public String getValue() {
		return value;
	}

	@Override
	public StatusType getStatus() {
		
		return statustype;
	}
	

}
