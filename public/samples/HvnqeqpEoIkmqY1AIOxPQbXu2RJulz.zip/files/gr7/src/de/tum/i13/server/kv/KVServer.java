package de.tum.i13.server.kv;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.logging.Logger;

public class  KVServer{

	
	
	
	public static void main(String[] args) throws IOException
	{
		
		ServerSocket server=null;
		
		try {
			
			server= new ServerSocket(5153);
			server.setReuseAddress(true);
			
			while(true) {
				
				Socket client = server.accept();
				ClientConnection connection = new ClientConnection(client);
				
				new Thread(connection).start();		
			}
					
		} finally {
			if (server!=null)
			{
				try {
					server.close();
				} catch (IOException e)
				{
					e.printStackTrace();
				}
			}
		}		
	}
	

}
