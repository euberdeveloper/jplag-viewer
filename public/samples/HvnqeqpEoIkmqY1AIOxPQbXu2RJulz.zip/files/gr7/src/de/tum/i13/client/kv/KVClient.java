package de.tum.i13.client.kv;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

import de.tum.i13.client.ActiveConnection;
import de.tum.i13.client.EchoConnectionBuilder;

public class KVClient {
	
	
	public static void main(String[] args) throws IOException {
        BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));

        ActiveConnection activeConnection = null;
        String port="5153";
        String ipAdress="127.0.0.1";
        String connectionline= "connect"+" "+ipAdress+" "+port;
        String[] connection = connectionline.split(" ");
        activeConnection = buildconnection(connection);
        for(;;) {
            System.out.print("KVClient> ");
            String line = reader.readLine();
            String[] command = line.split(" ");
            //System.out.print("command:");
            //System.out.println(line);
            switch (command[0]) {
                case "connect": ; break;
                case "put" : sendmessage(activeConnection, command, line); break;
                case "get" : sendmessage(activeConnection, command, line); break;
                case "delete" : sendmessage(activeConnection, command, line); break;
                case "quit": printEchoLine("KVClient exit!"); return;
                default: printEchoLine("Unknown command");
            }
        }
    }
	
	
	private static void printEchoLine(String msg) {
        System.out.println("KVClient> " + msg);
    }
	
	private static void sendmessage(ActiveConnection activeConnection, String[] command, String line) {
        if(activeConnection == null) {
            printEchoLine("Error! Not connected!");
            return;
        }
        int firstSpace = line.indexOf(" ");
        if(firstSpace == -1 || firstSpace + 1 >= line.length()) {
            printEchoLine("Error! no key-value Pair to send!");
            return;
        }

        activeConnection.write(line);

        try {
            printEchoLine(activeConnection.readline());
        } catch (IOException e) {
            printEchoLine("Error! Not connected!");
        }
    }
	
	
	
	private static ActiveConnection buildconnection(String[] command) {
        if(command.length == 3){
            try {
                EchoConnectionBuilder kvcb = new EchoConnectionBuilder(command[1], Integer.parseInt(command[2]));
                ActiveConnection ac = kvcb.connect();
                String confirmation = ac.readline();
                printEchoLine(confirmation);
                return ac;
            } catch (Exception e) {
                //Todo: separate between could not connect, unknown host and invalid port
                printEchoLine("Could not connect to server");
            }
        }
        return null;
    }

}
