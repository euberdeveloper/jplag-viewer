package de.tum.i13.shared;

import java.lang.ref.SoftReference;
import java.util.Optional;
import java.util.concurrent.ConcurrentHashMap;

import de.tum.i13.server.kv.KVMessage;
import de.tum.i13.server.kv.KVMessage.StatusType;
import de.tum.i13.server.kv.KVMessageImpl;


 
public class InMemoryCache implements Cache {
 
 
    private final ConcurrentHashMap<String, String> cache = new ConcurrentHashMap<>();
    private KVMessage kvmessage;
 
 
    @Override
    public void put(String key, String value) {
    	if(cache.containsKey(key))
    	{
    		kvmessage = new KVMessageImpl(key, value, StatusType.PUT_UPDATE);
    		cache.put(key, value);
    		return;
    	}
    	
        if (key == null) {
        	kvmessage = new KVMessageImpl(key, value, StatusType.PUT_ERROR);
            return;
        }
        if (value == null) {
        	kvmessage = new KVMessageImpl(key, value, StatusType.PUT_ERROR);
            cache.remove(key);
        } else {
            
            cache.put(key, value);
            kvmessage = new KVMessageImpl(key, value, StatusType.PUT_SUCCESS);
        }
    }
 
    @Override
    public void delete(String key) {
    	if(!cache.containsKey(key))
    	{
    		kvmessage = new KVMessageImpl(key, "", StatusType.DELETE_ERROR);
    		return;
    	}
    	kvmessage = new KVMessageImpl(key, cache.get(key) , StatusType.DELETE_SUCCESS);
        cache.remove(key);
    }
 
    @Override
    public Object get(String key) {
    	
    	if(!cache.containsKey(key))
    	{
    		kvmessage = new KVMessageImpl(key, "" , StatusType.GET_ERROR);
    		return Optional.ofNullable(cache.get(key)).orElse(null);
    	}
    	else {
    		kvmessage = new KVMessageImpl(key, Optional.ofNullable(cache.get(key)).orElse(null) , StatusType.GET_SUCCESS);
    		return Optional.ofNullable(cache.get(key)).orElse(null);
    
    	}
    }
 
    @Override
    public void clear() {
        cache.clear();
    }

	public KVMessage getMessage() {
		return kvmessage;
	}
 
 
}