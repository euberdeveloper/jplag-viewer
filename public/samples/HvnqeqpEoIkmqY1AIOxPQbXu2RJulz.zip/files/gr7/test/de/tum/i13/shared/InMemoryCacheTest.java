package de.tum.i13.shared;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

import de.tum.i13.server.kv.KVMessage;
import de.tum.i13.server.kv.KVMessageImpl;
import de.tum.i13.server.kv.KVStore;
import de.tum.i13.server.kv.KVStoreImpl;
import de.tum.i13.server.kv.KVMessage.StatusType;

class InMemoryCacheTest {

	@Test
	void SuccesTestPut() throws Exception {
		
		KVMessage kvmessageExpected = new KVMessageImpl("TestKey", "TestValue" , StatusType.PUT_SUCCESS);
		
		String expectedKey = kvmessageExpected.getKey();
		String expectedValue = kvmessageExpected.getValue();
		String expectedStatue = kvmessageExpected.getStatus().toString();
		
		Cache cacheTest = new InMemoryCache();
		cacheTest.put("TestKey", "TestValue");
		
		KVMessage kvmessageObserved =  cacheTest.getMessage();
		String observedKey = kvmessageObserved.getKey();
		String observedValue = kvmessageObserved.getValue();
		String observedStatue = kvmessageObserved.getStatus().toString();
		
		assertEquals(expectedKey, observedKey);
		assertEquals(expectedValue, observedValue);
		assertEquals(expectedStatue, observedStatue);
		
		
		
	}

	@Test
	void successtestGet() throws Exception {
		Cache cacheTest = new InMemoryCache();
		cacheTest.put("TestGetKey", "TestGetValue");
		
		KVMessage kvmessageExpected = new KVMessageImpl("TestGetKey", "TestGetValue" , StatusType.GET_SUCCESS);
		
		String expectedKey = kvmessageExpected.getKey();
		String expectedValue = kvmessageExpected.getValue();
		String expectedStatue = kvmessageExpected.getStatus().toString();
		
		cacheTest.get("TestGetKey");
		KVMessage kvmessageObserved = cacheTest.getMessage();
		String observedKey = kvmessageObserved.getKey();
		String observedValue = kvmessageObserved.getValue();
		String observedStatue = kvmessageObserved.getStatus().toString();
		
		assertEquals(expectedKey, observedKey);
		assertEquals(expectedValue, observedValue);
		assertEquals(expectedStatue, observedStatue);
		
		
	}

	@Test
	void errortestDelete() throws Exception {
		Cache cacheTest = new InMemoryCache();
		cacheTest.put("TestGetKey", "TestGetValue");
		
		KVMessage kvmessageExpected = new KVMessageImpl("NotFound", "" , StatusType.DELETE_ERROR);
		
		String expectedKey = kvmessageExpected.getKey();
		String expectedValue = kvmessageExpected.getValue();
		String expectedStatue = kvmessageExpected.getStatus().toString();
		
		cacheTest.delete("NotFound");
		KVMessage kvmessageObserved = cacheTest.getMessage();
		
		String observedKey = kvmessageObserved.getKey();
		String observedValue = kvmessageObserved.getValue();
		String observedStatue = kvmessageObserved.getStatus().toString();
		
		assertEquals(expectedKey, observedKey);
		assertEquals(expectedValue, observedValue);
		assertEquals(expectedStatue, observedStatue);
		
		
	}

}
