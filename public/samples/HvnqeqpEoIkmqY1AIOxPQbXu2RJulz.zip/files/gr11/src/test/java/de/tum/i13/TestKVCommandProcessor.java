package de.tum.i13;

import de.tum.i13.commandprocessor.CommandProcessor;
import de.tum.i13.server.ConnectionManager;
import de.tum.i13.server.commands.CommandWithCheckedArgsCount;

import de.tum.i13.server.commands.DeleteCommand;
import de.tum.i13.server.commands.GetCommand;
import de.tum.i13.server.commands.PutCommand;
import de.tum.i13.server.kv.IKVStore;

import org.junit.jupiter.api.Test;

import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;

public class TestKVCommandProcessor
{

    @Test
    public void correctParsingOfPut() throws Exception
    {

        IKVStore kv = mock(IKVStore.class);
        CommandProcessor<CommandWithCheckedArgsCount> kvcp = new CommandProcessor<CommandWithCheckedArgsCount>();
        ConnectionManager cm = mock(ConnectionManager.class);
        kvcp.addCommand(new PutCommand(kv, cm));
        kvcp.process("put key hello");

        verify(kv).put("key", "hello");
    }

    @Test
    public void correctParsingOfGet() throws Exception
    {

        IKVStore kv = mock(IKVStore.class);
        CommandProcessor<CommandWithCheckedArgsCount> kvcp = new CommandProcessor<CommandWithCheckedArgsCount>();
        ConnectionManager cm = mock(ConnectionManager.class);
        kvcp.addCommand(new GetCommand(kv, cm));
        kvcp.process("get key");

        verify(kv).get("key");
    }

    @Test
    public void correctParsingOfDelete() throws Exception
    {

        IKVStore kv = mock(IKVStore.class);
        CommandProcessor<CommandWithCheckedArgsCount> kvcp = new CommandProcessor<CommandWithCheckedArgsCount>();
        ConnectionManager cm = mock(ConnectionManager.class);
        kvcp.addCommand(new DeleteCommand(kv, cm));
        kvcp.process("delete key");

        verify(kv).delete("key");
    }
}
