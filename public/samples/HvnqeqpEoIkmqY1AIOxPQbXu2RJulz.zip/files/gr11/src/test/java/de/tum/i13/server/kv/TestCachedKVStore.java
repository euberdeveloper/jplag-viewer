package de.tum.i13.server.kv;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.mock;

import java.util.Map;
import java.util.TreeMap;

import org.junit.jupiter.api.Test;
import org.mockito.Mockito;

import static org.mockito.Mockito.*;

import de.tum.i13.kvshared.KVRuntimeException;
import de.tum.i13.server.kv.CachedKVStore;
import de.tum.i13.server.kv.IKVStore;
import de.tum.i13.server.kv.KVMessage;
import de.tum.i13.server.kv.KVMessage.StatusType;
import de.tum.i13.shared.Config;

public class TestCachedKVStore
{
    Map<String, String> _cashFillingValues = new TreeMap<>(Map.of("a", "val_a", "b", "val_b", "c", "val_c", "d", "val_d", "e", "val_e"));
    final String _testKey = "test";
    final String _testValue = "val_test";

    private CachedKVStore createCache(IKVStore kvStore, Config.CacheDisplacementStrategies strategy)
    {
        int cacheSize = 3;
        CachedKVStore cache = new CachedKVStore(kvStore, strategy, cacheSize);

        _cashFillingValues.entrySet().stream().limit(cacheSize).forEach(entry -> {
            try
            {
                cache.put(entry.getKey(), entry.getValue());
            }
            catch (KVRuntimeException e)
            {
                fail();
            }
        });
        return cache;
    }

    private void assertOldCacheEntryIsFound(CachedKVStore cache, String value) throws KVRuntimeException
    {
        assertEquals(_cashFillingValues.get(value), cache.get(value).getValue());
    }

    private void assertOldCacheEntryNotFound(CachedKVStore cache, String value) throws KVRuntimeException
    {
        assertNull(cache.get(value).getValue());
    }

    private void assertNewCacheEntryIsFound(CachedKVStore cache) throws KVRuntimeException
    {
        assertEquals(_testValue, cache.get(_testKey).getValue());
    }

    private void addNewCacheEntry(CachedKVStore cache) throws KVRuntimeException
    {
        cache.put(_testKey, _testValue);
    }

    @Test
    public void cache_FillingTillMaximum_CachesEverything() throws KVRuntimeException
    {
        IKVStore kvStore = mock(IKVStore.class);

        CachedKVStore sut = createCache(kvStore, Config.CacheDisplacementStrategies.FIFO);

        assertEquals(3, sut.size());
        assertOldCacheEntryIsFound(sut, "a");
        assertOldCacheEntryIsFound(sut, "b");
        assertOldCacheEntryIsFound(sut, "c");
    }

    @Test
    public void cache_UsingFIFO_RemovesFirstInsertedObject() throws KVRuntimeException
    {
        IKVStore kvStore = mock(IKVStore.class);
        CachedKVStore sut = createCache(kvStore, Config.CacheDisplacementStrategies.FIFO);

        addNewCacheEntry(sut);
        assertEquals(3, sut.size());
        assertNewCacheEntryIsFound(sut);

        assertOldCacheEntryNotFound(sut, "a");

        assertOldCacheEntryIsFound(sut, "b");
        assertOldCacheEntryIsFound(sut, "c");
    }

    @Test
    public void cache_UsingLFU_RemovesLeastFrequentlyUsedObject() throws KVRuntimeException
    {
        IKVStore kvStore = mock(IKVStore.class);
        CachedKVStore sut = createCache(kvStore, Config.CacheDisplacementStrategies.LFU);

        // get values to increase "used" counter
        sut.get("a");
        sut.get("a");
        sut.get("b"); // be is only used 1 time
        sut.get("c");
        sut.get("c");
        sut.get("c");

        addNewCacheEntry(sut);
        assertEquals(3, sut.size());
        assertNewCacheEntryIsFound(sut);

        assertOldCacheEntryNotFound(sut, "b");

        assertOldCacheEntryIsFound(sut, "a");
        assertOldCacheEntryIsFound(sut, "c");
    }

    @Test
    public void cache_UsingLRU_RemovesLeastRecentlyUsedObject() throws InterruptedException, KVRuntimeException
    {
        IKVStore kvStore = mock(IKVStore.class);
        CachedKVStore sut = createCache(kvStore, Config.CacheDisplacementStrategies.LRU);

        Thread.sleep(20); // wait so the timestamps differ
        // get value
        sut.get("a");
        Thread.sleep(20); // wait so the timestamps differ
        sut.get("c");
        Thread.sleep(20); // wait so the timestamps differ

        // b now should be the oldest

        addNewCacheEntry(sut);
        assertEquals(3, sut.size());
        assertNewCacheEntryIsFound(sut);

        assertOldCacheEntryNotFound(sut, "b");

        assertOldCacheEntryIsFound(sut, "a");
        assertOldCacheEntryIsFound(sut, "c");
    }

    @Test
    public void cache_putting_PutsToStore() throws KVRuntimeException
    {
        IKVStore kvStore = mock(IKVStore.class);

        createCache(kvStore, Config.CacheDisplacementStrategies.FIFO);

        // verify everything got stored
        verify(kvStore, Mockito.times(1)).put("a", "val_a");
        verify(kvStore, Mockito.times(1)).put("b", "val_b");
        verify(kvStore, Mockito.times(1)).put("c", "val_c");
    }

    @Test
    public void cache_getting_DisplacedCacheItemGetsFromStore() throws KVRuntimeException
    {
        IKVStore kvStore = mock(IKVStore.class);
        when(kvStore.get("a")).thenReturn(new KVMessage("a", "val_a", StatusType.GET_SUCCESS));

        CachedKVStore sut = createCache(kvStore, Config.CacheDisplacementStrategies.FIFO);

        addNewCacheEntry(sut); // this should displace "a"

        KVMessage result = sut.get("a"); // should get "a" from store again and place in store as well

        assertEquals(_cashFillingValues.get("a"), result.getValue()); // result value is as expected
        assertEquals(KVMessage.StatusType.GET_SUCCESS, result.getStatus()); // result status is as expected

        assertOldCacheEntryIsFound(sut, "a"); // item is in cache again

        verify(kvStore, Mockito.times(1)).get("a"); // only "a" was fetched from store
        verify(kvStore, Mockito.times(0)).get("b");
        verify(kvStore, Mockito.times(0)).get("c");
        verify(kvStore, Mockito.times(0)).get("test");
    }
}
