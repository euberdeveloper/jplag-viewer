package de.tum.i13;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import de.tum.i13.testauxiliaries.Auxiliaries;
import de.tum.i13.testauxiliaries.TestClient;
import de.tum.i13.testauxiliaries.TestServer;

import java.util.ArrayList;
import java.util.List;
import java.util.function.Consumer;
import java.util.logging.Level;

public class KVIntegrationTest
{
    @BeforeEach
    public void WipeTestData()
    {
        Auxiliaries.WipeDirectory(TestServer.getTestDataDirectory());
    }

    @Test
    public void smokeTest() throws Throwable
    {
        TestServer server = new TestServer("smokeTest").open();

        String command = "put 123 hallo";

        try
        {
            server.runAsClientThread(client -> {

                String result = client.connectSendReceiveAndDisconnect(command);

                Assertions.assertTrue(result.equals("put_update 123 hallo") || result.equals("put_success 123 hallo"));
            }, 10);
        }
        catch (Throwable ex)
        {
            throw ex; //rethrowing assures finally is called - there we can close the server
        }
        finally
        {
            server.close();
        }

        System.out.println("smoke test finished");
    }

    @Test
    public void enjoyTheEcho() throws Throwable
    {
        TestServer server = new TestServer("enjoyTheEcho").SetLogLevel(Level.WARNING).open();

        List<Consumer<TestClient>> clients = new ArrayList<Consumer<TestClient>>();

        for (int tcnt = 0; tcnt < 2; tcnt++)
        {
            final int finalTcnt = tcnt;

            clients.add(client -> {
                try
                {
                    Thread.sleep(finalTcnt * 100);
                }
                catch (InterruptedException ex)
                {
                    ex.printStackTrace();
                }
                for (int i = 0; i < 100; i++)
                {
                    String testKey = "thread_" + finalTcnt + "_" + i;
                    String testValue = "val_" + Integer.toString(i);

                    String resultPut = client.connectSendReceiveAndDisconnect("put " + testKey + " " + testValue);
                    Assertions.assertEquals("put_success " + testKey + " " + testValue, resultPut);

                    String resultGet = client.connectSendReceiveAndDisconnect("get " + testKey);
                    Assertions.assertEquals("get_success " + testKey + " " + testValue, resultGet);
                }
            });
        }

        try
        {
            server.runAsClientThread(clients, 30);
        }
        catch (Throwable ex)
        {
            throw ex; //rethrowing assures finally is called - there we can close the server
        }
        finally
        {
            server.close();
        }
    }
}
