package de.tum.i13.testauxiliaries;

import java.io.IOException;
import java.net.ServerSocket;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;
import java.util.function.Consumer;
import java.util.stream.Collectors;

import de.tum.i13.kvshared.KVRuntimeException;
import de.tum.i13.server.ServerMain;
import java.util.logging.*;

/**
 * Class to spawn a server as a thread. Offers an easy way to connect a testClient.
 * 
 * @author Christoph Poeppelbaum
 *
 */
public class TestServer extends Thread
{
    private String _name;
    private int _port;
    private String _ip = "127.0.0.1";
    private ServerMain _serverMain;
    private Map<String, String> _serverArgs = new HashMap<String, String>();
    private static final String _testDataDirectory = "testdata/";

    public TestServer(String name) throws IOException
    {
        super("Test Server Thread");
        _name = name;
        _port = getAnyFreeServerPort();
        _serverMain = new ServerMain();
        
        _serverArgs.put("-p", Integer.toString(_port));
        _serverArgs.put("-d", _testDataDirectory);
    }
    
    public TestServer SetLogLevel(Level level)
    {
        _serverArgs.put("-ll", level.toString());
        return this;
    }
    
    /**
     * Starts the server as a thread and waits 2 seconds (for any initialization of the thread). 
     * 
     * @return
     */
    public TestServer open()
    {
        this.start();
        
        try
        {
            Thread.sleep(2000);
        }
        catch (InterruptedException e)
        {
            e.printStackTrace();
        }
        
        return this;
    }
    
    /**
     * The directory of this server's data store
     * 
     * @return
     */
    public static String getTestDataDirectory()
    {
        return _testDataDirectory;
    }

    @Override
    public void run()
    {
        try
        {
            System.out.println(_name + " server started");
            
            ArrayList<String> serverArgs = new ArrayList<String>();
            _serverArgs.entrySet().forEach(a -> { serverArgs.add(a.getKey()); serverArgs.add(a.getValue()); });
            _serverMain.run(serverArgs.toArray(new String[0])); //blocking
            
            System.out.println(_name + " server was shut down");
        }
        catch (KVRuntimeException e)
        {
            e.printStackTrace();
        }
        catch (IOException e)
        {
            e.printStackTrace();
        }
    }
    
    /**
     * stops the server thread and waits 2 seconds for any shutdown actions.
     */
    public void close()
    {
        _serverMain.stop();
        try
        {
            Thread.sleep(2000);
        }
        catch (InterruptedException e)
        {
            e.printStackTrace();
        }
    }
    
    private int getAnyFreeServerPort() throws IOException
    {
        try (ServerSocket socket = new ServerSocket(0)) {
            socket.setReuseAddress(true);
            return socket.getLocalPort();
        }
    }
    
    /**
     * Runs given code as a new thread, acting as a client, connected to this server.
     * 
     * @param clientCodes each entry will spawn a separate thread.
     * @param timeout will cancel execution
     * @throws InterruptedException when errors within the given code happen
     * @throws ExecutionException when errors within the given code happen
     * @throws TimeoutException when timeout is reached
     */
    public void runAsClientThread(List<Consumer<TestClient>> clientCodes, int timeout) throws ExecutionException, TimeoutException, InterruptedException
    {
        List<CompletableFuture<Void>> computables = clientCodes.stream().map(c ->
            CompletableFuture.runAsync(new TestClient(_ip, _port, c)))
                .collect(Collectors.toList());
        
        CompletableFuture<Void> combinedFuture = CompletableFuture.allOf(computables.toArray(new CompletableFuture[computables.size()]));

        combinedFuture.get(timeout, TimeUnit.SECONDS);
    }
    
    /**
     * Runs given code as a new thread, acting as a client, connected to this server.
     * @param clientCode each entry will spawn a separate thread.
     * @param timeout will cancel execution
     * @throws InterruptedException when errors within the given code happen
     * @throws ExecutionException when errors within the given code happen
     * @throws TimeoutException when timeout is reached
     */
    public void runAsClientThread(Consumer<TestClient> clientCode, int timeout) throws InterruptedException, ExecutionException, TimeoutException
    {
        runAsClientThread(List.of(clientCode), timeout);
    }
}