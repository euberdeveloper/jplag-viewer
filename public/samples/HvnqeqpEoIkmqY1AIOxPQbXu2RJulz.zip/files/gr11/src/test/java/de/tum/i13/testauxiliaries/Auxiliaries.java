package de.tum.i13.testauxiliaries;

import java.io.File;

/**
 * Helper classes for tests
 * 
 * @author Christoph Poeppelbaum
 *
 */
public class Auxiliaries
{
    /**
     * Deletes all files recursively in given directory.
     * @param directory
     */
    public static void WipeDirectory(String directory)
    {
        File[] allContents = new File(directory).listFiles();
        if (allContents != null) {
            for (File file : allContents) {
                deleteDirectory(file);
            }
        }
    }
    
    private static boolean deleteDirectory(File directoryToBeDeleted) {
        File[] allContents = directoryToBeDeleted.listFiles();
        if (allContents != null) {
            for (File file : allContents) {
                deleteDirectory(file);
            }
        }
        return directoryToBeDeleted.delete();
    }
}
