package de.tum.i13.kvstoreclientlib;

import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import de.tum.i13.kvshared.KVRuntimeException;

public class TestKVStoreClient
{
    private IKVStoreClient _sut;

    @BeforeEach
    public void initTest()
    {
        _sut = new KVStoreClient();
    }

    @Test
    public void kvStoreClient_throwsException_whenConnectingWhileConnected() throws KVRuntimeException
    {
        IConnection connection = mock(IConnection.class);
        when(connection.receive()).thenReturn("test".getBytes());

        _sut.connect(connection); // should not throw

        Assertions.assertThrows(KVRuntimeException.class, () -> {
            _sut.connect(connection);
        });
    }

    @Test
    public void kvStoreClient_throwsException_whenDisconnectingWhileNotConnected()
    {
        Assertions.assertThrows(KVRuntimeException.class, () -> {
            _sut.disconnect();
        });
    }

    @Test
    public void kvStoreClient_throwsException_whenPuttingWithoutConnection()
    {
        Assertions.assertThrows(KVRuntimeException.class, () -> {
            _sut.put("any", "thing");
        });
    }

    @Test
    public void kvStoreClient_throwsException_whenGettingWithoutConnection()
    {
        Assertions.assertThrows(KVRuntimeException.class, () -> {
            _sut.get("any");
        });
    }
}
