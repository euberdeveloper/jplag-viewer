package de.tum.i13.server.kv;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.io.File;
import java.io.IOException;
import java.nio.file.Path;
import java.nio.file.Paths;

import org.junit.jupiter.api.Test;

import de.tum.i13.kvshared.KVRuntimeException;
import de.tum.i13.server.kv.KVMessage;
import de.tum.i13.server.kv.PersistentStorage;
import de.tum.i13.server.kv.KVMessage.StatusType;

public class TestPersistentStorage
{

    private PersistentStorage _testStorage;
    private Path path;

    @Test
    public void putGetDataTest() throws KVRuntimeException, IOException
    {
        path = Paths.get("/testDir");
        _testStorage = new PersistentStorage(path);
        String testKey = "key=";
        String testValue = "value";

        putTest(testKey, testValue);

        getTest(testKey, testValue);

        String newTestValue = "newValue";

        updateTest(testKey, newTestValue);

        deleteTest(testKey);

        _testStorage.getFolder().delete();

    }

    /**
     * Test the put method using a key and value
     * 
     * @param testKey
     * @param testValue
     * @throws KVRuntimeException
     */
    private void putTest(String testKey, String testValue) throws KVRuntimeException
    {
        KVMessage putMessage = _testStorage.put(testKey, testValue);

        StatusType putStatus = putMessage.getStatus();

        assertEquals(StatusType.PUT_SUCCESS, putStatus);
    }

    /**
     * Test to retrieve a value by a given key that already exists on the disk
     * 
     * @param testKey
     * @param expectedValue
     * @throws KVRuntimeException
     */
    private void getTest(String testKey, String expectedValue) throws KVRuntimeException
    {
        KVMessage retrievedMessage = _testStorage.get(testKey);

        String retrievedValue = retrievedMessage.getValue();
        StatusType retrievedStatus = retrievedMessage.getStatus();

        assertEquals(StatusType.GET_SUCCESS, retrievedStatus);
        assertEquals(expectedValue, retrievedValue);
    }

    /**
     * Test to replace a value by a given new value and key that already exists on
     * the disk
     * 
     * @param testKey
     * @param newValue
     * @throws KVRuntimeException
     */
    private void updateTest(String testKey, String newValue) throws KVRuntimeException
    {
        File keyFile = new File(_testStorage.getFolder().getAbsolutePath() + "/" + transformKey(testKey) + ".txt");

        assertTrue(keyFile.exists());

        KVMessage retrievedMessage = _testStorage.get(testKey);

        String oldValue = retrievedMessage.getValue();

        KVMessage updateMessage = _testStorage.put(testKey, newValue);

        StatusType updateStatus = updateMessage.getStatus();

        assertNotEquals(updateMessage.getValue(), oldValue);
        assertEquals(StatusType.PUT_UPDATE, updateStatus);
    }

    /**
     * Test to delete a value by a given key that already exists on the disk
     * 
     * @param testKey
     * @throws KVRuntimeException
     */
    private void deleteTest(String testKey) throws KVRuntimeException
    {
        File keyFile = new File(_testStorage.getFolder().getAbsolutePath() + "/" + transformKey(testKey) + ".txt");

        assertTrue(keyFile.exists());

        KVMessage deletedMessage = _testStorage.delete(testKey);

        StatusType deletedStatus = deletedMessage.getStatus();

        assertTrue(!keyFile.exists());
        assertEquals(StatusType.DELETE_SUCCESS, deletedStatus);

    }

    private String transformKey(String key)
    {
        key = key.replace("/", "-slash-");
        key = key.replace("+", "-plus-");
        key = key.replace("=", "-equal-");
        key = key.replace("*", "-star-");
        return key;
    }

}
