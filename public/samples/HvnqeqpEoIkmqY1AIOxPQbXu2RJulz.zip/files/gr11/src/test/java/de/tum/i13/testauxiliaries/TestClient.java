package de.tum.i13.testauxiliaries;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.InetSocketAddress;
import java.net.Socket;
import java.util.function.Consumer;

/**
 * Class to run code as a bare client within a new thread, communicating to our server implementation
 * 
 * @author Christoph Poeppelbaum
 *
 */
public class TestClient extends Thread
{
    private Consumer<TestClient> _runOnServer;
    private String _ip;
    private int _port;
    private Socket _socket;
    private PrintWriter _output;
    private BufferedReader _input;

    /**
     * Constructor
     * 
     * @param ip of the server
     * @param port of the server
     * @param run this code. Assertions can be made here.
     */
    public TestClient(String ip, int port, Consumer<TestClient> run)
    {
        super("Test Client Thread");
        _runOnServer = run;
        _ip = ip;
        _port = port;
    }

    @Override
    public void run()
    {
        _runOnServer.accept(this);
    }
    
    /**
     * connect to the server
     */
    public void connect()
    {
        try
        {
            _socket = new Socket();
            _socket.connect(new InetSocketAddress(_ip, _port));
            
            _output = new PrintWriter(_socket.getOutputStream());
            _input = new BufferedReader(new InputStreamReader(_socket.getInputStream()));
        }
        catch(Exception ex)
        {
            throw new RuntimeException(ex);
        }
    }
    
    /**
     * disconnect from server
     */
    public void disconnect()
    {
        try
        {
            _input.close();
            _output.close();
            _socket.close();
        }
        catch(Exception ex)
        {
            throw new RuntimeException(ex);
        }
    }
    
    /**
     * send this message to the server
     * 
     * @param request message to send
     */
    public void send(String request)
    {
        try
        {
            _output.write(request + "\r\n");
            _output.flush();
        }
        catch(Exception ex)
        {
            throw new RuntimeException(ex);
        }
    }
    
    /**
     * listen for an answer from the server
     * 
     * @return response
     */
    public String receive()
    {
        try
        {
            return _input.readLine();
        }
        catch(Exception ex)
        {
            throw new RuntimeException(ex);
        }
    }
    
    /**
     * combines send and receive message
     * 
     * @param request message to send
     * @return response
     */
    public String sendAndReceive(String request)
    {
        send(request);
        return receive();
    }
    
    /**
     * Connect and disconnect is done automaticaly. Combines send and receive.
     * 
     * @param request message to send
     * @return response
     */
    public String connectSendReceiveAndDisconnect(String request)
    {
        connect();
        receive(); //discard welcome message
        send(request);
        String result = receive();
        disconnect();
        return result;
    }
}
