/**
 * Shared helper classes for tests
 */
package de.tum.i13.testauxiliaries;