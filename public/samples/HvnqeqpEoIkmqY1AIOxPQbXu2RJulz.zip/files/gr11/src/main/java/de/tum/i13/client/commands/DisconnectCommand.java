package de.tum.i13.client.commands;

import java.util.Map;

import de.tum.i13.commandprocessor.CPExecutionRuntimeException;
import de.tum.i13.kvshared.KVRuntimeException;
import de.tum.i13.kvstoreclientlib.*;

/**
 * Command to disconnect the client from the server
 * 
 * @author Wen Qing Wei
 *
 */
public class DisconnectCommand extends CommandWithCheckedArgsCountAndHelp
{
    private IKVStoreClient _context;

    public DisconnectCommand(IKVStoreClient context)
    {
        _context = context;
    }

    @Override
    public String getCommandName()
    {
        return "disconnect";
    }

    @Override
    public String getDescription()
    {
        return "Trying to disconnect from the server";
    }

    @Override
    public Map<String, String> getArguments()
    {
        return null; // no arguments for this command needed
    }

    @Override
    protected void executeWithCheckedCountOfArgs(String[] args) throws CPExecutionRuntimeException
    {
        try
        {
            _context.disconnect();
        }
        catch (KVRuntimeException ex)
        {
            throw new CPExecutionRuntimeException(ex.getMessage());
        }
    }

}
