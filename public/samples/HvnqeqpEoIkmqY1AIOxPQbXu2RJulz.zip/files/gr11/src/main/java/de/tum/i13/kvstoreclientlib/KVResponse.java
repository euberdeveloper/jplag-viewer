package de.tum.i13.kvstoreclientlib;

/**
 * Model class for server responses. Adapted from given server KVMessage model.
 * 
 * @author Christoph Poeppelbaum
 *
 */
public class KVResponse
{
    private String _key;
    private String _value;
    private StatusType _status;

    /**
     * Represents the action and whether it was a success. Adapted from given server
     * KVMessage model.
     * 
     * @author Christoph Poeppelbaum
     *
     */
    public enum StatusType
    {
        GET_ERROR, /* requested tuple (i.e. value) not found */
        GET_SUCCESS, /* requested tuple (i.e. value) found */
        PUT_SUCCESS, /* Put - request successful, tuple inserted */
        PUT_UPDATE, /* Put - request successful, i.e. value updated */
        PUT_ERROR, /* Put - request not successful */
        DELETE_SUCCESS, /* Delete - request successful */
        DELETE_ERROR /* Delete - request successful */
    }

    /**
     * Constructor for KVResponse with all possible parameters.
     * 
     * @param key    identifier
     * @param value  the value associated to the identifier
     * @param status represents the action and whether it was a success
     */
    public KVResponse(String key, String value, StatusType status)
    {
        _key = key;
        _value = value;
        _status = status;
    }

    /**
     * This constructor omits "value", so getValue() will return null.
     * 
     * @param key    identifier
     * @param status represents the action and whether it was a success
     */
    public KVResponse(String key, StatusType status)
    {
        _key = key;
        _status = status;
    }

    /**
     * @return the key that is associated with this message, null if not key is
     *         associated.
     */
    public String getKey()
    {
        return _key;
    }

    /**
     * @return the value that is associated with this message, null if not value is
     *         associated.
     */
    public String getValue()
    {
        return _value;
    }

    /**
     * @return a status string that is used to identify request types, response
     *         types and error types associated to the message.
     */
    public StatusType getStatus()
    {
        return _status;
    }
}
