package de.tum.i13.server.kv.cache;

import java.util.Collection;
import java.util.Map;
import java.util.stream.Collectors;

/**
 * Last recently Used cache strategy.
 * 
 * @author Christoph Poeppelbaum
 *
 * @param <A> Key
 * @param <T> Item which has to implement ICacheItem
 */
public class CacheStrategyLRU<A, T extends ICacheItem> implements ICacheStrategy<A, T>
{

    @Override
    public Collection<A> getItemsToDisplace(Map<A, T> allCacheItems, int count)
    {
        return allCacheItems.entrySet().stream().sorted((e1, e2) -> e1.getValue().getTimeLastUsed().compareTo(e2.getValue().getTimeLastUsed())).limit(count).map(e -> e.getKey())
                .collect(Collectors.toList());
    }

}