package de.tum.i13.commandprocessor;

/**
 * Our custom Exception class which represents non fatal errors while executing
 * a command.
 * 
 * @author Christoph Poeppelbaum
 *
 */
public class CPExecutionRuntimeException extends Exception
{
    /**
     * 
     */
    private static final long serialVersionUID = 1L;

    public CPExecutionRuntimeException(String message)
    {
        super(message);
    }
}
