package de.tum.i13.server;

import java.io.IOException;

import de.tum.i13.kvshared.KVRuntimeException;

public class ServerMainEntry
{
    public static void main(String[] args) throws IOException, KVRuntimeException
    {
        ServerMain serverMain = new ServerMain();
        serverMain.run(args);
    }
}
