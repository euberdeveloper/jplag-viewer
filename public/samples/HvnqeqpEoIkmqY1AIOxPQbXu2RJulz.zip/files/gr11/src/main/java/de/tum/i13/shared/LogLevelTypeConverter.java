package de.tum.i13.shared;

import java.util.logging.Level;

import picocli.CommandLine;

public class LogLevelTypeConverter implements CommandLine.ITypeConverter<Level>
{

    @Override
    public Level convert(String value) throws Exception
    {
        return Level.parse(value);
    }

}
