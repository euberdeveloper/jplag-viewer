package de.tum.i13.client;

import java.util.Base64;

import de.tum.i13.kvstoreclientlib.KVResponse;

/**
 * Class with helper methods
 * 
 * @author Christoph Poeppelbaum
 *
 */
public class Auxiliaries
{
    /**
     * Creates a String from given KVResponse
     * 
     * @param response to parse.
     * @return parsed String.
     */
    public static String toString(KVResponse response)
    {
        String successMessage = "response: %s %s SUCCESS"; // action, key
        String errorMessage = "response: %s %s FAILED"; // action, key
        String successMessageWithValue = "response: %s %s %s SUCCESS"; // action, key, value
        String errorMessageWithValue = "response: %s %s %s FAILED"; // action, key, value

        String action = response.getStatus().name().split("_")[0].toLowerCase();
        String key = new String(Base64.getDecoder().decode(response.getKey()));
        String value = null;

        if (response.getValue() != null)
        {
            value = new String(Base64.getDecoder().decode(response.getValue()));
        }

        switch (response.getStatus())
        {
            case DELETE_SUCCESS:
                return String.format(successMessage, action, key);

            case DELETE_ERROR:
            case GET_ERROR:
                return String.format(errorMessage, action, key);

            case GET_SUCCESS:
            case PUT_SUCCESS:
            case PUT_UPDATE:
                return String.format(successMessageWithValue, action, key, value);

            case PUT_ERROR:
                return String.format(errorMessageWithValue, action, key, value);
            default:
                return "unknown message";
        }
    }
}
