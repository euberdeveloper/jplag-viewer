/**
 * The available shell commands which will be recognized by the
 * ShellInterpreter.
 */
package de.tum.i13.client.commands;