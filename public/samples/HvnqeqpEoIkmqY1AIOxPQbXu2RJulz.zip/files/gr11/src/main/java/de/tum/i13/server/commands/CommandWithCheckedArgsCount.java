package de.tum.i13.server.commands;

import java.util.logging.Logger;

import de.tum.i13.commandprocessor.CPExecutionRuntimeException;
import de.tum.i13.commandprocessor.ICommand;
import de.tum.i13.kvshared.KVRuntimeException;

/**
 * Command base class which checks count of arguments and will throw
 * ApplicationRuntimeException if check failed. Also provides a context for any
 * inheriting command to to something with.
 * 
 * @author Christoph Poeppelbaum
 *
 */
public abstract class CommandWithCheckedArgsCount implements ICommand
{
    private static final Logger _logger = Logger.getLogger(CommandWithCheckedArgsCount.class.getName());

    /**
     * The count of parameters needed.
     * 
     * @return count of parameters needed
     */
    abstract protected int getArgumentsCount();

    /**
     * Checks count of arguments and throws ApplicationRuntimeException if wrong
     * number of arguments
     * 
     * @param args Needed arguments. Contract: args is never null
     * @throws KVRuntimeException if wrong number of arguments
     */
    @Override
    public void execute(String[] args) throws CPExecutionRuntimeException
    {
        _logger.info(String.format("Command '%s' called with parameters '%s'.", getCommandName(), String.join(", ", args)));

        // enforce contracts
        assert args != null; // empty arguments are represented by array of size 0

        if (getArgumentsCount() == 0 && args.length != 0)
        {
            throw new IllegalArgumentException(String.format("Too many arguments. None needed"));
        }

        if (getArgumentsCount() != 0 && // true if parameters are required by this command
                (args == null || args.length != getArgumentsCount())) // if required, check if any args are given and assert count
        {
            throw new IllegalArgumentException(String.format("Wrong number of arguments. %s are needed.", getArgumentsCount()));
        }

        executeWithCheckedCountOfArgs(args);
    }

    /**
     * When this method is called the arguments are checked. Now actually call the
     * implementation of the inheriting class.
     * 
     * @param args checked arguments
     * @throws KVRuntimeException
     */
    abstract protected void executeWithCheckedCountOfArgs(String[] args) throws CPExecutionRuntimeException;
}
