package de.tum.i13.kvshared;

/**
 * Our custom Exception class which represents non fatal user input errors
 * 
 * @author Christoph Poeppelbaum
 *
 */
public class KVRuntimeException extends RuntimeException
{
    /**
     * 
     */
    private static final long serialVersionUID = 1L;

    public KVRuntimeException()
    {
    }

    public KVRuntimeException(String message)
    {
        super(message);
    }
}
