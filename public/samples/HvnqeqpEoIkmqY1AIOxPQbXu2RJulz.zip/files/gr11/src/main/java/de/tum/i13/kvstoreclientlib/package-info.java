/**
 * The KVStoreClient library which can be used by any client to communicate with
 * the KVStore.
 */
package de.tum.i13.kvstoreclientlib;