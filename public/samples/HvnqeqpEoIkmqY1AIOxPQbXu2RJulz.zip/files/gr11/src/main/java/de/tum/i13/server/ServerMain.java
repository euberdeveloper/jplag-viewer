package de.tum.i13.server;

import de.tum.i13.commandprocessor.CommandProcessor;
import de.tum.i13.kvshared.KVRuntimeException;
import de.tum.i13.server.commands.CommandWithCheckedArgsCount;
import de.tum.i13.server.commands.DeleteCommand;
import de.tum.i13.server.commands.DisconnectCommand;
import de.tum.i13.server.commands.GetCommand;
import de.tum.i13.server.commands.PutCommand;
import de.tum.i13.server.kv.CachedKVStore;
import de.tum.i13.server.kv.PersistentStorage;
import de.tum.i13.shared.Config;
import picocli.CommandLine;

import static de.tum.i13.shared.Config.parseCommandlineArgs;
import static de.tum.i13.shared.LogSetup.setupLogging;
import static de.tum.i13.shared.LogSetup.setLogLevel;

import java.io.*;
import java.net.InetSocketAddress;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.SocketException;
import java.util.Arrays;
import java.util.logging.Logger;

/**
 * Server Main. Based on given implementation which was commented with "chris on
 * 09.01.15."
 * 
 * @author Aaron Thoma
 *
 */
public class ServerMain
{
    private static final Logger _logger = Logger.getLogger(ServerMain.class.getName());
    private boolean _run = true;
    private ServerSocket _serverSocket;

    public void run(String[] args) throws IOException, KVRuntimeException
    {
        _run = true;

        if (Arrays.asList(args).contains("-h"))
        {
            CommandLine.usage(new Config(), System.out);
            System.exit(-1);
        }

        Config cfg = parseCommandlineArgs(args); // Do not change this
        setupLogging(cfg.logfile);
        setLogLevel(cfg.logLevel);

        _serverSocket = new ServerSocket();

        _logger.info("Server has been started");

        Runtime.getRuntime().addShutdownHook(new Thread()
        {
            @Override
            public void run()
            {
                _logger.info("Closing thread per connection kv server");
                System.out.println("shutdown hook");
                try
                {
                    _serverSocket.close();
                }
                catch (IOException e)
                {
                    _logger.warning(e.getMessage());
                }
            }
        });

        // bind to localhost only
        _serverSocket.bind(new InetSocketAddress(cfg.listenaddr, cfg.port));

        PersistentStorage store = new PersistentStorage(cfg.dataDir);
        CachedKVStore cachedStore = new CachedKVStore(store, cfg.strategy, cfg.cacheSize);

        while (_run)
        {
            try
            {
                Socket clientSocket = _serverSocket.accept();

                CommandProcessor<CommandWithCheckedArgsCount> logic = new CommandProcessor<CommandWithCheckedArgsCount>();
                ConnectionManager connection = new ConnectionManager(clientSocket);
                connection.open(clientSocket.getLocalSocketAddress(), clientSocket.getRemoteSocketAddress());

                ConnectionHandleThread th = new ConnectionHandleThread(logic, connection);

                logic.addCommand(new PutCommand(cachedStore, connection));
                logic.addCommand(new GetCommand(cachedStore, connection));
                logic.addCommand(new DeleteCommand(cachedStore, connection));
                logic.addCommand(new DisconnectCommand(th));

                // When we accept a connection, we start a new Thread for this connection
                th.start();

            }
            catch (SocketException ex)
            {
                _run = false;
            }
        }
    }

    public void stop()
    {
        _run = false;
        try
        {
            _serverSocket.close();
        }
        catch (IOException e)
        {
            //ignore
        }
    }
}
