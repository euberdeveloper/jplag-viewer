package de.tum.i13.server.commands;

import de.tum.i13.commandprocessor.CPExecutionRuntimeException;
import de.tum.i13.kvshared.KVRuntimeException;
import de.tum.i13.server.ConnectionManager;
import de.tum.i13.server.kv.IKVStore;
import de.tum.i13.server.kv.KVMessage;

/**
 * Implements the get command for the server.
 * 
 * @author Aaron Thoma
 *
 */
public class GetCommand extends CommandWithCheckedArgsCount
{
    private IKVStore _context;
    private ConnectionManager _connection;

    /**
     * Constructs a GetCommand
     * 
     * @param store      IKVStore the command uses to store data
     * @param connection ConnectionManager the command uses to send replies
     */
    public GetCommand(IKVStore store, ConnectionManager connection)
    {
        _context = store;
        _connection = connection;
    }

    @Override
    public String getCommandName()
    {
        return "get";
    }

    @Override
    protected void executeWithCheckedCountOfArgs(String[] args) throws CPExecutionRuntimeException
    {
        try
        {
            KVMessage result = _context.get(args[0]);
            _connection.sendKVMessage(result);
        }
        catch (KVRuntimeException ex)
        {
            throw new CPExecutionRuntimeException(ex.getMessage());
        }
    }

    @Override
    protected int getArgumentsCount()
    {
        return 1;
    }
}
