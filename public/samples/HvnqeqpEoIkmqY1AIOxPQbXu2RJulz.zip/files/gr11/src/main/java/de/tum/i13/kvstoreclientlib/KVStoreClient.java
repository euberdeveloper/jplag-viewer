package de.tum.i13.kvstoreclientlib;

import java.util.logging.Logger;

import de.tum.i13.kvshared.KVRuntimeException;
import de.tum.i13.kvstoreclientlib.KVResponse.StatusType;

/**
 * High level connection handler. This enforces basic checks and provides a
 * convenient methods for sending and receiving Strings
 * 
 * @author Christoph Poeppelbaum
 *
 */
public class KVStoreClient implements IKVStoreClient
{
    private static final Logger _logger = Logger.getLogger(KVStoreClient.class.getName());
    private IConnection _connection;
    private boolean _connected;

    @Override
    public String connect(IConnection connection) throws KVRuntimeException
    {
        if (_connected)
        {

            throw new KVRuntimeException("Already connected");
        }

        _connection = connection;

        _connection.open();

        _connected = true;

        byte[] buffer = _connection.receive();

        _logger.info("Server Welcoming message received.");

        String serverwelcome = unmarshall(buffer);

        return serverwelcome;
    }

    @Override
    public void disconnect() throws KVRuntimeException
    {
        if (!_connected)
        {

            throw new KVRuntimeException("Not connected");
        }

        try
        {
            _connection.send(marshall("disconnect"));

            _connection.close();
        }
        catch (KVRuntimeException ex)
        {
            // disconnect was not successful, probably server is down already. Silently
            // ignore.
        }
        finally
        {
            _connected = false;

            _logger.info("Disconnected.");

            System.out.println(String.format("EchoClient> Disconnected from Server"));
        }
    }

    @Override
    public KVResponse put(String key, String value) throws KVRuntimeException
    {
        if (!_connected)
        {
            throw new KVRuntimeException("Storing not possible without connection.");
        }

        if (!keyLength(key))
        {
            throw new KVRuntimeException(String.format("Key: '%s' does not meet expected key length.", key));
        }

        if (!valueLength(value))
        {
            throw new KVRuntimeException(String.format("Value: '%s' exceeds a values limit of 120KBytes.", value));
        }

        String fullMsg = "put " + key + " " + value;
        byte[] byteMsg = marshall(fullMsg);

        _connection.send(byteMsg);

        _logger.info(String.format("Put request sent for key:'%s' and value:'%s'.", key, value));

        byte[] answer = _connection.receive();
        String answerString = unmarshall(answer);

        _logger.info(String.format("Put request answer: '%s'", answerString));

        return decodeMessage(answerString);
    }

    @Override
    public KVResponse get(String key) throws KVRuntimeException
    {
        if (!_connected)
        {
            throw new KVRuntimeException("Retrieving value not possible without connection.");
        }

        if (!keyLength(key))
        {
            throw new KVRuntimeException(String.format("Key: '%s' does not meet expected key length", key));
        }

        String fullMsg = "get " + key;
        byte[] byteMsg = marshall(fullMsg);

        _connection.send(byteMsg);

        _logger.info(String.format("Get request sent for key:'%s'.", key));

        byte[] answer = _connection.receive();

        _logger.info(String.format("Value at key: '%s' received.", key));

        String answerString = unmarshall(answer);

        return decodeMessage(answerString);
    }

    @Override
    public KVResponse delete(String key) throws KVRuntimeException
    {
        if (!_connected)
        {
            throw new KVRuntimeException("Deleting value not possible without connection.");
        }

        if (!keyLength(key))
        {
            throw new KVRuntimeException(String.format("Key: '%s' does not meet expected key length", key));
        }

        String fullMsg = "delete " + key;
        byte[] byteMsg = marshall(fullMsg);

        _connection.send(byteMsg);

        _logger.info(String.format("Delete request sent for key:'%s'.", key));

        byte[] answer = _connection.receive();
        String answerString = unmarshall(answer);

        _logger.info(String.format("Deletion request answer: '%s'", answerString));

        return decodeMessage(answerString);
    }

    /**
     * Converts a String to a byte array
     * 
     * @param message String that contains message
     * @return Message converted from String to byte array
     */
    private byte[] marshall(String message)
    {
        message = message + "\r\n";
        byte[] messageByte = message.getBytes();
        return messageByte;
    }

    /**
     * Converts a byte array to a String
     * 
     * @param message Byte Array that contains message
     * @return Message converted from byte array to a String
     */
    private String unmarshall(byte[] message)
    {

        String answerString = "";
        char x;

        for (int i = 0; i < message.length; i++)
        {
            x = (char) message[i];
            answerString = answerString + x;
        }

        _logger.info("Message converted from byte array to String.");

        return answerString;
    }

    /**
     * Checks if key exceeds key length of 20 Bytes.
     * 
     * @param key Specified key
     * @return true if key smaller or equal than 20 Bytes, false if key larger than
     *         20 Bytes
     */
    private boolean keyLength(String key)
    {
        byte[] keyByte = key.getBytes();

        return (keyByte.length <= 20);
    }

    /**
     * Checks if value exceeds maximum value length of 120 KBytes.
     * 
     * @param value String that should be checked for length
     * @return true if value length smaller or equal than 120 KBytes, false if value
     *         length larger than 120 KBytes
     */
    private boolean valueLength(String value)
    {
        byte[] valueByte = value.getBytes();

        return (valueByte.length <= 120000);
    }

    @Override
    public boolean isConnected()
    {
        return _connected;
    }

    private KVResponse decodeMessage(String message) throws KVRuntimeException
    {
        _logger.info("received message: " + message);
        KVResponse response;
        try
        {
            String[] tokens = message.trim().split("\\s+", 3);

            StatusType status = StatusType.valueOf(tokens[0].toUpperCase());
            String key = tokens[1];

            if (tokens.length == 3)
            {
                String value = tokens[2];
                response = new KVResponse(key, value, status);
            }
            else
            {
                response = new KVResponse(key, status);
            }
        }
        catch (Exception ex)
        {
            throw new KVRuntimeException("server response was of unknown format");
        }

        return response;
    }

}
