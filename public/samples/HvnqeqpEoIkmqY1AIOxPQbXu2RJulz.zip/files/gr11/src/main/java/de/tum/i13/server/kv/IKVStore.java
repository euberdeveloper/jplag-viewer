package de.tum.i13.server.kv;

import de.tum.i13.kvshared.KVRuntimeException;

/**
 * Based on given implementation. We expect ApplicationRuntimeExceptions.
 * 
 * @author Christoph Poeppelbaum
 *
 */
public interface IKVStore
{

    /**
     * Inserts a key-value pair into the store.
     *
     * @param key   the key that identifies the given value.
     * @param value the value that is indexed by the given key.
     * @return a message that confirms the insertion of the tuple or an error.
     * @throws KVRuntimeException Any manageable exception.
     */
    public KVMessage put(String key, String value) throws KVRuntimeException;

    /**
     * Retrieves the value for a given key from the store.
     *
     * @param key the key that identifies the value.
     * @return the value, which is indexed by the given key.
     * @throws KVRuntimeException Any manageable exception.
     */
    public KVMessage get(String key) throws KVRuntimeException;

    /**
     * Deletes the given key and its value from the store.
     * 
     * @param key the key that identifies the value.
     * @return a message that confirms the deletion of the tuple or an error.
     * @throws KVRuntimeException Any manageable exception.
     */
    public KVMessage delete(String key) throws KVRuntimeException;
}
