package de.tum.i13.client.commands;

import java.util.Map;

import de.tum.i13.client.ShellInterpreter;
import de.tum.i13.commandprocessor.CPExecutionRuntimeException;

/**
 * Command to quit the program
 * 
 * @author Christoph Poeppelbaum
 *
 */
public class QuitCommand extends CommandWithCheckedArgsCountAndHelp
{
    private ShellInterpreter _shellInterpreter;

    public QuitCommand(ShellInterpreter shellInterpreter)
    {
        _shellInterpreter = shellInterpreter;
    }

    @Override
    public String getCommandName()
    {
        return "quit";
    }

    @Override
    public String getDescription()
    {
        return "Tears down the active connection to the server and exits the program execution";
    }

    @Override
    public Map<String, String> getArguments()
    {
        return null; // no arguments needed
    }

    @Override
    protected void executeWithCheckedCountOfArgs(String[] args) throws CPExecutionRuntimeException
    {
        _shellInterpreter.stop();
        _shellInterpreter.writeConsoleLine("invoking shutdown");
    }

}
