package de.tum.i13.client.commands;

import java.util.Map;
import java.util.logging.Logger;

import de.tum.i13.commandprocessor.CPExecutionRuntimeException;
import de.tum.i13.commandprocessor.ICommand;
import de.tum.i13.kvshared.KVRuntimeException;

/**
 * Command base class which checks count of arguments and will throw
 * ApplicationRuntimeException if check failed. Also provides textual
 * description of the command as well as it's needed arguments.
 * 
 * @author Christoph Poeppelbaum
 *
 */
public abstract class CommandWithCheckedArgsCountAndHelp implements ICommand
{
    private static final Logger _logger = Logger.getLogger(CommandWithCheckedArgsCountAndHelp.class.getName());

    /**
     * Description of the given command
     * 
     * @return description of the command
     */
    public abstract String getDescription();

    /**
     * A list of parameter names this command needs. These names are for printing or
     * logging purposes. The size of this list also determines how many arguments
     * are needed. Contract: Returns null if no argument needed.
     * 
     * @return pairs of parameter name and helpText
     */
    public abstract Map<String, String> getArguments();

    /**
     * Checks count of arguments and throws ApplicationRuntimeException if wrong
     * number of arguments
     * 
     * @param args Needed arguments. Contract: args is never null
     * @throws CPExecutionRuntimeException if wrong number of arguments
     */
    @Override
    public void execute(String[] args) throws CPExecutionRuntimeException
    {
        _logger.info(String.format("Command '%s' called with parameters '%s'.", getCommandName(), String.join(", ", args)));

        // enforce contracts
        assert args != null; // empty arguments are represented by array of size 0
        assert getArguments() == null || getArguments().size() != 0; // if no arguments needed, return value has to be
                                                                     // null. Else may not be of size 0.

        if (getArguments() == null && args.length != 0)
        {
            throw new IllegalArgumentException(String.format("Too many arguments. None needed"));
        }

        if (getArguments() != null && // true if parameters are required by this command
                (args == null || args.length != getArguments().size())) // if required, check if any args are given and
                                                                        // assert count
        {
            throw new IllegalArgumentException(String.format("Wrong number of arguments. These are needed: %s", String.join(", ", getArguments().keySet())));
        }

        executeWithCheckedCountOfArgs(args);
    }

    /**
     * When this method is called the arguments are checked. Now actually call the
     * implementation of the inheriting class.
     * 
     * @param args checked arguments
     * @throws KVRuntimeException
     */
    abstract protected void executeWithCheckedCountOfArgs(String[] args) throws CPExecutionRuntimeException;
}
