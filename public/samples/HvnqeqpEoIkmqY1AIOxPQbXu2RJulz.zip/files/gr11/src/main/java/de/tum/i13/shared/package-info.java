/**
 * Classes which client and server application share.
 */
package de.tum.i13.shared;