package de.tum.i13.client;

import java.util.logging.Logger;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.net.URI;
import java.nio.file.Path;
import java.nio.file.Paths;

import de.tum.i13.client.commands.*;
import de.tum.i13.commandprocessor.CommandProcessor;
import de.tum.i13.kvstoreclientlib.IKVStoreClient;
import de.tum.i13.kvstoreclientlib.KVStoreClient;
import de.tum.i13.shared.LogSetup;

/**
 * Client Main
 * 
 * @author Christoph Poeppelbaum
 *
 */
public class ClientMain
{

    private final static Logger _logger = Logger.getLogger(ClientMain.class.getName());

    /**
     * Entry point of the application
     * 
     * @param args Console arguments (ignored atm)
     */
    public static void main(String[] args)
    {
        Path logPath = Paths.get(URI.create("file:/test.log"));
        LogSetup.setupLogging(logPath);

        _logger.info("starting application");

        IKVStoreClient connectionManager = new KVStoreClient();
        CommandProcessor<CommandWithCheckedArgsCountAndHelp> commandProcessor = new CommandProcessor<CommandWithCheckedArgsCountAndHelp>();
        ShellInterpreter shellInterpreter = new ShellInterpreter(commandProcessor);

        commandProcessor.addCommand(new ConnectToSocketCommand(connectionManager, m -> shellInterpreter.writeConsoleLine(m)));
        commandProcessor.addCommand(new DisconnectCommand(connectionManager));
        commandProcessor.addCommand(new PutCommand(connectionManager, m -> shellInterpreter.writeConsoleLine(m)));
        commandProcessor.addCommand(new GetCommand(connectionManager, m -> shellInterpreter.writeConsoleLine(m)));
        commandProcessor.addCommand(new DeleteCommand(connectionManager, m -> shellInterpreter.writeConsoleLine(m)));
        commandProcessor.addCommand(new LogLevelCommand(_logger, m -> shellInterpreter.writeConsoleLine(m)));

        try
        {
            shellInterpreter.run(); // blocks till user quits or fatal error

            if (connectionManager.isConnected())
            {
                connectionManager.disconnect();
            }
        }
        catch (Throwable ex) // any fatal error shall be logged
        {
            StringWriter sw = new StringWriter();
            ex.printStackTrace(new PrintWriter(sw));
            _logger.severe(sw.toString());
        }

        _logger.info("application was terminated");
    }
}
