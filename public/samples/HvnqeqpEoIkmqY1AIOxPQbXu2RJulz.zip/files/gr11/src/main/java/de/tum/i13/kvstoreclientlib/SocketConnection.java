package de.tum.i13.kvstoreclientlib;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.Socket;
import java.net.UnknownHostException;
import java.util.Arrays;
import java.util.logging.Logger;

import de.tum.i13.kvshared.KVIOException;
import de.tum.i13.kvshared.KVRuntimeException;

/**
 * Connection model which encapsulates and handles a socket
 * 
 * @author Christoph Poeppelbaum
 *
 */
public class SocketConnection implements IConnection
{
    private static final Logger _logger = Logger.getLogger(SocketConnection.class.getName());
    private Socket _socket;
    private InputStream _in;
    private OutputStream _out;
    private String _address;
    private int _port;

    public SocketConnection(String address, int port)
    {
        _address = address;
        _port = port;
    }

    @Override
    public void open() throws KVRuntimeException
    {
        try
        {
            _socket = new Socket(_address, _port);

            _logger.info(String.format("Connection to adress: '%s' port: '%s' established", _address, _port));

        }
        catch (UnknownHostException ex)
        {

            throw new KVRuntimeException(String.format("Opening address '%s' and port '%s' failed: unknown host", _address, _port));
        }
        catch (IOException ex)
        {

            throw new KVRuntimeException(String.format("Opening address '%s' and port '%s' failed: %s", _address, _port, ex.getMessage()));
        }

        try
        {

            _in = _socket.getInputStream();

            _logger.info("InputStream assigend to varibale _in.");

        }
        catch (IOException ex)
        {

            throw new KVRuntimeException(String.format("InputStream creation failed: %s", ex.getMessage()));
        }

        try
        {

            _out = _socket.getOutputStream();

            _logger.info("OutputStream assigend to varibale _out.");

        }
        catch (IOException ex)
        {

            throw new KVRuntimeException(String.format("OutputStream creation failed: %s", ex.getMessage()));
        }
    }

    @Override
    public void close() throws KVRuntimeException
    {
        try
        {

            _in.close();

            _logger.info("InputStream closed.");

        }
        catch (IOException ex)
        {

            throw new KVRuntimeException(String.format("InputStream could not be closed: %s", ex.getMessage()));
        }

        try
        {

            _out.close();

            _logger.info("OutputStream closed.");

        }
        catch (IOException ex)
        {

            throw new KVRuntimeException(String.format("OutputStream could not be closed: %s", ex.getMessage()));
        }

        try
        {

            _socket.close();

            _logger.info("Socket closed.");

        }
        catch (IOException ex)
        {

            throw new KVRuntimeException(String.format("Socket could not be closed: %s", ex.getMessage()));
        }

    }

    @Override
    public void send(byte[] message) throws KVIOException
    {
        try
        {

            _out.write(message);

            _out.flush();

            _logger.info("Message written to OutputStream.");

        }
        catch (IOException ex)
        {

            throw new KVIOException();

        }

    }

    @Override
    public byte[] receive() throws KVRuntimeException
    {
        byte[] buffer = new byte[128000];
        int messagelength = 0;

        try
        {

            messagelength = _in.read(buffer);

            _logger.info("Bytes read out of InputStream.");

        }
        catch (IOException ex)
        {

            throw new KVRuntimeException(String.format("Receiving failed: %s", ex.getMessage()));
        }

        byte[] answer = Arrays.copyOf(buffer, messagelength - 2);

        return answer;
    }

}
