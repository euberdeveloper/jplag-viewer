/**
 * The KVStoreServer which handles key value pairs.
 */
package de.tum.i13.server;