package de.tum.i13.client.commands;

import java.util.Map;
import java.util.function.Consumer;

import de.tum.i13.commandprocessor.CPExecutionRuntimeException;
import de.tum.i13.kvshared.KVRuntimeException;
import de.tum.i13.kvstoreclientlib.*;

/**
 * Command to connect to a socket via address and port
 * 
 * @author Christoph Poeppelbaum
 *
 */
public class ConnectToSocketCommand extends CommandWithCheckedArgsCountAndHelp
{
    private Map<String, String> _arguments;
    private IKVStoreClient _connectionManager;
    private Consumer<String> _outputPrinter;

    public ConnectToSocketCommand(IKVStoreClient connectionManager, Consumer<String> outputPrinter)
    {
	_connectionManager = connectionManager;
	_outputPrinter = outputPrinter;

	_arguments = Map.of("address", "Hostname or IP address of the echo server.", "port",
		"The port of the echo service on the respective server.");
    }

    @Override
    public String getCommandName()
    {
	return "connect";
    }

    @Override
    public String getDescription()
    {
	return "Tries to establish a connection to the server based on the given address of the echo server and the port number";
    }

    @Override
    public Map<String, String> getArguments()
    {
	return _arguments;
    }

    @Override
    protected void executeWithCheckedCountOfArgs(String[] args) throws CPExecutionRuntimeException
    {
	String address = args[0];
	int port;

	try
	{
	    port = Integer.parseInt(args[1]);
	} catch (NumberFormatException ex)
	{
	    throw new IllegalArgumentException("argument 'port' has to be a number");
	}

	SocketConnection socketConnection = new SocketConnection(address, port);

	try
	{
	    String result = _connectionManager.connect(socketConnection);
	    _outputPrinter.accept(result);
	}
	catch(KVRuntimeException ex)
	{
	    throw new CPExecutionRuntimeException(ex.getMessage());
	}
    }

}
