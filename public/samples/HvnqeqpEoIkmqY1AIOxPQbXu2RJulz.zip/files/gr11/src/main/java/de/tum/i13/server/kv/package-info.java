/**
 * The actual KVStore logic.
 */
package de.tum.i13.server.kv;