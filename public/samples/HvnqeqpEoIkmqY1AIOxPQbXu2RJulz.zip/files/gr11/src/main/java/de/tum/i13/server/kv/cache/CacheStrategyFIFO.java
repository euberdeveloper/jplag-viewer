package de.tum.i13.server.kv.cache;

import java.util.Collection;
import java.util.Map;
import java.util.stream.Collectors;

/**
 * First In First Out cache strategy.
 * 
 * @author Christoph Poeppelbaum
 *
 * @param <A> Key
 * @param <T> Item which has to implement ICacheItem
 */
public class CacheStrategyFIFO<A, T extends ICacheItem> implements ICacheStrategy<A, T>
{

    @Override
    public Collection<A> getItemsToDisplace(Map<A, T> allCacheItems, int count)
    {
        return allCacheItems.entrySet().stream().sorted((e1, e2) -> e1.getValue().getTimeCreated().compareTo(e2.getValue().getTimeCreated())).limit(count).map(e -> e.getKey())
                .collect(Collectors.toList());
    }

}
