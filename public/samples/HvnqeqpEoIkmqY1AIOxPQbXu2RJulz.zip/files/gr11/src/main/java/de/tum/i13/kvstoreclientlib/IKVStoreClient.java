package de.tum.i13.kvstoreclientlib;

import de.tum.i13.kvshared.KVRuntimeException;

/**
 * High level connection handler. This enforces basic checks and provides a
 * convenient methods for sending and receiving Strings
 * 
 * @author Christoph Poeppelbaum
 *
 */
public interface IKVStoreClient
{
    /**
     * Here we can inject any class, handling a connection, even a stub for unit
     * testing
     * 
     * @param connection A low level connection handler
     * @return welcome message from server
     * @throws KVStoreClientRuntimeException when already a connection is open
     */
    String connect(IConnection connection) throws KVRuntimeException;

    /**
     * Indicates if a connection is open
     * 
     * @return true if connection is open
     */
    boolean isConnected();

    /**
     * Tears down the connection
     * 
     * @throws KVStoreClientRuntimeException when no connection is open
     */
    void disconnect() throws KVRuntimeException;

    /**
     * Sends message through the connection with a value that should be stored at a
     * specified key
     * 
     * @param key   Specific Key where the Value should be stored
     * @param value Value that should be stored
     * @return result as KVResponse
     * @throws KVStoreClientRuntimeException when no connection is open or when
     *                                       key/value does not meet expectation
     */
    KVResponse put(String key, String value) throws KVRuntimeException;

    /**
     * Sends message through the connection to get value at specified key
     * 
     * @param key Specified key to stored value
     * @return result as KVResponse
     * @throws KVStoreClientRuntimeException when no connection is open or when key
     *                                       does not meet expectation
     */
    KVResponse get(String key) throws KVRuntimeException;

    /**
     * Sends message through the connection to delete value at specified key
     * 
     * @param key Specified key where the value to be deleted should be stored
     * @return result as KVResponse
     * @throws KVStoreClientRuntimeException when no connection is open or when key
     *                                       does not meet expectation
     */
    KVResponse delete(String key) throws KVRuntimeException;
}
