package de.tum.i13.commandprocessor;

import java.util.Collection;
import java.util.HashMap;
import java.util.Map;

/**
 * Stores all available commands and either returns all available or one
 * corresponding by a string (or throws Exception if not found).
 * 
 * @author Christoph Poeppelbaum
 *
 */
public class CommandProcessor<T extends ICommand>
{
    private Map<String, T> _availableCommands;

    public CommandProcessor()
    {
        _availableCommands = new HashMap<String, T>();
    }

    /**
     * Add a command which will then be found by the getCommand method or
     * getAvailableCommands
     * 
     * @param command Command to store
     */
    public void addCommand(T command)
    {
        _availableCommands.put(command.getCommandName().toLowerCase(), command);
    }

    /**
     * Retrieve list of all available (previously stored) commands
     * 
     * @return list of all available commands
     */
    public Collection<T> getAvailableCommands()
    {
        return _availableCommands.values();
    }

    /**
     * Get specified command by name
     * 
     * @param name Name to search for within available commands
     * @return Specified command
     * @throws CPCommandNotFoundException If command was not found
     */
    private T getCommand(String name) throws CPCommandNotFoundException
    {
        if (_availableCommands.containsKey(name.toLowerCase()))
        {
            return _availableCommands.get(name.toLowerCase());
        }
        else
        {
            throw new CPCommandNotFoundException(String.format("command '%s' not found", name));
        }
    }

    /**
     * Accepts a string which will splitted by it's spaces. First word has to be the
     * command name to search for, everything following are arguments.
     * 
     * @param line String which represents a command and is to be parsed.
     * @throws CPExecutionRuntimeException If command was not found
     * @throws IllegalArgumentException    If wrong arguments are given
     */
    public void process(String line) throws CPExecutionRuntimeException, CPCommandNotFoundException, IllegalArgumentException
    {
        String[] tokens = line.trim().trim().split("\\s+", 3);

        ICommand command = getCommand(tokens[0]);
        String[] commandArgs = new String[tokens.length - 1];
        System.arraycopy(tokens, 1, commandArgs, 0, commandArgs.length);

        command.execute(commandArgs);
    }
}
