package de.tum.i13.server.commands;

import de.tum.i13.commandprocessor.CPExecutionRuntimeException;
import de.tum.i13.server.ConnectionHandleThread;

/**
 * Implements the command disconnect
 * 
 * @author Aaron Thoma
 *
 */
public class DisconnectCommand extends CommandWithCheckedArgsCount
{
    private ConnectionHandleThread _connection;

    /**
     * Constructs a DisconnectCommand
     * 
     * @param connectionThread ConnectionHandleThread which should be notified of
     *                         disconnection from client
     */
    public DisconnectCommand(ConnectionHandleThread connectionThread)
    {
        _connection = connectionThread;
    }

    @Override
    public String getCommandName()
    {
        return "disconnect";
    }

    @Override
    protected int getArgumentsCount()
    {
        return 0;
    }

    @Override
    protected void executeWithCheckedCountOfArgs(String[] args) throws CPExecutionRuntimeException
    {
        _connection.requestStop();
    }

}
