package de.tum.i13.client;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Map;
import java.util.logging.Logger;

import de.tum.i13.client.commands.*;
import de.tum.i13.commandprocessor.CPCommandNotFoundException;
import de.tum.i13.commandprocessor.CPExecutionRuntimeException;
import de.tum.i13.commandprocessor.CommandProcessor;

/**
 * Handles user input and interpretes as commands, as well as prints
 * 
 * @author Christoph Poeppelbaum
 *
 */
public class ShellInterpreter
{
    private static final Logger _logger = Logger.getLogger(ShellInterpreter.class.getName());
    private static final String Prompt = "EchoClient> ";
    private static boolean _requestShutdown = false;

    private CommandProcessor<CommandWithCheckedArgsCountAndHelp> _commandProcessor;

    public ShellInterpreter(CommandProcessor<CommandWithCheckedArgsCountAndHelp> commandProcessor)
    {
        _commandProcessor = commandProcessor;

        // adding commands that belong to shell
        _commandProcessor.addCommand(new HelpCommand(this));
        _commandProcessor.addCommand(new QuitCommand(this));
    }

    /**
     * runs till user quits or the stop method is called
     * 
     * @throws IOException exception from BufferedReader.ReadLine
     */
    public void run() throws IOException
    {
        _logger.info("shellinterpreter startet");

        BufferedReader input;
        input = new BufferedReader(new InputStreamReader(System.in));

        while (!_requestShutdown)
        {
            try
            {
                String line = readConsoleLine(input);
                _commandProcessor.process(line);
            }
            catch (CPCommandNotFoundException ex) // no command with this name was found, so print help text
            {
                writeConsoleLine(ex.getMessage());
                help();
            }
            catch (IllegalArgumentException ex)
            {
                writeConsoleLine(ex.getMessage());
                help();
            }
            catch (CPExecutionRuntimeException ex)
            {
                writeConsoleLine("error: " + ex.getMessage());

                _logger.warning(ex.getMessage());
            }
        }
    }

    /**
     * Prints message to console.
     * 
     * @param message text to write.
     */
    public void writeConsoleLine(String message)
    {
        String line = Prompt + message;
        _logger.fine(line);
        System.out.println(line);
    }

    private String readConsoleLine(BufferedReader input) throws IOException
    {
        System.out.print(Prompt);
        String line = input.readLine();
        _logger.fine(Prompt + line);
        return line;
    }

    /**
     * Stops the blocking executing of the shell interpreter
     */
    public void stop()
    {
        _requestShutdown = true;

        _logger.info("shellinterpreter stopped");
    }

    /**
     * Prints help text to console.
     */
    public void help()
    {
        ArrayList<CommandWithCheckedArgsCountAndHelp> commands = new ArrayList<CommandWithCheckedArgsCountAndHelp>(_commandProcessor.getAvailableCommands());
        String helptext = "\n========== Help ==========\n";

        Collections.sort(commands, new Comparator<CommandWithCheckedArgsCountAndHelp>()
        {
            @Override
            public int compare(CommandWithCheckedArgsCountAndHelp o1, CommandWithCheckedArgsCountAndHelp o2)
            {
                return String.CASE_INSENSITIVE_ORDER.compare(o1.getCommandName(), o2.getCommandName());
            }
        });

        for (CommandWithCheckedArgsCountAndHelp command : commands)
        {
            helptext += command.getCommandName() + " - " + command.getDescription() + "\n";
            if (command.getArguments() != null)
            {
                for (Map.Entry<String, String> argument : command.getArguments().entrySet())
                {
                    helptext += "\t" + argument.getKey() + " - " + argument.getValue() + "\n";
                }
            }
        }
        helptext += "=========================";

        _logger.info("showing helptext");

        writeConsoleLine(helptext);
    }
}
