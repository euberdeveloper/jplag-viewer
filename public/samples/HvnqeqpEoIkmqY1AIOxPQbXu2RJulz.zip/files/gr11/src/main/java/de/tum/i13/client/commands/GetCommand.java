package de.tum.i13.client.commands;

import java.util.Base64;
import java.util.Map;
import java.util.function.Consumer;

import de.tum.i13.client.Auxiliaries;
import de.tum.i13.commandprocessor.CPExecutionRuntimeException;
import de.tum.i13.kvshared.KVIOException;
import de.tum.i13.kvshared.KVRuntimeException;
import de.tum.i13.kvstoreclientlib.*;

/**
 * Command to get the value at specified key from StorageServer.
 * 
 * @author Aaron Thoma
 *
 */

public class GetCommand extends CommandWithCheckedArgsCountAndHelp
{
    private IKVStoreClient _context;
    private Map<String, String> _arguments;
    private Consumer<String> _outputPrinter;

    public GetCommand(IKVStoreClient context, Consumer<String> outputPrinter)
    {
        _context = context;
        _arguments = Map.of("key", "specified key where the value is stored");
        _outputPrinter = outputPrinter;
    }

    @Override
    public String getCommandName()
    {
        return "get";
    }

    @Override
    public String getDescription()
    {
        return "Gets the value at specified key from StorageServer";
    }

    @Override
    public Map<String, String> getArguments()
    {
        return _arguments;
    }

    @Override
    protected void executeWithCheckedCountOfArgs(String[] args) throws CPExecutionRuntimeException
    {
        try
        {
            KVResponse result = _context.get(Base64.getEncoder().encodeToString(args[0].getBytes()));
            _outputPrinter.accept(Auxiliaries.toString(result));
        }
        catch (KVIOException ex)
        {
            try
            {
                _outputPrinter.accept("Disconnected because Server could not be reached.");
                _context.disconnect();
            }
            catch (KVRuntimeException e)
            {
                throw new CPExecutionRuntimeException(e.getMessage());
            }
        }
        catch (KVRuntimeException ex)
        {
            throw new CPExecutionRuntimeException(ex.getMessage());
        }

    }

}
