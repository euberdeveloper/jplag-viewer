package de.tum.i13.server.kv.cache;

import java.time.Instant;

/**
 * Wrapper for items to be cached, which holds additional statistical
 * informations which CacheStrategies can make use of.
 * 
 * @author Christoph Poeppelbaum
 *
 * @param <T> Type of the actual item to cache.
 */
public class CacheItem<T> implements ICacheItem
{
    private T _item;
    private int _countUsed = 0;
    private Instant _timeLastUsed;
    private Instant _timeCreated;

    public CacheItem(T content)
    {
        _timeCreated = _timeLastUsed = Instant.now();
        _item = content;
    }

    public T getContent()
    {
        return _item;
    }

    @Override
    public void markAsUsed()
    {
        _timeLastUsed = Instant.now();
        _countUsed = _countUsed + 1;
    }

    @Override
    public int getCountUsed()
    {
        return _countUsed;
    }

    @Override
    public Instant getTimeLastUsed()
    {
        return _timeLastUsed;
    }

    @Override
    public Instant getTimeCreated()
    {
        return _timeCreated;
    }
}
