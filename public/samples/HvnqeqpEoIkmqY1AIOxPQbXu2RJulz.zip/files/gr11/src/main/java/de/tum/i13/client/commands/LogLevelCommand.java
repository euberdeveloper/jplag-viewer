package de.tum.i13.client.commands;

import java.util.Map;
import java.util.function.Consumer;
import java.util.logging.Level;
import java.util.logging.Logger;

import de.tum.i13.commandprocessor.CPExecutionRuntimeException;
import de.tum.i13.kvshared.KVRuntimeException;

/**
 * Command to change the log level
 * 
 * @author Wen Qing Wei
 *
 */
public class LogLevelCommand extends CommandWithCheckedArgsCountAndHelp
{
    private Logger _logger;
    private Map<String, String> _arguments;
    private String currentLevel;
    private String previousLevel;
    private Consumer<String> _outputPrinter;

    public LogLevelCommand(Logger logger, Consumer<String> outputPrinter)
    {
        currentLevel = "ALL";
        _logger = logger;
        _arguments = Map.of("level", " One of the following log levels: " + "(SEVERE | WARNING | INFO | CONFIG | FINE | FINER | FINEST)");
        _outputPrinter = outputPrinter;
    }

    /**
     * Enumeration of different usable log levels for the logger
     * 
     * @author Wen Qing Wei
     *
     */

    public enum LogLevels
    {
        SEVERE, WARNING, INFO, CONFIG, FINE, FINER, FINEST
    }

    /**
     * checks if the level in the input exists as a log level
     * 
     * @param level in the input
     * @return true if the log level exists, otherwise false
     */
    private boolean contains(String input)
    {
        for (LogLevels level : LogLevels.values())
        {
            if (level.name().equals(input))
            {
                return true;
            }
        }

        return false;
    }

    @Override
    public String getCommandName()
    {
        return "logLevel";
    }

    @Override
    public String getDescription()
    {
        return "Sets the logger to the specified log level";
    }

    @Override
    public Map<String, String> getArguments()
    {
        return _arguments;
    }

    /**
     * @throws KVRuntimeException when the log level given in the input does not
     *                            exist or is not valid
     */
    @Override
    protected void executeWithCheckedCountOfArgs(String[] args) throws CPExecutionRuntimeException
    {
        if (!contains(args[0]))
        {
            _logger.warning("Specified log level does not exist.");
            _logger.warning("Try one of the following levels: SEVERE , WARNING , INFO , CONFIG , FINE , FINER , FINEST");

            throw new IllegalArgumentException("Specified log level does not exist.\n" + "Try one of the following levels: SEVERE , WARNING , INFO , CONFIG , FINE , FINER , FINEST");
        }
        previousLevel = currentLevel;
        currentLevel = args[0];
        _logger.setLevel(Level.parse(currentLevel));
        _logger.info("changed log level to " + currentLevel);
        _outputPrinter.accept("loglevel set from " + previousLevel + " to " + currentLevel);
    }

}