package de.tum.i13.commandprocessor;

/**
 * Minimal interface for a command which can be executed via command line
 * 
 * @author Christoph Poeppelbaum
 *
 */
public interface ICommand
{
    /**
     * The name by which this command may be found
     * 
     * @return name of this command
     */
    String getCommandName();

    /**
     * This executes a specified method.
     * 
     * @param args Needed arguments for the method this command is calling.
     * @throws CPExecutionRuntimeException If arguments are not sufficient or thrown
     *                                     by the method this command is calling.
     * @throws IllegalArgumentException    If wrong arguments are given
     */
    void execute(String[] args) throws CPExecutionRuntimeException, IllegalArgumentException;
}
