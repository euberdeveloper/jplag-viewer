/**
 * The client to interact with KVServer via the kvstoreclientlib "library".
 */
package de.tum.i13.client;