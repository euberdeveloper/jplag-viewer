package de.tum.i13.server.kv.cache;

import java.util.Collection;
import java.util.Map;

/**
 * Algorithm which calculates the items to be deleted from the cache if it has
 * to be shrunk.
 * 
 * @author Christoph Poeppelbaum
 *
 * @param <A> Key
 * @param <T> Item which has to implement ICacheItem
 */
public interface ICacheStrategy<A, T extends ICacheItem>
{
    /**
     * Picks given amount of items from given list.
     * 
     * @param allCacheItems List of all cached items.
     * @param count         Amount of items to choose.
     * @return Chosen Items which shall be deleted from cache.
     */
    Collection<A> getItemsToDisplace(Map<A, T> allCacheItems, int count);
}
