package de.tum.i13.server.kv.cache;

import java.time.Instant;

/**
 * Wrapper for items to be cached, which holds additional statistical
 * informations which CacheStrategies can make use of.
 * 
 * @author Christoph Poeppelbaum
 *
 */
public interface ICacheItem
{
    /**
     * Increments the "Used" counter and updates LastUsed timestamp.
     */
    void markAsUsed();

    /**
     * Returns the "Used" counter.
     * 
     * @return count of how often this cache item was requested.
     */
    int getCountUsed();

    /**
     * Returns timestamp when this cache item was used last time.
     * 
     * @return Timestamp when this cache item was used last time
     */
    Instant getTimeLastUsed();

    /**
     * Returns timestamp when this cache item was created.
     * 
     * @return Timestamp when this cache item was created
     */
    Instant getTimeCreated();
}