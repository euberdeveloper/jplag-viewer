package de.tum.i13.server.kv;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.PrintWriter;
import java.nio.file.Path;
import java.util.logging.Logger;

import de.tum.i13.kvshared.KVRuntimeException;
import de.tum.i13.server.kv.KVMessage.StatusType;

/**
 * Storage class to put or get data (key and value) using the file system with
 * the filename being the key and the file content being the value
 * 
 * @author Wen Qing Wei
 *
 */

public class PersistentStorage implements IKVStore
{
    private static final Logger _logger = Logger.getLogger(PersistentStorage.class.getName());
    private File folder;

    /**
     * Creates storage folder if it does not exist already
     * 
     * @param path where the data are stored
     * @throws IOException if folder cannot be created
     */
    public PersistentStorage(Path path) throws IOException
    {
        folder = new File(System.getProperty("user.dir") + '/' + path.toString());
        if (!folder.exists())
        {
            folder.mkdir();
        }
        _logger.info("folder for data: " + folder.getAbsolutePath());
    }

    public File getFolder()
    {
        return this.folder;
    }

    /**
     * Inserts value using the given key if the key does not exist in storage yet,
     * otherwise updates/overwrites value using the exisitng key
     * 
     * @param key   (file name)
     * @param value (file content) to be stored on the server
     * @return KVMessage with appropriate status type
     * @throws KVRuntimeException if the file cannot be created
     */
    @Override
    public KVMessage put(String key, String value) throws KVRuntimeException
    {
        File keyFile = new File(folder.getAbsolutePath(), transformKey(key) + ".txt");
        _logger.info("created file: " + keyFile.getAbsolutePath());
        StatusType status = StatusType.PUT_SUCCESS;
        try
        {
            if (!keyFile.createNewFile())
            {
                _logger.info("Value updated on disk");
                status = StatusType.PUT_UPDATE;
            }
            else
            {
                _logger.info("Value added to disk");
            }
            writeToFile(keyFile, value);
        }
        catch (IOException e)
        {
            _logger.warning("File cannot be created, key cmight contain inappropriate characters");
            return new KVMessage(key, StatusType.PUT_ERROR);
        }
        return new KVMessage(key, value, status);
    }

    /**
     * Clears the file content using the given key
     * 
     * @param key (file name)
     * @return KVMessage with null value and appropriate status type
     * @throws KVRuntimeException if the key/file does not exist
     */
    @Override
    public KVMessage delete(String key) throws KVRuntimeException
    {
        File keyFile = new File(folder.getName(), transformKey(key) + ".txt");
        _logger.info("created file: " + keyFile.getName());
        if (keyFile.exists())
        {
            keyFile.delete();
        }
        else
        {
            _logger.warning("Error while deleting value");
            return new KVMessage(key, StatusType.DELETE_ERROR);
        }
        _logger.info("Value on disk successfully deleted");
        return new KVMessage(key, StatusType.DELETE_SUCCESS);
    }

    /**
     * Extracts the file content (value) using the given key
     * 
     * @param key that is used to retrieve the value
     * @return KVMessage with value read from disk or null if the file doesn't exist
     *         and appropriate status type
     * @throws KVRuntimeException if the key/file does not exist
     */
    @Override
    public KVMessage get(String key) throws KVRuntimeException
    {
        File keyFile = new File(folder.getName(), transformKey(key) + ".txt");
        _logger.info("created file: " + keyFile.getName());
        if (keyFile.exists())
        {
            try
            {
                BufferedReader reader = new BufferedReader(new FileReader(keyFile));
                String s;
                s = reader.readLine();
                _logger.info("Value successfully read from disk");
                reader.close();
                return new KVMessage(key, s, StatusType.GET_SUCCESS);
            }
            catch (IOException e)
            {
                throw new KVRuntimeException("Value cannot be read");
            }
        }
        else
        {
            _logger.warning("Value cannot be retrieved from disk");
            return new KVMessage(key, StatusType.GET_ERROR);
        }
    }

    /**
     * Writes the content onto file
     * 
     * @param key   (file)
     * @param value (file content)
     * @throws FileNotFoundException
     */

    private void writeToFile(File key, String value) throws FileNotFoundException
    {
        PrintWriter writer = new PrintWriter(key);
        writer.print(value);
        writer.close();
    }

    /**
     * As a key can contain characters that cannot be accepted by file names, those
     * should be replaced with patterns
     * 
     * @param key
     * @return key with replaced patterns
     */
    private String transformKey(String key)
    {
        key = key.replace("/", "-slash-");
        key = key.replace("+", "-plus-");
        key = key.replace("=", "-equal-");
        key = key.replace("*", "-star-");
        return key;
    }

}
