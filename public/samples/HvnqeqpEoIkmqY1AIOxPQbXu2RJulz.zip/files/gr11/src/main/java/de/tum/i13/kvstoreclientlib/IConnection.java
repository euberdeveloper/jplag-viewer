package de.tum.i13.kvstoreclientlib;

import de.tum.i13.kvshared.KVRuntimeException;

/**
 * Low level connection handler. This is used by KVStoreClient for establishing
 * the actual connection.
 * 
 * @author Christoph Poeppelbaum
 *
 */
public interface IConnection
{
    /**
     * Initializes the connection for sending and receiving
     * 
     * @throws KVStoreClientRuntimeException If the connection could not be opened
     *                                       for any reason
     */
    void open() throws KVRuntimeException;

    /**
     * Tears down the connection
     * 
     * @throws KVStoreClientRuntimeException If the connection could not be closed
     *                                       for any reason
     */
    void close() throws KVRuntimeException;

    /**
     * Sends a message through the connection
     * 
     * @param message Byte representation to send
     * @throws KVStoreClientRuntimeException If the message was not send successful
     */
    void send(byte[] message) throws KVRuntimeException;

    /**
     * Receives a message from the connection
     * 
     * @return Byte representation of message received
     * @throws KVStoreClientRuntimeException If there was an error while receiving
     */
    byte[] receive() throws KVRuntimeException;
}
