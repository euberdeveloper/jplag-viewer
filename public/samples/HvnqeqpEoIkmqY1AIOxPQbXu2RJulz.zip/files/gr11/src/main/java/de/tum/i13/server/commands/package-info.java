/**
 * The Commands the server will recognize from input streams by any client
 * socket.
 */
package de.tum.i13.server.commands;