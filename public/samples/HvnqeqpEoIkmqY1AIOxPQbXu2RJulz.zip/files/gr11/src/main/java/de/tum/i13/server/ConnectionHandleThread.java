package de.tum.i13.server;

import de.tum.i13.commandprocessor.CPCommandNotFoundException;
import de.tum.i13.commandprocessor.CPExecutionRuntimeException;
import de.tum.i13.commandprocessor.CommandProcessor;
import de.tum.i13.server.commands.CommandWithCheckedArgsCount;

import java.util.logging.Logger;

/**
 * Class that implements the run method for incoming connections
 * 
 * @author Aaron Thoma
 *
 */
public class ConnectionHandleThread extends Thread
{
    private static final Logger _logger = Logger.getLogger(ConnectionHandleThread.class.getName());
    private CommandProcessor<CommandWithCheckedArgsCount> _commandFactory;
    private ConnectionManager _clientConnection;
    private boolean _requestStop;

    /**
     * Constructs a ConnectionHandleThread
     * 
     * @param commandFactory   CommandProcessor which is used to process the
     *                         incoming String
     * @param clientConnection ConnectionManager which is used to read and write
     */
    public ConnectionHandleThread(CommandProcessor<CommandWithCheckedArgsCount> commandFactory, ConnectionManager clientConnection)
    {
        this._commandFactory = commandFactory;
        this._clientConnection = clientConnection;
    }

    @Override
    public void run()
    {
        try
        {
            String firstLine;
            while (!_requestStop && (firstLine = _clientConnection.read()) != null)
            {
                try
                {
                    _commandFactory.process(firstLine);
                }
                catch (CPCommandNotFoundException ex) // no command with this name was found, so print help text
                {
                    _logger.severe(ex.getMessage());
                    _clientConnection.send("error - unknown request");
                }
                catch (IllegalArgumentException ex)
                {
                    _logger.warning(ex.getMessage());
                    _clientConnection.send(ex.getMessage());
                }
                catch (CPExecutionRuntimeException ex)
                {
                    _logger.warning(ex.getMessage());
                    _clientConnection.send(ex.getMessage());
                }
            }

            // shutting down
            _clientConnection.close();
        }
        catch (Exception ex)
        {
            ex.printStackTrace();
        }
    }

    /**
     * Sets _requestStop to true
     */
    public void requestStop()
    {
        _requestStop = true;
    }
}
