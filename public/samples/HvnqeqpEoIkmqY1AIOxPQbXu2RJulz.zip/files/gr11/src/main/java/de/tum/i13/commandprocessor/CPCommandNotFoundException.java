package de.tum.i13.commandprocessor;

/**
 * Represents the case that a given string could not be parsed to a String.
 * 
 * @author Christoph Poeppelbaum
 *
 */
public class CPCommandNotFoundException extends Exception
{
    /**
     * 
     */
    private static final long serialVersionUID = 1L;

    public CPCommandNotFoundException(String message)
    {
        super(message);
    }
}
