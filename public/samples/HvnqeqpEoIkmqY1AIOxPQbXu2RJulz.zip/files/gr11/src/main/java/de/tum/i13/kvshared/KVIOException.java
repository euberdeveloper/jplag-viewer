package de.tum.i13.kvshared;

/**
 * Error while communicating between kvclient and kvserver.
 * 
 * @author Aaron Thoma
 *
 */
public class KVIOException extends KVRuntimeException
{

    /**
     * 
     */
    private static final long serialVersionUID = 1L;

    public KVIOException()
    {

    }

}
