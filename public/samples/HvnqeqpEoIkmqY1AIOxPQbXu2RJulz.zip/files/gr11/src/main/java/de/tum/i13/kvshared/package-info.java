/**
 * Classes which kvstoreclientlib and server share
 */
package de.tum.i13.kvshared;