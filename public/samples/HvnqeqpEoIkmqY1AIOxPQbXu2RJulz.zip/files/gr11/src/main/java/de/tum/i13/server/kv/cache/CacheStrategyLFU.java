package de.tum.i13.server.kv.cache;

import java.util.Collection;
import java.util.Map;
import java.util.stream.Collectors;

/**
 * Least Frequently Used cache strategy.
 * 
 * @author Christoph Poeppelbaum
 *
 * @param <A> Key
 * @param <T> Item which has to implement ICacheItem
 */
public class CacheStrategyLFU<A, T extends ICacheItem> implements ICacheStrategy<A, T>
{

    @Override
    public Collection<A> getItemsToDisplace(Map<A, T> allCacheItems, int count)
    {
        return allCacheItems.entrySet().stream().sorted((e1, e2) -> Integer.compare(e1.getValue().getCountUsed(), e2.getValue().getCountUsed())).limit(count).map(e -> e.getKey())
                .collect(Collectors.toList());
    }

}