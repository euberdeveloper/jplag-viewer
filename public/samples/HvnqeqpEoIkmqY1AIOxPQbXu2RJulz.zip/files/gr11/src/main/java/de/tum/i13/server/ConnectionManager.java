package de.tum.i13.server;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.io.UnsupportedEncodingException;
import java.net.Socket;
import java.net.SocketAddress;
import java.util.logging.Logger;

import de.tum.i13.kvshared.KVRuntimeException;
import de.tum.i13.server.kv.KVMessage;
import de.tum.i13.server.kv.KVMessage.StatusType;
import de.tum.i13.shared.Constants;

/**
 * Class that handles the direct socket communication between the server and one
 * specified client
 * 
 * @author Aaron Thoma
 *
 */
public class ConnectionManager
{

    private static final Logger _logger = Logger.getLogger(ConnectionManager.class.getName());

    private Socket _clientSocket;
    private final String _welcomeMessage = "Connection to MSRG Echo server established: %s";
    private BufferedReader _in;
    private PrintWriter _out;

    /**
     * Constructs a ConnectionManager
     * 
     * @param clientSocket Socket of the client this instance handles
     */
    public ConnectionManager(Socket clientSocket)
    {
        _clientSocket = clientSocket;
    }

    /**
     * Sends acceptance message to client
     * 
     * @param address       InetSocketAddress of server
     * @param remoteAddress InetSocketAddress of client
     * 
     * @throws KVRuntimeException when I/O Error occurs or the character encoding is
     *                            not supported
     */
    public void open(SocketAddress address, SocketAddress remoteAddress) throws KVRuntimeException
    {
        try
        {
            _out = new PrintWriter(new OutputStreamWriter(_clientSocket.getOutputStream(), Constants.TELNET_ENCODING));
            _in = new BufferedReader(new InputStreamReader(_clientSocket.getInputStream(), Constants.TELNET_ENCODING));

            _logger.info(String.format("BufferedReader and Printwriter for '%s' has been created.", _clientSocket.getInetAddress().toString()));
        }
        catch (UnsupportedEncodingException ex)
        {
            throw new KVRuntimeException(ex.getMessage());
        }
        catch (IOException ex)
        {
            throw new KVRuntimeException(ex.getMessage());
        }

        send(String.format(_welcomeMessage, address, address.toString()));

        _logger.info("new connection: " + remoteAddress.toString());

    }

    /**
     * Closes the the Input-/ OutputStream
     * 
     * @throws KVRuntimeException when I/O Error occurs
     */
    public void close() throws KVRuntimeException
    {
        try
        {
            _in.close();
        }
        catch (IOException e)
        {
            throw new KVRuntimeException(e.getMessage());
        }
        _out.close();

        _logger.info("connection closed: " + _clientSocket.getInetAddress().toString());
    }

    /**
     * Reads the a line of text from the InputStream
     * 
     * @return String that was read
     * @throws KVRuntimeException when I/O Error occurs
     */
    public String read() throws KVRuntimeException
    {
        try
        {
            return _in.readLine();
        }
        catch (IOException ex)
        {
            throw new KVRuntimeException(ex.getMessage());
        }
    }

    /**
     * Method that sends answer from server to client via OutputStream
     * 
     * @param message String that contains a message from server to client
     * 
     */
    public void send(String message)
    {

        String sendable = message + "\r\n";

        _out.write(sendable);
        _out.flush();

        _logger.info(String.format("Answer: '%s' was send to '%s'.", sendable, _clientSocket.getInetAddress().toString()));
    }

    /**
     * Converts a KVMessage to a String before sending
     * 
     * @param message Answer from server in the KVMessage format
     * 
     */
    public void sendKVMessage(KVMessage message)
    {
        String messageString = convertKVMessage(message);

        send(messageString);
    }

    /**
     * Converts a KVMessage to a String
     * 
     * @param message KVMessage that will be converted
     * @return Message of the type String
     */
    private String convertKVMessage(KVMessage message)
    {
        String key = message.getKey();
        String value = message.getValue();
        Enum<StatusType> statusEnum = message.getStatus();

        String status = statusEnum.toString().toLowerCase();

        String msg = status + " " + key;

        if (value != null)
        {
            msg = msg + " " + value;
        }

        return msg;
    }

}