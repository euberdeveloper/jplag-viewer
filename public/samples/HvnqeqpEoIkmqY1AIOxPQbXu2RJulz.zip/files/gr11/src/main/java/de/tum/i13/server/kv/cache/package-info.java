/**
 * Additional helper classes for the caching mechanism.
 */
package de.tum.i13.server.kv.cache;