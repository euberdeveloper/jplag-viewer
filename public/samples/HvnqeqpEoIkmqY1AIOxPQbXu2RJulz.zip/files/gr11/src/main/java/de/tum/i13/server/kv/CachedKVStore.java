package de.tum.i13.server.kv;

import java.util.Collection;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentMap;
import java.util.logging.Logger;
import java.util.stream.Collectors;

import de.tum.i13.kvshared.KVRuntimeException;
import de.tum.i13.server.kv.KVMessage.StatusType;
import de.tum.i13.server.kv.cache.CacheItem;
import de.tum.i13.server.kv.cache.CacheStrategyFIFO;
import de.tum.i13.server.kv.cache.CacheStrategyLFU;
import de.tum.i13.server.kv.cache.CacheStrategyLRU;
import de.tum.i13.server.kv.cache.ICacheStrategy;
import de.tum.i13.shared.Config;

/**
 * A wrapper which takes an IKVStore and enriches it with a synchronized
 * memoizer / caching mechanism.
 * 
 * @author Christoph Poeppelbaum
 *
 */
public class CachedKVStore implements IKVStore
{
    private static final Logger _logger = Logger.getLogger(CachedKVStore.class.getName());

    private final IKVStore _kvStore;
    private final ConcurrentMap<String, CacheItem<String>> _cachedItems = new ConcurrentHashMap<String, CacheItem<String>>();
    private final ICacheStrategy<String, CacheItem<String>> _displacementStrategy;
    private final int _maxCacheSize;

    private class PutResultWrapper
    {
        KVMessage _result;

        public KVMessage get()
        {
            return _result;
        }

        public void set(KVMessage value)
        {
            _result = value;
        }
    }

    /**
     * Constructs a CachedKVStore.
     * 
     * @param kvStore  The kvStore which is to be cached.
     * @param strategy The strategy which is to be used when displacing cache items.
     * @param maxSize  Max size of cache before items are getting displaced.
     */
    public CachedKVStore(IKVStore kvStore, Config.CacheDisplacementStrategies strategy, int maxSize)
    {
        switch (strategy)
        {
            case FIFO:
                _displacementStrategy = new CacheStrategyFIFO<>();
                break;
            case LFU:
                _displacementStrategy = new CacheStrategyLFU<>();
                break;
            case LRU:
                _displacementStrategy = new CacheStrategyLRU<>();
                break;
            default:
                throw new IllegalArgumentException("DisplacementStrategy unknown");

        }
        if (kvStore == null)
        {
            throw new IllegalArgumentException("kvStore may not be null");
        }

        _logger.info("Cache strategy set: " + _displacementStrategy.getClass().getName());

        _kvStore = kvStore;
        _maxCacheSize = maxSize;
    }

    @Override
    public KVMessage get(String key) throws KVRuntimeException
    {
        try
        {
            /*
             * Here, we let the hash value be calculated (meaning read from disk), but if
             * multiple threads come here while reading has not finished, all these threads
             * would trigger reading from disk. This is a potential performance hit on edge
             * cases.
             *
             * The book "Java Concurrency in Practice by Brian Goetz and Tim Peierls"
             * suggests a solution for this with the "Final implementation of Memoizer". We
             * did implement it out of curiosity. You may have a look in the branch
             * IOQueueCaching were we have several implementations. However we feel this is
             * beyond the scope of this exercise and bloats the code unnecessarily.
             * 
             */
            CacheItem<String> cachedItem = _cachedItems.computeIfAbsent(key, k -> {
                String itemToCache = null;
                synchronized (_kvStore)
                {
                    try
                    {
                        itemToCache = _kvStore.get(k).getValue();
                    }
                    catch (KVRuntimeException e)
                    {
                        return null;
                    }
                }
                if (itemToCache != null)
                {
                    _logger.fine("Adding item to cache by get: " + key);
                    shrinkCacheIfNeeded();
                    return new CacheItem<String>(itemToCache);
                }
                else
                {
                    return null; // will throw NullPointerException because HashMap does not support null values.
                }
            });
            cachedItem.markAsUsed();
            return new KVMessage(key, cachedItem.getContent(), StatusType.GET_SUCCESS);
        }
        catch (NullPointerException e)
        {
            return new KVMessage(key, StatusType.GET_ERROR); // so catch NullPointerException. This happens if there was no hit in cache and
                                                             // not in kvstore as well.
        }
    }

    @Override
    public KVMessage delete(String key) throws KVRuntimeException
    {
        _cachedItems.remove(key);
        _logger.fine("Removed item from cache by delete: " + key);

        synchronized (_kvStore)
        {
            return _kvStore.delete(key);
        }
    }

    @Override
    public KVMessage put(String key, String value) throws KVRuntimeException
    {
        final PutResultWrapper putResult = new PutResultWrapper();

        // keep cache up to date. But make this update and writing to disk atomic.
        _cachedItems.compute(key, (k, v) -> {
            shrinkCacheIfNeeded();

            synchronized (_kvStore)
            {
                KVMessage item;
                try
                {
                    item = _kvStore.put(key, value);
                    putResult.set(item);
                    return new CacheItem<String>(value);
                }
                catch (KVRuntimeException e)
                {
                    return null;
                }
            }
        });

        _logger.fine("Added item to cache by put: " + key);

        return putResult.get();
    }

    private void shrinkCacheIfNeeded()
    {
        int countToDelete = _cachedItems.size() - _maxCacheSize + 1;
        if (countToDelete > 0)
        {
            Collection<String> itemsToDelete = _displacementStrategy.getItemsToDisplace(_cachedItems, countToDelete);
            itemsToDelete.forEach(i -> _cachedItems.remove(i));

            _logger.fine("Displacing triggered. Removed items from cache: " + itemsToDelete.stream().map(i -> i.toString()).collect(Collectors.joining(", ")));
        }
    }

    /**
     * Returns count of items in cache.
     * 
     * @return Count of items in cache
     */
    public int size()
    {
        return _cachedItems.size();
    }
}
