/**
 * Independent class which processes strings and creates executable commands.
 */
package de.tum.i13.commandprocessor;