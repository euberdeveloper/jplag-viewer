package de.tum.i13.client.commands;

import java.util.Map;

import de.tum.i13.client.ShellInterpreter;
import de.tum.i13.commandprocessor.CPExecutionRuntimeException;

/**
 * Command to print the help text
 * 
 * @author Christoph Poeppelbaum
 *
 */
public class HelpCommand extends CommandWithCheckedArgsCountAndHelp
{
    private ShellInterpreter _shellInterpreter;

    public HelpCommand(ShellInterpreter shellInterpreter)
    {
        _shellInterpreter = shellInterpreter;
    }

    @Override
    public String getDescription()
    {
        return "Shows this text";
    }

    @Override
    public Map<String, String> getArguments()
    {
        return null; // no arguments needed
    }

    @Override
    public String getCommandName()
    {
        return "help";
    }

    @Override
    protected void executeWithCheckedCountOfArgs(String[] args) throws CPExecutionRuntimeException
    {
        _shellInterpreter.help();
    }

}
