package de.tum.i13;

import de.tum.i13.KVserver.nio.StartSimpleNioServer;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.InetSocketAddress;
import java.net.Socket;

import static org.hamcrest.CoreMatchers.equalTo;
import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.MatcherAssert.assertThat;

/**
 * The focus of this test class is to test the effects of concurrent commands from 2 clients on the database.
 */
public class ConcurrencyTest {

    public static Integer port = 5152;

    @BeforeAll
    public static void serverSetup() throws InterruptedException {
        Thread th = new Thread(() -> {
            try {
                StartSimpleNioServer.main(new String[]{"-p", port.toString()});
            } catch (IOException e) {
                e.printStackTrace();
            }
        });
        th.start(); // started the KVserver
        Thread.sleep(2000);
    }

    public String doRequest(Socket s, String req) throws IOException {
        PrintWriter output = new PrintWriter(s.getOutputStream());
        BufferedReader input = new BufferedReader(new InputStreamReader(s.getInputStream()));

        output.write(req + "\r\n");
        output.flush();

        return input.readLine();
    }

    /**
     * The test connects 2 clients to our server. The first client inserts the key-value pair. The second client updates
     * the key inserted by the first client with the value eulav. The first client gets his original key and he must
     * receive the new value inserted by the second client, which he does.
     *
     * @throws IOException
     */
    @Test
    public void concurrentInsertionTest1() throws IOException {
        Socket client1 = new Socket();
        client1.connect(new InetSocketAddress("127.0.0.1", port));
        doRequest(client1, "");

        Socket client2 = new Socket();
        client2.connect(new InetSocketAddress("127.0.0.1", port));
        doRequest(client2, "");

        assertThat(doRequest(client1, "put key value"), is(equalTo("put_success key")));
        assertThat(doRequest(client2, "put key eulav"), is(equalTo("put_update key")));
        assertThat(doRequest(client1, "get key"), is(equalTo("get_success key eulav")));
        assertThat(doRequest(client1, "delete key"), is(equalTo("delete_success key")));
    }

    /**
     * The test connects 2 clients to our server. The first client tries to get a nonexistent key from the database, and
     * he receives an error as the key is not in the database yet. The second client inserts the key-value pair in the
     * database. The first client tries again to get his original key. This time he receives a success, as the second
     * client inserted the key at a prior time.
     *
     * @throws IOException
     */
    @Test
    public void concurrentInsertionTest2() throws IOException {
        Socket client1 = new Socket();
        client1.connect(new InetSocketAddress("127.0.0.1", port));
        doRequest(client1, "");

        Socket client2 = new Socket();
        client2.connect(new InetSocketAddress("127.0.0.1", port));
        doRequest(client2, "");

        assertThat(doRequest(client1, "get key"), is(equalTo("get_error key")));
        assertThat(doRequest(client2, "put key value"), is(equalTo("put_success key")));
        assertThat(doRequest(client1, "get key"), is(equalTo("get_success key value")));
        assertThat(doRequest(client1, "delete key"), is(equalTo("delete_success key")));
    }

    /**
     * The test connects 2 clients to our server. The first client inserts the key-value pair. The second client deletes
     * the key and value inserted by the first client. The first client tries to get his inserted pair, but he receives
     * an error, as the second client deleted his entry.
     *
     * @throws IOException
     */
    @Test
    public void concurrentDeletionTest1() throws IOException {
        Socket client1 = new Socket();
        client1.connect(new InetSocketAddress("127.0.0.1", port));
        doRequest(client1, "");

        Socket client2 = new Socket();
        client2.connect(new InetSocketAddress("127.0.0.1", port));
        doRequest(client2, "");

        assertThat(doRequest(client1, "put key value"), is(equalTo("put_success key")));
        assertThat(doRequest(client2, "delete key"), is(equalTo("delete_success key")));
        assertThat(doRequest(client1, "get key"), is(equalTo("get_error key")));
    }


    /**
     * The test connects 2 clients to our server. The first client inserts the key-value pair. The second client deletes
     * he key and value inserted by the first client. The first client tries to delete his inserted pair, but he receives
     * an error, as the second client already deleted his entry.
     *
     * @throws IOException
     */
    @Test
    public void concurrentDeletionTest2() throws IOException {
        Socket client1 = new Socket();
        client1.connect(new InetSocketAddress("127.0.0.1", port));
        doRequest(client1, "");

        Socket client2 = new Socket();
        client2.connect(new InetSocketAddress("127.0.0.1", port));
        doRequest(client2, "");

        assertThat(doRequest(client1, "put key value"), is(equalTo("put_success key")));
        assertThat(doRequest(client2, "delete key"), is(equalTo("delete_success key")));
        assertThat(doRequest(client1, "delete key"), is(equalTo("delete_error key")));
    }
}
