package de.tum.i13;

import de.tum.i13.KVserver.kv.persistence.PersistenceHandler;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;

public class PersistenceTest {

    public static PersistenceHandler handler;

    @BeforeAll
    static void createNewDatabase() {
        handler = new PersistenceHandler("testDB/databasePersistenceTest.txt");
    }

    @Test
    public void putPersistenceTest() throws IOException {
        handler.insertInDB("foo", "bar");
        List<String> dbContent = Files.readAllLines(Paths.get("testDB/databasePersistenceTest.txt"));
        for (String pair : dbContent) {
            assertEquals("foo: bar", pair);
        }
    }

    @Test
    public void getPersistenceTest() throws IOException {
        FileWriter writer = new FileWriter(new File("testDB/databasePersistenceTest.txt"));
        writer.write("foo: bar");
        writer.flush();
        assertEquals("foo: bar", "foo: " + handler.getFromDB("foo"));
    }

    @Test
    public void updatePersistenceTest() throws IOException {
        FileWriter writer = new FileWriter(new File("testDB/databasePersistenceTest.txt"));
        writer.write("foo: bar");
        writer.flush();
        handler.updateInDB("foo", "barbar");
        List<String> dbContent = Files.readAllLines(Paths.get("testDB/databasePersistenceTest.txt"));
        for (String pair : dbContent) {
            assertEquals("foo: barbar", pair);
        }
    }

    @Test
    public void deletePersistenceTest() throws IOException {
        FileWriter writer = new FileWriter(new File("testDB/databasePersistenceTest.txt"));
        writer.write("foo: bar");
        writer.flush();
        handler.deleteFromDB("foo");
        List<String> dbContent = Files.readAllLines(Paths.get("testDB/databasePersistenceTest.txt"));
        for (String pair : dbContent) {
            assertEquals("", pair);
        }
    }

    @AfterEach
    public void testDatabaseBreakdown() throws IOException {
        FileWriter writer = new FileWriter(new File("testDB/databasePersistenceTest.txt"));
        writer.write("");
        writer.flush();
    }
}
