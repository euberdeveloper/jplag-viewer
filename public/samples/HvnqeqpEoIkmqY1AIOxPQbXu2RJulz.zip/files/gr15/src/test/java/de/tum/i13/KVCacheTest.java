package de.tum.i13;

import de.tum.i13.KVserver.kv.KVCommandProcessor;
import de.tum.i13.KVserver.kv.KVManagerFIFO;
import de.tum.i13.KVserver.kv.KVManagerLFU;
import de.tum.i13.KVserver.kv.KVManagerLRU;
import de.tum.i13.KVserver.kv.persistence.PersistenceHandler;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

public class KVCacheTest {

    @Test
    public void testFIFO() {
        KVManagerFIFO testStore = new KVManagerFIFO(5);
        KVCommandProcessor kvcp = new KVCommandProcessor(testStore);
        testStore.setPersistenceHandler(new PersistenceHandler("testDB/database.txt"));

        kvcp.process("put matt damon");
        kvcp.process("put george clooney");
        kvcp.process("put johnny depp");
        kvcp.process("put ben affleck");
        kvcp.process("put clint eastwood");
        kvcp.process("put kevin spacey");
        Assertions.assertEquals("george", testStore.queue.remove());
    }

    @Test
    public void testFIFOLoadInCache() {
        KVManagerFIFO testStore = new KVManagerFIFO(5);
        KVCommandProcessor kvcp = new KVCommandProcessor(testStore);
        testStore.setPersistenceHandler(new PersistenceHandler("testDB/database.txt"));

        kvcp.process("put matt damon");
        kvcp.process("put george clooney");
        kvcp.process("put johnny depp");
        kvcp.process("put ben affleck");
        kvcp.process("put clint eastwood");
        kvcp.process("put kevin spacey");
        // Cache should now be full, matt should only be in the persistent db due to displacement
        Assertions.assertFalse(testStore.cache.containsKey("matt"));
        kvcp.process("get matt");
        Assertions.assertTrue(testStore.cache.containsKey("matt"));
    }

    @Test
    public void testLRU() {
        KVManagerLRU testStore = new KVManagerLRU(5);
        testStore.setPersistenceHandler(new PersistenceHandler("testDB/database.txt"));

        KVCommandProcessor kvcp = new KVCommandProcessor(testStore);
        kvcp.process("put matt damon");
        kvcp.process("put george clooney");
        kvcp.process("put johnny depp");
        kvcp.process("put ben affleck");
        kvcp.process("get matt"); // getting matt should put him in front of the queue again
        kvcp.process("put clint eastwood");
        kvcp.process("get johnny");
        System.out.println(testStore.queue.toString());
        Assertions.assertEquals("george", testStore.queue.remove());
        Assertions.assertEquals("ben", testStore.queue.remove());
        Assertions.assertEquals("matt", testStore.queue.remove());
        Assertions.assertEquals("clint", testStore.queue.remove());
        Assertions.assertEquals("johnny", testStore.queue.remove());
    }

    @Test
    public void testLFU() {
        KVManagerLFU testStore = new KVManagerLFU(5);
        testStore.setPersistenceHandler(new PersistenceHandler("testDB/database.txt"));
        KVCommandProcessor kvcp = new KVCommandProcessor(testStore);

        kvcp.process("put matt damon");
        kvcp.process("get matt"); // getting matt should put him in front of the queue again
        kvcp.process("put johnny depp");
        kvcp.process("get johnny");
        kvcp.process("get johnny");
        kvcp.process("put george clooney");
        kvcp.process("get george");
        kvcp.process("get george");
        kvcp.process("get george");
        kvcp.process("put ben affleck");
        kvcp.process("get ben");
        kvcp.process("get ben");
        kvcp.process("get ben");
        kvcp.process("get ben");
        kvcp.process("put clint eastwood");

        Assertions.assertEquals(1, testStore.frequecyMap.get("clint"));
        Assertions.assertEquals(2, testStore.frequecyMap.get("matt"));
        Assertions.assertEquals(3, testStore.frequecyMap.get("johnny"));
        Assertions.assertEquals(4, testStore.frequecyMap.get("george"));
        Assertions.assertEquals(5, testStore.frequecyMap.get("ben"));

        kvcp.process("put kevin spacey");
        Assertions.assertFalse(testStore.cache.containsKey("clint")); // clint should have been removed because he has the lowest frequency
    }


    @AfterEach
    public void teardown() {
        KVManagerFIFO testStore = new KVManagerFIFO(5);
        KVCommandProcessor kvcp = new KVCommandProcessor(testStore);
        testStore.setPersistenceHandler(new PersistenceHandler("testDB/database.txt"));

        kvcp.process("delete matt");
        kvcp.process("delete george");
        kvcp.process("delete johnny");
        kvcp.process("delete ben");
        kvcp.process("delete kevin");
        kvcp.process("delete clint");
    }
}
