package de.tum.i13;

import de.tum.i13.KVserver.kv.KVCommandProcessor;
import de.tum.i13.KVserver.kv.KVManager;
import de.tum.i13.shared.KVMessage;
import org.junit.jupiter.api.Test;

import static org.mockito.Mockito.*;

public class KVCommandProcessorTest {

    @Test
    public void correctParsingOfPut() throws Exception {
        KVManager kv = mock(KVManager.class);
        KVCommandProcessor kvcp = new KVCommandProcessor(kv);
        KVMessage response = new KVMessage("key", "hello", KVMessage.StatusType.PUT_SUCCESS);
        when(kv.put("key", "hello")).thenReturn(response);
        kvcp.process("put key hello");
        verify(kv).put("key", "hello");
    }

    @Test
    public void correctParsingOfGet() throws Exception {
        KVManager kv = mock(KVManager.class);
        KVCommandProcessor kvcp = new KVCommandProcessor(kv);
        KVMessage response = new KVMessage("key", "hello", KVMessage.StatusType.GET_SUCCESS);
        when(kv.get("key")).thenReturn(response);
        kvcp.process("get key");
        verify(kv).get("key");
    }

    @Test
    public void correctParsingOfDelete() throws Exception {
        KVManager kv = mock(KVManager.class);
        KVCommandProcessor kvcp = new KVCommandProcessor(kv);
        KVMessage response = new KVMessage("key", KVMessage.StatusType.DELETE_SUCCESS);
        when(kv.delete("key")).thenReturn(response);
        kvcp.process("delete key");
        verify(kv).delete("key");
    }
}
