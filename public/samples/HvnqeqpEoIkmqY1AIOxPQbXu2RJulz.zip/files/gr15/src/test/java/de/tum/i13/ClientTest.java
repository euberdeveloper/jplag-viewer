package de.tum.i13;

import de.tum.i13.KVserver.nio.StartSimpleNioServer;
import de.tum.i13.client.Milestone1Main;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;

import java.io.*;
import java.net.ServerSocket;
import java.net.Socket;


public class ClientTest {
    public static Integer port = 5153;

    @BeforeAll
    public static void serverSetup() throws InterruptedException {
        Thread th = new Thread(() -> {
            try {
                StartSimpleNioServer.main(new String[]{"-p", port.toString()});
            } catch (IOException e) {
                e.printStackTrace();
            }
        });
        th.start(); // started the KVserver
        Thread.sleep(2000);
    }

    @Test
    public void testClientPut() throws IOException {
        Thread serverThread = new Thread(() -> {
            try {
                ServerSocket serverSocket = new ServerSocket(port);
                Socket client = serverSocket.accept();
                System.out.println("Connection accepted");
                BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(client.getInputStream()));
                Assertions.assertEquals(bufferedReader.readLine(), "put key hello");
            } catch (IOException e) {
            }
        });
        serverThread.start();

        String input = "connect 127.0.0.1 " + port + "\n" +
                "put key hello\nquit\n";
        InputStream in = new ByteArrayInputStream(input.getBytes());
        System.setIn(in);
        Milestone1Main.main(null);
    }

    @Test
    public void testClientGet() throws IOException {
        Thread serverThread = new Thread(() -> {
            try {
                ServerSocket serverSocket = new ServerSocket(port);
                Socket client = serverSocket.accept();
                System.out.println("Connection accepted");
                BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(client.getInputStream()));
                Assertions.assertEquals(bufferedReader.readLine(), "get key");
            } catch (IOException e) {
            }
        });
        serverThread.start();

        String input = "connect 127.0.0.1 " + port + "\n" +
                "get key\nquit\n";
        InputStream in = new ByteArrayInputStream(input.getBytes());
        System.setIn(in);
        Milestone1Main.main(null);
    }

    @Test
    public void testClientDelete() throws IOException {
        Thread serverThread = new Thread(() -> {
            try {
                ServerSocket serverSocket = new ServerSocket(port);
                Socket client = serverSocket.accept();
                System.out.println("Connection accepted");
                BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(client.getInputStream()));
                Assertions.assertEquals(bufferedReader.readLine(), "delete key");
            } catch (IOException e) {
            }
        });
        serverThread.start();

        String input = "connect 127.0.0.1 " + port + "\n" +
                "delete key\nquit\n";
        InputStream in = new ByteArrayInputStream(input.getBytes());
        System.setIn(in);
        Milestone1Main.main(null);
    }

    @Test
    public void testClientConnect() throws IOException {
        Thread serverThread = new Thread(() -> {
            try {
                ServerSocket serverSocket = new ServerSocket(port);
                Socket client = serverSocket.accept();
                System.out.println("Connection accepted");
                Assertions.assertNotNull(client); //eig überflüssig
            } catch (IOException e) {
            }
        });
        serverThread.start();

        String input = "connect 127.0.0.1 " + port + "\nquit\n";
        InputStream in = new ByteArrayInputStream(input.getBytes());
        System.setIn(in);
        Milestone1Main.main(null);
    }

}


