package de.tum.i13;

import de.tum.i13.KVserver.nio.StartSimpleNioServer;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;

import java.io.*;
import java.net.InetSocketAddress;
import java.net.Socket;
import java.nio.charset.StandardCharsets;

import static org.hamcrest.CoreMatchers.equalTo;
import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.MatcherAssert.assertThat;

public class KVIntegrationTest {

    public static Integer port = 5151;

    @BeforeAll
    public static void serverSetup() throws InterruptedException {
        Thread th = new Thread(() -> {
            try {
                StartSimpleNioServer.main(new String[]{"-p", port.toString()});
            } catch (IOException e) {
                e.printStackTrace();
            }
        });
        th.start(); // started the KVserver
        Thread.sleep(2000);
    }

    public String doRequest(Socket s, String req) throws IOException {
        PrintWriter output = new PrintWriter(new OutputStreamWriter(
                s.getOutputStream(), StandardCharsets.UTF_8), true);
        BufferedReader input = new BufferedReader(new InputStreamReader(
                s.getInputStream(), StandardCharsets.UTF_8));

        output.write(req + "\r\n");
        output.flush();

        return input.readLine();
    }

    public String doRequest(String req) throws IOException {
        Socket s = new Socket();
        s.connect(new InetSocketAddress("127.0.0.1", port));
        String res = doRequest(s, req);
        s.close();

        return res;
    }

    @Test
    public void testWelcomeMessage() throws IOException {
        assertThat(doRequest(""), is(equalTo("Connection to T15 Storage KVserver established: /127.0.0.1:" + port)));
    }

    @Test
    public void testPutKeyLength() throws IOException {
        Socket s = new Socket();
        s.connect(new InetSocketAddress("127.0.0.1", port));
        doRequest(s, "");
        assertThat(doRequest(s, "put 12345678901234567890 value"), is(equalTo("put_success 12345678901234567890")));
        assertThat(doRequest(s, "delete 12345678901234567890"), is(equalTo("delete_success 12345678901234567890")));
        assertThat(doRequest(s, "put 123456789012345678901 value"), is(equalTo("put_error 123456789012345678901")));
        s.close();
    }

    @Test
    public void testPutArbitraryKey() throws IOException {
        Socket s = new Socket();
        s.connect(new InetSocketAddress("127.0.0.1", port));
        doRequest(s, "");
        assertThat(doRequest(s, "put £™¡®´∑ƒ© value"), is(equalTo("put_success £™¡®´∑ƒ©")));
        assertThat(doRequest(s, "get £™¡®´∑ƒ©"), is(equalTo("get_success £™¡®´∑ƒ© value")));
        assertThat(doRequest(s, "delete £™¡®´∑ƒ©"), is(equalTo("delete_success £™¡®´∑ƒ©")));
        assertThat(doRequest(s, "get £™¡®´∑ƒ©"), is(equalTo("get_error £™¡®´∑ƒ©")));
        s.close();
    }

    @Test
    public void testPutArbitraryValue() throws IOException {
        Socket s = new Socket();
        s.connect(new InetSocketAddress("127.0.0.1", port));
        doRequest(s, "");
        assertThat(doRequest(s, "put key £ ™¡® ´∑ƒ  ©"), is(equalTo("put_success key")));
        assertThat(doRequest(s, "get key"), is(equalTo("get_success key £ ™¡® ´∑ƒ  ©")));
        assertThat(doRequest(s, "delete key"), is(equalTo("delete_success key")));
        assertThat(doRequest(s, "get key"), is(equalTo("get_error key")));
        s.close();
    }

    @Test
    public void testInvalidCommand() throws IOException {
        Socket s = new Socket();
        s.connect(new InetSocketAddress("127.0.0.1", port));
        doRequest(s, "");
        assertThat(doRequest(s, "püt key £ ™¡® ´∑ƒ  ©"), is(equalTo("error Unknown Command")));
        assertThat(doRequest(s, "keyyyyyyyyyy geeeeeeet"), is(equalTo("error Unknown Command")));
        s.close();
    }

    @Test
    public void testDeleteNonExistent() throws IOException {
        Socket s = new Socket();
        s.connect(new InetSocketAddress("127.0.0.1", port));
        doRequest(s, "");
        assertThat(doRequest(s, "put ooga booga"), is(equalTo("put_success ooga")));
        assertThat(doRequest(s, "delete ooga"), is(equalTo("delete_success ooga")));
        assertThat(doRequest(s, "delete ooga"), is(equalTo("delete_error ooga")));
    }

    @Test
    public void testGetNonExistent() throws IOException {
        Socket s = new Socket();
        s.connect(new InetSocketAddress("127.0.0.1", port));
        doRequest(s, "");
        assertThat(doRequest(s, "get ooga booga"), is(equalTo("get_error ooga")));

    }

    @Test
    public void testUpdate() throws IOException {
        Socket s = new Socket();
        s.connect(new InetSocketAddress("127.0.0.1", port));
        doRequest(s, "");
        assertThat(doRequest(s, "put key booga"), is(equalTo("put_success key")));
        assertThat(doRequest(s, "put key looga"), is(equalTo("put_update key")));
        assertThat(doRequest(s, "delete key"), is(equalTo("delete_success key")));
    }
}
