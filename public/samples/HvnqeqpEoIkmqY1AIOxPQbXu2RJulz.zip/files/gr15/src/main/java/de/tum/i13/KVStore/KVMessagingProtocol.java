package de.tum.i13.KVStore;

import de.tum.i13.shared.KVMessage;

import java.io.IOException;

public class KVMessagingProtocol implements KVStore {
    private ActiveConnection clientSocket;

    public KVMessagingProtocol(ActiveConnection clientSocket) {
        this.clientSocket = clientSocket;
    }

    private static void printShellLine(String msg) {
        System.out.println("T15Client> " + msg);
    }

    public ActiveConnection getClientSocket() {
        return clientSocket;
    }

    @Override
    public KVMessage put(String key, String value) {
        return null;
    }

    @Override
    public KVMessage get(String key) {
        return null;
    }

    @Override
    public KVMessage delete(String key) {
        return null;
    }

    /**
     * The method tries to build a connection with the KVServer. If the passed parameters are correct, the client is
     * connected to the server, and we can start the interaction. If the passed parameters are wrong, there is no
     * connection established.
     *
     * @param command contains the host and port parameters passed by the client in the CLI
     * @return clientSocket the client socket if the connection was successful or null if it wasn't
     */
    public ActiveConnection buildConnection(String[] command) {
        if (command.length == 3) {
            try {
                KVServerConnectionBuilder kvcb = new KVServerConnectionBuilder(command[1], Integer.parseInt(command[2]));
                clientSocket = kvcb.connect();
                String confirmation = clientSocket.readline();
                printShellLine(confirmation);
                return clientSocket;
            } catch (Exception e) {
                printShellLine("Could not connect to KVserver");
            }
        }
        return null;
    }

    /**
     * The method tries to disconnect from the KVServer.
     *
     * @param activeConnection the connection we want to close.
     */
    public void closeConnection(ActiveConnection activeConnection) {
        if (activeConnection != null) {
            try {
                activeConnection.close();
            } catch (Exception e) {
                activeConnection = null;
            }
        }
    }

    /**
     * The method gives further to the server the command given by the client. In case there is no connection established,
     * we let the client know. If the message from the client is empty, we also let him know, and we do not pass this
     * message to the server. Finally, if the message is complete, we pass it to the server. We then try to read and
     * print the answer of the server.
     *
     * @param command tells the server what it is supposed to do
     * @param data    the data the server must handle in relation to the passed command.
     */
    public void sendMessage(KVMessage.StatusType command, String data) {
        if (clientSocket == null) {
            printShellLine("Error! Not connected!");
            return;
        }

        String line = command.toString().toLowerCase() + " " + data;
        int firstSpace = line.indexOf(" ");
        if (firstSpace == -1 || firstSpace + 1 >= line.length()) {
            printShellLine("Error! Nothing to send!");
            return;
        }

        clientSocket.write(line);

        try {
            printShellLine(clientSocket.readline());
        } catch (IOException e) {
            printShellLine("Error! Not connected!");
        }
    }
}
