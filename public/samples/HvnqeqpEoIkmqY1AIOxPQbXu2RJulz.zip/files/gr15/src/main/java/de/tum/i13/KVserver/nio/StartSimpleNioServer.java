package de.tum.i13.KVserver.nio;

import de.tum.i13.KVserver.kv.KVCommandProcessor;
import de.tum.i13.KVserver.kv.KVManager;
import de.tum.i13.KVserver.kv.persistence.PersistenceHandler;
import de.tum.i13.shared.CommandProcessor;
import de.tum.i13.shared.Config;

import java.io.IOException;
import java.util.logging.Logger;

import static de.tum.i13.shared.Config.parseCommandlineArgs;
import static de.tum.i13.shared.LogSetup.setupLogging;

public class StartSimpleNioServer {

    public static Logger logger = Logger.getLogger(StartSimpleNioServer.class.getName());

    public static void main(String[] args) throws IOException {
        Config cfg = parseCommandlineArgs(args);  //Do not change this
        setupLogging(cfg.logfile);
        logger.info("Config: " + cfg.toString());
        logger.info("starting KVserver");

        PersistenceHandler persistenceHandler = new PersistenceHandler(cfg.dataDir + "/database.txt");

        KVManager kvManager = cfg.cacheStrategy; // getFromDB strategy read from CL
        kvManager.setPersistenceHandler(persistenceHandler);
        kvManager.setMaxSize(cfg.cacheSize); // set size to value read from CLA
        CommandProcessor kvProcessor = new KVCommandProcessor(kvManager);

        Runtime.getRuntime().addShutdownHook(new Thread(() -> {
            try {
                kvManager.flushCacheToDisk(); // Shutdown hook starts a thread that becomes active when a SIGINT or SIGINT
            } catch (IOException e) {
                logger.severe("Could not save to disk after shutdown");
            }
        }));

        SimpleNioServer sn = new SimpleNioServer(kvProcessor);
        sn.bindSockets(cfg.listenaddr, cfg.port);
        try {
            sn.start();
        } catch (IOException e) { // If an exception occurs, the cache will be flushed to disk
            kvManager.flushCacheToDisk();
        }
    }
}
