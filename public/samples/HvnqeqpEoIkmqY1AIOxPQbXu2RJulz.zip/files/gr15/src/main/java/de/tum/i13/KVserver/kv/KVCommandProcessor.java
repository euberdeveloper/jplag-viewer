package de.tum.i13.KVserver.kv;

import de.tum.i13.KVserver.nio.StartSimpleNioServer;
import de.tum.i13.client.Milestone1Main;
import de.tum.i13.shared.CommandProcessor;
import de.tum.i13.shared.KVMessage;

import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.util.logging.Logger;

/**
 * This class is responsible for handling client messages. Valid commands are:
 * put <key> <value>
 * get <key>
 * delete <key>
 * Failed operations return an ERROR message, else SUCCESS message is returned.
 * Other unknown commands return an Error message.
 */
public class KVCommandProcessor implements CommandProcessor {
    public static Logger logger = Logger.getLogger(KVCommandProcessor.class.getName());
    /**
     * The KVManager is responsible for handling cache and accessing the Database
     */
    private final KVManager kvManager;

    public KVCommandProcessor(KVManager kvManager) {
        this.kvManager = kvManager;
    }


    /**
     * This method will parse the client message for a put, get, delete message.
     * The proper storage handling is passed on to the KVManager.
     * If the command is unknown, an ERROR message is returned
     *
     * @param command String that contains the entire message from the client
     * @return storeAnswer is a KVmessage.toString(). Can be a SUCCESS or ERROR message
     */
    @Override
    public String process(String command) {
        command = command.replace("\r\n", "");
        String[] commandArgs = command.split("\\s");
        KVMessage storeAnswer;
        String key, value;
        switch (commandArgs[0]) {
            case "put":
                String[] valueArr = new String[commandArgs.length - 2];
                System.arraycopy(commandArgs, 2, valueArr, 0, valueArr.length);
                key = commandArgs[1];
                value = Milestone1Main.convertStrArrayToStr(valueArr, " ");
                try {
                    StartSimpleNioServer.logger.info("The client tries to insert the pair " + key + ": " + value + " in the database.");
                    storeAnswer = kvManager.put(key, value);
                } catch (Exception e) {
                    storeAnswer = new KVMessage(commandArgs[1], commandArgs[2], KVMessage.StatusType.PUT_ERROR);
                    StartSimpleNioServer.logger.severe("There has been an error while trying to insert the pair " + key + ": " + value + " in the database.");
                }
                break;
            case "get":
                key = commandArgs[1];
                try {
                    StartSimpleNioServer.logger.info("The client tries to read the value of the key: " + key + ".");
                    storeAnswer = kvManager.get(key);
                } catch (Exception e) {
                    storeAnswer = new KVMessage(commandArgs[1], KVMessage.StatusType.GET_ERROR);
                    StartSimpleNioServer.logger.severe("There has been an error while trying to read the value of the key: " + key + ".");
                }
                break;
            case "delete":
                key = commandArgs[1];
                try {
                    StartSimpleNioServer.logger.info("The client tries to delete the key: " + key + " and it's associated value from the database.");
                    storeAnswer = kvManager.delete(key);
                } catch (Exception e) {
                    storeAnswer = new KVMessage(commandArgs[1], KVMessage.StatusType.DELETE_ERROR);
                    StartSimpleNioServer.logger.severe("There has been an error while trying to delete the key: " + key + " and it's associated value.");
                }
                break;
            default:
                storeAnswer = new KVMessage("Unknown Command", KVMessage.StatusType.ERROR);
                break;
        }
        return storeAnswer.toString() + "\r\n";
    }

    /**
     * Notification for an accepted connection
     *
     * @param address       address of the KVserver
     * @param remoteAddress the address of the client
     * @return notification message
     */
    @Override
    public String connectionAccepted(InetSocketAddress address, InetSocketAddress remoteAddress) {
        logger.info("New connection: " + remoteAddress.toString());
        return "Connection to T15 Storage KVserver established: " + address.toString() + "\r\n";
    }

    /**
     * Logging for a closed connection
     *
     * @param address address of the KVserver
     */
    @Override
    public void connectionClosed(InetAddress address) {
        logger.info("Connection closed: " + address.toString());
    }
}
