package de.tum.i13.client;

import de.tum.i13.KVStore.KVMessagingProtocol;
import de.tum.i13.shared.KVMessage;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.logging.Level;
import java.util.logging.Logger;

import static de.tum.i13.shared.LogSetup.setupLogging;


public class Milestone1Main {
    private final static Logger LOGGER = Logger.getLogger(Milestone1Main.class.getName());

    public static void main(String[] args) throws IOException {
        BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));
        Path path = Paths.get("client.log");
        LOGGER.setLevel(setupLogging(path));
        KVMessagingProtocol kvStore = new KVMessagingProtocol(null);
        printHelp();
        KVMessage.StatusType command;
        String data;
        for (; ; ) {
            System.out.print("T15Client> ");
            String line = reader.readLine();
            String[] body = line.split(" ");
            switch (body[0]) {
                case "connect":
                    LOGGER.info("The client tries to connect to the server.");

                    kvStore.buildConnection(body);
                    break;
                case "put":
                    LOGGER.info("The client tries to insert a key-value pair in the storage server.");
                    if (body.length < 3) {
                        printShellLine("Method args incorrect");
                        LOGGER.warning("User provided wrong arguments for put");
                        break;
                    }
                    command = KVMessage.StatusType.PUT;
                    String[] value = new String[body.length - 2];
                    System.arraycopy(body, 2, value, 0, value.length);
                    data = body[1] + " " + convertStrArrayToStr(value, " ");
                    LOGGER.info("User calls put " + data);
                    kvStore.sendMessage(command, data); // just a placeholder, as put can have variable number of args
                    break;
                case "get":
                    LOGGER.info("The client tries to get a key-value pair from the storage server.");
                    if (body.length != 2) {
                        printShellLine("Method args incorrect");
                        LOGGER.warning("User provided wrong arguments for get");
                        break;
                    }
                    command = KVMessage.StatusType.GET;
                    data = body[1];
                    LOGGER.info("User calls get " + body[1]);
                    kvStore.sendMessage(command, data);
                    break;
                case "delete":
                    LOGGER.info("The client tries to delete a key-value pair from the storage server.");
                    if (body.length != 2) {
                        printShellLine("Method args incorrect");
                        LOGGER.warning("User provided wrong arguments for delete");
                        break;
                    }
                    command = KVMessage.StatusType.DELETE;
                    data = body[1];
                    LOGGER.info("User calls delete " + body[1]);
                    kvStore.sendMessage(command, data);

                    break;
                case "logLevel":
                    LOGGER.info("The client tries set a new log level for the logger.");
                    if (body.length != 2) {
                        LOGGER.warning("User provided the wrong number of logLevel arguments");
                        printShellLine("Invalid use of logLevel: logLevel {ALL | SEVERE | WARNING | INFO | CONFIG | FINE | FINER | FINEST | OFF}");
                    }
                    setLogLevel(body[1]);
                    break;
                case "disconnect":
                    LOGGER.info("The client tries to disconnect from the server.");
                    kvStore.closeConnection(kvStore.getClientSocket());
                    break;
                case "help":
                    LOGGER.info("User calls help");
                    printHelp();
                    break;
                case "quit":
                    LOGGER.info("The client will now quit the program.");
                    printShellLine("Application exit!");
                    return;
                default:
                    LOGGER.info("The client passed an unknown command.");
                    printShellLine("Unknown command");
            }
        }
    }

    private static void printHelp() {
        System.out.println("Available commands:");
        System.out.println("\tconnect <address> <port> - Tries to establish a TCP- connection to the echo KVserver based on the given KVserver address and the port number of the echo service.");
        System.out.println("\tdisconnect - Tries to disconnect from the connected KVserver.");
        System.out.println("\tput <key> <value> - Inserts or updates a Key/Value pair in the storage server.");
        System.out.println("\tget <key> - Retrieves a Key/Value pair from the database.");
        System.out.println("\tdelete <key> - Removes a Key/Value pair from the storage server.");
        System.out.println("\tlogLevel <level> - Sets the logger to the specified log level (ALL | DEBUG | INFO | WARN | ERROR | FATAL | OFF)");
        System.out.println("\thelp - Display this help");
        System.out.println("\tquit - Tears down the active connection to the KVserver and exits the program execution.");
    }

    private static void printShellLine(String msg) {
        System.out.println("T15Client> " + msg);
    }

    private static void setLogLevel(String level) {
        try {
            Level newLevel = Level.parse(level);
            LOGGER.info("Setting LOGGER.level to " + newLevel.getName());
            printShellLine("LogLevel set from " + LOGGER.getLevel() + " to " + newLevel.getName());
            LOGGER.setLevel(newLevel);
        } catch (IllegalArgumentException e) {
            LOGGER.warning("User entered an invalid logLevel");
            printShellLine("Not a valid loglevel. Setting logLevel failed");
        }
    }

    public static String convertStrArrayToStr(String[] words, String separator) {
        if (words.length == 0) {
            return "";
        }
        if (words.length == 1) {
            return words[0];
        }
        StringBuilder str = new StringBuilder(words[0]);
        for (int i = 1; i < words.length; i++) {
            str.append(separator).append(words[i]);
        }
        return str.toString();
    }

}
