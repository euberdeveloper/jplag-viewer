package de.tum.i13.KVserver.kv;

import de.tum.i13.KVserver.kv.persistence.PersistenceHandler;
import de.tum.i13.KVserver.nio.StartSimpleNioServer;
import de.tum.i13.shared.KVMessage;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

/**
 * KVManager is responsible for handling the cache and accessing the database if a cache miss occurs.
 */
public abstract class KVManager {
    public Map<String, String> cache;
    /**
     * maxSize is the size of the cache
     */
    protected int maxSize;
    /**
     * Direct access to the database is delegated to the persistenceHandler
     */
    protected PersistenceHandler persistenceHandler;

    public KVManager(int maxSize) {
        this.cache = new HashMap<>();
        this.maxSize = maxSize;
    }

    public void setPersistenceHandler(PersistenceHandler persistenceHandler) {
        this.persistenceHandler = persistenceHandler;
    }

    /**
     * Inserts a key-value pair into the KVServer.
     *
     * @param key   the key that identifies the given value.
     * @param value the value that is indexed by the given key.
     * @return a message that confirms the insertion of the tuple or an error.
     * @throws Exception if put command cannot be executed (e.g. not connected to any
     *                   KV KVserver).
     */
    public KVMessage put(String key, String value) throws Exception {
        KVMessage.StatusType responseStatus = KVMessage.StatusType.PUT_SUCCESS;

        //Key-Value lengths check
        if (key.length() > 20) {
            responseStatus = KVMessage.StatusType.PUT_ERROR;
            StartSimpleNioServer.logger.warning("The key: " + key + " passed by the client exceeds the accepted length of 20 Bytes.");
            return new KVMessage(key, value, responseStatus);
        } else if (value.length() > 120000) {
            responseStatus = KVMessage.StatusType.PUT_ERROR;
            StartSimpleNioServer.logger.warning("The value: " + value + " passed by the client exceeds the accepted length of 120 KBytes.");
            return new KVMessage(key, value, responseStatus);
        }

        String cacheValue = cache.get(key);
        updatePut(key);
        if (cacheValue == null) { // cache miss
            cache.put(key, value);
        } else { // key in cache => update cache and db
            cache.put(key, value);
            responseStatus = KVMessage.StatusType.PUT_UPDATE;
            StartSimpleNioServer.logger.info("The system updated the existing key: " + key + " with the new value: " + value + " in the cache.");
        }
        return new KVMessage(key, value, responseStatus);
    }

    /**
     * Retrieves the value for a given key from the KVServer.
     *
     * @param key the key that identifies the value.
     * @return the value, which is indexed by the given key.
     * @throws Exception if getFromDB command cannot be executed (e.g. not connected to any
     *                   KV KVserver).
     */
    public KVMessage get(String key) throws Exception {
        KVMessage.StatusType responseStatus = KVMessage.StatusType.GET_SUCCESS;
        String cacheValue = cache.get(key);
        if (cacheValue == null) { // cache miss
            String dbValue = persistenceHandler.getFromDB(key);
            if (dbValue == null) { // db miss, key not present anywhere
                StartSimpleNioServer.logger.warning("The key: " + key + " requested by the client has no associated value in the database or cache.");
                responseStatus = KVMessage.StatusType.GET_ERROR;
                return new KVMessage(key, responseStatus);
            } else { // key only in db => load key into cache and return
                cache.put(key, dbValue);
                updatePut(key);
                StartSimpleNioServer.logger.info("The system found the KVPair: " + key + ": " + dbValue + " on disk.");
                return new KVMessage(key, dbValue, responseStatus);
            }
        } else { // key in cache, return value
            updateGet(key);
            StartSimpleNioServer.logger.info("The system found the KVPair: " + key + ": " + cacheValue + " in the cache.");
            return new KVMessage(key, cacheValue, responseStatus);
        }
    }

    /**
     * Deletes the value and key for a given key from the KVServer.
     *
     * @param key the key that identifies the value.
     * @return whether the operation was successful or not
     * @throws Exception if delete command cannot be executed (e.g. not connected to any
     *                   KV KVserver).
     */
    public KVMessage delete(String key) throws Exception { // if a key is to be deleted, simply remove it from cache and db
        KVMessage.StatusType responseStatus = KVMessage.StatusType.DELETE_SUCCESS;
        String cacheValue = cache.remove(key);
        updateDelete(key);
        String dbKey = persistenceHandler.deleteFromDB(key);
        if (cacheValue == null) {
            if (dbKey == null) {
                StartSimpleNioServer.logger.info("The key: " + key + " passed by the client doesn't exist in the database or cache.");
                responseStatus = KVMessage.StatusType.DELETE_ERROR;
                return new KVMessage(key, responseStatus);
            }
        }
        StartSimpleNioServer.logger.info("The system deleted the key: " + key + " and it's paired value from the database");
        return new KVMessage(key, responseStatus);
    }

    public void flushCacheToDisk() throws IOException {
        for (Map.Entry<String, String> entry : cache.entrySet()) {
            if (persistenceHandler.getFromDB(entry.getKey()) == null) {
                persistenceHandler.insertInDB(entry.getKey(), entry.getValue());
            } else {
                persistenceHandler.updateInDB(entry.getKey(), entry.getValue());
            }
        }
    }

    /**
     * The cache is updated according to the selected strategy
     *
     * @param key
     */
    abstract void updatePut(String key) throws IOException;

    abstract void updateGet(String key);

    abstract void updateDelete(String key);

    public void setMaxSize(int maxSize) {
        this.maxSize = maxSize;
    }
}
