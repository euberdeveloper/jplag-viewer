package de.tum.i13.KVserver.kv.persistence;

import de.tum.i13.shared.Constants;

import java.io.BufferedWriter;
import java.io.File;
import java.io.IOException;
import java.nio.charset.Charset;
import java.nio.file.Files;
import java.util.List;

public class PersistenceHandler {
    private final String filePath;
    private File dataFile;

    public PersistenceHandler(String filePath) {
        this.filePath = filePath;
        initFile(filePath);
    }

    /**
     * Creates the database file. The file name and extension are inside the filePath parameter.
     *
     * @param filePath The file path in String format of our database file.
     */
    private void initFile(String filePath) {
        try {
            this.dataFile = new File(filePath);
            if (dataFile.createNewFile()) {
                // Created new file
            } else {
                // File exists, read into cache
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    /**
     * The method updates the value of the mentioned key in the persistent database file.
     *
     * @param key   The key for which we have to change the value.
     * @param value The new value for the given key.
     * @throws IOException if we cannot read the contents of the database file, or if we cannot write in the file the changes
     *                     we have made to it's content.
     */
    public void updateInDB(String key, String value) throws IOException {
        File database = new File(filePath);
        List<String> dbContent = Files.readAllLines(database.toPath());

        String newKeyValue = key + ": " + value;

        String currentKeyValue = dbContent.stream()
                .filter(kv -> kv.startsWith(key))
                .findFirst()
                .get();
        int updateIndex = dbContent.indexOf(currentKeyValue);
        dbContent.set(updateIndex, newKeyValue);

        writeInFile(database, dbContent);
    }

    /**
     * The method inserts a new key-value pair in the persistent database file.
     *
     * @param key   The key we want to insert in the database.
     * @param value The value we want to insert in the database, for the given key.
     * @throws IOException if we cannot read the contents of the database file, or if we cannot write in the file the changes
     *                     we have made to it's content.
     */
    public void insertInDB(String key, String value) throws IOException {
        File database = new File(filePath);
        List<String> dbContent = Files.readAllLines(database.toPath());

        String newKeyValue;
        newKeyValue = key + ": " + value;
        dbContent.add(newKeyValue);

        writeInFile(database, dbContent);
    }

    /**
     * The method finds the value associated with the given key in the persistent database file.
     *
     * @param key The key for which we want to get the associated value from the database.
     * @return the value associated with the given key.
     * @throws IOException if we cannot read the contents of the database file
     */
    public String getFromDB(String key) throws IOException {
        File database = new File(filePath);
        List<String> dbContent = Files.readAllLines(database.toPath());
        String currentKeyValue = dbContent.stream()
                .filter(kv -> kv.startsWith(key))
                .findFirst()
                .orElse("");

        if (currentKeyValue.isEmpty()) {
            return null;
        } else {
            int separatorIndex = currentKeyValue.indexOf(": ");
            return currentKeyValue.substring(separatorIndex + 2);
        }
    }

    /**
     * The method deletes the given key and it's associated value from the persistent database file.
     *
     * @param key The key we want to delete from the database.
     * @throws IOException if we cannot read the contents of the database file, or if we cannot write in the file the changes
     *                     we have made to it's content.
     */
    public String deleteFromDB(String key) throws IOException {
        File database = new File(filePath);
        List<String> dbContent = Files.readAllLines(database.toPath());
        String currentKeyValue = dbContent.stream()
                .filter(s -> s.startsWith(key))
                .findFirst()
                .orElse("");

        if (currentKeyValue.isEmpty()) {
            return null;
        }
        dbContent.remove(currentKeyValue);

        writeInFile(database, dbContent);
        return key;
    }

    /**
     * The method writes in the passed file parameter the contents of the list parameter.
     *
     * @param database  The file we want to write in.
     * @param dbContent The content that we want to write in the file.
     * @throws IOException if we cannot create our writer from the file.
     */
    private void writeInFile(File database, List<String> dbContent) throws IOException {
        BufferedWriter databaseWriter = Files.newBufferedWriter(database.toPath(), Charset.forName(Constants.TELNET_ENCODING));
        for (String s : dbContent) {
            databaseWriter.write(s + "\r");
        }
        databaseWriter.flush();
    }
}
