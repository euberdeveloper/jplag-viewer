package de.tum.i13.shared;

public class Constants {
    public static final String TELNET_ENCODING = "UTF-8"; // encoding for telnet
}
