package de.tum.i13.KVStore;

import de.tum.i13.shared.KVMessage;

public interface KVStore {
    KVMessage put(String key, String value);

    KVMessage get(String key);

    KVMessage delete(String key);
}
