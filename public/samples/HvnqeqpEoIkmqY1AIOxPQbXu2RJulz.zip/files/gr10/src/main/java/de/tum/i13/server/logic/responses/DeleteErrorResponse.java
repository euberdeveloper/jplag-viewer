package de.tum.i13.server.logic.responses;

public class DeleteErrorResponse extends KeyResponse {
    public DeleteErrorResponse(String key) {
        super(key);
    }

    @Override
    public String toString() {
        return "delete_error " + this.getKey();
    }
}
