package de.tum.i13.server.communication;


import de.tum.i13.server.logic.operations.*;

import java.util.Base64;

public class ServerParser {

    /**
     * Turns the input into a Operation
     *
     * @param line The input, only has valid returns for current API
     * @return a Operation that can be executed with the given arguments, if the input was valid
     */
    public Operation parse(String line) {
        if (line == null || line.isEmpty()) {
            return null;
        }
        line = line.trim();

        String[] tokens = line.split("\\s+", 2);

        String baseOperation = tokens[0];

        switch (baseOperation) {
            case "put":
                return parsePutOperationArgs(line);
            case "get":
                return parseGetOperationArgs(line);
            case "delete":
                return parseDeleteOperationArgs(line);
            default:
                return parseUnknownOperationArgs(line);
        }
    }

    private Operation parsePutOperationArgs(String arguments) {
        String[] tokens = arguments.split("\\s+", 3);
        if (tokens.length != 3) {
            return new InvalidOperation("The put operation takes exactly two arguments");
        }

        String key = tokens[1];
        String value = tokens[2];
        return new PutOperation(key, value);
    }

    private Operation parseGetOperationArgs(String arguments) {
        String[] tokens = arguments.split("\\s+", 3);
        if (tokens.length != 2) {
            return new InvalidOperation("The get operation takes exactly one argument");
        }

        String key = tokens[1];
        return new GetOperation(key);
    }

    private Operation parseDeleteOperationArgs(String arguments) {
        String[] tokens = arguments.split("\\s+", 3);
        if (tokens.length != 2) {
            return new InvalidOperation("The delete operation takes exactly one argument");
        }

        String key = tokens[1];
        return new DeleteOperation(key);
    }

    private Operation parseUnknownOperationArgs(String line) {
        return new InvalidOperation("Unknown operation \"" + line + "\". Please refer to the supported operations");
    }

    private String decodeBase64(String encoded) {
        return new String(Base64.getDecoder().decode(encoded));
    }

}
