package de.tum.i13.client.logic;

import de.tum.i13.client.Visitor;

public class DisconnectCommand extends Command {

    @Override
    public String execute(Visitor visitor) throws Exception {
        return visitor.execute(this);
    }

}
