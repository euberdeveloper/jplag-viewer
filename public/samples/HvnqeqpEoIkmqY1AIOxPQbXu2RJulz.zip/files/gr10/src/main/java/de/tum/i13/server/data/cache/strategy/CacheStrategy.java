package de.tum.i13.server.data.cache.strategy;

import de.tum.i13.server.data.cache.exceptions.CacheMissException;
import de.tum.i13.server.data.disk.DiskReadWriter;
import de.tum.i13.server.logic.operations.DeleteOperation;
import de.tum.i13.server.logic.operations.GetOperation;
import de.tum.i13.server.logic.operations.Operation;
import de.tum.i13.server.logic.operations.PutOperation;
import de.tum.i13.server.logic.responses.*;
import de.tum.i13.shared.config.Config;

import java.util.List;
import java.util.Map;

public abstract class CacheStrategy {

    private int cacheSize;

    /**
     * Creates a new CacheStrategy
     *
     * @param cacheSize the specified size
     */
    public CacheStrategy(int cacheSize) {
        this.cacheSize = cacheSize;
    }

    public static CacheStrategy createCacheStrategy(Config config) {
        switch (config.cacheStrategy) {
            case LRU:
                return new LRUCacheStrategy(config.cacheSize);
            case LFU:
                return new LFUCacheStrategy(config.cacheSize);
            case FIFO:
            default:
                return new FIFOCacheStrategy(config.cacheSize);
        }
    }

    /**
     * Returns a value for a key if it exists
     *
     * @param key that is searched
     * @return a value if the key exists, otherwise null
     * @throws CacheMissException if the key does not exist the exception is thrown
     */
    public abstract String getValueFromCache(String key) throws CacheMissException;

    /**
     * Sets a value in the Cache for the key value pair, update incase the key already exists
     *
     * @param key   the key that shall be used
     * @param value the value assigned to the key
     * @throws CacheMissException if the key does not exist in the Cache an Exception is thrown
     */
    public abstract void setValueInCache(String key, String value) throws CacheMissException;

    /**
     * Used for the specific implementation per Cache, also updates the Cache
     *
     * @param key   The key that should be added
     * @param value The value that should be added
     * @return the Entry that was added
     */
    public abstract Map.Entry<String, String> addEntryToCache(String key, String value);

    /**
     * Used for the specific implementation per Cache, also updates the Cache
     *
     * @param key the Key that should be deleted
     * @throws CacheMissException If the key is not in the Cache
     */
    public abstract void deleteFromCache(String key) throws CacheMissException;

    /**
     * Used for the specific implementation per Cache, also updates the Cache
     *
     * @return all the Entries that are currently stored in the Cache
     */
    public abstract List<Map.Entry<String, String>> getAllEntriesFromCache();

    /**
     * To get the size of the cache
     *
     * @return cacheSize
     */
    public int getCacheSize() {
        return this.cacheSize;
    }

}
