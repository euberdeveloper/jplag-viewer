package de.tum.i13.server.data;

import de.tum.i13.client.communication.Communicator;
import de.tum.i13.server.data.cache.exceptions.CacheMissException;
import de.tum.i13.server.data.cache.strategy.CacheStrategy;
import de.tum.i13.server.data.disk.DiskReadWriter;
import de.tum.i13.server.logic.operations.*;
import de.tum.i13.server.logic.responses.*;

import java.io.IOException;
import java.util.Map;
import java.util.logging.Logger;

public class PersistentDataManager implements DataManager {

    private CacheStrategy cacheStrategy;

    private DiskReadWriter diskReadWriter;

    private static final Logger LOGGER = Logger.getLogger(PersistentDataManager.class.getName());


    /**
     * Creates a new PersistentDataManager that performs the operations upon the database
     *
     * @param cacheStrategy  The specified Strategy (FIFO/LFU/LRU)
     * @param diskReadWriter to write surplus to the Disk
     */
    public PersistentDataManager(CacheStrategy cacheStrategy, DiskReadWriter diskReadWriter) {
        this.cacheStrategy = cacheStrategy;
        this.diskReadWriter = diskReadWriter;
    }

    @Override
    public Response get(GetOperation getOperation) {
        String key = getOperation.getKey();
        String value = null;
        try {
            LOGGER.info("Loading value from Cache");
            value = this.cacheStrategy.getValueFromCache(key);
            return new GetSuccessResponse(key, value);
        } catch (CacheMissException cme) {
            LOGGER.info("Loading value from Disk");
            try {
                value = this.diskReadWriter.read(key);
            } catch (IOException ioe) {
                LOGGER.throwing(diskReadWriter.getClass().getName(), "read", ioe);
                return new GetErrorResponse(key);
            }
            if (value != null) {
                Map.Entry<String, String> displacedEntry = this.cacheStrategy.addEntryToCache(key, value);
                if (displacedEntry != null) {
                    try {
                        this.diskReadWriter.write(displacedEntry.getKey(), displacedEntry.getValue());
                    } catch (IOException ioe) {
                        LOGGER.throwing(diskReadWriter.getClass().getName(), "write", ioe);
                        return new GetErrorResponse(key);
                    }
                }
                return new GetSuccessResponse(key, value);
            } else {
                return new GetErrorResponse(key);
            }
        }
    }

    @Override
    public Response put(PutOperation putOperation) {
        String key = putOperation.getKey();
        String value = putOperation.getValue();
        try {
            try {
                LOGGER.info("Setting value in Cache");
                this.cacheStrategy.setValueInCache(key, value);
                return new PutUpdateResponse(key);
            } catch (CacheMissException cme) {
                LOGGER.info("Setting value on Disk");
                boolean alreadyPresent = this.diskReadWriter.write(key, value);
                Map.Entry<String, String> displacedEntry = this.cacheStrategy.addEntryToCache(key, value);
                if (displacedEntry != null) {

                }
                return alreadyPresent ? new PutUpdateResponse(key) : new PutSuccessResponse(key);
            }
        } catch (IOException ioe) {
            LOGGER.throwing(diskReadWriter.getClass().getName(), "write", ioe);
            return new PutErrorResponse(key, value);
        }
    }

    @Override
    public Response delete(DeleteOperation deleteOperation) {
        String key = deleteOperation.getKey();
        try {
            try {
                LOGGER.info("Deleting value from Cache and Disk");
                this.cacheStrategy.deleteFromCache(key);
                this.diskReadWriter.delete(key);
                return new DeleteSuccessResponse(key);
            } catch (CacheMissException cme) {
                LOGGER.info("Deleting value from Disk");
                boolean success = this.diskReadWriter.delete(key);
                return success ? new DeleteSuccessResponse(key) : new DeleteErrorResponse(key);
            }
        } catch (IOException ioe) {
            LOGGER.throwing(diskReadWriter.getClass().getName(), "delete", ioe);
        }
        return new DeleteErrorResponse(key);
    }

    public void storeCompleteCacheToDisk() {
        LOGGER.info("Storing Cache to Disk");
        try {
            for (Map.Entry<String, String> entry : this.cacheStrategy.getAllEntriesFromCache()) {
                this.diskReadWriter.write(entry.getKey(), entry.getValue());
            }
        } catch (IOException ioe) {
            LOGGER.throwing(diskReadWriter.getClass().getName(), "write", ioe);
        }

    }
}
