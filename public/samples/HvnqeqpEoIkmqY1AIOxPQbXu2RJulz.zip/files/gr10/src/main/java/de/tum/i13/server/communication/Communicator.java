package de.tum.i13.server.communication;

import de.tum.i13.server.logic.OperationsVisitor;
import de.tum.i13.shared.config.Config;

import java.io.IOException;
import java.net.InetSocketAddress;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.LinkedList;
import java.util.List;
import java.util.logging.Logger;

public class Communicator {

    private OperationsVisitor logic;

    private int port;

    private String listenAddr;

    private ServerSocket serverSocket;

    private List<Session> sessions;

    private final static Logger LOGGER = Logger.getLogger(Communicator.class.getName());

    /**
     * Creates a new Communicator that handles the Connections
     *
     * @param config       Holds the information for creating the server
     * @param logic        Methods of the Server
     * @param serverSocket to accept connections
     */
    public Communicator(Config config, OperationsVisitor logic, ServerSocket serverSocket) {
        this.logic = logic;
        this.port = config.port;
        this.listenAddr = config.listenaddr;
        this.serverSocket = serverSocket;
        this.sessions = new LinkedList<>();
    }

    private void initialize() throws IOException {
        serverSocket.bind(new InetSocketAddress(this.listenAddr, this.port));

        LOGGER.info("Successfully initialized communicator on \"" + this.listenAddr + "\":\"" + this.port + "\"");
    }

    /**
     * Starts the accepting of Connections, then proceeds to create seperate Threads for each new
     * Connection
     */
    public void start() {
        try {
            this.initialize();

            while (true) {
                Socket clientSocket = this.serverSocket.accept();
                LOGGER.info("accepted new incoming connection");

                Session session = new Session(clientSocket, logic, new ServerParser(), new ServerSerializer(), this);
                Thread sessionThread = new Thread(session);
                sessionThread.start();
                this.sessions.add(session);
            }
        } catch (IOException ioe) {

        }
        this.stop();
    }

    public void deregister(Session session) {
        if (this.sessions.contains(session)) {
            this.sessions.remove(session);
        }
    }

    /**
     * Closes the Server down, disrupts all communication
     */
    public void stop() {
        LOGGER.info("Closing kv server communicator");
        try {
            serverSocket.close();
        } catch (IOException e) {
            e.printStackTrace();
        }

        for (Session session : this.sessions) {
            session.stop();
        }
    }

}
