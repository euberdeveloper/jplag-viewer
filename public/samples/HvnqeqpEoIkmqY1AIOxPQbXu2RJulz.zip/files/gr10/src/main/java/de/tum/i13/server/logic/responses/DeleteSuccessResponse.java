package de.tum.i13.server.logic.responses;

public class DeleteSuccessResponse extends KeyResponse {
    public DeleteSuccessResponse(String key) {
        super(key);
    }

    @Override
    public String toString() {
        return "delete_success " + this.getKey();
    }
}
