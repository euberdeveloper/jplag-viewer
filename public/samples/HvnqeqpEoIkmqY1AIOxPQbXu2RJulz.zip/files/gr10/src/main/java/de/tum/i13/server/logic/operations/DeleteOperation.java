package de.tum.i13.server.logic.operations;

import de.tum.i13.server.logic.OperationsVisitor;
import de.tum.i13.server.logic.responses.Response;

public class DeleteOperation extends Operation {

    private String key;

    public DeleteOperation(String key) {
        this.key = key;
    }

    @Override
    public void execute(OperationsVisitor visitor) {
        visitor.execute(this);
    }

    public String getKey() {
        return this.key;
    }

}
