package de.tum.i13.client.ui.cli;

import de.tum.i13.client.logic.*;
import de.tum.i13.shared.exceptions.ArgumentsException;

import java.util.List;
import java.util.logging.Level;

public class Parser {

    /**
     * Parse the tokens read from the user input
     *
     * @param tokens the already split input ["baseCommand", "arg1 arg2"]
     * @return the parsed command
     * @throws ArgumentsException
     */
    public Command parse(List<String> tokens) throws ArgumentsException {
        if (isEmpty(tokens)) {
            return null;
        }

        String baseCommand = tokens.get(0);

        switch (baseCommand) {
            case "connect":
                return parseConnectCommandArgs(tokens);
            case "disconnect":
                return parseDisconnectCommandArgs(tokens);
            case "logLevel":
                return parseLogLevelCommandArgs(tokens);
            case "help":
                return parseHelpCommandArgs(tokens);
            case "quit":
                return parseQuitCommandArgs(tokens);
            case "put":
                return parsePutCommandArgs(tokens);
            case "get":
                return parseGetCommandArgs(tokens);
            default:
                return parseHelpCommandUnknownArgs(tokens);
        }
    }

    /**
     * Parse the arguments for the connect command
     *
     * @param tokens the already split input ["connect", "arg1 arg2"]
     * @return the ConnectCommand
     * @throws ArgumentsException
     */
    private ConnectCommand parseConnectCommandArgs(List<String> tokens) throws ArgumentsException {
        if (tokens.size() != 2) {
            throw new ArgumentsException("No arguments specified");
        }

        List<String> commandArguments = List.of(tokens.get(1).split("\\s+"));
        if (commandArguments.size() != 2) {
            throw new ArgumentsException("Connect takes exactly two arguments");
        }

        String hostname = commandArguments.get(0);

        int port;
        try {
            port = Integer.parseInt(commandArguments.get(1));
        } catch (NumberFormatException nfe) {
            throw new ArgumentsException("Second argument of connect command must be a port number and of type int");
        }

        return new ConnectCommand(hostname, port);
    }

    /**
     * Parse the arguments for the disconnect command
     *
     * @param tokens the already split input ["disconnect"]
     * @return the DisconnectCommand
     * @throws ArgumentsException
     */
    private DisconnectCommand parseDisconnectCommandArgs(List<String> tokens) throws ArgumentsException {
        if (tokens.size() != 1) {
            throw new ArgumentsException("Disconnect doesn't take any arguments");
        }
        return new DisconnectCommand();
    }

    /**
     * Parse the arguments for the logLevel command
     *
     * @param tokens the already split input ["logLevel", "ALL"]
     * @return the LogLevelCommand
     * @throws ArgumentsException
     */
    private LogLevelCommand parseLogLevelCommandArgs(List<String> tokens) throws ArgumentsException {
        if (tokens.size() != 2) {
            throw new ArgumentsException("Illegal number of arguments specified");
        }
        Level desiredLogLevel;
        try {
            desiredLogLevel = Level.parse(tokens.get(1));
        } catch (IllegalArgumentException iae) {
            throw new ArgumentsException("Unspecified logLevel. Only ( ALL | CONFIG | FINE | FINEST | INFO| OFF |\n" + "SEVERE | WARNING ) are allowed.");
        }
        return new LogLevelCommand(desiredLogLevel);
    }

    /**
     * Parse the arguments for the quit command
     *
     * @param tokens the already split input ["disconnect"]
     * @return the DisconnectCommand
     * @throws ArgumentsException
     */
    private QuitCommand parseQuitCommandArgs(List<String> tokens) throws ArgumentsException {
        if (tokens.size() != 1) {
            throw new ArgumentsException("Too many arguments");
        }
        return new QuitCommand();
    }

    /**
     * Parse the arguments for the help command
     *
     * @param tokens the already split input ["help"]
     * @return the HelpCommand
     * @throws ArgumentsException
     */
    private HelpCommand parseHelpCommandArgs(List<String> tokens) throws ArgumentsException {
        if (tokens.size() != 1) {
            throw new ArgumentsException("Too many arguments");
        }
        return new HelpCommand();
    }

    /**
     * Get a help command if the entered user input is unknown
     *
     * @param tokens the already split input
     * @return the HelpCommand
     * @throws ArgumentsException
     */
    private HelpCommand parseHelpCommandUnknownArgs(List<String> tokens) throws ArgumentsException {
        return new HelpCommand(tokens);
    }

    /**
     * Parses the arguments of a Put Command
     *
     * @param tokens the already split input
     * @return A PutCommand if there where 2 arguments, A Delete Command if there was only one
     * @throws ArgumentsException
     */
    private Command parsePutCommandArgs(List<String> tokens) throws ArgumentsException {
        if (tokens.size() != 2) {
            throw new ArgumentsException("No arguments specified");
        }

        List<String> putArguments = List.of(tokens.get(1).split("\\s+", 2));
        if (putArguments.size() == 1) {
            if (putArguments.get(0).isEmpty()) {
                throw new ArgumentsException("No arguments specified");
            }
            String key = putArguments.get(0);
            return new DeleteCommand(key);
        }
        if (putArguments.size() != 2) {
            throw new ArgumentsException("Put takes exactly two arguments");
        }

        String key = putArguments.get(0);
        String value = putArguments.get(1);

        return new PutCommand(key, value);
    }

    /**
     * Parses the arguments of a Get Command
     *
     * @param tokens the already split input
     * @return The GetCommand
     * @throws ArgumentsException
     */
    private GetCommand parseGetCommandArgs(List<String> tokens) throws ArgumentsException {
        if (tokens.size() != 2) {
            throw new ArgumentsException("A key to get value of must be specified");
        }
        return new GetCommand(tokens.get(1));
    }

    /**
     * Parses the arguments of a DeleteCommand
     *
     * @param tokens the already split input
     * @return The DeleteCommand
     * @throws ArgumentsException
     */
    private DeleteCommand parseDeleteCommandArgs(List<String> tokens) throws ArgumentsException {
        if (tokens.size() != 2) {
            throw new ArgumentsException("A key to delete must be specified");
        }
        return new DeleteCommand(tokens.get(1));
    }

    private boolean isEmpty(List<String> tokens) {
        return tokens == null || tokens.stream().filter((s -> !s.isEmpty())).count() == 0;
    }
}
