package de.tum.i13.server.logic.operations;

import de.tum.i13.server.logic.OperationsVisitor;

public class InvalidOperation extends Operation {

    private String description;

    public InvalidOperation(String description) {
        this.description = description;
    }

    @Override
    public void execute(OperationsVisitor visitor) {
        visitor.execute(this);
    }

    public String getDescription() {
        return this.description;
    }
}
