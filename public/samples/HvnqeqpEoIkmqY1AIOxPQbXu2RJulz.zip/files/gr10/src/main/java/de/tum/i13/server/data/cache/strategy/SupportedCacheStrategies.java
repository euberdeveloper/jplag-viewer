package de.tum.i13.server.data.cache.strategy;

public enum SupportedCacheStrategies {
    FIFO,
    LRU,
    LFU
}
