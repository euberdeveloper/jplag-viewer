package de.tum.i13.server.logic.responses;

public class GetSuccessResponse extends KeyValueResponse{

    public GetSuccessResponse(String key, String value) {
        super(key, value);
    }

    @Override
    public String toString() {
        return "get_success " + this.getKey() + " " + this.getValue();
    }
}
