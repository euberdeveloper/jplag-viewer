package de.tum.i13.client;

import de.tum.i13.client.communication.Communicator;
import de.tum.i13.client.ui.cli.CLIInput;
import de.tum.i13.client.logic.*;

import java.util.logging.Level;
import java.io.IOException;
import java.util.logging.Logger;

import static de.tum.i13.shared.LogSetup.*;

public class TestClient implements Visitor {

    private boolean quit;

    private final static Logger LOGGER = Logger.getLogger(TestClient.class.getName());
    private Communicator communicator;
    private boolean running;

    public TestClient(Communicator communicator) {
        this.communicator = communicator;
        running = true;
    }

    public static void main(String[] args) {
        setupLogging("client.log", Level.ALL);

        LOGGER.info("Creating a new Socket");

        Communicator communicator = new Communicator();
        TestClient client = new TestClient(communicator);
        CLIInput cliInput = new CLIInput(client, System.in, System.out);

        try {
            cliInput.start();
        } catch (IOException e) {
            e.printStackTrace();
        }

    }

    public boolean isRunning() {
        return running;
    }

    /**
     * Method to connect to server
     *
     * @param c Connect command to be executed
     * @return Shell output about connection status
     * @throws Exception if connection cannot be established
     */
    public String execute(ConnectCommand c) throws Exception {
        String shellOutput;
        try {
            shellOutput = communicator.connect(c.getHostname(), c.getPort());
        } catch (Exception e) {
            return e.getMessage();
        }
        return shellOutput;
    }

    /**
     * Method to terminate connection to server
     *
     * @param c Disconnect command to be executed
     * @return Shell output about connection status
     * @throws Exception if connection cannot be terminated or is already terminated
     */
    public String execute(DisconnectCommand c) throws Exception {
        ConnectCommand currentConnection;
        try {
            currentConnection = communicator.getConnectionInfo();
            communicator.disconnect();
        } catch (Exception e) {
            return e.getMessage();
        }
        return "Connection terminated: " + currentConnection.getHostname() + " / " + currentConnection.getPort();
    }

    /**
     * Method to display help message to client
     *
     * @param c Help command to be executed
     * @return Shell output with list of commands
     */
    public String execute(HelpCommand c) {
        return c.getHelpMessage();
    }

    /**
     * Method to change log levels
     *
     * @param c LogLevel command to be executed
     * @return Shell output with previous and current log levels
     */
    public String execute(LogLevelCommand c) {
        Level prevLevel = getLogLevel();
        setLogLevel(c.getLogLevel());
        return "loglevel set from " + prevLevel + " to " + c.getLogLevel();
    }

    /**
     * Method to quit and close the client application
     *
     * @param c Quit command to be executed
     * @return Shell output about impending shutdown
     * @throws Exception if connection cannot be terminated or is already terminated
     */
    public String execute(QuitCommand c) throws Exception {
        if (communicator.isConnected()) {
            communicator.disconnect();
        }
        running = false;
        return "Application exit!";
    }


    /**
     * Method to send a put command to the database
     *
     * @param c putCommand to be executed
     * @return The response of the Server
     * @throws Exception if connection is not correctly setup
     */
    public String execute(PutCommand c) throws Exception {
        String shellOutput;
        try {
            shellOutput = communicator.sendAndReceive(c.toString());
        } catch (Exception e) {
            return e.getMessage();
        }
        return shellOutput;
    }

    /**
     * Method to send a get command to the database
     *
     * @param c getCommand to be executed
     * @return The response of the Server
     * @throws Exception if connection is not correctly setup
     */
    public String execute(GetCommand c) throws Exception {
        String shellOutput;
        try {
            shellOutput = communicator.sendAndReceive(String.format("%s %s", "get", c.getKey()));
        } catch (Exception e) {
            return e.getMessage();
        }
        return shellOutput;
    }

    /**
     * Method to send a delete(put without a value) command to the database
     *
     * @param c deleteCommand to be executed
     * @return The response of the Server
     * @throws Exception if connection is not correctly setup
     */
    public String execute(DeleteCommand c) throws Exception {
        String shellOutput;
        try {
            shellOutput = communicator.sendAndReceive(String.format("%s %s", "delete", c.getKey()));
        } catch (Exception e) {
            return e.getMessage();
        }
        return shellOutput;
    }
}
