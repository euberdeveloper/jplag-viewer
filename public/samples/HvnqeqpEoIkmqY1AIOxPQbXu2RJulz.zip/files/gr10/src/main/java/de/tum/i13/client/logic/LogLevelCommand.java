package de.tum.i13.client.logic;

import de.tum.i13.client.Visitor;

import java.util.logging.Level;

public class LogLevelCommand extends Command {

    private Level logLevel;

    public LogLevelCommand(Level level) {
        this.logLevel = level;
    }

    public Level getLogLevel() {
        return logLevel;
    }

    @Override
    public String execute(Visitor visitor) {
        return visitor.execute(this);
    }

}
