package de.tum.i13.shared.config;

import de.tum.i13.server.data.cache.strategy.SupportedCacheStrategies;
import picocli.CommandLine;

import java.util.Arrays;

public class CacheStrategyTypeConverter implements CommandLine.ITypeConverter<SupportedCacheStrategies> {

    @Override
    public SupportedCacheStrategies convert(String s) throws Exception {
        for (SupportedCacheStrategies cs : SupportedCacheStrategies.values()) {
            if (cs.name().equals(s)) {
                return cs;
            }
        }
        throw new CommandLine.TypeConversionException("Cache strategy \"" + s + "\" is unknown," +
                " only " + Arrays.toString(SupportedCacheStrategies.values()) + " are supported.");
    }

}
