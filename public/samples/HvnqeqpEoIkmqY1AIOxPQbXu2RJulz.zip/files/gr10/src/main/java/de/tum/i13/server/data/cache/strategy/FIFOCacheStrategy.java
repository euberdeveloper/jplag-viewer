package de.tum.i13.server.data.cache.strategy;

import de.tum.i13.server.data.cache.exceptions.CacheMissException;

import java.util.*;

import java.util.LinkedList;

public class FIFOCacheStrategy extends CacheStrategy {

    private LinkedList<Map.Entry<String, String>> list;

    public FIFOCacheStrategy(int cacheSize) {
        super(cacheSize);
        this.list = new LinkedList<>();
    }

    @Override
    public String getValueFromCache(String key) throws CacheMissException {
        for (Map.Entry<String, String> entry : this.list) {
            if (entry.getKey().equals(key)) {
                return entry.getValue();
            }
        }
        throw new CacheMissException();
    }

    @Override
    public void setValueInCache(String key, String value) throws CacheMissException {
        for (Map.Entry<String, String> entry : this.list) {
            if (entry.getKey().equals(key)) {
                entry.setValue(value);
                return;
            }
        }
        throw new CacheMissException();
    }

    @Override
    public Map.Entry<String, String> addEntryToCache(String key, String value) {
        Map.Entry<String, String> entry = new AbstractMap.SimpleEntry(key, value);
        Map.Entry<String, String> displacedEntry = null;
        if (this.list.size() >= this.getCacheSize()) {
            displacedEntry = this.list.removeFirst();
        }
        this.list.addLast(entry);
        return displacedEntry;
    }

    @Override
    public void deleteFromCache(String key) throws CacheMissException {
        for (Map.Entry<String, String> entry : this.list) {
            if (entry.getKey().equals(key)) {
                this.list.remove(entry);
                return;
            }
        }
        throw new CacheMissException();
    }

    @Override
    public List<Map.Entry<String, String>> getAllEntriesFromCache() {
        return this.list;
    }

}
