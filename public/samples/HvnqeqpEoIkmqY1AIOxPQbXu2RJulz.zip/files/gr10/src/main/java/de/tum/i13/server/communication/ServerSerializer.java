package de.tum.i13.server.communication;

import de.tum.i13.server.logic.responses.ErrorResponse;
import de.tum.i13.server.logic.responses.Response;

public class ServerSerializer {

    /**
     * Turns a Response into a String to be sent
     *
     * @param response The Response that should be turned into a String
     * @return the Repsonse as a String with a Delimiter to signify the end of the Communication
     */
    public String serialize(Response response) {
        if (response == null) {
            response = new ErrorResponse("internal server error");
        }

        return ensureDelimiter(response.toString());
    }

    private String ensureDelimiter(String message) {
        return message.endsWith("\r\n") ? message : message + "\r\n";
    }
}
