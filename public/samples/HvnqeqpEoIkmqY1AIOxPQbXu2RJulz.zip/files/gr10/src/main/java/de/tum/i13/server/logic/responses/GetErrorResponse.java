package de.tum.i13.server.logic.responses;

public class GetErrorResponse extends KeyResponse {
    public GetErrorResponse(String key) {
        super(key);
    }

    @Override
    public String toString() {
        return "get_error " + this.getKey();
    }
}
