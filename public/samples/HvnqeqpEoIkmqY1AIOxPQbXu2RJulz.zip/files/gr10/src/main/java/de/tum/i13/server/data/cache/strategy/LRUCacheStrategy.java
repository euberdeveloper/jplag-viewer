package de.tum.i13.server.data.cache.strategy;

import de.tum.i13.server.data.cache.exceptions.CacheMissException;
import de.tum.i13.server.data.disk.DiskReadWriter;
import de.tum.i13.server.logic.operations.DeleteOperation;
import de.tum.i13.server.logic.operations.GetOperation;
import de.tum.i13.server.logic.operations.PutOperation;
import de.tum.i13.server.logic.responses.*;

import java.util.AbstractMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

public class LRUCacheStrategy extends CacheStrategy {

    private LinkedList<Map.Entry<String, String>> list;

    public LRUCacheStrategy(int cacheSize) {
        super(cacheSize);
        this.list = new LinkedList<>();
    }

    @Override
    public String getValueFromCache(String key) throws CacheMissException {
        for (Map.Entry<String, String> entry : this.list) {
            if (entry.getKey().equals(key)) {
                return entry.getValue();
            }
        }
        throw new CacheMissException();
    }

    private int findPosInList(String key) throws CacheMissException {
        for (Map.Entry<String, String> entry : this.list) {
            if (entry.getKey().equals(key)) {
                return list.indexOf(entry);
            }
        }
        throw new CacheMissException();
    }

    @Override
    public void setValueInCache(String key, String value) throws CacheMissException {
        for (Map.Entry<String, String> entry : this.list) {
            if (entry.getKey().equals(key)) {
                int pos = findPosInList(key);
                Map.Entry<String, String> e = this.list.get(pos);
                this.list.remove(pos);
                this.list.addFirst(e);
                return;
            }
        }
        throw new CacheMissException();

    }

    @Override
    public Map.Entry<String, String> addEntryToCache(String key, String value) {
        Map.Entry<String, String> entry = new AbstractMap.SimpleEntry(key, value);
        Map.Entry<String, String> displacedEntry = null;
        if (this.list.size() >= this.getCacheSize()) {
            displacedEntry = this.list.removeLast();
        }
        this.list.addFirst(entry);
        return displacedEntry;
    }

    @Override
    public void deleteFromCache(String key) throws CacheMissException {
        for (Map.Entry<String, String> entry : this.list) {
            if (entry.getKey().equals(key)) {
                this.list.remove(entry);
                return;
            }
        }
        throw new CacheMissException();
    }

    @Override
    public List<Map.Entry<String, String>> getAllEntriesFromCache() {
        return this.list;
    }

}
