package de.tum.i13.client.logic;

import de.tum.i13.client.Visitor;

public class DeleteCommand extends Command {

    private String key;

    public DeleteCommand(String key) {
        this.key = key;
    }

    public String getKey() {
        return key;
    }

    @Override
    public String execute(Visitor visitor) throws Exception {
        return visitor.execute(this);
    }

}
