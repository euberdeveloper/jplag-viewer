package de.tum.i13.server.logic.responses;

public class PutSuccessResponse extends KeyResponse {
    public PutSuccessResponse(String key) {
        super(key);
    }

    @Override
    public String toString() {
        return "put_success " + this.getKey();
    }
}
