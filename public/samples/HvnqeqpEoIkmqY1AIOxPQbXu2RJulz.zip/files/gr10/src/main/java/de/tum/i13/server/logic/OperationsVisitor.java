package de.tum.i13.server.logic;

import de.tum.i13.server.logic.operations.DeleteOperation;
import de.tum.i13.server.logic.operations.GetOperation;
import de.tum.i13.server.logic.operations.InvalidOperation;
import de.tum.i13.server.logic.operations.PutOperation;

public interface OperationsVisitor {

    public void execute(DeleteOperation deleteOperation);

    public void execute(GetOperation getOperation);

    public void execute(PutOperation putOperation);

    public void execute(InvalidOperation invalidOperation);

}
