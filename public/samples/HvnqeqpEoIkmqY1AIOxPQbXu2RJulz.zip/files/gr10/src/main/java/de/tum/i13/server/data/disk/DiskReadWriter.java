package de.tum.i13.server.data.disk;

import de.tum.i13.shared.config.Config;

import java.io.*;
import java.nio.file.Path;
import java.util.Properties;

public class DiskReadWriter {

    private final static String FILE_NAME = "main.properties";

    private Properties prop;
    private String currentFilePath;

    /**
     * Creates a diskReadWriter and saves the FilePath
     *
     * @param config supplies the file path
     */
    public DiskReadWriter(Config config) {
        currentFilePath = config.dataDir.resolve(FILE_NAME).toAbsolutePath().toString();
        prop = new Properties();
    }

    /**
     * Gives the value for a specific key from the file
     *
     * @param key for which the value is searched
     * @return value of the key
     * @throws IOException If there are issues with the FileIO
     */
    public String read(String key) throws IOException {
        this.loadPropertiesFromFile();
        return (String) prop.getOrDefault(key, null);
    }

    /**
     * Writes a key value pair onto the disk
     *
     * @param key   the key that shall be written
     * @param value the corresponding data for the key
     * @return true if the value was existent(update), false if it wasn't(put)
     * @throws IOException If there are issues with FileIO
     */
    public boolean write(String key, String value) throws IOException {
        this.loadPropertiesFromFile();
        boolean returnValue = prop.containsKey(key);
        prop.setProperty(key, value);
        this.storePropertiesToFile();
        return returnValue;
    }

    /**
     * Deletes a key from the disk
     *
     * @param key the key that shall be deleted
     * @return true if the key is existent, false if the key does not exist
     * @throws IOException If there are issues with FileIO
     */
    public boolean delete(String key) throws IOException {
        this.loadPropertiesFromFile();

        if (prop.containsKey(key)) {
            prop.remove(key);
            this.storePropertiesToFile();
            return true;
        } else {
            return false;
        }
    }

    private void loadPropertiesFromFile() throws IOException {
        ensureFileExists();
        try {
            this.prop.load(new FileInputStream(currentFilePath));
        } catch (IOException ioException) {
            ioException.printStackTrace();
        }
    }

    private void ensureFileExists() {
        try {
            File file = new File(currentFilePath);
            if (!file.exists()) {
                file.createNewFile();
            }
        } catch (IOException ioException) {
            ioException.printStackTrace();
        }
    }

    private void storePropertiesToFile() throws IOException {
        try {
            this.prop.store(new FileOutputStream(currentFilePath), null);
        } catch (IOException ioException) {
            ioException.printStackTrace();
        }
    }
}
