package de.tum.i13.server.logic.responses;

public class ErrorResponse implements Response {

    private String description;

    public ErrorResponse(String description){
        this.description = description;
    }

    @Override
    public String toString(){
        return "error: " + this.description;
    }

}
