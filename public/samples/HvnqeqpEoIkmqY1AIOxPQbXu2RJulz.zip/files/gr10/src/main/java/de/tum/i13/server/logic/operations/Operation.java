package de.tum.i13.server.logic.operations;

import de.tum.i13.server.logic.OperationsVisitor;
import de.tum.i13.server.logic.responses.Response;

public abstract class Operation {

    private Response response;

    public abstract void execute(OperationsVisitor visitor);

    public void setResponse(Response response) {
        this.response = response;
    }

    public Response getResponse() {
        return this.response;
    }

}
