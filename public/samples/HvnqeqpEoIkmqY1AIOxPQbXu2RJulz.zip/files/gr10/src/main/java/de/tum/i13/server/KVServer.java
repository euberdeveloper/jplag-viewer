package de.tum.i13.server;

import de.tum.i13.server.communication.Communicator;
import de.tum.i13.server.data.DataManager;
import de.tum.i13.server.data.PersistentDataManager;
import de.tum.i13.server.data.cache.strategy.CacheStrategy;
import de.tum.i13.server.data.disk.DiskReadWriter;
import de.tum.i13.server.logic.KVServerLogic;
import de.tum.i13.server.logic.OperationsVisitor;
import de.tum.i13.shared.LogSetup;
import de.tum.i13.shared.config.Config;

import java.io.IOException;
import java.net.ServerSocket;
import java.util.concurrent.locks.ReentrantReadWriteLock;
import java.util.logging.Logger;

public class KVServer {

    private Communicator communicator;

    private OperationsVisitor logic;

    private DataManager dataManager;

    private static final Logger LOGGER = Logger.getLogger(KVServer.class.getName());


    /**
     * Creates a new Server, the main class
     *
     * @param communicator That shall be used for communicating with the clients
     * @param logic        To execute the operations(Library)
     * @param dataManager  Performs Operations upon the database
     */
    public KVServer(Communicator communicator, OperationsVisitor logic, DataManager dataManager) {
        this.communicator = communicator;
        this.logic = logic;
        this.dataManager = dataManager;
    }

    /**
     * Starts the Server, starts accepting connections
     */
    public void start() {
        this.communicator.start();
    }

    /**
     * Stops the Server, does this by stopping the communication module and storing all the Data
     * currently in the cache to the Disk
     */
    public void stop() {
        this.communicator.stop();
        this.dataManager.storeCompleteCacheToDisk();
    }

    /**
     * Sets the server Up using the arguments specified
     *
     * @param args The arguments, for specifics look at spec document
     * @return The Server that was created
     * @throws IOException
     */
    public static KVServer setup(String[] args) throws IOException {
        Config config = Config.parseCommandlineArgs(args);
        LogSetup.setupLogging(config.logfile.toString(), config.level);

        if (config.usagehelp) {
            config.printHelpMessage();
            System.exit(0);
        }

        CacheStrategy cacheStrategy = CacheStrategy.createCacheStrategy(config);
        DiskReadWriter diskReadWriter = new DiskReadWriter(config);
        DataManager dataManager = new PersistentDataManager(cacheStrategy, diskReadWriter);
        ReentrantReadWriteLock readWriteLock = new ReentrantReadWriteLock();

        OperationsVisitor logic = new KVServerLogic(dataManager, readWriteLock);

        Communicator communicator = new Communicator(config, logic, new ServerSocket());

        KVServer server = new KVServer(communicator, logic, dataManager);

        Runtime.getRuntime().addShutdownHook(new Thread() {
            @Override
            public void run() {
                server.stop();
            }
        });

        LOGGER.info("Sucessfully started Server on Port:" + config.port);

        return server;
    }

    /**
     * Main method creates a server using the args
     *
     * @param args for the Server
     * @throws IOException
     */
    public static void main(String[] args) throws IOException {
        setup(args).start();
    }

}
