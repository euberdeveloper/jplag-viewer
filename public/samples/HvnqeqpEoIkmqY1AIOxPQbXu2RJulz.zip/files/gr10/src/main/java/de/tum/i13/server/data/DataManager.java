package de.tum.i13.server.data;

import de.tum.i13.server.logic.operations.DeleteOperation;
import de.tum.i13.server.logic.operations.GetOperation;
import de.tum.i13.server.logic.operations.PutOperation;
import de.tum.i13.server.logic.responses.Response;

public interface DataManager {

    /**
     * Performs a given getOperation
     *
     * @param getOperation contains the key for the Operation
     * @return a GetResponse, dependent on the result of the Operation (Sucess or Error)
     */
    public Response get(GetOperation getOperation);

    /**
     * Performs a given putOperation
     *
     * @param putOperation contains the key value pair for the Operation
     * @return a putResponse, dependent on the result of the Operation (Sucess or Update or Error)
     */
    public Response put(PutOperation putOperation);

    /**
     * Performs a given deleteOperation
     *
     * @param deleteOperation contains the key for the Opearation
     * @return a deleteResponse, dependent on the result of the Operation(Sucess or Error)
     */
    public Response delete(DeleteOperation deleteOperation);

    /**
     * Stores the complete cache to the Disk, for shutting down the Server
     */
    public void storeCompleteCacheToDisk();
}
