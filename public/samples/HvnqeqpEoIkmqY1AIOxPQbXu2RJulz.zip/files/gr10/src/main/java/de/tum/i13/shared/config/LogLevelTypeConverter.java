package de.tum.i13.shared.config;

import picocli.CommandLine;

import java.util.logging.Level;

public class LogLevelTypeConverter implements CommandLine.ITypeConverter<Level> {

    @Override
    public Level convert(String s) throws Exception {
        try{
            return Level.parse(s);
        } catch (IllegalArgumentException iae) {
            throw new CommandLine.TypeConversionException("LogLevel \"" + s + "\" is unknown.");
        }
    }
}
