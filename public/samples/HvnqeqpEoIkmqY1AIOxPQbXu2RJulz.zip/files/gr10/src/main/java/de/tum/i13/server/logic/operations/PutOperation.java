package de.tum.i13.server.logic.operations;

import de.tum.i13.server.logic.OperationsVisitor;
import de.tum.i13.server.logic.responses.Response;

public class PutOperation extends Operation {

    private String key;

    private String value;

    public PutOperation(String key, String value) {
        this.key = key;
        this.value = value;
    }

    @Override
    public void execute(OperationsVisitor visitor) {
        visitor.execute(this);
    }

    public String getKey() {
        return this.key;
    }

    public String getValue() {
        return this.value;
    }

}
