package de.tum.i13.server.logic.responses;

public class PutUpdateResponse extends KeyResponse {
    public PutUpdateResponse(String key) {
        super(key);
    }

    @Override
    public String toString() {
        return "put_update " + this.getKey();
    }
}
