package de.tum.i13.server.logic;

import de.tum.i13.client.communication.Communicator;
import de.tum.i13.server.data.DataManager;
import de.tum.i13.server.logic.operations.DeleteOperation;
import de.tum.i13.server.logic.operations.GetOperation;
import de.tum.i13.server.logic.operations.InvalidOperation;
import de.tum.i13.server.logic.operations.PutOperation;
import de.tum.i13.server.logic.responses.ErrorResponse;
import de.tum.i13.server.logic.responses.Response;

import java.util.concurrent.locks.ReentrantReadWriteLock;
import java.util.logging.Logger;


public class KVServerLogic implements OperationsVisitor {

    private DataManager dataManager;

    private ReentrantReadWriteLock readWriteLock;

    private static final Logger LOGGER = Logger.getLogger(KVServerLogic.class.getName());


    /**
     * Creates a new KVServerLogic that executes the Operations sent by the Server and
     * administrates the Locks
     *
     * @param dataManager   That perfoms the Operations on the Database
     * @param readWriteLock The lock for Operating upon the Database
     */
    public KVServerLogic(DataManager dataManager, ReentrantReadWriteLock readWriteLock) {
        this.dataManager = dataManager;
        this.readWriteLock = readWriteLock;
    }

    /**
     * Performs the given Delete operation
     *
     * @param deleteOperation with the key that should be deleted and holds the Response
     */
    @Override
    public void execute(DeleteOperation deleteOperation) {
        LOGGER.info("Trying to delete key: " + deleteOperation.getKey());
        this.readWriteLock.writeLock().lock();
        Response response = this.dataManager.delete(deleteOperation);
        this.readWriteLock.writeLock().unlock();

        deleteOperation.setResponse(response);
    }

    /**
     * Performs the given Get operation
     *
     * @param getOperation with the key that should be got and holds the Response
     */
    @Override
    public void execute(GetOperation getOperation) {
        LOGGER.info("Trying to get key: " + getOperation.getKey());
        this.readWriteLock.readLock().lock();
        Response response = this.dataManager.get(getOperation);
        this.readWriteLock.readLock().unlock();

        getOperation.setResponse(response);
    }

    /**
     * Performs the given Put operation
     *
     * @param putOperation with the key value pair that shall be inserted or updated and holds
     *                     Response
     */
    @Override
    public void execute(PutOperation putOperation) {
        LOGGER.info("Trying to put key: " + putOperation.getKey() + ",with value: " + putOperation.getValue());
        this.readWriteLock.writeLock().lock();
        Response response = this.dataManager.put(putOperation);
        this.readWriteLock.writeLock().unlock();
        putOperation.setResponse(response);
    }

    /**
     * Handling of an Invalid operation
     *
     * @param invalidOperation the Operation and an Error that includes the command that was given
     */
    @Override
    public void execute(InvalidOperation invalidOperation) {
        invalidOperation.setResponse(new ErrorResponse(invalidOperation.getDescription()));
    }

}
