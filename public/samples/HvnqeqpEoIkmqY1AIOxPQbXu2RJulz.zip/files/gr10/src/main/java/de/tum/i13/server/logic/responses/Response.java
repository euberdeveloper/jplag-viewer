package de.tum.i13.server.logic.responses;

public interface Response {


}
