package de.tum.i13.server.data.cache.strategy;

import de.tum.i13.server.data.cache.exceptions.CacheMissException;

import java.util.*;

public class LFUCacheStrategy extends CacheStrategy {

    private PriorityQueue<Map.Entry<String, Map.Entry<String, Integer>>> priorityQueue;

    public LFUCacheStrategy(int cacheSize) {
        super(cacheSize);
        this.priorityQueue = new PriorityQueue<>(11, new LFUPairComparator());
    }

    @Override
    public String getValueFromCache(String key) throws CacheMissException {
        for (Map.Entry<String, Map.Entry<String, Integer>> entry : this.priorityQueue) {
            if (entry.getKey().equals(key)) {
                Map.Entry<String, Map.Entry<String, Integer>> updatedEntry =
                        new AbstractMap.SimpleEntry<>(key, new AbstractMap.SimpleEntry<>(entry.getValue().getKey(), entry.getValue().getValue() + 1));
                priorityQueue.remove(entry);
                priorityQueue.add(updatedEntry);
                return updatedEntry.getValue().getKey();
            }
        }
        throw new CacheMissException();
    }

    @Override
    public void setValueInCache(String key, String value) throws CacheMissException {
        for (Map.Entry<String, Map.Entry<String, Integer>> entry : this.priorityQueue) {
            if (entry.getKey().equals(key)) {
                Map.Entry<String, Map.Entry<String, Integer>> updatedEntry =
                        new AbstractMap.SimpleEntry<>(key, new AbstractMap.SimpleEntry<>(value, entry.getValue().getValue() + 1));
                priorityQueue.remove(entry);
                priorityQueue.add(updatedEntry);
                return;
            }
        }
        throw new CacheMissException();
    }

    @Override
    public Map.Entry<String, String> addEntryToCache(String key, String value) {
        Map.Entry<String, Map.Entry<String, Integer>> newEntry = new AbstractMap.SimpleEntry<>(key, new AbstractMap.SimpleEntry<>(value, 0));
        Map.Entry<String, Map.Entry<String, Integer>> displacedEntry = null;

        if (this.priorityQueue.size() >= this.getCacheSize()) {
            displacedEntry = this.priorityQueue.poll();
        }
        this.priorityQueue.add(newEntry);

        if (displacedEntry == null) {
            return null;
        }
        return new AbstractMap.SimpleEntry<>(displacedEntry.getKey(), displacedEntry.getValue().getKey());
    }

    @Override
    public void deleteFromCache(String key) throws CacheMissException {
        for (Map.Entry<String, Map.Entry<String, Integer>> entry : this.priorityQueue) {
            if (entry.getKey().equals(key)) {
                this.priorityQueue.remove(entry);
                return;
            }
        }
        throw new CacheMissException();
    }

    @Override
    public List<Map.Entry<String, String>> getAllEntriesFromCache() {
        List<Map.Entry<String, String>> list = new LinkedList<>();
        for (Map.Entry<String, Map.Entry<String, Integer>> entry : this.priorityQueue) {
            list.add(new AbstractMap.SimpleEntry<>(entry.getKey(), entry.getValue().getKey()));
        }
        return list;
    }

    public PriorityQueue<Map.Entry<String, Map.Entry<String, Integer>>> getPriorityQueue() {
        return this.priorityQueue;
    }
}

class LFUPairComparator implements Comparator<Map.Entry<String, Map.Entry<String, Integer>>> {

    public int compare(Map.Entry<String, Map.Entry<String, Integer>> entry1, Map.Entry<String, Map.Entry<String, Integer>> entry2) {
        if(entry1.getValue().getValue() < entry2.getValue().getValue())  {
            return -1;
        }

        else if (entry1.getValue().getValue().equals(entry2.getValue().getValue())) {
            return 0;
        }
        else {
            return 1;
        }
    }

}

