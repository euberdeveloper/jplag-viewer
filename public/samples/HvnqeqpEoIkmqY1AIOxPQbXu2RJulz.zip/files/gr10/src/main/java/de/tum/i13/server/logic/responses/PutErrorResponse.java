package de.tum.i13.server.logic.responses;

public class PutErrorResponse extends KeyValueResponse {
    public PutErrorResponse(String key, String value) {
        super(key, value);
    }

    @Override
    public String toString() {
        return "put_error " + this.getKey() + " " + this.getValue();
    }
}
