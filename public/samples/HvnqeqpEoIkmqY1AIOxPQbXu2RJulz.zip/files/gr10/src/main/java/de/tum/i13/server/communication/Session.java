package de.tum.i13.server.communication;

import de.tum.i13.server.logic.OperationsVisitor;
import de.tum.i13.server.logic.operations.Operation;
import de.tum.i13.shared.Constants;

import java.io.*;
import java.net.Socket;
import java.util.logging.Logger;

/**
 * This class signifies the Thread that is used per connection
 */
public class Session implements Runnable {

    private Socket socket;

    private OperationsVisitor logic;

    private ServerParser parser;

    private ServerSerializer serializer;

    private Communicator communicator;

    private Logger LOGGER = Logger.getLogger(Session.class.getName());

    public Session(Socket socket, OperationsVisitor logic, ServerParser parser, ServerSerializer serializer, Communicator communicator) {
        this.socket = socket;
        this.logic = logic;
        this.parser = parser;
        this.serializer = serializer;
        this.communicator = communicator;
    }


    /**
     * This method takes the Input from a Client and calls the appropriate Operations to the input
     */
    @Override
    public void run() {
        LOGGER.info("Starting new session");
        try {
            BufferedReader in = new BufferedReader(new InputStreamReader(this.socket.getInputStream(), Constants.TELNET_ENCODING));
            PrintWriter out = new PrintWriter(new OutputStreamWriter(this.socket.getOutputStream(), Constants.TELNET_ENCODING));

            printWelcomeMessage();

            String firstLine;
            while ((firstLine = in.readLine()) != null) {
                LOGGER.info("received new input command: \"" + firstLine + "\"");
                Operation operation = this.parser.parse(firstLine);
                if (operation == null) {
                    continue;
                }
                operation.execute(logic);

                out.write(serializer.serialize(operation.getResponse()));
                out.flush();
            }
        } catch (IOException ioe) {
            LOGGER.severe(ioe.getMessage());
        }
        this.stop();
    }

    private void printWelcomeMessage() {
        PrintWriter out = null;
        try {
            out = new PrintWriter(new OutputStreamWriter(this.socket.getOutputStream(), Constants.TELNET_ENCODING));
        } catch (IOException ioException) {
            LOGGER.severe(ioException.getMessage());
        }

        out.write("Connection to KV-Server established: " + this.socket.getInetAddress() + ":" + this.socket.getPort() + "\r\n");
        out.flush();
    }

    public void stop() {
        this.communicator.deregister(this);
        try {
            this.socket.close();
        } catch (IOException ioException) {
            LOGGER.severe(ioException.getMessage());
        }
        LOGGER.info("Stopping session");
    }
}
