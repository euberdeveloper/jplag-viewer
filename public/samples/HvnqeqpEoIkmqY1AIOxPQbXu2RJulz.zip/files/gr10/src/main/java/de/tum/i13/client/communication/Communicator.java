package de.tum.i13.client.communication;

import de.tum.i13.client.communication.out.ClientNetworkParser;
import de.tum.i13.client.communication.out.Serializer;
import de.tum.i13.client.communication.out.TCPSender;
import de.tum.i13.client.logic.ConnectCommand;
import de.tum.i13.shared.exceptions.ConnectionException;

import java.net.Socket;
import java.util.logging.Logger;

public class Communicator {

    private TCPSender tcpSender;
    private static final Logger LOGGER = Logger.getLogger(Communicator.class.getName());

    /**
     * Method to send a message via preestablished connection
     *
     * @param message To be sent
     * @return The echo from the Server
     * @throws Exception If error occurs during
     */
    public String sendAndReceive(String message) throws Exception {
        if (!isConnected()) {
            throw new ConnectionException("No active connections found");
        }

        if (message != null) {
            return tcpSender.communicate(message);
        }
        //TODO
        throw new RuntimeException();
    }

    /**
     * Connects to a Server
     *
     * @param host hostname of the Server
     * @param port
     * @throws Exception if connection can not be established
     */
    public String connect(String host, int port) throws Exception {
        if (isConnected()) {
            throw new ConnectionException("There is already an active connection");
        }
        try {
            tcpSender = createTCPSender(new Socket(host, port));
            return tcpSender.init();
        } catch (Exception e) {
            throw new RuntimeException("Failed to establish connection to " + host + " at Port " + port);
        }
    }

    private TCPSender createTCPSender(Socket socket) throws Exception {
        return new TCPSender(socket, new Serializer(), new ClientNetworkParser());
    }

    /**
     * Disconnects from the Server it is conncted to
     *
     * @throws Exception If Server connection cant be ended
     */
    public void disconnect() throws Exception {
        if (!tcpSender.isClosed()) {
            tcpSender.disconnect();
        } else {
            throw new ConnectionException("No active connections found");
        }
    }

    /**
     * Check to see if there is an active Connection
     * @return
     */
    public boolean isConnected() {
        if (tcpSender != null) {
            return !tcpSender.isClosed();
        }
        return false;
    }

    /**
     * Gives the current Connection Information
     * @return A ConnectCommand with the current Connections' hostname and port
     * @throws Exception if there is no Connection
     */
    public ConnectCommand getConnectionInfo() throws Exception {
        if (isConnected()) {
            return tcpSender.getConnection();
        }
        throw new ConnectionException("Connection not found");
    }

}
