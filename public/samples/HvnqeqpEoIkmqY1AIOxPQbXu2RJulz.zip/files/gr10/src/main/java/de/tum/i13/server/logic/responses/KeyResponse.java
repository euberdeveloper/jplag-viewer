package de.tum.i13.server.logic.responses;

public abstract class KeyResponse implements Response {

    private String key;

    public KeyResponse(String key) {
        this.key = key;
    }

    public String getKey() {
        return this.key;
    }
}
