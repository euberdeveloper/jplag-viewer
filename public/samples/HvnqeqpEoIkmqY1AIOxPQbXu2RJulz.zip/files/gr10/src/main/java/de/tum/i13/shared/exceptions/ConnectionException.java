package de.tum.i13.shared.exceptions;

public class ConnectionException extends Exception {

    public ConnectionException(String errorMessage) {
        super(errorMessage);
    }

}
