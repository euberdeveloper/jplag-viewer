package de.tum.i13.client.ui.cli;

import de.tum.i13.client.TestClient;
import de.tum.i13.client.logic.Command;
import de.tum.i13.shared.exceptions.ArgumentsException;

import java.io.*;
import java.util.List;

public class CLIInput {

    private final static String CLIENT_NAME = "EchoClient";

    private TestClient client;

    private Parser parser;

    private BufferedReader input;

    private PrintWriter out;

    public CLIInput(TestClient client, InputStream in, OutputStream out) {
        this.client = client;
        this.parser = new Parser();
        this.input = new BufferedReader(new InputStreamReader(in));
        this.out = new PrintWriter(new BufferedOutputStream(out));
    }

    /**
     * Start parsing input and execute the commands in the client
     *
     * @throws IOException
     */
    public void start() throws IOException {
        while (client.isRunning()) {
            List<String> inputTokens = this.readInput();
            Command command;
            try {
                command = this.parser.parse(inputTokens);
            } catch (ArgumentsException ae) {
                this.writeOutput(ae);
                continue;
            }

            String result = null;
            try {
                if (command != null) {
                    result = command.execute(client);
                }
            } catch (Exception e) {
                e.printStackTrace();
            }

            this.writeOutput(result);
        }
    }

    /**
     * Read a new line of input
     *
     * @return the read input split into the base command and the arguments ["baseCommand", "arg1 arg2"]
     * @throws IOException
     */
    private List<String> readInput() throws IOException {
        this.out.print(CLIENT_NAME + "> ");
        this.out.flush();
        String inputLine = input.readLine();
        return List.of(inputLine.trim().split("\\s+", 2));
    }

    /**
     * Print out the given output with each line beginning with the name of the client
     *
     * @param message the message to print
     */
    private void writeOutput(String message) {
        if (message == null || message.isEmpty()) {
            return;
        }
        String[] lines = message.trim().split("\n");
        for (String line : lines) {
            this.out.println(CLIENT_NAME + "> " + line);
        }
        this.out.flush();
    }

    /**
     * Print out the given output by the Exception
     *
     * @param e the Exception to print out
     */
    private void writeOutput(Exception e) {
        this.writeOutput(e.toString());
    }

}
