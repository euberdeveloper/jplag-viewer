package de.tum.i13.server.data.cache.exceptions;

public class CacheMissException extends Exception {
}
