package de.tum.i13.server.communication;

import de.tum.i13.client.logic.DeleteCommand;
import de.tum.i13.server.logic.KVServerLogic;
import de.tum.i13.server.logic.OperationsVisitor;
import de.tum.i13.server.logic.operations.DeleteOperation;
import de.tum.i13.server.logic.operations.GetOperation;
import de.tum.i13.server.logic.operations.PutOperation;
import de.tum.i13.server.logic.responses.DeleteSuccessResponse;
import de.tum.i13.server.logic.responses.GetSuccessResponse;
import de.tum.i13.server.logic.responses.PutSuccessResponse;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.RepeatedTest;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import org.mockito.stubbing.Answer;

import java.io.*;
import java.net.Socket;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
public class TestSession {

    @Mock
    private Socket socketMock = mock(Socket.class);

    private InputStream inputStreamMock;

    private ByteArrayOutputStream outputStreamMock;

    @Mock
    private OperationsVisitor logic = mock(OperationsVisitor.class);

    @Mock
    private Communicator communicatorMock = mock(Communicator.class);

    @InjectMocks
    private Session session;

    @BeforeEach
    public void setup() {
        this.outputStreamMock = new ByteArrayOutputStream();

        ServerParser parser = new ServerParser();
        ServerSerializer serializer = new ServerSerializer();
        this.session = new Session(socketMock, logic, parser, serializer, communicatorMock);
    }

    @AfterEach
    public void teardown() {
        doNothing().when(communicatorMock).deregister(any(Session.class));
        this.session.stop();
    }

    @Test
    public void testWelcomeMessage() {
        try {
            Mockito.when(socketMock.getInputStream()).thenReturn(new ByteArrayInputStream("".getBytes()));
            Mockito.when(socketMock.getOutputStream()).thenReturn(outputStreamMock);
        } catch (IOException ioException) {
            fail(ioException);
        }

        String[] outputLines = startSessionAndWait();

        assertEquals("Connection to KV-Server established: null:0", outputLines[0]);
    }

    @Test
    public void testGetCorrect() {
        String key = "key";
        String value = "value";
        String inputString = "get " + key + "\r\n";

        try {
            Answer<Void> answer = invocation -> {
                GetOperation operation = invocation.getArgument(0);
                operation.setResponse(new GetSuccessResponse(key, value));
                return null;
            };
            doAnswer(answer).when(logic).execute(any(GetOperation.class));

            Mockito.when(socketMock.getInputStream()).thenReturn(new ByteArrayInputStream(inputString.getBytes()));
            Mockito.when(socketMock.getOutputStream()).thenReturn(outputStreamMock);
        } catch (IOException e) {
            fail(e);
        }

        String[] outputLines = startSessionAndWait();

        assertEquals("get_success " + key + " " + value, outputLines[1]);
    }

    @Test
    public void testPutCorrect() {
        String key = "key";
        String value = "value";
        String inputString = "put " + key + " " + value;

        try {
            Answer<Void> answer = invocation -> {
                PutOperation operation = invocation.getArgument(0);
                operation.setResponse(new PutSuccessResponse(key));
                return null;
            };
            doAnswer(answer).when(logic).execute(any(PutOperation.class));

            Mockito.when(socketMock.getInputStream()).thenReturn(new ByteArrayInputStream(inputString.getBytes()));
            Mockito.when(socketMock.getOutputStream()).thenReturn(outputStreamMock);
        } catch (IOException e) {
            fail(e);
        }

        String[] outputLines = startSessionAndWait();

        assertEquals("put_success " + key, outputLines[1]);
    }

    @Test
    public void testDeleteCorrect() {
        String key = "key";
        String inputString = "delete " + key;

        try {
            Answer<Void> answer = invocation -> {
                DeleteOperation operation = invocation.getArgument(0);
                operation.setResponse(new DeleteSuccessResponse(key));
                return null;
            };
            doAnswer(answer).when(logic).execute(any(DeleteOperation.class));

            Mockito.when(socketMock.getInputStream()).thenReturn(new ByteArrayInputStream(inputString.getBytes()));
            Mockito.when(socketMock.getOutputStream()).thenReturn(outputStreamMock);
        } catch (IOException e) {
            fail(e);
        }

        String[] outputLines = startSessionAndWait();

        assertEquals("delete_success " + key, outputLines[1]);
    }

    private String[] startSessionAndWait() {
        Thread t = new Thread(this.session);
        t.start();

        try {
            Thread.sleep(100);
        } catch (InterruptedException e) {
            fail(e);
        }

        return outputStreamMock.toString().split("\r\n");
    }


}
