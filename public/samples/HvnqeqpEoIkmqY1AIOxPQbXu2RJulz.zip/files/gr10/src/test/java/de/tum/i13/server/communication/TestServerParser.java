package de.tum.i13.server.communication;

import de.tum.i13.server.logic.operations.*;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestInstance;

import java.util.Base64;

import static org.junit.jupiter.api.Assertions.*;

@TestInstance(TestInstance.Lifecycle.PER_CLASS)
public class TestServerParser {

    private ServerParser parser;

    @BeforeAll
    public void initialSetup() {
        this.parser = new ServerParser();
    }

    @Test
    public void testStringNull() {
        String input = null;
        Operation operation = parser.parse(input);
        assertNull(operation);
    }

    @Test
    public void testStringEmpty() {
        String input = "";
        Operation operation = parser.parse(input);
        assertNull(operation);
    }

    @Test
    public void testPutCorrect() {
        String key = "key";
        String value = Base64.getEncoder().encodeToString("value".getBytes());
        String input = "put " + key + " " + value;

        Operation operation = parser.parse(input);
        assertNotNull(operation);
        assertEquals(PutOperation.class, operation.getClass());

        assertEquals(key, ((PutOperation) operation).getKey());
        assertEquals(value, ((PutOperation) operation).getValue());
    }

    @Test
    public void testPutNotEnoughArgs() {
        String key = "key";
        String value = "";
        String input = "put " + key + " " + Base64.getEncoder().encodeToString(value.getBytes());

        Operation operation = parser.parse(input);
        assertNotNull(operation);
        assertEquals(InvalidOperation.class, operation.getClass());

        assertEquals("The put operation takes exactly two arguments",
                ((InvalidOperation) operation).getDescription());
    }

    @Test
    public void testPutArgContainsSpace() {
        String key = "key";
        String value = Base64.getEncoder().encodeToString("va lue".getBytes());
        String input = "put " + key + " " + value;

        Operation operation = parser.parse(input);
        assertNotNull(operation);
        assertEquals(PutOperation.class, operation.getClass());

        assertEquals(key, ((PutOperation) operation).getKey());
        assertEquals(value, ((PutOperation) operation).getValue());
    }

    @Test
    public void testPutArgContainsLineBreak() {
        String key = "key";
        String value = Base64.getEncoder().encodeToString("va\nlue".getBytes());
        String input = "put " + key + " " + value;

        Operation operation = parser.parse(input);
        assertNotNull(operation);
        assertEquals(PutOperation.class, operation.getClass());

        assertEquals(key, ((PutOperation) operation).getKey());
        assertEquals(value, ((PutOperation) operation).getValue());
    }

    @Test
    public void testGetCorrect() {
        String key = "key";
        String input = "get " + key;

        Operation operation = parser.parse(input);
        assertNotNull(operation);
        assertEquals(GetOperation.class, operation.getClass());

        assertEquals(key, ((GetOperation) operation).getKey());
    }

    @Test
    public void testGetNoArgs() {
        String key = "";
        String input = "get " + key;

        Operation operation = parser.parse(input);
        assertNotNull(operation);
        assertEquals(InvalidOperation.class, operation.getClass());

        assertEquals("The get operation takes exactly one argument",
                ((InvalidOperation) operation).getDescription());
    }

    @Test
    public void testGetWithoutAnyArgs() {
        String input = "get";

        Operation operation = parser.parse(input);
        assertNotNull(operation);
        assertEquals(InvalidOperation.class, operation.getClass());

        assertEquals("The get operation takes exactly one argument",
                ((InvalidOperation) operation).getDescription());
    }

    @Test
    public void testGetTooManyArgs() {
        String key = "key1 key2";
        String input = "get " + key;

        Operation operation = parser.parse(input);
        assertNotNull(operation);
        assertEquals(InvalidOperation.class, operation.getClass());

        assertEquals("The get operation takes exactly one argument",
                ((InvalidOperation) operation).getDescription());
    }

    @Test
    public void testDeleteCorrect() {
        String key = "key";
        String input = "delete " + key;

        Operation operation = parser.parse(input);
        assertNotNull(operation);
        assertEquals(DeleteOperation.class, operation.getClass());

        assertEquals(key, ((DeleteOperation) operation).getKey());
    }

    @Test
    public void testDeleteTooManyArgs() {
        String key = "key1 key2";
        String input = "delete " + key;

        Operation operation = parser.parse(input);
        assertNotNull(operation);
        assertEquals(InvalidOperation.class, operation.getClass());

        assertEquals("The delete operation takes exactly one argument",
                ((InvalidOperation) operation).getDescription());
    }

    @Test
    public void testUnknownOperation() {
        String input = "foo bar bla";

        Operation operation = parser.parse(input);
        assertNotNull(operation);
        assertEquals(InvalidOperation.class, operation.getClass());

        assertEquals("Unknown operation \"" + input + "\". Please refer to the supported operations",
                ((InvalidOperation) operation).getDescription());
    }

}
