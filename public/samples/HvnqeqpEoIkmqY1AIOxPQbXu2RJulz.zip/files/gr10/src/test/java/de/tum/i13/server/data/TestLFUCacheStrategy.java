package de.tum.i13.server.data;

import de.tum.i13.server.data.cache.exceptions.CacheMissException;
import de.tum.i13.server.data.cache.strategy.LFUCacheStrategy;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.util.AbstractMap;

import static org.junit.jupiter.api.Assertions.*;

public class TestLFUCacheStrategy {

    private LFUCacheStrategy lfuCacheStrategy;

    @BeforeEach
    public void setup() {
        this.lfuCacheStrategy = new LFUCacheStrategy(2);
    }

    @AfterEach
    public void teardown() {
    }

    @Test
    public void testGetValueFromCacheCorrect() {
        String value = null;
        this.lfuCacheStrategy.addEntryToCache("foo", "bar");
        try {
            value = this.lfuCacheStrategy.getValueFromCache("foo");
        } catch (Exception e) {
            fail(e);
        }

        assertEquals("bar", value);
        assertEquals(1, this.lfuCacheStrategy.getPriorityQueue().size());
        assertEquals(1, this.lfuCacheStrategy.getPriorityQueue().peek().getValue().getValue());
    }

    @Test
    public void testGetValueFromCacheKeyNotInCache() {
        this.lfuCacheStrategy.addEntryToCache("not foo", "bar");

        CacheMissException thrown = assertThrows(CacheMissException.class, () -> this.lfuCacheStrategy.getValueFromCache("foo"));
        assertNull(thrown.getMessage());
        assertEquals(1, this.lfuCacheStrategy.getPriorityQueue().size());
        assertEquals(new AbstractMap.SimpleEntry<>("not foo", new AbstractMap.SimpleEntry<>("bar", 0)), this.lfuCacheStrategy.getPriorityQueue().peek());
    }

    @Test
    public void testGetValueFromCacheEmptyCache() {
        CacheMissException thrown = assertThrows(CacheMissException.class, () -> this.lfuCacheStrategy.getValueFromCache("foo"));
        assertNull(thrown.getMessage());
        assertEquals(0, this.lfuCacheStrategy.getPriorityQueue().size());
    }

    @Test
    public void testAddEntryToCacheWithoutDisplacedEntry() {
        assertNull(this.lfuCacheStrategy.addEntryToCache("foo1", "bar"));
        try {
            assertEquals("bar", lfuCacheStrategy.getValueFromCache("foo1"));
        } catch (Exception e) {
            fail(e);
        }

        assertEquals(new AbstractMap.SimpleEntry<>("foo1", new AbstractMap.SimpleEntry<>("bar", 1)), this.lfuCacheStrategy.getPriorityQueue().peek());

        assertNull(this.lfuCacheStrategy.addEntryToCache("foo2", "barbar"));

        try {
            assertEquals("barbar", lfuCacheStrategy.getValueFromCache("foo2"));
        } catch (Exception e) {
            fail(e);
        }

        assertEquals(new AbstractMap.SimpleEntry<>("foo1", new AbstractMap.SimpleEntry<>("bar", 1)), this.lfuCacheStrategy.getPriorityQueue().peek());
    }

    @Test
    public void testAddEntryToCacheWithDisplacedEntry() {
        assertNull(this.lfuCacheStrategy.addEntryToCache("foo1", "bar"));

        try {
            assertEquals("bar", lfuCacheStrategy.getValueFromCache("foo1"));
        } catch (Exception e) {
            fail(e);
        }

        assertEquals(new AbstractMap.SimpleEntry<>("foo1", new AbstractMap.SimpleEntry<>("bar", 1)), this.lfuCacheStrategy.getPriorityQueue().peek());
        assertNull(this.lfuCacheStrategy.addEntryToCache("foo2", "barbar"));

        try {
            assertEquals("barbar", lfuCacheStrategy.getValueFromCache("foo2"));
        } catch (Exception e) {
            fail(e);
        }

        assertEquals(new AbstractMap.SimpleEntry<>("foo1", new AbstractMap.SimpleEntry<>("bar", 1)), this.lfuCacheStrategy.getPriorityQueue().peek());
        assertEquals(new AbstractMap.SimpleEntry("foo1", "bar"), this.lfuCacheStrategy.addEntryToCache("foo3", "barbarbar"));
        assertEquals(new AbstractMap.SimpleEntry<>("foo3", new AbstractMap.SimpleEntry<>("barbarbar", 0)), this.lfuCacheStrategy.getPriorityQueue().peek());

        try {
            assertEquals("barbarbar", lfuCacheStrategy.getValueFromCache("foo3"));
        } catch (Exception e) {
            fail(e);
        }
    }
}
