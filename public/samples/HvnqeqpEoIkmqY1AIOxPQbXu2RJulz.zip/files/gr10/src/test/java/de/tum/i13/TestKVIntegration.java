package de.tum.i13;

import de.tum.i13.client.TestClient;
import de.tum.i13.client.communication.Communicator;
import de.tum.i13.client.ui.cli.CLIInput;
import de.tum.i13.server.KVServer;
import org.junit.jupiter.api.*;

import java.io.*;
import java.util.Arrays;
import java.util.HashSet;
import java.util.Set;

import static org.junit.jupiter.api.Assertions.*;

@TestInstance(TestInstance.Lifecycle.PER_CLASS)
public class TestKVIntegration {

    public static Integer port = 5153;
    private static Set<String> keySet;
    private static KVServer server;
    private TestClient client1;
    private TestClient client2;

    @BeforeAll
    public void initialSetup() throws InterruptedException {
        keySet = new HashSet<>(Arrays.asList("foo1", "foo2", "foo3"));

        Thread th = new Thread() {
            @Override
            public void run() {
                try {
                    server = KVServer.setup(new String[]{"-p" + port.toString()});
                    server.start();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        };
        th.start(); // started the server
        Thread.sleep(1000);

        Communicator communicator1 = new Communicator();
        this.client1 = new TestClient(communicator1);

        Communicator communicator2 = new Communicator();
        this.client2 = new TestClient(communicator2);
    }

    @BeforeEach
    public void testSetup() throws IOException {
        String command = "connect localhost " + port;
        for (String key : keySet) {
            command += "\n put " + key;
        }
        command += "\n disconnect";
        doRequest(client1, command);

    }

    @AfterAll
    public static void finalTeardown() {
        server.stop();
    }


    public String doRequest(TestClient client, String req) {
        ByteArrayOutputStream output = new ByteArrayOutputStream();
        CLIInput cliInput = new CLIInput(client, new ByteArrayInputStream(req.getBytes()), output);

        Thread th = new Thread() {
            @Override
            public void run() {
                try {
                    cliInput.start();
                } catch (IOException | NullPointerException e) {
                }
            }
        };
        th.start();
        try {
            Thread.sleep(100);
        } catch (InterruptedException e) {
            fail(e);
        }

        return output.toString();
    }

    @Test
    public void testConnect() {
        String command = "connect localhost " + port + "\n";
        String[] outputLines = doRequest(client1, command).split("\n");

        assertTrue(outputLines[0].contains("EchoClient> Connection to KV-Server established: /127.0.0.1:"));
    }

    @Test
    public void testDisconnect() {
        String command = "connect localhost " + port;
        command += "\ndisconnect";

        String[] outputLines = doRequest(client1, command).split("\n");
        assertTrue(outputLines[1].contains("Connection terminated: localhost / "));
    }

    @Test
    public void testPutAndGet() throws IOException {
        String key = "foo1";
        String value = "bar";
        String command = "connect localhost " + port + "\r\n";

        command += String.format("put %s %s\r\n", key, value);
        command += String.format("get %s\r\n ", key);

        String[] outputLines = doRequest(client1, command).split("\n");
        assertTrue(outputLines[1].contains(String.format("EchoClient> put_success %s", key)));
        assertTrue(outputLines[2].contains(String.format("EchoClient> get_success %s %s", key, value)));
    }

    @Test
    public void testPutAsUpdate() throws IOException {
        String key = "foo1";
        String valueOld = "bar";
        String valueNew = "barbar";
        String command = "connect localhost " + port;

        command += String.format("\r\nput %s %s", key, valueOld);
        command += String.format("\r\nget %s", key);
        command += String.format("\r\nput %s %s", key, valueNew);
        command += String.format("\r\nget %s", key);

        String[] outputLines = doRequest(client1, command).split("\n");
        assertTrue(outputLines[1].contains(String.format("EchoClient> put_success %s", key)));
        assertTrue(outputLines[2].contains(String.format("EchoClient> get_success %s %s", key, valueOld)));
        assertTrue(outputLines[3].contains(String.format("EchoClient> put_update %s", key)));
        assertTrue(outputLines[4].contains(String.format("EchoClient> get_success %s %s", key, valueNew)));
    }

    @Test
    public void testGetNonexistentKey() throws IOException {
        String key = "foo1";
        String command = "connect localhost " + port;

        command += String.format("\r\nget %s", key);
        String[] outputLines = doRequest(client1, command).split("\n");
        assertTrue(outputLines[1].contains(String.format("EchoClient> get_error %s", key)));
    }

    @Test
    public void testDelete() {
        String key = "foo1";
        String value = "bar";
        String command = "connect localhost " + port;
        command += String.format("\nput %s %s", key, value);
        command += String.format("\nget %s", key);
        command += String.format("\nput %s", key);
        command += String.format("\nget %s", key);
        command += String.format("\nput %s %s", key, value);

        String[] outputLines = doRequest(client1, command).split("\n");

        assertTrue(outputLines[1].contains(String.format("EchoClient> put_success %s", key)));
        assertTrue(outputLines[2].contains(String.format("EchoClient> get_success %s %s", key, value)));
        assertTrue(outputLines[3].contains(String.format("EchoClient> delete_success %s", key)));
        assertTrue(outputLines[4].contains(String.format("EchoClient> get_error %s", key)));
        assertTrue(outputLines[5].contains(String.format("EchoClient> put_success %s", key)));
    }

    @Test
    public void testPutAndGet2Clients() throws InterruptedException, IOException {
        String key = "foo1";
        String value = "bar";
        String command = "connect localhost " + port;

        command += String.format("\r\nput %s %s", key, value);
        String[] outputLines = doRequest(client1, command).split("\n");
        assertTrue(outputLines[1].contains(String.format("put_success %s", key)));

        command = "connect localhost " + port;
        command += String.format("\r\nget %s", key);
        outputLines = doRequest(client2, command).split("\n");
        assertTrue(outputLines[1].contains(String.format("get_success %s %s", key, value)));
    }

    @Test
    public void testConflictingPut() throws InterruptedException, IOException {
        String key = "foo1";
        String value1 = "bar";
        String value2 = "barbar";
        String command = "connect localhost " + port;

        command += String.format("\r\nput %s %s", key, value1);
        String[] outputLines = doRequest(client1, command).split("\n");
        assertTrue(outputLines[1].contains(String.format("put_success %s", key)));


        command = "connect localhost " + port;
        command += String.format("\r\nput %s %s", key, value2);
        outputLines = doRequest(client2, command).split("\n");
        assertTrue(outputLines[1].contains(String.format("put_update %s", key)));


        command = "connect localhost " + port;
        command += String.format("\r\nget %s", key);
        outputLines = doRequest(client1, command).split("\n");
        assertTrue(outputLines[1].contains(String.format("get_success %s %s", key, value2)));
    }

    @Test
    public void testConflictingGetAndDelete() throws InterruptedException, IOException {
        String key = "foo1";
        String value = "bar";
        String command = "connect localhost " + port;
        command += String.format("\nput %s %s", key, value);

        String[] outputLines1 = doRequest(client1, command).split("\n");
        assertTrue(outputLines1[1].contains(String.format("EchoClient> put_success %s", key)));

        command = "connect localhost " + port;
        command += String.format("\nput %s", key);

        String[] outputLines2 = doRequest(client2, command).split("\n");
        assertTrue(outputLines2[1].contains(String.format("EchoClient> delete_success %s", key)));

        command = String.format("get %s", key);
        String[] outputLines3 = doRequest(client1, command).split("\n");
        assertTrue(outputLines3[0].contains(String.format("EchoClient> get_error %s", key)));
    }

    @Test
    public void testUnknownCommandResponse() throws IOException {
        String command = "random input";

        String[] outputLines = doRequest(client1, command).split("\n");

        assertTrue(outputLines[0].contains("EchoClient> " + command + " : Unknown command"));

    }
}
