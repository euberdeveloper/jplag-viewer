package de.tum.i13.server.data;

import de.tum.i13.server.data.DataManager;
import de.tum.i13.server.data.PersistentDataManager;
import de.tum.i13.server.data.cache.strategy.CacheStrategy;
import de.tum.i13.server.data.cache.strategy.FIFOCacheStrategy;
import de.tum.i13.server.data.disk.DiskReadWriter;
import de.tum.i13.server.logic.operations.DeleteOperation;
import de.tum.i13.server.logic.operations.PutOperation;
import de.tum.i13.server.logic.responses.*;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;

import java.io.IOException;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.mock;

public class TestPersistentDataManager {

    @Mock
    private DiskReadWriter diskReadWriterMock = mock(DiskReadWriter.class);

    @InjectMocks
    private PersistentDataManager dataManager;


    @BeforeEach
    public void setup() {
        this.dataManager = new PersistentDataManager(new FIFOCacheStrategy(2), diskReadWriterMock);
        try {
            Mockito.when(diskReadWriterMock.read(any(String.class))).thenReturn(null);
            Mockito.when(diskReadWriterMock.write(any(String.class), any(String.class))).thenReturn(false);
            Mockito.when(diskReadWriterMock.delete(any(String.class))).thenReturn(true);
        } catch (IOException ioe) {
            ioe.printStackTrace();
        }
    }

    @AfterEach
    public void teardown() {
    }

    @Test
    public void testPutSuccessResponse() {
        Response response = this.dataManager.put(new PutOperation("key", ""));

        assertEquals(PutSuccessResponse.class, response.getClass());
    }

    @Test
    public void testPutUpdateResponse() {
        this.dataManager.put(new PutOperation("key", ""));
        Response response = this.dataManager.put(new PutOperation("key", ""));

        assertEquals(PutUpdateResponse.class, response.getClass());
    }

    @Test
    public void testDiskInteractionsOnCachedValueUpdate() {
        this.dataManager.put(new PutOperation("key", ""));
        this.dataManager.put(new PutOperation("key", ""));
        try {
            Mockito.verify(this.diskReadWriterMock).write("key", "");
        } catch (IOException ioe) {
            ioe.printStackTrace();
        }
    }

    @Test
    public void testDeleteNotFound() {
        try {
            Mockito.when(this.diskReadWriterMock.delete("key")).thenReturn(false);
        } catch (IOException ioe) {
            ioe.printStackTrace();
        }
        Response response = this.dataManager.delete(new DeleteOperation("key"));

        assertEquals(DeleteErrorResponse.class, response.getClass());
    }

    @Test
    public void testDeleteSuccessfulFromDisk() {
        try {
            Mockito.when(this.diskReadWriterMock.delete("key")).thenReturn(true);
        } catch (IOException ioe) {
            ioe.printStackTrace();
        }
        Response response = this.dataManager.delete(new DeleteOperation("key"));

        assertEquals(DeleteSuccessResponse.class, response.getClass());
    }

}
