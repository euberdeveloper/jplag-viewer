package de.tum.i13.client;

import de.tum.i13.client.communication.Communicator;
import de.tum.i13.client.logic.*;
import de.tum.i13.shared.LogSetup;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import picocli.CommandLine;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.mock;

public class TestClientTest {

    @Mock
    private Communicator communicator = mock(Communicator.class);
    @Mock
    private LogSetup logSetup = mock(LogSetup.class);

    @InjectMocks
    private TestClient client;

    @BeforeEach
    public void setup() {
        this.client = new TestClient(communicator);
    }

    @Test
    public void testConnect() {
        try {
            Mockito.when(communicator.connect("127.0.0.1", 1337)).thenReturn("Connected");
        } catch (Exception e) {
            fail(e.getMessage());
        }
        ConnectCommand connectCommand = new ConnectCommand("127.0.0.1", 1337);
        String s = "";
        try {
            s = client.execute(connectCommand);
        } catch (Exception e) {
            fail(e.getMessage());
        }
        assertTrue(s.equals("Connected"));
    }

    @Test
    public void testDisconnect() {
        ConnectCommand c = new ConnectCommand("127.0.0.1", 1337);
        try {
            Mockito.when(communicator.getConnectionInfo()).thenReturn(c);
            doNothing().when(communicator).disconnect();
        } catch (Exception e) {
            fail(e.getMessage());
        }
        String s = "";
        try {
            s = client.execute(new DisconnectCommand());
        } catch (Exception e) {
            fail(e.getMessage());
        }
        assertTrue(s.equals("Connection terminated: " + c.getHostname() + " / " + c.getPort()));
    }

    @Test
    public void testHelp() {
        HelpCommand help = new HelpCommand();
        String s = client.execute(help);
        assertTrue(s.equals(help.getHelpMessage()));
    }

    @Test
    public void testQuit() {
        QuitCommand quitCommand = new QuitCommand();
        Mockito.when(communicator.isConnected()).thenReturn(true);
        try {
            doNothing().when(communicator).disconnect();
        } catch (Exception e) {
            fail(e.getMessage());
        }
        String s = "";
        try {
            s = client.execute(quitCommand);
        } catch (Exception e) {
            fail(e.getMessage());
        }
        assertTrue(s.equals("Application exit!"));
        assertFalse(client.isRunning());
    }

    @Test
    public void testPut() {
        PutCommand put = new PutCommand("foo", "bar");
        try {
            Mockito.when(communicator.sendAndReceive(put.toString())).thenReturn(put.getKey() + " " + put.getValue());
        } catch (Exception e) {
            fail(e);
        }
        String s = "";
        try {
            s = client.execute(put);
        } catch (Exception e) {
            fail(e);
        }
        assertTrue(s.equals(put.getKey() + " " + put.getValue()));
    }

    @Test
    public void testGet() {
        GetCommand get = new GetCommand("foo");
        try {
            Mockito.when(communicator.sendAndReceive("get foo")).thenReturn("bar");
        } catch (Exception e) {
            fail(e.getMessage());
        }
        String s = "";
        try {
            s = client.execute(get);
        } catch (Exception e) {
            fail(e.getMessage());
        }
        assertTrue(s.equals("bar"));
    }

    @Test
    public void testDelete() {
        DeleteCommand del = new DeleteCommand("foo");
        try {
            Mockito.when(communicator.sendAndReceive("delete foo")).thenReturn("deleted");
        } catch (Exception e) {
            fail(e.getMessage());
        }
        String s = "";
        try {
            s = client.execute(del);
        } catch (Exception e) {
            fail(e.getMessage());
        }
        assertTrue(s.equals("deleted"));
    }


}
