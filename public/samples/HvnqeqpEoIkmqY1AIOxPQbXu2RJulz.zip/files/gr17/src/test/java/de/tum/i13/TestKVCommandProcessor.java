package de.tum.i13;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import org.junit.jupiter.api.Test;

import de.tum.i13.server.kv.KVCommandProcessor;
import de.tum.i13.shared.kv.KVMessage;
import de.tum.i13.shared.kv.KVMessageImplementation;
import de.tum.i13.shared.kv.KVStore;

public class TestKVCommandProcessor {

	KVStore kv = mock(KVStore.class);

	@Test
	public void correctHandlingOfWrongInput() throws Exception {
		KVCommandProcessor kvcp = new KVCommandProcessor(kv);
		String command = "arbitrary command key value";
		String result = kvcp.process(command);

		verify(kv, never()).get("key");
		verify(kv, never()).put("key", "value");
		assertEquals(result, "error invalid input: " + command + "\r\n");
	}

	@Test
	public void correctParsingOfGet() throws Exception {
		KVMessage expectedReturnValue = new KVMessageImplementation("key", "hello", KVMessage.StatusType.GET_SUCCESS);
		when(kv.get("key")).thenReturn(expectedReturnValue);
		KVCommandProcessor kvcp = new KVCommandProcessor(kv);
		String result = kvcp.process("get key");

		verify(kv).get("key");
		assertEquals(result, expectedReturnValue.toString() + "\r\n");
	}

	@Test
	public void correctParsingOfPut() throws Exception {
		KVMessage expectedReturnValue = new KVMessageImplementation("key", "hello", KVMessage.StatusType.PUT_SUCCESS);
		when(kv.put("key", "hello")).thenReturn(expectedReturnValue);
		KVCommandProcessor kvcp = new KVCommandProcessor(kv);
		String result = kvcp.process("put key hello");

		verify(kv).put("key", "hello");
		assertEquals(result, expectedReturnValue.toString() + "\r\n");
	}
}
