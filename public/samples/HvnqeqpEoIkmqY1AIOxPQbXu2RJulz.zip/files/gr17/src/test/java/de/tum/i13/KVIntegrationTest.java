package de.tum.i13;

import static org.hamcrest.CoreMatchers.equalTo;
import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.MatcherAssert.assertThat;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.InetSocketAddress;
import java.net.Socket;

import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;

import de.tum.i13.shared.kv.KVMessage;
import de.tum.i13.shared.kv.KVMessageImplementation;

public class KVIntegrationTest {

	public static Integer port = 5153;

	private static Thread serverThread;

	@BeforeAll
	public static void setUpServer() {
		serverThread = new Thread() {
			@Override
			public void run() {
				try {
					de.tum.i13.server.nio.StartSimpleNioServer.main(new String[] { "-p", port.toString() });
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
		};
		serverThread.start(); // started the server
	}

	@AfterAll
	public static void tearDownServer() {
		serverThread.interrupt();
	}

	@Test
	public void connectionAndWelcomeMessageTest() throws InterruptedException, IOException {
		Thread.sleep(2000);

		Socket s = new Socket();
		s.connect(new InetSocketAddress("127.0.0.1", port));
		assertThat(doRequest(""), is(equalTo("Connected to 127.0.0.1:" + port)));
		s.close();

	}

	public String doRequest(Socket s, String req) throws IOException {
		PrintWriter output = new PrintWriter(s.getOutputStream());
		BufferedReader input = new BufferedReader(new InputStreamReader(s.getInputStream()));

		output.write(req + "\r\n");
		output.flush();

		String res = input.readLine();
		return res;
	}

	public String doRequest(String req) throws IOException {
		Socket s = new Socket();
		s.connect(new InetSocketAddress("127.0.0.1", port));
		String res = doRequest(s, req);
		s.close();

		return res;
	}

	@Test
	public void massGetNonExistingKeyTest() throws IOException, InterruptedException {
		Thread.sleep(2000);
		for (int tcnt = 0; tcnt < 2; tcnt++) {
			final int finalTcnt = tcnt;
			new Thread() {
				@Override
				public void run() {
					try {
						Thread.sleep(finalTcnt * 100);
					} catch (InterruptedException e) {
						e.printStackTrace();
					}
					try {
						for (int i = 0; i < 100; i++) {
							Socket s = new Socket();
							s.connect(new InetSocketAddress("127.0.0.1", port));

							// Check Welcome Message
							String expextedResult = "Connected to 127.0.0.1:" + port;
							assertThat(doRequest(s, ""), is(equalTo(expextedResult)));

							// Try getting a non existant key
							String command = "get nonExistingKey";
							expextedResult = new KVMessageImplementation("nonExistingKey", null,
									KVMessage.StatusType.GET_ERROR).toString();
							assertThat(doRequest(s, command), is(equalTo(expextedResult)));
							s.close();
						}
					} catch (Exception e) {
						e.printStackTrace();
					}
				}
			}.start();
		}
	}
}
