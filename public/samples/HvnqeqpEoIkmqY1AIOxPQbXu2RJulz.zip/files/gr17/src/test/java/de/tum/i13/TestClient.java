package de.tum.i13;

import static de.tum.i13.client.Application.executeGet;
import static de.tum.i13.client.Application.executePut;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.PrintStream;

import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import de.tum.i13.client.Application;
import de.tum.i13.client.kv.KVStoreApplication;
import de.tum.i13.shared.kv.KVMessage;
import de.tum.i13.shared.kv.KVMessage.StatusType;

public class TestClient {

	private static KVStoreApplication kvstore = new KVStoreApplication();
	private static final PrintStream standardOut = System.out;
	private static final ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
	private static Thread serverThread;
	private static final Integer port = 5153;

	/**
	 * Generate a key that is unique for every test run.
	 */
	private static String getUniqueKey() {
		long ut2 = System.currentTimeMillis();
		return String.valueOf(ut2);
	}

	@BeforeAll
	public static void init() throws IOException {
		serverThread = new Thread() {
			@Override
			public void run() {
				try {
					de.tum.i13.server.nio.StartSimpleNioServer.main(new String[] { "-p", port.toString() });
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
		};
		serverThread.start();
		kvstore.connect("localhost", port);
	}

	@AfterAll
	public static void shutDown() {
		Application.executeDisconnect();
		serverThread.interrupt();
	}

	@BeforeEach
	public void insertPair() {
		kvstore.put("name", "bob");
	}

	@BeforeEach
	public void setUpConsole() {
		System.setOut(new PrintStream(outputStream));
		kvstore.put("name", "bob");
	}

	@AfterEach
	public void tearDown() {
		System.setOut(standardOut);
	}

	@Test
	public void testDeleteError() {
		KVMessage response = kvstore.put(getUniqueKey(), null);
		assertEquals(StatusType.DELETE_ERROR, response.getStatus());
	}

	@Test
	public void testDeleteSuccess() {
		KVMessage response = kvstore.put("name", "");
		assertEquals(StatusType.DELETE_SUCCESS, response.getStatus());
	}

	@Test
	public void testEncodedLengthGet() {
		String[] tokens = { "get", "Herearealotofcharssssssss" };
		executeGet(tokens);
		assertTrue(outputStream.toString().contains("Error! Invalid input for get, incorrect size of key."));
	}

	@Test
	public void testGet() {
		KVMessage response = kvstore.get("name");
		assertEquals("bob", response.getValue());
	}

	@Test
	public void testGetError() {
		assertEquals(StatusType.GET_ERROR, kvstore.get("ebrfn").getStatus());
	}

	@Test
	public void testIncorrectFormPut() {
		String command = "put   n   ";
		executePut(command);
		assertTrue(outputStream.toString().contains("Incorrect form"));
	}

	@Test
	public void testInputWithOneWhitespacePut() {
		String command = "put ";
		executePut(command);
		assertTrue(outputStream.toString().contains("incorrect number of arguments"));
	}

	@Test
	public void testNrArgGet() {
		String[] tokens = { "get", "name", "number" };
		executeGet(tokens);
		assertTrue(outputStream.toString().contains("Error! Invalid input for get, incorrect number of arguments."));
	}

	@Test
	public void testPutInsert() {
		KVMessage response = kvstore.put(getUniqueKey(), "fdsxeetfgv");
		assertEquals(StatusType.PUT_SUCCESS, response.getStatus());
	}

	@Test
	public void testPutUpdate() {
		KVMessage response = kvstore.put("name", "alice");
		assertEquals(StatusType.PUT_UPDATE, response.getStatus());
	}

	@Test
	public void testSecondWhitespaceLastIndexPut() {
		String command = "put hello ";
		executePut(command);
		assertTrue(outputStream.toString().contains("Incorrect form"));
	}

	@Test
	public void testSizeKeyPut() {
		String command = "put herearealotofcharssssssss hello";
		executePut(command);
		assertTrue(outputStream.toString().contains("Invalid input for put, incorrect size of arguments."));
	}

	@Test
	public void testSizeValuePut() {
		String command = "put key ";
		for (int i = 1; i <= 60001; i++) {
			command += "b";
		}
		executePut(command);
		assertTrue(outputStream.toString().contains("Invalid input for put, incorrect size of arguments."));
	}
}
