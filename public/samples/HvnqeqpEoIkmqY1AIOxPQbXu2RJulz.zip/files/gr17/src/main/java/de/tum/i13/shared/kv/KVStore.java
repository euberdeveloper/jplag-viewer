package de.tum.i13.shared.kv;

public interface KVStore {

	/**
	 * Retrieves the value for a given key from the KVServer.
	 *
	 * @param key
	 *        the key that identifies the value.
	 * @return the value, which is indexed by the given key.
	 */
	public KVMessage get(String key);

	/**
	 * Inserts a key-value pair into the KVServer.
	 *
	 * @param key
	 *        the key that identifies the given value.
	 * @param value
	 *        the value that is indexed by the given key.
	 * @return a message that confirms the insertion of the tuple or an error.
	 */
	public KVMessage put(String key, String value);

}
