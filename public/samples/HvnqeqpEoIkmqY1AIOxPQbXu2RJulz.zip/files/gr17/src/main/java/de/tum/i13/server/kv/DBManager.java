package de.tum.i13.server.kv;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.logging.Logger;

import de.tum.i13.server.nio.StartSimpleNioServer;
import de.tum.i13.shared.kv.KVMessage;
import de.tum.i13.shared.kv.KVMessageImplementation;

/**
 * this class is managing access to the persistent storage
 *
 * @author Group 17
 */
public class DBManager {

	/**
	 * represents path of the data file
	 */
	private String file;

	private BufferedReader br;
	private BufferedWriter bw;

	private Logger logger = Logger.getLogger(StartSimpleNioServer.class.getName());

	public DBManager(String file) {
		this.file = file;
	}

	/**
	 * this method deletes a specific value in the persistent storage
	 *
	 * @param key
	 *        the method will search the persistent storage for this key and delete
	 *        it with the corresponding value
	 * @return a KVMessage object containing DELETE_SUCCESS if deletion succeeded or
	 *         DELETE_ERROR if failed
	 * @throws IOException
	 */
	public KVMessage delete(String key) throws IOException {
		logger.info("delete method is running");

		try {
			br = new BufferedReader(new FileReader(file));
		} catch (FileNotFoundException e) {
			logger.warning("no file found to delete from");
			return new KVMessageImplementation(key, null, KVMessage.StatusType.DELETE_ERROR);
		}

		logger.info("reading from data");

		HashMap<String, String> fileMap = new HashMap<>();

		boolean updated = false;

		String k, v;
		String deletedValue = null;
		while ((k = br.readLine()) != null) {
			v = br.readLine();

			if (k.equals(key)) {
				deletedValue = v;
				updated = true;
			} else {
				fileMap.put(k, v);
			}
		}
		br.close();

		if (updated) {
			logger.info("found value to delete");

			bw = new BufferedWriter(new FileWriter(file));
			for (String i : fileMap.keySet()) {
				bw.write(i + "\n" + fileMap.get(i) + "\n");
			}

			bw.close();

			logger.info("value deleted");

			return new KVMessageImplementation(key, deletedValue, KVMessage.StatusType.DELETE_SUCCESS);
		}

		logger.warning("no value found to delete");

		return new KVMessageImplementation(key, null, KVMessage.StatusType.DELETE_ERROR);
	}

	/**
	 * this method searches for a specific value in the persistent storage
	 *
	 * @param key
	 *        the method will search the persistent storage for this key and return
	 *        it with the corresponding value
	 * @return a KVMessage object containing the value and GET_SUCCESS if value
	 *         found or GET_ERROR without value if not found
	 * @throws IOException
	 */
	public KVMessage get(String key) throws IOException {
		logger.info("get method is running");

		try {
			br = new BufferedReader(new FileReader(file));
		} catch (FileNotFoundException e) {
			logger.warning("no file found to read from");
			return new KVMessageImplementation(key, null, KVMessage.StatusType.GET_ERROR);
		}

		logger.info("reading from data");
		String k, v;
		while ((k = br.readLine()) != null) {
			v = br.readLine();

			if (k.equals(key)) {
				br.close();
				logger.info("found value");
				return new KVMessageImplementation(key, v, KVMessage.StatusType.GET_SUCCESS);
			}
		}
		br.close();
		logger.warning("no value found");
		return new KVMessageImplementation(key, null, KVMessage.StatusType.GET_ERROR);
	}

	/**
	 * this method stores/updates a specific value in the persistent storage
	 *
	 * @param key
	 *        the key for storing/updating the value
	 * @param value
	 *        the value to be stored/updated
	 * @return a KVMessage object containing PUT_SUCCESS if storing succeeded or
	 *         PUT_UPDATE if existing value was updated
	 * @throws IOException
	 */
	public KVMessage put(String key, String value) throws IOException {
		logger.info("running put method");

		try {
			br = new BufferedReader(new FileReader(file));
		} catch (FileNotFoundException e) {
			logger.info("file not found, creating new file");

			bw = new BufferedWriter(new FileWriter(file));

			bw.write(key + "\n" + value + "\n");

			bw.close();

			logger.info("created new file and stored value");

			return new KVMessageImplementation(key, value, KVMessage.StatusType.PUT_SUCCESS);
		}

		HashMap<String, String> fileMap = new HashMap<>();

		boolean updated = false;

		logger.info("reading file");

		String k, v;
		while ((k = br.readLine()) != null) {
			v = br.readLine();

			if (k.equals(key)) {
				fileMap.put(key, value);

				updated = true;
			} else {
				fileMap.put(k, v);
			}
		}
		br.close();

		if (updated) {
			logger.info("key already exists");

			bw = new BufferedWriter(new FileWriter(file));

			for (String i : fileMap.keySet()) {
				bw.write(i + "\n" + fileMap.get(i) + "\n");
			}

			bw.close();

			logger.info("value updated");
			return new KVMessageImplementation(key, value, KVMessage.StatusType.PUT_UPDATE);
		}
		bw = new BufferedWriter(new FileWriter(file, true));

		bw.write(key + "\n" + value + "\n");

		bw.close();

		logger.info("stored value");

		return new KVMessageImplementation(key, value, KVMessage.StatusType.PUT_SUCCESS);
	}

	/**
	 * This method flushes the cache and saves any cached values persitently.
	 * <P>
	 * 22.11.2020
	 *
	 * @throws IOException
	 */
	public void shutDown(LinkedHashMap<String, String> cache) throws IOException {
		for (String k : cache.keySet()) {
			put(k, cache.get(k));
		}
	}
}