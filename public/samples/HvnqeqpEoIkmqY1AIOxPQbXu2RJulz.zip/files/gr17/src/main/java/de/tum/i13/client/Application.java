package de.tum.i13.client;

import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.util.Base64;
import java.util.logging.Level;
import java.util.logging.Logger;

import de.tum.i13.client.kv.KVStoreApplication;
import de.tum.i13.shared.Constants;
import de.tum.i13.shared.kv.KVMessage;

/**
 * The application logic is implemented in this class. It uses an object of the
 * KVStoreApplication class for communication with a kv server.
 * 
 * @author Gruppe 17
 *
 *         08.11.2020
 *
 */

public class Application {

	/**
	 * The string that precedes any line in the console. For the MS 2, no base for
	 * output is specified. For the sake of reusability for future milestones, the
	 * base is changed to an empty string instead of being removed completely.
	 */
	public static final String BASE = "";

	private static KVStoreApplication kvStore = new KVStoreApplication();

	/**
	 * The Logger object is declared here again for ease of access.
	 */
	public final static Logger LOGGER = Logger.getLogger(Client.class.getName());
	/**
	 * Flag whether the application is currently running or not.
	 */
	private static boolean isRunning = true;

	/**
	 * This method is executed when the logLevel command is issued. If the user
	 * inputs an invalid log level he will be notified and the log level doesn't
	 * change.
	 * <P>
	 * 07.11.2020
	 *
	 * @param tokens
	 *        the tokenized input from the user (including both the command and the
	 *        arguments)
	 */
	private static void adjustLogLevel(String[] tokens) {
		if (tokens.length != 2) {
			invalidInput(String.format(" for %s, incorrect number of arguments. Expected 1 but got %d",
					Constants.LOGLEVEL_COMMAND, tokens.length - 1), tokens);
			return;
		}
		try {
			Level previous = LOGGER.getLevel();
			// In case of receiving the log level failing, the parent logger is checked and
			// if still no log level can be determined, it is assumed the level was
			// Level.ALL
			if (previous == null) {
				previous = LOGGER.getParent().getLevel();
			}
			if (previous == null) {
				previous = Level.ALL;
			}
			LOGGER.setLevel(Level.parse(tokens[1]));
			String output = String.format("Log level set from %s to %s", previous.toString(), tokens[1]);
			LOGGER.info(output);
			printToConsole(output);
		} catch (IllegalArgumentException e) {
			invalidInput(String.format(" for %s, argument %s is invalid", Constants.LOGLEVEL_COMMAND, tokens[1]),
					tokens);
		}
	}

	/**
	 * This method returns the length of a string in bytes when encoded with the
	 * given encoding (Telnet).
	 * <P>
	 * 15.11.2020
	 *
	 * @param s
	 *        the string which length should be returned
	 * @return the length of the string in bytes
	 * @throws UnsupportedEncodingException
	 *         In case the string contains characters not supported by the encoding
	 */
	private static int encodedLengthKey(String s) throws UnsupportedEncodingException {
		return s.getBytes(Constants.TELNET_ENCODING).length;
	}

	/**
	 * This method returns the length of a string in bytes when encoded with the
	 * given encoding (Base64).
	 * <P>
	 * 17.11.2020
	 *
	 * @param s
	 *        the string which length should be returned
	 * @return the length of the string in bytes
	 * @throws UnsupportedEncodingException
	 *         In case the string contains characters not supported by the encoding
	 */
	private static int encodedLengthValue(String s) {
		return Base64.getEncoder().encode(s.getBytes()).length;

	}

	/**
	 * This method splits the input read from the command line into tokens and
	 * checks if the first token is a valid command. If yes, it passes the entire
	 * input to the respective method where error handling concerning the rest of
	 * the input is performed.
	 * <P>
	 * 06.11.2020
	 *
	 * @param command
	 *        the input from the user (including both the command and the arguments)
	 */
	public static void executeCommand(String command) {
		// Skip blank input lines (common CLI feature)
		if (command.isBlank()) {
			return;
		}
		// Remove unnecessary spaces
		String[] tokens = sanitize(command.split(" "));

		switch (tokens[0]) {
		case Constants.CONNECT_COMMAND:
			executeConnect(tokens);
			break;
		case Constants.DISCONNECT_COMMAND:
			executeDisconnect(tokens);
			break;
		case Constants.PUT_COMMAND:
			executePut(command);
			break;
		case Constants.GET_COMMAND:
			executeGet(tokens);
			break;
		case Constants.HELP_COMMAND:
			printHelp(tokens);
			break;
		case Constants.LOGLEVEL_COMMAND:
			adjustLogLevel(tokens);
			break;
		case Constants.QUIT_COMMAND:
			quit();
			break;
		default:
			printToConsole("Error! Unknown command: " + command);
			printHelp();
		}
	}

	/**
	 * This method is executed when the connect command is issued. If an established
	 * connection already exists, it is terminated automatically before the new one
	 * is established.
	 * <P>
	 * 07.11.2020
	 *
	 * @param tokens
	 *        the tokenized input from the user (including both the command and the
	 *        arguments)
	 */
	private static void executeConnect(String[] tokens) {
		if (tokens.length != 3) {
			invalidInput(String.format(" for %s, incorrect number of arguments. Expected 2 but got %d",
					Constants.CONNECT_COMMAND, tokens.length - 1), tokens);
			return;
		}
		if (kvStore.isConnected()) {
			executeDisconnect();
		}
		try {
			int port = Integer.parseInt(tokens[2]);

			byte[] answer = kvStore.connect(tokens[1], port);

			String recvMsg = new String(answer, Constants.TELNET_ENCODING).stripTrailing();
			LOGGER.info(String.format("Connection established to %s:%s; received message %s", tokens[1], tokens[2],
					recvMsg));
			printToConsole(recvMsg);
		} catch (NumberFormatException e) {
			invalidInput(String.format(" for %s, portnumber %s is invalid", Constants.CONNECT_COMMAND, tokens[2]),
					tokens);
		} catch (IOException e) {
			String output = String.format("Error! Unable to connect to %s:%s", tokens[1], tokens[2]);
			LOGGER.warning(output + "; " + e.toString());
			printToConsole(output);
		}
	}

	/**
	 * As other methods need the disconnect method as well, this method simulates a
	 * valid execution of the disconnect command from the user. This eliminates the
	 * need of adding the confusing argument, which consists of an array with just
	 * one element, where the disconnect method is called internally.
	 * <P>
	 * 08.11.2020
	 *
	 */
	public static void executeDisconnect() {
		executeDisconnect(new String[] { Constants.DISCONNECT_COMMAND });
	}

	/**
	 * This method is executed when the disconnect command is issued. If there is no
	 * current connection to terminate the user gets notified.
	 * <P>
	 * 07.11.2020
	 *
	 * @param tokens
	 *        the tokenized input from the user (including both the command and the
	 *        arguments)
	 */
	private static void executeDisconnect(String[] tokens) {
		if (tokens.length != 1) {
			invalidInput(String.format(" for %s, incorrect number of arguments. Expected 0 but got %d",
					Constants.DISCONNECT_COMMAND, tokens.length - 1), tokens);
			return;
		}
		if (!kvStore.isConnected()) {
			LOGGER.warning("Tried to disconnect, but no connection was established beforehand.");
			printToConsole("No established connection to terminate.");
			return;
		}
		String lastHost = kvStore.getHost();
		int lastPort = kvStore.getPort();
		try {
			kvStore.disconnect();
		} catch (IOException e) {
			String output = "Error during disconnect";
			LOGGER.warning(output + "; " + e.toString());
			printToConsole(output);
			return;
		}
		// For consistency, the format for the server stays host:port, unlike the
		// example in the assignment (host / port)
		String output = String.format("Connection terminated %s:%d", lastHost, lastPort);
		LOGGER.info(output);
		printToConsole(output);
	}

	/**
	 * This method is executed when the GET command is issued. The user must give
	 * only one argument which contains the key. The encoded key size can't be greater
	 * than 20 Byte. If no connection is established the user is notified. In order to
	 * pass the GET-request on to the server, this method calls the get method on
	 * the kvStore object
	 * <P>
	 * 18.11.2020
	 *
	 * @param tokens
	 *        the tokenized input from the user (including both the command and the
	 *        key)
	 */
	public static void executeGet(String[] tokens) {
		if (tokens.length != 2) {
			invalidInput(String.format(" for %s, incorrect number of arguments. Expected 1 but got %d",
					Constants.GET_COMMAND, tokens.length - 1), tokens);
			return;
		}
		if (!kvStore.isConnected()) {
			LOGGER.warning(String.format("Tried to execute %s without established connection.", Constants.GET_COMMAND));
			printToConsole("Error! Not connected!");
			return;
		}
		String key = tokens[1];
		try {
			if (encodedLengthKey(key) > Constants.MAX_KEY_SIZE) {
				invalidInput(String.format(
						" for %s, incorrect size of key. The allowed max key size is %d bytes but given key is %d bytes long",
						Constants.GET_COMMAND, Constants.MAX_KEY_SIZE, encodedLengthKey(key)), tokens);
				return;
			}
		} catch (UnsupportedEncodingException e) {
			invalidInput(String.format(" for %s. The key contains characters that are not supported by the %s encoding",
					Constants.GET_COMMAND, Constants.TELNET_ENCODING), tokens);
			return;
		}

		KVMessage response = kvStore.get(key);
		if (response.getStatus() == KVMessage.StatusType.GET_SUCCESS) {
			printToConsole(response.getValue());
		} else {
			printToConsole("Error! Could not receive value for key " + response.getKey());
		}
	}

	/**
	 * This method is executed when the PUT command is issued. If no connection is
	 * established the user is notified. The key must contain at least one character
	 * (no whitespace). The encoded key size is at most 20 Byte and the encoded
	 * value size is at most 120 KByte. If the value is empty (== "") it sends a
	 * delete command to the server. In order to pass the put-request on to the
	 * server, this method invokes the put-method on to the kvStore object.
	 * <P>
	 * 18.11.2020
	 *
	 * @param command
	 *        the input from the user
	 */
	public static void executePut(String command) {
		if (!kvStore.isConnected()) {
			LOGGER.warning(String.format("Tried to execute %s without established connection.", Constants.PUT_COMMAND));
			printToConsole("Error! Not connected!");
			return;
		}

		String key = "";
		String value = "";
		boolean deleteCommand = false;
		String[] tokens = command.split(" ");

		if (tokens.length < 2) {
			invalidInput(String.format(" for %s, incorrect number of arguments", Constants.PUT_COMMAND),
					new String[] { command });
			return;
		}

		int space1 = command.indexOf(' ');
		int space2 = command.indexOf(' ', space1 + 1);

		// put used as a delete command example: "put key"
		if (space2 == -1) {
			key = command.substring(space1 + 1);
			value = "";
			deleteCommand = true;
		}

		// when value ex: "put key value" or "put key "
		if (space2 == space1 + 1 || space2 == command.length() - 1) {
			printToConsole("Incorrect form of put-command.");
			LOGGER.warning("Incorrect form of put-command.");
			printHelp();
			return;
		}

		if (!deleteCommand) {
			key = command.substring(space1 + 1, space2);
			value = command.substring(space2 + 1);
		}

		try {
			if (encodedLengthKey(key) > Constants.MAX_KEY_SIZE
					|| encodedLengthValue(value) > Constants.MAX_VALUE_SIZE) {
				invalidInput(String.format(
						" for %s, incorrect size of arguments. Expected max size of key %d Byte and max size of value %d Byte but got %d Byte and %d Byte",
						Constants.PUT_COMMAND, Constants.MAX_KEY_SIZE, Constants.MAX_VALUE_SIZE, encodedLengthKey(key),
						encodedLengthValue(value)), new String[] { command });
				return;
			}
		} catch (UnsupportedEncodingException e) {
			invalidInput(String.format(
					" for %s, the key or value contains characters not supported by the %s or Base64 encoding.",
					Constants.PUT_COMMAND, Constants.TELNET_ENCODING), new String[] { command });
			return;
		}

		KVMessage msg = kvStore.put(key, value);
		printToConsole(msg.getStatus() == KVMessage.StatusType.PUT_ERROR
				|| msg.getStatus() == KVMessage.StatusType.DELETE_ERROR ? "ERROR" : "SUCCESS");
	}

	/**
	 * Whenever the user tries to issue an invalid command or a valid command with
	 * invalid arguments this method informs the user and prints the help message.
	 * <P>
	 * 08.11.2020
	 *
	 * @param extraMsg
	 *        more information concerning the invalid input
	 * @param tokens
	 *        the tokenized input from the user (including both the command and the
	 *        arguments)
	 */
	private static void invalidInput(String extraMsg, String[] tokens) {
		String output = String.format("Error! Invalid input%s, input was: %s", extraMsg, String.join(" ", tokens));
		LOGGER.warning(output);
		printToConsole(output);
		printHelp();
	}

	/**
	 * Returns whether the application is still running. Once the user issues the
	 * quit command this method returns false
	 * <P>
	 * 08.11.2020
	 *
	 * @return true if and only if the application hasn't been terminated yet by the
	 *         user.
	 */
	public static boolean isRunning() {
		return isRunning;
	}

	/**
	 * As other methods need the printHelp method as well, this method simulates a
	 * valid execution of the help command from the user. This eliminates the need
	 * of adding the confusing argument, which consists of an array with just one
	 * element (the valid help command), where the printHelp method is called
	 * internally.
	 * <P>
	 * 08.11.2020
	 *
	 */
	private static void printHelp() {
		printHelp(new String[] { Constants.HELP_COMMAND });
	}

	/**
	 * This method prints a help message to the console with a detailed description
	 * of all valid commands the user can issue.
	 * <P>
	 * 08.11.2020
	 *
	 */
	private static void printHelp(String[] tokens) {
		if (tokens.length != 1) {
			invalidInput(String.format(" for %s, incorrect number of arguments. Expected 0 but got %d",
					Constants.HELP_COMMAND, tokens.length - 1), tokens);
			return;
		}
		printToConsole("---------------Help---------------");
		printToConsole("Connect to an KV server and issue any of the following commands");
		printToConsole("List of commands:");
		printToConsole(String.format(
				"\t%s <hostname> <port> : connects to the specified host and port. If a connection was already established, it is terminated before connecting to the specified host",
				Constants.CONNECT_COMMAND));
		printToConsole(String.format("\t%s : terminates the current connection", Constants.DISCONNECT_COMMAND));
		printToConsole(String.format(
				"\t%s <key> <value> : Sends a key value pair to the server or updates the current value with the given value "
						+ "if the server already contains the specified key or deletes the entry for the given key if <value> equals null."
						+ " Max size of key is %d bytes and max size of value is %d bytes.",
				Constants.PUT_COMMAND, Constants.MAX_KEY_SIZE, Constants.MAX_VALUE_SIZE));
		printToConsole(String.format(
				"\t%s <key> : Retrieves the value for the given key from the storage server. Max size of key is %d bytes.",
				Constants.GET_COMMAND, Constants.MAX_KEY_SIZE));
		printToConsole(String.format("\t%s : displays this message", Constants.HELP_COMMAND));
		printToConsole(String.format(
				"\t%s <logLevel> : changes the log level to the specified one. Valid options are SEVERE, WARNING, INFO, CONFIG, FINE, FINER, FINEST and ALL",
				Constants.LOGLEVEL_COMMAND));
		printToConsole(String.format("\t%s : Terminates any current connection and exits the program execution",
				Constants.QUIT_COMMAND));
		printToConsole("----------------------------------");
	}

	/**
	 * This method prints a message to the console with the preceding base for
	 * output. In MS 2, no base is specified, so this method is a little bit
	 * redundant, but in case it is needed in future milestones, it is not deleted
	 * completely.
	 * <P>
	 * 08.11.2020
	 *
	 * @param msg
	 *        the message that should be shown on screen
	 */
	public static void printToConsole(String msg) {
		System.out.println(BASE + msg);
	}

	/**
	 * This method terminates any active connection and exits the program execution.
	 * <P>
	 * 08.11.2020
	 */
	private static void quit() {
		if (kvStore.isConnected()) {
			executeDisconnect();
		}
		LOGGER.info("Exited application succesfully.");
		printToConsole("Application exit!");

		isRunning = false;
	}

	/**
	 * This method removes excess spaces between arguments, that are represented by
	 * empty Strings once the input is tokenized. Therefore, any command can be
	 * issued with as much spaces as the user (accidentally) puts between arguments
	 * or before the command. An exception to this rule is the send command, where
	 * every character after the first "send " (with a single space) is considered
	 * part of the message. However, spaces before the send command will still be
	 * ignored. This is only done for the sake of the application being as user
	 * friendly as possible.
	 * <P>
	 * 08.11.2020
	 *
	 * @param tokens
	 *        the tokenized input from the user
	 * @return the tokens without any empty strings
	 */
	private static String[] sanitize(String[] tokens) {
		int numNonEmptyArgs = 0;
		for (String s : tokens) {
			if (s != null && !s.equals("")) {
				numNonEmptyArgs++;
			}
		}
		String[] result = new String[numNonEmptyArgs];
		numNonEmptyArgs = 0;
		for (String s : tokens) {
			if (s != null && !s.equals("")) {
				result[numNonEmptyArgs++] = s;
			}
		}
		return result;
	}
}
