package de.tum.i13.server.kv.memorymanager;

import java.nio.file.Path;
import java.util.LinkedHashMap;

/**
 * This class implements the LRU displacement strategy. The HashMap that caches
 * the values is set to order the values in access order (true in the
 * constructor), therefore a normal get() operation retrieves the last recently
 * used value. The size of the map is set in a way that results in a good
 * tradeoff between a small space overhead and collision minimization to reduce
 * rehash operations and hence increase performance.
 * 
 * @author Gruppe 17
 *
 *         23.11.2020
 *
 */
public class LRUMemoryManager extends MemoryManager {

	public LRUMemoryManager(int cacheSize, Path dataDir) {
		super(cacheSize, dataDir);
		final float loadFactor = 0.75f;
		final int mapSize = (int) (cacheSize / loadFactor + 1);
		cache = new LinkedHashMap<>(mapSize, loadFactor, true);
	}

}
