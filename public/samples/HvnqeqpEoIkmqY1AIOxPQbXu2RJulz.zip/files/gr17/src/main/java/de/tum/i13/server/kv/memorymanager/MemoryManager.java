package de.tum.i13.server.kv.memorymanager;

import java.io.File;
import java.io.IOException;
import java.nio.file.Path;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.logging.Logger;

import de.tum.i13.server.kv.DBManager;
import de.tum.i13.server.nio.StartSimpleNioServer;
import de.tum.i13.shared.Constants;
import de.tum.i13.shared.kv.KVMessage;
import de.tum.i13.shared.kv.KVMessageImplementation;
import de.tum.i13.shared.kv.KVStore;

/**
 * This class is responsible for caching and persistently storing data.
 * 
 * @author Marc Engelmann
 *
 *         13.11.2020
 *
 */
public abstract class MemoryManager implements KVStore {

	protected static Logger logger = Logger.getLogger(StartSimpleNioServer.class.getName());

	/**
	 * A factory method that returns the correct MemoryManager object according to
	 * the command line arguments.
	 * <P>
	 * 13.11.2020
	 *
	 * @param displacementStrategy
	 *        which displacement strategy should be used
	 * @param cacheSize
	 *        the maximum amount of keys stored in the cache
	 * @param dataDir
	 *        the path to the directory in which the data file is stored
	 * @return the correct MemoryManager
	 */
	public static MemoryManager getManager(String displacementStrategy, int cacheSize, Path dataDir) {
		switch (displacementStrategy) {
		case "LRU":
			logger.info("LRU strategy chosen");
			return new LRUMemoryManager(cacheSize, dataDir);
		case "LFU":
			logger.info("LFU strategy chosen");
			return new LFUMemoryManager(cacheSize, dataDir);
		default:
			logger.info("FIFO strategy chosen");
			return new FIFOMemoryManager(cacheSize, dataDir);
		}
	}

	/**
	 * The maximum number of keys stored in the cache.
	 */
	protected final int cacheSize;

	/**
	 * the path to the directory in which the data file is stored
	 */
	protected final Path dataDir;

	/**
	 * the storage cache
	 */
	protected LinkedHashMap<String, String> cache;

	/**
	 * the DBManager for accessing the persistent storage
	 */
	protected DBManager dbm;

	public MemoryManager(int cacheSize, Path dataDir) {
		this.cacheSize = cacheSize;
		this.dataDir = dataDir;

		// The size of the map is set in a way that results in a good
		// tradeoff between a small space overhead and collision minimization to reduce
		// rehash operations and hence increase performance.
		final float loadFactor = 0.75f;
		final int mapSize = (int) (cacheSize / loadFactor + 1);
		cache = new LinkedHashMap<>(mapSize, loadFactor, false);

		dbm = new DBManager(dataDir.toString() + File.separator + Constants.SAVE_FILE_NAME);
	}

	/**
	 * this method frees space in the cache if needed and stores given key/value
	 * pair in it
	 *
	 * @param key
	 *        the key that identifies the given value
	 * @param value
	 *        the value to be stored in the cache
	 * @throws IOException
	 */
	protected void addToCache(String key, String value) throws IOException {
		while (cache.size() >= cacheSize) {
			Map.Entry<String, String> first = cache.entrySet().iterator().next();
			String keyToBeDisplaced = first.getKey();
			String valueToBeDisplaced = first.getValue();

			dbm.put(keyToBeDisplaced, valueToBeDisplaced);

			cache.remove(keyToBeDisplaced);
		}
		cache.put(key, value);
	}

	/**
	 * this method deletes given key and corresponding value from cache/storage
	 *
	 * @param key
	 *        the key that identifies the value
	 * @return a KVMessage object containing DELETE_SUCCESS if deletion succeeded or
	 *         DELETE_ERROR if failed
	 */
	public KVMessage delete(String key) {
		logger.info("delete method running");

		String v = cache.get(key);
		boolean foundInCache = false;
		if (v != null) {
			cache.remove(key);
			foundInCache = true;
			logger.info("deleted value in cache");
		}
		try {
			KVMessage result = dbm.delete(key);
			if (!foundInCache) {
				return result;
			} else {
				logger.warning("deleted value");
				return new KVMessageImplementation(key, v, KVMessage.StatusType.DELETE_SUCCESS);
			}
		} catch (IOException e) {
			logger.warning("could not delete value because of IOException");
			return new KVMessageImplementation(key, null, KVMessage.StatusType.DELETE_ERROR);
		}
	}

	/**
	 * this method searches for the value identified by given key
	 *
	 * @param key
	 *        the key that identifies the value
	 * @return a KVMessage object containing value with GET_SUCCESS if found or
	 *         GET_ERROR without value if not found
	 */
	@Override
	public KVMessage get(String key) {
		logger.info("running get method");

		String v = cache.get(key);
		if (v != null) {
			logger.info("value found in cache");
			return new KVMessageImplementation(key, v, KVMessage.StatusType.GET_SUCCESS);
		} else {
			logger.info("value not in cache");
			try {
				KVMessage msg = dbm.get(key);
				if (msg.getValue() != null) {
					logger.info("found value in database");
					addToCache(msg.getKey(), msg.getValue());
					logger.info("added value to cache");
				}
				return msg;
			} catch (IOException e) {
				logger.warning("could not get value because of IOException");
				return new KVMessageImplementation(key, null, KVMessage.StatusType.GET_ERROR);
			}
		}
	}

	/**
	 * this method stores/updates the given key/value pair
	 *
	 * @param key
	 *        the key that identifies the given value
	 * @param val
	 *        value to be stored/updated
	 * @return a KVMessage object containing PUT_SUCCESS if storing succeeded or
	 *         PUT_UPDATE if existing value was updated or PUT_ERROR if storing
	 *         failed
	 */
	@Override
	public KVMessage put(String key, String val) {
		logger.info("running put method");

		String v = cache.get(key);
		if (v != null) {
			logger.info("value found in cache");
			cache.put(key, val);
			logger.info("updated value in cache");
			return new KVMessageImplementation(key, val, KVMessage.StatusType.PUT_UPDATE);
		} else {
			logger.info("value not in cache");
			try {
				addToCache(key, val);
				logger.info("value added to cache");
				return new KVMessageImplementation(key, val, KVMessage.StatusType.PUT_SUCCESS);
			} catch (IOException e) {
				logger.warning("could not put value because of IOException");
				return new KVMessageImplementation(key, val, KVMessage.StatusType.PUT_ERROR);
			}
		}
	}

	/**
	 * This method flushes the cache and saves any cached values persitently.
	 * <P>
	 * 22.11.2020
	 *
	 * @throws IOException
	 */
	public void shutdown() throws IOException {
		dbm.shutDown(cache);
	}
}
