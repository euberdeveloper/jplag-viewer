package de.tum.i13.server.kv.memorymanager;

import java.nio.file.Path;

/**
 * This class implements the FIFO displacement strategy. The HashMap that caches
 * the values stores them in insertion order, therefore a simple get() operation
 * retrieves the oldest value.
 * 
 * @author Gruppe 17
 *
 *         23.11.2020
 *
 */
public class FIFOMemoryManager extends MemoryManager {

	public FIFOMemoryManager(int cacheSize, Path dataDir) {
		super(cacheSize, dataDir);
	}

}
