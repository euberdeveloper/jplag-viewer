package de.tum.i13.shared.kv;

/**
 * A class to instantiate KVMessage objects.
 * 
 * @author Marc Engelmann
 *
 *         13.11.2020
 *
 */
public class KVMessageImplementation implements KVMessage {

	private final String key;

	private final String val;

	private final StatusType status;

	/**
	 * In case of an unspecified error, a description can be sent back to the
	 * client.
	 */
	private String errorDescription;

	/**
	 * When an unspecified error occurs, this constructor sets all fields
	 * accordingly.
	 * 
	 * @param error
	 *        a description of the unspecified error
	 * 
	 *        13.11.2020
	 */
	public KVMessageImplementation(String error) {
		this.key = "";
		this.val = "";
		this.status = StatusType.UNSPECIFIED_ERROR;
		this.errorDescription = error;
	}

	/**
	 * In case of any other message than an unspecified error, this constructor sets
	 * all fields accordingly
	 * 
	 * @param key
	 *        the key of the key value pair belonging to this message
	 * @param val
	 *        the value of the key value pair belonging to this message
	 * @param status
	 *        the status type of this message
	 * 
	 *        13.11.2020
	 */
	public KVMessageImplementation(String key, String val, StatusType status) {
		this.key = key;
		this.val = val;
		this.status = status;
	}

	@Override
	public String getKey() {
		return key;
	}

	@Override
	public StatusType getStatus() {
		return status;
	}

	@Override
	public String getValue() {
		return val;
	}

	@Override
	public String toString() {
		if (this.status == StatusType.UNSPECIFIED_ERROR) {
			return "error " + this.errorDescription;
		}
		return this.status.toString().toLowerCase() + " " + key
				+ (this.status == StatusType.GET_SUCCESS ? " " + val : "");
	}

}
