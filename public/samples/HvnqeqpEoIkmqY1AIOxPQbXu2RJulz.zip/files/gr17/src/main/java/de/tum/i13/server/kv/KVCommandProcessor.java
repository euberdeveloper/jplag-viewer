package de.tum.i13.server.kv;

import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.util.logging.Logger;

import de.tum.i13.server.kv.memorymanager.MemoryManager;
import de.tum.i13.server.nio.StartSimpleNioServer;
import de.tum.i13.shared.CommandProcessor;
import de.tum.i13.shared.Constants;
import de.tum.i13.shared.kv.KVMessage;
import de.tum.i13.shared.kv.KVStore;

/**
 * This class handles requests received from clients.
 * 
 * @author Marc Engelmann
 *
 *         23.11.2020
 *
 */
public class KVCommandProcessor implements CommandProcessor {

	public Logger logger = Logger.getLogger(StartSimpleNioServer.class.getName());
	/**
	 * This object is responsibly for storing and receiving values.
	 */
	private KVStore kvStore;

	public KVCommandProcessor(KVStore kvStore) {
		this.kvStore = kvStore;
	}

	@Override
	public String connectionAccepted(InetSocketAddress address, InetSocketAddress remoteAddress) {
		logger.info(String.format("New connection accepted: %s <==> %s", address.toString(), remoteAddress.toString()));
		return String.format("Connected to %s:%d\r\n", address.getHostName(), address.getPort());
	}

	@Override
	public void connectionClosed(InetAddress address) {
		logger.info(String.format("Connection to %s closed\r\n", address.toString()));
	}

	private String executeDelete(String[] tokens) {
		logger.info("Delete request issued.");
		return toSendableFormat(((MemoryManager) kvStore).delete(tokens[1]));
	}

	private String executeGet(String[] tokens) {
		logger.info("Get request issued.");
		return toSendableFormat(kvStore.get(tokens[1]));
	}

	private String executePut(String command) {
		logger.info("Put request issued.");
		int space1 = command.indexOf(' ');
		int space2 = command.indexOf(' ', space1 + 1);

		String key = command.substring(space1 + 1, space2);
		String value = command.substring(space2 + 1);
		return toSendableFormat(kvStore.put(key, value));
	}

	@Override
	public String process(String command) {
		// Remove the CRLF
		command = command.replaceAll("\\r\\n", "");

		String[] tokens = command.split(" ");
		switch (tokens[0]) {
		case Constants.PUT_COMMAND:
			return executePut(command);
		case Constants.GET_COMMAND:
			return executeGet(tokens);
		case Constants.DELETE_COMMAND:
			return executeDelete(tokens);
		default:
			logger.warning("Unrecognized command received: " + command.strip());
			return toSendableFormat("error invalid input: " + command.strip());
		}

	}

	/**
	 * All responses from the server have to end with a CRLF, this method ensures
	 * this.
	 * <P>
	 * 23.11.2020
	 *
	 * @param msg
	 *        the response from the server
	 * @return the response with a CRLF
	 */
	public String toSendableFormat(KVMessage msg) {
		return msg.toString() + "\r\n";
	}

	/**
	 * All responses from the server have to end with a CRLF, this method ensures
	 * this.
	 * <P>
	 * 23.11.2020
	 *
	 * @param msg
	 *        the response from the server
	 * @return the response with a CRLF
	 */
	public String toSendableFormat(String msg) {
		return msg + "\r\n";
	}

}
