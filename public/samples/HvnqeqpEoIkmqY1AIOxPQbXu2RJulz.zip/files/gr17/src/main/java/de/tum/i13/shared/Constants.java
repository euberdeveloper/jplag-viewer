package de.tum.i13.shared;

public class Constants {
	public static final String TELNET_ENCODING = "ISO-8859-1"; // encoding for telnet

	/**
	 * The maximum length of a key in bytes.
	 */
	public static int MAX_KEY_SIZE = 20;

	/**
	 * The maximum length of a value in bytes.
	 */
	public static int MAX_VALUE_SIZE = 120000;

	/**
	 * Command that can only be sent by issuing the put <key> command without a
	 * value.
	 */
	public static final String DELETE_COMMAND = "delete";

	/**
	 * Commands the user can issue.
	 */
	public static final String QUIT_COMMAND = "quit";
	public static final String CONNECT_COMMAND = "connect";
	public static final String DISCONNECT_COMMAND = "disconnect";
	public static final String HELP_COMMAND = "help";
	public static final String LOGLEVEL_COMMAND = "logLevel";
	public static final String GET_COMMAND = "get";
	public static final String PUT_COMMAND = "put";

	/**
	 * Responses the server can send back to the client when the put command is
	 * issued from the client
	 */
	public static final String PUT_SUCCESS = "put_success";
	public static final String PUT_ERROR = "put_error";
	public static final String PUT_UPDATE = "put_update";
	public static final String DELETE_SUCCESS = "delete_success";
	public static final String DELETE_ERROR = "delete_error";

	/**
	 * The name of the file in which the data is persistently stored.
	 */
	public static final String SAVE_FILE_NAME = "data.txt";

}
