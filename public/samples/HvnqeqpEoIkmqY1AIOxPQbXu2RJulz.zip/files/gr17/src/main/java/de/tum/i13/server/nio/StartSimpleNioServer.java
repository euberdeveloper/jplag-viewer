package de.tum.i13.server.nio;

import static de.tum.i13.shared.Config.parseCommandlineArgs;
import static de.tum.i13.shared.LogSetup.setupLoggingNew;

import java.io.IOException;
import java.util.logging.Handler;
import java.util.logging.Logger;

import de.tum.i13.server.kv.KVCommandProcessor;
import de.tum.i13.server.kv.memorymanager.MemoryManager;
import de.tum.i13.shared.CommandProcessor;
import de.tum.i13.shared.Config;

/**
 * This class starts the NIO server.
 * 
 * @author Gruppe 17
 *
 *         20.11.2020
 *
 */
public class StartSimpleNioServer {

	public static Logger logger = Logger.getLogger(StartSimpleNioServer.class.getName());

	public static void main(String[] args) throws IOException {
		Config cfg = parseCommandlineArgs(args); // Do not change this
		setupLoggingNew(cfg.logfile);
		logger.info("Config: " + cfg.toString());

		if (cfg.usagehelp) {
			logger.info("Help message was displayed, terminated server.");
			Config.printhelp();
			System.exit(0);
		}

		logger.setLevel(cfg.logLevel);
		logger.info("Set log level to " + cfg.logLevel + ".");

		MemoryManager mm = MemoryManager.getManager(cfg.displacementStrategy, cfg.cacheSize, cfg.dataDir);
		CommandProcessor kvLogic = new KVCommandProcessor(mm);
		SimpleNioServer sn = new SimpleNioServer(kvLogic);

		Runtime.getRuntime().addShutdownHook(new Thread() {
			@Override
			public void run() {
				System.out.println("Shutting down NIO server");
				logger.info("Shutting down NIO server");
				try {
					mm.shutdown();
				} catch (IOException e) {
					logger.warning("Exception during shutting down server: " + e);
				}

				for (Handler h : logger.getHandlers()) {
					h.close();
				}
			}

		});

		logger.info("starting server");

		sn.bindSockets(cfg.listenaddr, cfg.port);
		logger.info("Sockets succesfully bound.");

		sn.start();
	}
}
