package de.tum.i13.client.kv;

import static de.tum.i13.client.Application.LOGGER;

import java.io.IOException;
import java.util.Base64;

import de.tum.i13.client.Application;
import de.tum.i13.client.Connection;
import de.tum.i13.client.ConnectionManager;
import de.tum.i13.shared.Constants;
import de.tum.i13.shared.kv.KVMessage;
import de.tum.i13.shared.kv.KVMessage.StatusType;
import de.tum.i13.shared.kv.KVMessageImplementation;
import de.tum.i13.shared.kv.KVStore;

/**
 * This class represents the client side KVStore module.
 * 
 * @author Gruppe 17
 *
 *         15.11.2020
 *
 */
public class KVStoreApplication implements KVStore {

	/**
	 * The Connection Object used to communicate with the Server. When no server is
	 * connected the value of this attribute should always be none.
	 */
	private static Connection conn = null;

	/**
	 * This method connects to the specified host and port.
	 * <P>
	 * 15.11.2020
	 *
	 * @param host
	 *        the host name or IP address of the server
	 * @param port
	 *        the port number
	 * @return any bytes received from the server upon connecting
	 * @throws IOException
	 *         in case of an error during connecting
	 */
	public byte[] connect(String host, int port) throws IOException {
		try {
			conn = new ConnectionManager();
			conn.connect(host, port);

			byte[] answer = conn.receive();

			if (answer == null) {
				throw new IOException(String.format("No answer received from %s:%d", host, port));
			}
			return answer;
		} catch (IOException e) {
			// In case of the connection failing, maintain the invariant.
			conn = null;
			throw e;
		}
	}

	/**
	 * This method disconnects from the connected server.
	 * <P>
	 * 15.11.2020
	 *
	 * @throws IOException
	 *         in case of an error during disconnecting
	 */
	public void disconnect() throws IOException {
		if (conn == null) {
			return;
		}
		conn.disconnect();
		conn = null;
	}

	/**
	 * This method is executed when the GET command is issued. It sends the
	 * specified command to the currently connected server and retrives its value
	 * if it exists or if it doesn't exist an error is thrown. If
	 * sending of the request or receiving of the response fails, the user is
	 * notified. Both command and key are in telnet encoded.
	 * <P>
	 * 18.11.2020
	 *
	 * @param key
	 *        the key whose value will be retrieved
	 *
	 * @return a KVMessage containing key, value and StatusType
	 */
	@Override
	public KVMessage get(String key) {
		KVMessage result = null;
		try {
			byte[] encodedRequest = (Constants.GET_COMMAND + " " + key + "\r\n").getBytes(Constants.TELNET_ENCODING);
			conn.send(encodedRequest);
		} catch (IOException e) {
			String output = String.format(
					"Error! Unable to send the message to %s:%d, possibly the connection broke down", conn.getHost(),
					conn.getPort());
			LOGGER.warning(output + "; " + e.toString());
			Application.printToConsole(output);
		}
		try {
			byte[] answer = conn.receive();
			if (answer == null) {
				throw new IOException(String.format("No answer received from %s:%d", conn.getHost(), conn.getPort()));
			}
			byte[] firstPart = new byte[9];
			System.arraycopy(answer, 0, firstPart, 0, 9);
			String firstPartString = new String(firstPart, Constants.TELNET_ENCODING);

			switch (firstPartString) {
			case "get_error":
				result = new KVMessageImplementation(key, "", StatusType.GET_ERROR);
				LOGGER.info(String.format("There was no value associated to this key: %s", key));
				break;
			case "get_succe":
				int valueSize = answer.length - key.length() - 15;
				byte[] valueBytes = new byte[valueSize];

				// copy the value from the received answer
				System.arraycopy(answer, 13 + key.length(), valueBytes, 0, valueSize);

				// decode the value
				String value = new String(Base64.getDecoder().decode(valueBytes));
				result = new KVMessageImplementation(key, value, StatusType.GET_SUCCESS);
				LOGGER.info(String.format("Successfully received value: %s", value));
				break;
			default:
				result = new KVMessageImplementation("Unknown response.");
			}
		} catch (IOException e) {
			String output = String.format(
					"Error! Unable to recieve response from %s:%d although the sending was successful", conn.getHost(),
					conn.getPort());
			LOGGER.warning(output + "; " + e.toString());
			Application.printToConsole(output);
		}
		return result;
	}

	/**
	 * This method returns the hostname of the currently connected server.
	 * <P>
	 * 15.11.2020
	 *
	 * @return the host name
	 */
	public String getHost() {
		return conn.getHost();
	}

	/**
	 * This method returns the port number of the currently connected server.
	 * <P>
	 * 15.11.2020
	 *
	 * @return the port number
	 */
	public int getPort() {
		return conn.getPort();
	}

	/**
	 * This method returns whether a connection is currently established.
	 * <P>
	 * 15.11.2020
	 *
	 * @return
	 */
	public boolean isConnected() {
		return conn != null;
	}

	/**
	 * This method is executed when the PUT command is issued. It sends the put or
	 * delete command based on "value" to the currently connected server and waits
	 * for a reply. If sending of the request or receiving of the response fails the
	 * user is notified. The command and key are in telnet encoded, value is in
	 * Base64 encoded.
	 * <P>
	 * 18.11.2020
	 *
	 * @param key
	 * @param value
	 *
	 * @return a KVMessage containing key, value and StatusType
	 */
	@Override
	public KVMessage put(String key, String value) {
		KVMessage result = null;
		try {
			byte[] request = null;
			if (value == null || value.isBlank()) {
				request = (Constants.DELETE_COMMAND + " " + key + "\r\n").getBytes(Constants.TELNET_ENCODING);
			} else {
				byte[] encodedPutKey = (Constants.PUT_COMMAND + " " + key + " ").getBytes(Constants.TELNET_ENCODING);
				byte[] encodedValue = Base64.getEncoder().encode(value.getBytes());
				byte[] encodedRN = "\r\n".getBytes(Constants.TELNET_ENCODING);

				request = new byte[encodedPutKey.length + encodedValue.length + encodedRN.length];

				System.arraycopy(encodedPutKey, 0, request, 0, encodedPutKey.length);
				System.arraycopy(encodedValue, 0, request, encodedPutKey.length, encodedValue.length);
				System.arraycopy(encodedRN, 0, request, encodedPutKey.length + encodedValue.length, encodedRN.length);
			}
			conn.send(request);
		} catch (IOException e) {
			String output = String.format(
					"Error! Unable to send the message to %s:%d, possibly the connection broke down", conn.getHost(),
					conn.getPort());
			LOGGER.warning(output + "; " + e.toString());
			Application.printToConsole(output);
			return new KVMessageImplementation(key, value, KVMessage.StatusType.PUT_ERROR);
		}

		try {
			byte[] answer = conn.receive();
			if (answer == null) {
				throw new IOException(String.format("No answer received from %s:%d", conn.getHost(), conn.getPort()));
			}
			String recvMsg = new String(answer, Constants.TELNET_ENCODING);
			String[] tokens = recvMsg.split(" ");
			switch (tokens[0]) {
			case Constants.PUT_SUCCESS:
				result = new KVMessageImplementation(key, value, StatusType.PUT_SUCCESS);
				LOGGER.info(String.format("Key: %s and value: %s successfully inserted.", key, value));
				break;
			case Constants.PUT_ERROR:
				result = new KVMessageImplementation(key, value, StatusType.PUT_ERROR);
				LOGGER.info(String.format("An error occured while trying to insert key: %s and value: %s", key, value));
				break;
			case Constants.PUT_UPDATE:
				result = new KVMessageImplementation(key, value, StatusType.PUT_UPDATE);
				LOGGER.info(String.format("Successfully updated the value: %s to the given key: %s", value, key));
				break;
			case Constants.DELETE_SUCCESS:
				result = new KVMessageImplementation(key, value, StatusType.DELETE_SUCCESS);
				LOGGER.info(String.format("Successfully deleted the value to the given key: %s", key));
				break;
			case Constants.DELETE_ERROR:
				result = new KVMessageImplementation(key, value, StatusType.DELETE_ERROR);
				LOGGER.info(
						String.format("An error occured while trying to delete the value to the given key: %s", key));
				break;
			default:
				result = new KVMessageImplementation("Unknown response.");
			}
		} catch (IOException e) {
			String output = String.format(
					"Error! Unable to recieve response from %s:%d although the sending was successful", conn.getHost(),
					conn.getPort());
			LOGGER.warning(output + "; " + e.toString());
			Application.printToConsole(output);
			result = new KVMessageImplementation(key, value, KVMessage.StatusType.PUT_ERROR);
		}
		return result;
	}
}
