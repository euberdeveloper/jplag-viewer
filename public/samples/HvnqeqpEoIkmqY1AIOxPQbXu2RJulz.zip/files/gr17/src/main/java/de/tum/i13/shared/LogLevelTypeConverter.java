package de.tum.i13.shared;

import java.util.logging.Level;

import picocli.CommandLine;

/**
 * Converts log level input from the user to a valid log level or throws an
 * exception when the input is invalid.
 * 
 * @author Marc Engelmann
 *
 *         19.11.2020
 *
 */
public class LogLevelTypeConverter implements CommandLine.ITypeConverter<Level> {

	@Override
	public Level convert(String value) throws IllegalArgumentException {
		return Level.parse(value);
	}

}
