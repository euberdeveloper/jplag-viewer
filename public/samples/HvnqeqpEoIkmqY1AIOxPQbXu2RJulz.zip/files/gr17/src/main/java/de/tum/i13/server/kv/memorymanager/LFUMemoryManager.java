package de.tum.i13.server.kv.memorymanager;

import java.io.IOException;
import java.nio.file.Path;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashSet;
import java.util.Set;

import de.tum.i13.shared.kv.KVMessage;
import de.tum.i13.shared.kv.KVMessageImplementation;

/**
 * this class implements the LFU displacement strategy
 *
 * @author group 17
 */
public class LFUMemoryManager extends MemoryManager {

	/**
	 * stores the current access counter for every key in the cache
	 */
	private HashMap<String, Integer> keyToCounter;

	/**
	 * stores a LinkedHashSet for every currently existing counter c. The LinkedHashSet then contains every key which currently has counter equal to c
	 */
	private HashMap<Integer, LinkedHashSet<String>> counterToKeys;

	/**
	 * currently smallest access counter available in the cache
	 */
	private int minCounter;

	public LFUMemoryManager(int cacheSize, Path dataDir) {
		super(cacheSize, dataDir);
		keyToCounter = new HashMap<>();
		counterToKeys = new HashMap<>();
		minCounter = 2;
	}

	/**
	 * this method overrides the addToCache() method from its superclass MemoryManager to work for LFU
	 */
	@Override
	public KVMessage delete(String key) {
		logger.info("delete method running");

		String v = cache.get(key);
		boolean foundInCache = false;
		if (v != null) {
			int count = keyToCounter.get(key);

			cache.remove(key);
			keyToCounter.remove(key);

			if (counterToKeys.get(count).size() > 1) {
				counterToKeys.get(count).remove(key);
			} else {
				counterToKeys.remove(count);
				if (minCounter == count) {
					Set<Integer> allCounters = counterToKeys.keySet();
					minCounter = getMin(allCounters);
				}
			}
			foundInCache = true;

			logger.info("deleted value in cache");
		}
		try {
			KVMessage result = dbm.delete(key);
			if (!foundInCache) {
				return result;
			} else {
				logger.warning("deleted value");
				return new KVMessageImplementation(key, v, KVMessage.StatusType.DELETE_SUCCESS);
			}
		} catch (IOException e) {
			logger.warning("could not delete value because of IOException");
			return new KVMessageImplementation(key, null, KVMessage.StatusType.DELETE_ERROR);
		}
	}

	/**
	 * this method overrides the get() method from its superclass MemoryManager to work for LFU
	 */
	@Override
	public KVMessage get(String key) {
		logger.info("running get method");

		String v = cache.get(key);
		if (v != null) {
			logger.info("value found in cache");

			int count = keyToCounter.get(key);

			keyToCounter.replace(key, count + 1);

			if (!counterToKeys.containsKey(count + 1)) {
				counterToKeys.put(count + 1, new LinkedHashSet<>());
			}
			counterToKeys.get(count + 1).add(key);

			if (counterToKeys.get(count).size() > 1) {
				counterToKeys.get(count).remove(key);
			} else {
				counterToKeys.remove(count);
				if (minCounter == count) {
					minCounter++;
				}
			}
			return new KVMessageImplementation(key, v, KVMessage.StatusType.GET_SUCCESS);
		} else {
			logger.info("value not in cache");
			try {
				KVMessage msg = dbm.get(key);
				if (msg.getValue() != null) {
					logger.info("found value in database");
					addToCache(msg.getKey(), msg.getValue());
					logger.info("added value to cache");
				}
				return msg;
			} catch (IOException e) {
				logger.warning("could not get value because of IOException");
				return new KVMessageImplementation(key, null, KVMessage.StatusType.GET_ERROR);
			}
		}
	}

	/**
	 * this method overrides the put() method from its superclass MemoryManager to work for LFU
	 */
	@Override
	public KVMessage put(String key, String val) {
		logger.info("running put method");

		String v = cache.get(key);
		if (v != null) {
			logger.info("value found in cache");
			int count = keyToCounter.get(key);

			cache.replace(key, val);
			keyToCounter.replace(key, count + 1);
			if (!counterToKeys.containsKey(count + 1)) {
				counterToKeys.put(count + 1, new LinkedHashSet<>());
			}
			counterToKeys.get(count + 1).add(key);

			if (counterToKeys.get(count).size() > 1) {
				counterToKeys.get(count).remove(key);
			} else {
				counterToKeys.remove(count);
				if (minCounter == count) {
					minCounter++;
				}
			}
			logger.info("updated value in cache");
			return new KVMessageImplementation(key, val, KVMessage.StatusType.PUT_UPDATE);
		} else {
			logger.info("value not in cache");
			try {
				addToCache(key, val);
				logger.info("value added to cache");
				return new KVMessageImplementation(key, val, KVMessage.StatusType.PUT_SUCCESS);
			} catch (IOException e) {
				logger.warning("could not put value because of IOException");
				return new KVMessageImplementation(key, val, KVMessage.StatusType.PUT_ERROR);
			}
		}
	}

	/**
	 * this method overrides the addToCache() method from its superclass MemoryManager to work for LFU
	 */
	@Override
	protected void addToCache(String key, String value) throws IOException {
		logger.info("addToCache is running");

		if (cache.size() >= cacheSize) {
			logger.info("freeing space in cache for new value");

			String keyToBeDisplaced = counterToKeys.get(minCounter).iterator().next();
			String valueToBeDisplaced = cache.get(keyToBeDisplaced);

			dbm.put(keyToBeDisplaced, valueToBeDisplaced);

			if (counterToKeys.get(minCounter).size() > 1) {
				counterToKeys.get(minCounter).remove(keyToBeDisplaced);
			} else {
				counterToKeys.remove(minCounter);
			}

			cache.remove(keyToBeDisplaced);
			keyToCounter.remove(keyToBeDisplaced);

			logger.info("displaced a key/value pair from cache to storage");
		}

		cache.put(key, value);
		keyToCounter.put(key, 1);

		if (!counterToKeys.containsKey(1)) {
			counterToKeys.put(1, new LinkedHashSet<>());
		}
		counterToKeys.get(1).add(key);
		minCounter = 1;

		logger.info("inserted new value into cache");
	}

	/**
	 * this methods gives back the smallest integer of a Set of integers
	 *
	 * @param counters Set of integers
	 * @return smallest integer the given Set of integers contains
	 */
	private int getMin(Set<Integer> counters) {
		int min;

		if (counters.isEmpty()) {
			return 2;
		} else {
			Iterator<Integer> it = counters.iterator();
			min = it.next();
			while (it.hasNext()) {
				int tmp = it.next();
				if (tmp < min) {
					min = tmp;
				}
			}
			return min;
		}
	}

}
