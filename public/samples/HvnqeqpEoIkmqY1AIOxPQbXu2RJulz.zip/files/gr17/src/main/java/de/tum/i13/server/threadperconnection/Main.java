package de.tum.i13.server.threadperconnection;

import static de.tum.i13.shared.Config.parseCommandlineArgs;
import static de.tum.i13.shared.LogSetup.setupLoggingNew;

import java.io.IOException;
import java.net.InetSocketAddress;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.logging.Handler;
import java.util.logging.Logger;

import de.tum.i13.server.kv.KVCommandProcessor;
import de.tum.i13.server.kv.memorymanager.MemoryManager;
import de.tum.i13.shared.CommandProcessor;
import de.tum.i13.shared.Config;

/**
 * Created by chris on 09.01.15.
 */
public class Main {

	public static Logger logger = Logger.getLogger(Main.class.getName());

	public static void main(String[] args) throws IOException {
		Config cfg = parseCommandlineArgs(args); // Do not change this
		setupLoggingNew(cfg.logfile);
		logger.info("Config: " + cfg.toString());

		if (cfg.usagehelp) {
			logger.info("Help message was displayed, terminated server.");
			Config.printhelp();
			System.exit(0);
		}

		logger.setLevel(cfg.logLevel);
		logger.info("Set log level to " + cfg.logLevel + ".");

		final ServerSocket serverSocket = new ServerSocket();
		final MemoryManager mm = MemoryManager.getManager(cfg.displacementStrategy, cfg.cacheSize, cfg.dataDir);
		final CommandProcessor kvLogic = new KVCommandProcessor(mm);

		Runtime.getRuntime().addShutdownHook(new Thread() {
			@Override
			public void run() {
				System.out.println("Closing thread per connection kv server");
				try {
					serverSocket.close();
					mm.shutdown();
				} catch (IOException e) {
					System.err.println("Exception during shutting down server: " + e);
					logger.warning("Exception during shutting down server: " + e);
				}

				for (Handler h : logger.getHandlers()) {
					h.close();
				}
			}

		});

		// bind to localhost only
		serverSocket.bind(new InetSocketAddress(cfg.listenaddr, cfg.port));

		while (true) {
			Socket clientSocket = serverSocket.accept();

			// When we accept a connection, we start a new Thread for this connection
			Thread th = new ConnectionHandleThread(kvLogic, clientSocket);
			th.start();
		}
	}
}
