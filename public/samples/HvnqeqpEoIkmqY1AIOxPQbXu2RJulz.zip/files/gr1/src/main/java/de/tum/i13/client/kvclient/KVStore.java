package de.tum.i13.client.kvclient;

import de.tum.i13.server.kv.KVMessage;

import java.io.IOException;

public interface KVStore {

    /**
     * Initializes a connection with a KVStore-Server.
     *
     * @param host the host of the server
     * @param port the port of the server
     * @return connection confirmation message
     * @throws ReestablishConnectionException if the connection was already initialized
     * @throws IOException                    if a networking error occurred {@link java.net.Socket#Socket(String, int)}
     */
    String connect(String host, int port) throws IOException;

    /**
     * Disconnects the current connection.
     *
     * @return disconnect confirmation message
     * @throws UnestablishedConnectionException if the connection was not initialized before
     * @throws IOException                      exception from closing the underlying {@link java.net.Socket}
     */
    String disconnect() throws IOException;

    /**
     * Inserts a key-value pair into the KVStore.
     *
     * @param key   the key that identifies the given value.
     * @param value the value that is indexed by the given key.
     * @return a message that confirms the insertion of the tuple or an error.
     * @throws UnestablishedConnectionException if no connection was established before
     * @throws IOException                      if a networking problem occurs
     */
    KVMessage put(String key, String value) throws IOException;

    /**
     * Retrieves the value for a given key from the KVStore.
     *
     * @param key the key that identifies the value.
     * @return the value, which is indexed by the given key.
     * @throws UnestablishedConnectionException if no connection was established before
     * @throws IOException                      if a networking problem occurs
     */
    KVMessage get(String key) throws IOException;

    /**
     * Remove a key and value pair from KVStore.
     *
     * @param key the key that identifies the given value.
     * @return a message that confirms the deletion of the tuple or an error.
     * @throws UnestablishedConnectionException if no connection was established before
     * @throws IOException                      if a networking problem occurs
     */
    KVMessage delete(String key) throws IOException;

}
