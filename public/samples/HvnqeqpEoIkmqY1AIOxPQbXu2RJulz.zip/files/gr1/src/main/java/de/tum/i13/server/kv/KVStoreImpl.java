package de.tum.i13.server.kv;

import de.tum.i13.server.kv.kvcache.KVCache;
import de.tum.i13.server.kv.persistence.DiskPersistence;

import java.time.Duration;
import java.time.Instant;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 * Something like a Bridge pattern.
 * https://en.wikipedia.org/wiki/Bridge_pattern
 */
public class KVStoreImpl implements KVStore {
    private final static Logger LOGGER = Logger.getLogger(KVStoreImpl.class.getName());

    private final DiskPersistence diskPersistence;
    private final KVCache cache;

    public KVStoreImpl(DiskPersistence diskPersistence, KVCache cache) {
        this.diskPersistence = diskPersistence;
        this.cache = cache;
    }

    /**
     * Adds the pair to the cache and persists in the disk
     *
     * @param key   the key that identifies the given value.
     * @param value the value that is indexed by the given key.
     * @return KVMessage status
     */
    @Override
    public KVMessage put(String key, String value) {
        LOGGER.log(Level.INFO, String.format("put %s %s", key, value));
        Instant start = Instant.now();
        cache.put(key, value);
        Instant cacheEnd = Instant.now();
        KVMessage result = diskPersistence.put(key, value);
        Instant diskEnd = Instant.now();
        // log time measurements
        LOGGER.log(Level.FINEST, String.format("put %s %s; cache duration: %d ns", key, value, Duration.between(start, cacheEnd).toNanos()));
        LOGGER.log(Level.FINEST, String.format("put %s %s; disk duration: %d ns", key, value, Duration.between(cacheEnd, diskEnd).toNanos()));
        return result;
    }

    /**
     * Fetch from the cache if not there fetch from the disk
     *
     * @param key the key that identifies the value.
     * @return KVMessage containing the key and the value
     */
    @Override
    public KVMessage get(String key) {
        LOGGER.log(Level.INFO, String.format("get %s", key));
        Instant start = Instant.now();
        String value = cache.get(key);
        Instant cacheEnd = Instant.now();
        LOGGER.log(Level.FINEST, String.format("get %s; cache duration: %d ns", key, Duration.between(start, cacheEnd).toNanos()));
        if (value == null) {
            LOGGER.log(Level.INFO, String.format("cache miss %s", key));
            KVMessage result = diskPersistence.get(key);
            Instant diskEnd = Instant.now();
            LOGGER.log(Level.FINEST, String.format("get %s; disk duration: %d ns", key, Duration.between(cacheEnd, diskEnd).toNanos()));
            return result;
        }
        LOGGER.log(Level.INFO, String.format("cache hit %s", key));
        return new KVMessageImpl(key, value, KVMessage.StatusType.GET_SUCCESS);
    }

    /**
     * Delete from the cache and the disk
     *
     * @param key the key that identifies the given value.
     * @return KVMessage status - success/failure
     */
    @Override
    public KVMessage delete(String key) {
        LOGGER.log(Level.INFO, String.format("delete %s", key));
        Instant start = Instant.now();
        cache.delete(key);
        Instant cacheEnd = Instant.now();
        KVMessage result = diskPersistence.delete(key);
        Instant diskEnd = Instant.now();
        LOGGER.log(Level.FINEST, String.format("delete %s; cache duration: %d ns", key, Duration.between(start, cacheEnd).toNanos()));
        LOGGER.log(Level.FINEST, String.format("delete %s; disk duration: %d ns", key, Duration.between(cacheEnd, diskEnd).toNanos()));
        return result;
    }
}
