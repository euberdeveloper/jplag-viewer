package de.tum.i13.shared;

import java.util.Base64;

/**
 * Helper class to handle encoding and decoding messages using {@link Base64}.
 *
 * @see Base64
 */
public class Encode {
    /**
     * Encodes a string using base64 encoding.
     *
     * @param str the string to encode
     * @return the encoded string
     */
    public static String encode(String str) {
        Base64.Encoder encode = Base64.getEncoder();
        byte[] encoded = encode.encode(str.getBytes(Constants.TELNET_CHARSET));
        return new String(encoded);
    }

    /**
     * Decodes a string using base64 encoding.
     *
     * @param str the base64 encoded string
     * @return the decoded string
     */
    public static String decode(String str) {
        Base64.Decoder decode = Base64.getDecoder();
        byte[] decoded = decode.decode(str.getBytes(Constants.TELNET_CHARSET));
        return new String(decoded);
    }
}
