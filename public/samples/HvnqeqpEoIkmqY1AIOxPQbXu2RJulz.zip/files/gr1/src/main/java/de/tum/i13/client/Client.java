package de.tum.i13.client;

import de.tum.i13.client.kvclient.KVClient;
import de.tum.i13.client.kvclient.KVStore;
import de.tum.i13.client.kvclient.ReestablishConnectionException;
import de.tum.i13.client.kvclient.UnestablishedConnectionException;
import de.tum.i13.server.kv.KVMessage;
import de.tum.i13.shared.Constants;
import de.tum.i13.shared.LogSetup;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.SocketTimeoutException;
import java.net.UnknownHostException;
import java.nio.file.Paths;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.stream.Collectors;
import java.util.stream.Stream;


public class Client {
    final static String TAG = Client.class.getName();
    private final static Logger LOGGER = Logger.getLogger(Client.class.getName());

    public static void main(String[] args) throws Exception {
        LogSetup.setupLogging(Paths.get("client.log"));
        LOGGER.info("Starting CLI");

        BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));
        KVStore client = new KVClient();
        for (; ; ) {
            System.out.print("KVStoreClient> ");
            String line = null;
            try {
                line = reader.readLine();
            } catch (IOException e) {
                printLine(Constants.ERROR_INPUT_EXCEPTION);
                LOGGER.throwing(TAG, "main", e);
                disconnect(client, true);
                printLine("Application exit!");
                return;
            }
            LOGGER.finest("INPUT: " + line);
            // split the user input so we can process the command tokens
            String[] command = line.split(" ");
            // handle the various commands based on user input
            switch (command[0]) {
                case "connect":
                    connect(command, client);
                    break;
                case "disconnect":
                    disconnect(client, false);
                    break;
                case "logLevel":
                    setLogLevel(command[1], command);
                    break;
                case "help":
                    printLine(Constants.HELP_TEXT);
                    break;
                case "put":
                    if (command.length < 3) {
                        LOGGER.warning("invalid argument number");
                        printLine(String.format(Constants.ERROR_INVALID_NUMBER_ARGUMENTS, Constants.COMMAND_PUT));
                        break;
                    }
                    try {
                        KVMessage response = client.put(command[1], Stream.of(command).skip(2).collect(Collectors.joining(" ")));
                        printLine(response.toString());
                    } catch (Exception e) {
                        handleException(e);
                    }
                    break;
                case "get":
                    if (command.length != 2) {
                        LOGGER.warning("invalid argument number");
                        printLine(String.format(Constants.ERROR_INVALID_NUMBER_ARGUMENTS, Constants.COMMAND_GET));
                        break;
                    }
                    try {
                        KVMessage response = client.get(command[1]);
                        printLine(response.toString());
                    } catch (Exception e) {
                        handleException(e);
                    }
                    break;
                case "delete":
                    if (command.length != 2) {
                        LOGGER.warning("invalid argument number");
                        printLine(String.format(Constants.ERROR_INVALID_NUMBER_ARGUMENTS, Constants.COMMAND_DEL));
                        break;
                    }
                    try {
                        KVMessage response = client.delete(command[1]);
                        printLine(response.toString());
                    } catch (Exception e) {
                        handleException(e);
                    }
                    break;
                case "quit":
                    disconnect(client, true);
                    printLine("Application exit!");
                    System.exit(0);
                    break;
                default:
                    printLine(Constants.ERROR_UNKNOWN_COMMAND);
                    printLine(Constants.HELP_TEXT);
            }
        }
    }

    private static void connect(String[] command, KVStore client) {
        if (command.length != 3) {
            LOGGER.warning("invalid argument number");
            printLine(String.format(Constants.ERROR_INVALID_NUMBER_ARGUMENTS, Constants.COMMAND_CONNECT));
            return;
        }
        int port = 0;
        try {
            port = Integer.parseInt(command[2]);
        } catch (NumberFormatException e) {
            LOGGER.throwing(TAG, "main", e);
            printLine(Constants.ERROR_INVALID_ARGUMENT_PORT);
            return;
        }
        try {
            String confirmation = client.connect(command[1], port);
            printLine(confirmation);
        } catch (Exception e) {
            // handle the various types of exceptions by presenting them in a meaningful way to the user
            LOGGER.throwing(TAG, "connect", e);
            if (e instanceof ReestablishConnectionException) {
                printLine(String.format(Constants.ERROR_RECONNECT, Constants.COMMAND_DISCONNECT));
            } else if (e instanceof UnknownHostException) {
                printLine(String.format(Constants.ERROR_UNKNOWN_HOST, command[1], port));
            } else if (e instanceof IllegalArgumentException) {
                printLine(Constants.ERROR_PORT_OUT_OF_RANGE);
            } else if (e instanceof SecurityException) {
                printLine(Constants.ERROR_OPERATION_PERMITTED);
            } else if (e instanceof SocketTimeoutException) {
                printLine(Constants.ERROR_SOCKET_TIMEOUT);
            } else {
                printLine(Constants.ERROR_I_O_EXCEPTION);
            }
        }
    }

    private static void disconnect(KVStore client, boolean silent) {
        try {
            String confirmation = client.disconnect();
            printLine(String.format("Connection terminated: %s", confirmation));
        } catch (Exception e) {
            // if the operation is silent,
            // eg: at program exit, dont show the UnestablishedConnectionException as the user might not be connected
            if (e instanceof UnestablishedConnectionException) {
                if (!silent) {
                    LOGGER.throwing(TAG, "disconnect", e);
                    printLine(String.format(Constants.ERROR_NO_CONNECTION, Constants.COMMAND_CONNECT));
                }
            } else {
                LOGGER.throwing(TAG, "disconnect", e);
                printLine(Constants.ERROR_I_O_EXCEPTION);
            }
        }

    }

    private static void handleException(Exception e) {
        if (e instanceof IllegalArgumentException) {
            LOGGER.throwing(TAG, "handleException", e);
            printLine("Error: " + e.getMessage());
        } else if (e instanceof UnestablishedConnectionException) {
            LOGGER.throwing(TAG, "handleException", e);
            printLine(String.format(Constants.ERROR_NO_CONNECTION, Constants.COMMAND_CONNECT));
        } else {
            LOGGER.throwing(TAG, "handleException", e);
            printLine(Constants.ERROR_I_O_EXCEPTION);
        }
    }

    private static void setLogLevel(String level, String[] command) {
        if (command.length != 2) {
            LOGGER.warning("invalid argument number");
            printLine(String.format(Constants.ERROR_INVALID_NUMBER_ARGUMENTS, Constants.COMMAND_LOG_LEVEL));
            return;
        }
        // check if the input is valid
        Level logLevel = null;
        if (Constants.LOG_LEVELS.containsKey(level)) {
            logLevel = Constants.LOG_LEVELS.get(level);
        }
        if (logLevel == null) {
            // no valid loglevel was provided
            LOGGER.warning("invalid log level");
            printLine(String.format(Constants.ERROR_INVALID_LOG_LEVEL, String.join(" | ", Constants.LOG_LEVELS.keySet())));
            return;
        }
        // change the current log level and retrieve the old one
        Level old = LogSetup.changeLogLevel(logLevel);
        printLine(String.format("Log-level set from %s to %s", old.getName(), logLevel.getName()));
    }


    private static void printLine(String msg) {
        LOGGER.finest("OUTPUT: " + msg);
        System.out.println("KVStoreClient> " + msg);
    }
}
