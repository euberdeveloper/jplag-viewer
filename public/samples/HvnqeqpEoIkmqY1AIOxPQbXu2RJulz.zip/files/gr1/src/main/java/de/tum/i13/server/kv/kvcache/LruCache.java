package de.tum.i13.server.kv.kvcache;

/**
 * This is a LRU cache configuration of the {@link InsertAccessCache}.
 */
public class LruCache extends InsertAccessCache {
    /**
     * Initializes the Cache with max size
     * And sets the access order to true to use sorting by access order.
     *
     * @param size the max size of the cache
     * @see java.util.LinkedHashMap#LinkedHashMap(int, float, boolean)
     */
    public LruCache(int size) {
        // set the access order to true to achieve LRU displacement
        super(size, true);
    }
}
