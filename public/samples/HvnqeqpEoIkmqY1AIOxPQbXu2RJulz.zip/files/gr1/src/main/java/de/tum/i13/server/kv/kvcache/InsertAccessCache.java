package de.tum.i13.server.kv.kvcache;

import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.Map;

/**
 * Implementation of either a FIFO or LRU cache.
 * Which cache displacement method used is determined by the accessOrder of the {@link LinkedHashMap}.
 */
abstract class InsertAccessCache extends KVCache {

    // the cache map used to store temporary cache entries
    protected final LinkedHashMap<String, String> cache;

    /**
     * Initializes the Cache with max size and
     * specifies the cache displacement method by setting the access order.
     *
     * @param size        the max size of the cache
     * @param accessOrder the access order of the underlying {@link LinkedHashMap}
     * @see LinkedHashMap#LinkedHashMap(int, float, boolean)
     */
    protected InsertAccessCache(int size, boolean accessOrder) {
        super(size);
        if (size <= 0) {
            throw new IllegalArgumentException("size must be greater zero");
        }
        this.cache = new LinkedHashMap<>(0, 0.75f, accessOrder);
    }

    @Override
    public String get(String key) {
        if (key == null) {
            throw new NullPointerException("key must be != null");
        }
        synchronized (this) {
            // if the cache is configured as LRU this will also update the position of the cache entry
            String value = cache.get(key);
            if (value != null) {
                // cache hit, return the value
                return value;
            }
        }
        // cache miss
        return null;
    }

    @Override
    public void put(String key, String value) {
        if (key == null || value == null) {
            throw new NullPointerException("key and value must be != null");
        }
        // perform eviction if needed
        synchronized (this) {
            // check if the item was already present
            if (cache.containsKey(key)) {
                // no need to evict
                cache.put(key, value);
                return;
            }
        }
        evict();
        synchronized (this) {
            // in fifo and lru simply insert the cache entry
            cache.put(key, value);
        }
    }

    @Override
    protected void evict() {
        while (true) {
            synchronized (this) {
                // determine if we have to evict
                if (cache.size() < this.getMaxSize()) {
                    break;
                }
                // get the tail of the cache which will be the element we have to evict
                String toEvict = null;
                for (Map.Entry<String, String> entry : cache.entrySet()) {
                    toEvict = entry.getKey();
                    break;
                }
                // remove the element
                cache.remove(toEvict);
            }
        }
    }

    @Override
    public void delete(String key) {
        synchronized (this) {
            cache.remove(key);
        }
    }

    @Override
    public void clear() {
        synchronized (this) {
            // clear the cache
            this.cache.clear();
        }
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        synchronized (this) {
            Iterator<Map.Entry<String, String>> iter = cache.entrySet().iterator();
            while (iter.hasNext()) {
                Map.Entry<String, String> entry = iter.next();
                sb.append(entry.getKey());
                sb.append('=').append('"');
                sb.append(entry.getValue());
                sb.append('"');
                if (iter.hasNext()) {
                    sb.append(',').append(' ');
                }
            }
        }
        return sb.toString();
    }
}
