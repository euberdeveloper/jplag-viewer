package de.tum.i13.server.kv;

import de.tum.i13.shared.CommandProcessor;
import de.tum.i13.shared.Constants;

import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.time.Duration;
import java.time.Instant;
import java.util.logging.Logger;

public class KVCommandProcessor implements CommandProcessor {
    public static Logger logger = Logger.getLogger(KVCommandProcessor.class.getName());
    private final KVStore kvStore;

    public KVCommandProcessor(KVStore kvStore) {
        this.kvStore = kvStore;
    }

    @Override
    public String process(String command) {
        Instant start = Instant.now();
        // strip the delimiter
        command = command.replace("\r\n", "");
        logger.info("got command: " + command);

        if (command.isEmpty()) {
            return handleUnknownRequest(command);
        }
        KVMessageImpl request;
        try {
            request = new KVMessageImpl(command);
        } catch (IllegalArgumentException e) {
            logger.warning("got unknown command: " + command);
            logger.throwing(KVCommandProcessor.class.getName(), "process", e);
            return handleUnknownRequest(command);
        }
        if (request.getStatus() != KVMessage.StatusType.PUT
                && request.getStatus() != KVMessage.StatusType.GET
                && request.getStatus() != KVMessage.StatusType.DELETE) {
            logger.warning("got unknown command: " + command);
            return handleUnknownRequest(command);
        }
        String response = "";
        switch (request.getStatus()) {
            case PUT:
                response = handlePut(request);
                break;
            case GET:
                response = handleGet(request);
                break;
            case DELETE:
                response = handleDelete(request);
                break;
            default:
                return handleUnknownRequest(command);
        }
        logger.info("sending response: " + response);
        Instant end = Instant.now();
        logger.info(String.format("handling \"%s\" took: %d ms", command, Duration.between(start, end).toMillis()));
        return response;
    }

    @Override
    public String connectionAccepted(InetSocketAddress address, InetSocketAddress remoteAddress) {
        logger.info("new connection: " + remoteAddress.toString());

        return addDelimiter("Connection to KVStore server established: " + address.toString());
    }

    @Override
    public void connectionClosed(InetAddress remoteAddress) {
        logger.info("connection closed: " + remoteAddress.toString());
    }

    private String handleUnknownRequest(String command) {
        logger.warning("unknown request: " + command);
        return addDelimiter("error unknown request; valid requests are: put key value | get key | delete key");
    }

    private String handlePut(KVMessage message) {
        if (message.getKey().getBytes(Constants.TELNET_CHARSET).length > Constants.MAX_KEY_SIZE
                || message.getValue().getBytes(Constants.TELNET_CHARSET).length > Constants.MAX_VALUE_SIZE) {
            logger.warning(String.format("invalid data size: key size: %d, value size: %d", message.getKey().getBytes(Constants.TELNET_CHARSET).length, message.getValue().getBytes(Constants.TELNET_CHARSET).length));
            return handlePutError(message.getKey(), message.getValue());
        }
        try {
            // encode the message so we can store it correctly in the database
            message.encode();
            KVMessage result = kvStore.put(message.getKey(), message.getValue());
            // decode again to send replies
            result.decode();
            switch (result.getStatus()) {
                case PUT_SUCCESS:
                    return handlePutSuccess(result.getKey(), result.getValue());
                case PUT_UPDATE:
                    return handlePutUpdate(result.getKey(), result.getValue());
                case PUT_ERROR:
                    return handlePutError(result.getKey(), result.getValue());
                default:
                    return handlePutError(result.getKey(), result.getValue());
            }
        } catch (Exception e) {
            logger.throwing(KVCommandProcessor.class.getName(), "handlePut", e);
            message.decode();
            return handlePutError(message.getKey(), message.getValue());
        }
    }

    private String handlePutError(String key, String value) {
        logger.warning(String.format("error inserting: %s %s", key, value));
        return addDelimiter(String.format("put_error %s %s", key, value));
    }

    private String handlePutSuccess(String key, String value) {
        logger.info(String.format("successfully inserted: %s %s", key, value));
        return addDelimiter(String.format("put_success %s", key));
    }

    private String handlePutUpdate(String key, String value) {
        logger.info(String.format("successfully updated: %s %s", key, value));
        return addDelimiter(String.format("put_update %s", key));
    }

    private String handleGet(KVMessage message) {
        if (message.getKey().getBytes(Constants.TELNET_CHARSET).length > Constants.MAX_KEY_SIZE) {
            logger.warning(String.format("invalid data size: key size: %d", message.getKey().getBytes(Constants.TELNET_CHARSET).length));
            return handleGetError(message.getKey());
        }
        try {
            message.encode();
            KVMessage result = kvStore.get(message.getKey());
            result.decode();
            switch (result.getStatus()) {
                case GET_SUCCESS:
                    return handleGetSuccess(result.getKey(), result.getValue());
                case GET_ERROR:
                    return handleGetError(result.getKey());
                default:
                    return handleGetError(result.getKey());
            }
        } catch (Exception e) {
            logger.throwing(KVCommandProcessor.class.getName(), "handleGet", e);
            message.decode();
            return handleGetError(message.getKey());
        }
    }

    private String handleGetError(String key) {
        logger.warning(String.format("error getting: %s", key));
        return addDelimiter(String.format("get_error %s", key));
    }

    private String handleGetSuccess(String key, String value) {
        logger.info(String.format("successfully got: %s %s", key, value));
        return addDelimiter(String.format("get_success %s %s", key, value));
    }

    private String handleDelete(KVMessage message) {
        if (message.getKey().getBytes(Constants.TELNET_CHARSET).length > Constants.MAX_KEY_SIZE) {
            logger.warning(String.format("invalid data size: key size: %d", message.getKey().getBytes(Constants.TELNET_CHARSET).length));
            return handleDeleteError(message.getKey());
        }
        try {
            message.encode();
            KVMessage result = kvStore.delete(message.getKey());
            result.decode();
            switch (result.getStatus()) {
                case DELETE_SUCCESS:
                    return handleDeleteSuccess(result.getKey());
                case DELETE_ERROR:
                    return handleDeleteError(result.getKey());
                default:
                    return handleDeleteError(result.getKey());
            }
        } catch (Exception e) {
            logger.throwing(KVCommandProcessor.class.getName(), "handleDelete", e);
            message.decode();
            return handleDeleteError(message.getKey());
        }
    }

    private String handleDeleteError(String key) {
        logger.warning(String.format("error deleting: %s", key));
        return addDelimiter(String.format("delete_error %s", key));
    }

    private String handleDeleteSuccess(String key) {
        logger.info(String.format("successfully deleted: %s", key));
        return addDelimiter(String.format("delete_success %s", key));
    }

    private String addDelimiter(String result) {
        return result + "\r\n";
    }
}
