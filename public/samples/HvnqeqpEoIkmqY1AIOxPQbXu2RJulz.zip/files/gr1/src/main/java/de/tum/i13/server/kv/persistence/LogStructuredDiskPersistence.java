package de.tum.i13.server.kv.persistence;

import de.tum.i13.server.kv.KVMessage;
import de.tum.i13.server.kv.KVMessageImpl;
import de.tum.i13.server.kv.persistence.errors.PersistenceException;

import java.io.*;
import java.util.HashMap;
import java.util.Map;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 * Log structured disk store for key value pairs
 * ASSUMPTIONS
 * keys and values are in BASE64 -  no new lines or escape chars
 */
public class LogStructuredDiskPersistence implements DiskPersistence {
    private final static Logger LOGGER = Logger.getLogger(LogStructuredDiskPersistence.class.getName());
    //stores key/value offset in the file to find it later
    private final Map<String, ValueLocation> valueLocationMap = new HashMap<>();
    private final BufferedWriter writer;
    private final RandomAccessFile reader;
    private final String fileName = "log.txt";
    private final File file;

    /**
     * Deletes previous instantiation of that file
     */
    public LogStructuredDiskPersistence(String folder) throws PersistenceException {
        LOGGER.log(Level.INFO, String.format("initializing on folder %s", folder));
        try {
            file = new File(folder, fileName);
            if (file.exists()) {
                buildIndexFrom(folder);
            } else {
                file.createNewFile();
            }
            LOGGER.log(Level.INFO, String.format("initializing log file %s", file.getAbsolutePath()));
            this.writer = new BufferedWriter(new FileWriter(file, true));
            this.reader = new RandomAccessFile(file, "r");
        } catch (IOException e) {
            LOGGER.log(Level.SEVERE, "Error while initializing LogStructuredDiskPersistence", e);
            throw new PersistenceException("Couldn't open a file", e);
        }
    }

    /**
     * Reads the file and sequentially reapplies operations
     *
     * @param folder from where to reconstruct the structure
     * @throws IOException
     */
    synchronized private void buildIndexFrom(String folder) throws IOException {
        File file = new File(folder, fileName);
        BufferedReader bufferedReader = new BufferedReader(new FileReader(file));
        String line;
        int offset = 0;
        while ((line = bufferedReader.readLine()) != null) {
            if (line.length() == 0) break;
            String[] arr = line.split(",");
            if (arr[0].equals("put")) {
                int prefixLength = arr[0].length() + arr[1].length() + 2;//commas
                valueLocationMap.put(arr[1], new ValueLocation(offset + prefixLength, arr[2].length()));
            }
            if (arr[0].equals("del")) {
                valueLocationMap.remove(arr[1]);
            }
            offset += line.length();
            offset += 1;//new line char
        }
        bufferedReader.close();
    }

    /**
     * Fetch the value from the disk using the file offset in the map
     *
     * @param key key associated with the value
     * @return if successful KVMessage key value pair with the success status of the request
     * else null as value and failure status in the KVMessage
     */
    @Override
    synchronized public KVMessage get(String key) {
        if (!valueLocationMap.containsKey(key)) return new KVMessageImpl(key, null, KVMessage.StatusType.GET_ERROR);
        ValueLocation valueLocation = valueLocationMap.get(key);
        try {
            byte[] readBuffer = new byte[valueLocation.length];
            reader.seek(valueLocation.offSet);
            reader.read(readBuffer);
            String value = new String(readBuffer);
            LOGGER.log(Level.INFO, String.format("Getting from log structured store  (%s, %s)", key, value));
            return new KVMessageImpl(key, value, KVMessage.StatusType.GET_SUCCESS);
        } catch (IOException e) {
            LOGGER.log(Level.SEVERE, String.format("Couldn't read from file at offset %d", valueLocation.offSet), e);
            return new KVMessageImpl(key, null, KVMessage.StatusType.GET_ERROR);
        }
    }

    /**
     * Comma is used as delimiter as BASE64 encoded string doesn't contain comma in its encoding
     * https://en.wikipedia.org/wiki/Base64
     *
     * @param key   key associated with the value
     * @param value value associated with the key
     * @return return operation status with the argument
     * status PUT_UPDATE is returned if key was already in the store
     * status PUT_SUCCESS is returned if key was not previously in the store
     * status PUT_ERROR is returned if an error occurred
     */
    @Override
    synchronized public KVMessage put(String key, String value) {
        long offset = file.length();
        String prefix = String.format("put,%s,", key);
        //sometimes string length is not the same as char array length
        long valueOffset = offset + prefix.toCharArray().length;
        int valueLength = value.toCharArray().length;
        String entry = prefix + value + "\n";

        char[] kvCharArray = entry.toCharArray();
        try {
            writer.write(kvCharArray);
            writer.flush();
        } catch (IOException e) {
            LOGGER.log(Level.SEVERE, "Couldn't append to the file", e);
            return new KVMessageImpl(key, null, KVMessage.StatusType.PUT_ERROR);
        }

        LOGGER.log(Level.INFO, String.format("Putting - (%s, %s) into log structured store", key, value));
        boolean contained = valueLocationMap.containsKey(key);
        valueLocationMap.put(key, new ValueLocation(valueOffset, valueLength));
        offset += kvCharArray.length;

        KVMessage.StatusType status = KVMessage.StatusType.PUT_SUCCESS;
        if (contained) status = KVMessage.StatusType.PUT_UPDATE;
        return new KVMessageImpl(key, value, status);
    }

    /**
     * Delete from the in memory map of key-> offset.
     * Instead of deleting the entry from the file we mark entry deleted putting a tombstone.
     *
     * @param key key to be deleted
     * @return Status of the request
     */
    @Override
    synchronized public KVMessage delete(String key) {
        if (!valueLocationMap.containsKey(key)) return new KVMessageImpl(key, null, KVMessage.StatusType.DELETE_ERROR);
        valueLocationMap.remove(key);
        char[] tombStone = String.format("del,%s\n", key).toCharArray();
        try {
            writer.write(tombStone);
            writer.flush();
        } catch (IOException e) {
            LOGGER.log(Level.SEVERE, "Couldn't append to the file", e);
            return new KVMessageImpl(key, null, KVMessage.StatusType.DELETE_ERROR);
        }
        LOGGER.log(Level.INFO, String.format("Successfully deleted from log structured store - %s ", key));

        return new KVMessageImpl(key, null, KVMessage.StatusType.DELETE_SUCCESS);
    }

    synchronized public void shutDown() throws IOException {
        writer.flush();
        writer.close();
        reader.close();
    }

    private static class ValueLocation {
        long offSet;
        int length;

        ValueLocation(long offSet, int length) {
            this.offSet = offSet;
            this.length = length;
        }
    }
}
