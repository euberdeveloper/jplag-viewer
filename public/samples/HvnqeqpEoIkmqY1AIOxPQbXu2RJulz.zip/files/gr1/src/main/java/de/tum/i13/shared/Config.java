package de.tum.i13.shared;

import picocli.CommandLine;

import java.io.IOException;
import java.net.InetSocketAddress;
import java.nio.file.Files;
import java.nio.file.Path;

/**
 * Helper class to parse the command line arguments for the KVServer.
 */
@CommandLine.Command(name = "kv-server",
        description = "Starts a simple Key-Value-Storage server.")
public class Config {
    @CommandLine.Option(names = "-p", description = "sets the port of the server", defaultValue = "5153")
    public int port;

    @CommandLine.Option(names = "-a", description = "which address the server should listen to", defaultValue = "127.0.0.1")
    public String listenaddr;

    @CommandLine.Option(names = "-b", description = "bootstrap broker where clients and other brokers connect first to retrieve configuration, port and ip, e.g., 192.168.1.1:5153", defaultValue = "clouddatabases.i13.in.tum.de:5153")
    public InetSocketAddress bootstrap;

    @CommandLine.Option(names = "-d", description = "directory for data files", defaultValue = "data/")
    public Path dataDir;

    @CommandLine.Option(names = "-l", description = "name of the logfile", defaultValue = "echo.log")
    public Path logfile;

    @CommandLine.Option(names = "-ll", description = "loglevel of the server", defaultValue = "ALL")
    public String logLevel;

    @CommandLine.Option(names = "-c", description = "max size of the cache", defaultValue = "100")
    public int cacheSize;

    @CommandLine.Option(names = "-s", description = "cache displacement strategy (FIFO, LRU, LFU)", defaultValue = "FIFO")
    public String cacheDisplacement;

    @CommandLine.Option(names = "-h", description = "displays help", usageHelp = true)
    public boolean usagehelp;

    /**
     * Parses the command line arguments into a config object used to initialize the sever.
     *
     * @param args the command line arguments
     * @return the resulting config object
     */
    public static Config parseCommandlineArgs(String[] args) {
        Config cfg = new Config();
        CommandLine.ParseResult parseResult = new CommandLine(cfg).registerConverter(InetSocketAddress.class, new InetSocketAddressTypeConverter()).parseArgs(args);
        if (cfg.usagehelp) {
            // display help and exit
            CommandLine.usage(new Config(), System.out);
            System.exit(0);
        }
        // create the data directory if needed
        if (!Files.exists(cfg.dataDir)) {
            try {
                Files.createDirectory(cfg.dataDir);
            } catch (IOException e) {
                System.out.println("Could not create directory");
                e.printStackTrace();
                System.exit(-1);
            }
        }

        // check if the log level is valid
        if (!Constants.LOG_LEVELS.containsKey(cfg.logLevel)) {
            System.out.println(String.format(Constants.ERROR_INVALID_LOG_LEVEL, String.join(" | ", Constants.LOG_LEVELS.keySet())));
            System.exit(-1);
        }

        // check if the cache size is valid
        if (cfg.cacheSize <= 0) {
            System.out.println("ERROR: cache size can`t be <= 0");
            System.exit(-1);
        }

        // check if the cache displacement is valid
        if (!cfg.cacheDisplacement.equals("FIFO") && !cfg.cacheDisplacement.equals("LRU") && !cfg.cacheDisplacement.equals("LFU")) {
            System.out.println("ERROR: cache size can`t be <= 0");
            System.exit(-1);
        }


        if (!parseResult.errors().isEmpty()) {
            for (Exception ex : parseResult.errors()) {
                System.out.println("ERROR: parsing arguments: " + ex.toString());
                ex.printStackTrace();
            }
            CommandLine.usage(new Config(), System.out);
            System.exit(-1);
        }

        return cfg;
    }

    @Override
    public String toString() {
        return "Config{" +
                "port=" + port +
                ", listenaddr='" + listenaddr + '\'' +
                ", bootstrap=" + bootstrap +
                ", dataDir=" + dataDir +
                ", logfile=" + logfile +
                ", logLevel=" + logLevel +
                ", cacheSize=" + cacheSize +
                ", cacheDisplacement=" + cacheDisplacement +
                ", usagehelp=" + usagehelp +
                '}';
    }
}

