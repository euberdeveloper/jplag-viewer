package de.tum.i13.server.kv;

import de.tum.i13.shared.Encode;

import java.util.stream.Collectors;
import java.util.stream.Stream;

public class KVMessageImpl implements KVMessage {
    private StatusType status;
    private String value;
    private String key;

    public KVMessageImpl(String key, String value, StatusType status) {
        this.value = value;
        this.key = key;
        this.status = status;
    }

    public KVMessageImpl(String command) throws IllegalArgumentException {
        parseMessage(command);
    }

    @Override
    public String getKey() {
        return key;
    }

    @Override
    public String getValue() {
        return value;
    }

    public void setValue(String value) {
        this.value = value;
    }

    @Override
    public StatusType getStatus() {
        return status;
    }

    @Override
    public void encode() {
        if (key != null) {
            this.key = Encode.encode(key);
        }
        if (value != null) {
            this.value = Encode.encode(value);
        }
    }

    @Override
    public void decode() {
        if (key != null) {
            this.key = Encode.decode(key);
        }
        if (value != null) {
            this.value = Encode.decode(value);
        }
    }

    @Override
    public String toString() {
        String command = String.format("%s %s", commands[this.status.ordinal()], this.key);
        if (this.value != null) {
            command += String.format(" %s", this.value);
        }
        return command;
    }

    /**
     * Parses a Message from a command string.
     *
     * @param command the command to parse
     */
    private void parseMessage(String command) {
        if (command == null || command.isEmpty()) {
            throw new IllegalArgumentException("command can not be empty");
        }
        String[] tokens = command.split(" ");
        if (tokens.length < 2) {
            throw new IllegalArgumentException("unknown command");
        }
        switch (tokens[0]) {
            case "put":
                if (tokens.length < 3) {
                    throw new IllegalArgumentException("unknown command");
                }
                this.key = tokens[1];
                this.value = Stream.of(tokens).skip(2).collect(Collectors.joining(" "));
                this.status = StatusType.PUT;
                return;
            case "put_success":
                if (tokens.length != 2) {
                    throw new IllegalArgumentException("unknown command");
                }
                this.key = tokens[1];
                this.status = StatusType.PUT_SUCCESS;
                return;
            case "put_update":
                if (tokens.length != 2) {
                    throw new IllegalArgumentException("unknown command");
                }
                this.key = tokens[1];
                this.status = StatusType.PUT_UPDATE;
                return;
            case "put_error":
                if (tokens.length != 3) {
                    throw new IllegalArgumentException("unknown command");
                }
                this.key = tokens[1];
                this.value = tokens[2];
                this.status = StatusType.PUT_UPDATE;
                return;
            case "get":
                if (tokens.length != 2) {
                    throw new IllegalArgumentException("unknown command");
                }
                this.key = tokens[1];
                this.status = StatusType.GET;
                return;
            case "get_success":
                if (tokens.length != 3) {
                    throw new IllegalArgumentException("unknown command");
                }
                this.key = tokens[1];
                this.value = tokens[2];
                this.status = StatusType.GET_SUCCESS;
                return;
            case "get_error":
                if (tokens.length != 2) {
                    throw new IllegalArgumentException("unknown command");
                }
                this.key = tokens[1];
                this.status = StatusType.GET_ERROR;
                return;
            case "delete":
                if (tokens.length != 2) {
                    throw new IllegalArgumentException("unknown command");
                }
                this.key = tokens[1];
                this.status = StatusType.DELETE;
                break;
            case "delete_success":
                if (tokens.length != 2) {
                    throw new IllegalArgumentException("unknown command");
                }
                this.key = tokens[1];
                this.status = StatusType.DELETE_SUCCESS;
                break;
            case "delete_error":
                if (tokens.length != 2) {
                    throw new IllegalArgumentException("unknown command");
                }
                this.key = tokens[1];
                this.status = StatusType.DELETE_ERROR;
                break;
            default:
                throw new IllegalArgumentException("unknown command");
        }
    }
}
