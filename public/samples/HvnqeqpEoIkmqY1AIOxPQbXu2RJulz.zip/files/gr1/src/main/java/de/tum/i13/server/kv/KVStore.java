package de.tum.i13.server.kv;

public interface KVStore {

    /**
     * Inserts a key-value pair into the KVStore.
     *
     * @param key   the key that identifies the given value.
     * @param value the value that is indexed by the given key.
     * @return a message that confirms the insertion of the tuple or an error.
     */
    KVMessage put(String key, String value);

    /**
     * Retrieves the value for a given key from the KVStore.
     *
     * @param key the key that identifies the value.
     * @return the value, which is indexed by the given key.
     */
    KVMessage get(String key);

    /**
     * Remove a key and value pair from KVStore.
     *
     * @param key the key that identifies the given value.
     * @return a message that confirms the deletion of the tuple or an error.
     */
    KVMessage delete(String key);

}