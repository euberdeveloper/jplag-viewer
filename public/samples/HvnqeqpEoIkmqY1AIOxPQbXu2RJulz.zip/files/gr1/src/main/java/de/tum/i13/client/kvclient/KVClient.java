package de.tum.i13.client.kvclient;

import de.tum.i13.server.kv.KVMessage;
import de.tum.i13.server.kv.KVMessageImpl;
import de.tum.i13.shared.Constants;
import de.tum.i13.shared.Encode;

import java.io.BufferedReader;
import java.io.IOException;
import java.util.logging.Logger;

public class KVClient implements KVStore {
    final static String TAG = KVClient.class.getName();
    private final static Logger LOGGER = Logger.getLogger(KVClient.class.getName());
    private ActiveConnection activeConnection;

    @Override
    public String connect(String host, int port) throws IOException {
        if (activeConnection != null) {
            throw new ReestablishConnectionException();
        }
        ConnectionBuilder connectionBuilder = new ConnectionBuilder(host, port);
        activeConnection = connectionBuilder.connect();
        return activeConnection.readline();
    }

    @Override
    public String disconnect() throws IOException {
        if (activeConnection == null) {
            throw new UnestablishedConnectionException();
        }
        String connectionHost = activeConnection.getInfo();
        activeConnection.close();
        activeConnection = null;
        return connectionHost;
    }

    @Override
    public KVMessage put(String key, String value) throws IOException {
        if (activeConnection == null) {
            throw new UnestablishedConnectionException();
        }
        LOGGER.finest("put: " + key + " " + value);
        // check if key or value are null or empty
        if (key == null || key.isEmpty()) throw new IllegalArgumentException("key must not be empty");
        if (value == null || value.isEmpty()) throw new IllegalArgumentException("value must not be empty");
        // encode value
        LOGGER.finest("encoding value... ");
        String valueEncrypted = Encode.encode(value);
        // check for length of key and value
        if (key.getBytes(Constants.TELNET_CHARSET).length > Constants.MAX_KEY_SIZE) {
            LOGGER.warning(String.format("invalid key length: %d", key.getBytes(Constants.TELNET_CHARSET).length));
            throw new IllegalArgumentException("key length is too big");
        }
        if (valueEncrypted.getBytes(Constants.TELNET_CHARSET).length > Constants.MAX_VALUE_SIZE) {
            LOGGER.warning(String.format("invalid value length: %d", valueEncrypted.getBytes(Constants.TELNET_CHARSET).length));
            throw new IllegalArgumentException("value length is too big");
        }

        // send message to server
        KVMessageImpl message = new KVMessageImpl(key, valueEncrypted, KVMessage.StatusType.PUT);
        try {
            message = sendReceive(message);

        } catch (Exception e) {
            LOGGER.throwing(TAG, "put", e);
            throw new IOException("Network Error: Could not receive data");
        }
        return message;
    }

    @Override
    public KVMessage get(String key) throws IOException {
        if (activeConnection == null) {
            throw new UnestablishedConnectionException();
        }
        LOGGER.finest("get: " + key);
        //check if key is null or empty
        if (key == null || key.isEmpty()) throw new IllegalArgumentException("key must not be empty");
        // check for length of key
        if (key.getBytes(Constants.TELNET_CHARSET).length > Constants.MAX_KEY_SIZE) {
            LOGGER.warning(String.format("invalid key length: %d", key.getBytes(Constants.TELNET_CHARSET).length));
            throw new IllegalArgumentException("key length is too big");
        }

        // send message to server
        KVMessageImpl message = new KVMessageImpl(key, null, KVMessage.StatusType.GET);
        try {
            message = sendReceive(message);

        } catch (Exception e) {
            LOGGER.throwing(TAG, "get", e);
            throw new IOException("Network Error: Could not receive data");
        }

        return message;
    }

    @Override
    public KVMessage delete(String key) throws IOException {
        if (activeConnection == null) {
            throw new UnestablishedConnectionException();
        }
        LOGGER.finest("del: " + key);
        // check if key is null or empty
        if (key == null || key.isEmpty()) throw new IllegalArgumentException("key must not be empty");
        // check for length of key
        if (key.getBytes(Constants.TELNET_CHARSET).length > Constants.MAX_KEY_SIZE) {
            LOGGER.warning(String.format("invalid key length: %d", key.getBytes(Constants.TELNET_CHARSET).length));
            throw new IllegalArgumentException("key length is too big");
        }

        KVMessageImpl message = new KVMessageImpl(key, null, KVMessage.StatusType.DELETE);
        // send message to server
        try {
            message = sendReceive(message);

        } catch (Exception e) {
            LOGGER.throwing(TAG, "KVClient", e);
            throw new IOException("Network Error: Could not receive data");
        }

        return message;
    }

    /**
     * Sends a {@link KVMessage} to the server and receives the result.
     *
     * @param message the message to send
     * @return the received message
     * @throws IOException              exceptions from {@link BufferedReader#readLine()}
     * @throws IllegalArgumentException very unlikely from {@link KVMessageImpl#KVMessageImpl(String)}
     */
    private KVMessageImpl sendReceive(KVMessageImpl message) throws IOException, IllegalArgumentException {
        //Sending Data
        LOGGER.info("Sending message: " + message.toString());
        String sending = message.toString();
        activeConnection.write(sending);
        try {
            //Receiving Data
            String received = activeConnection.readline();
            LOGGER.info("Received message: " + received);
            //Decoding the received String
            message = new KVMessageImpl(received);
            LOGGER.finest("decoding received String from Server... ");
            if (message.getValue() != null) {
                message.setValue(Encode.decode(message.getValue()));
            }
        } catch (Exception e) {
            LOGGER.throwing(TAG, "KVClient", e);
            throw new IOException("Network Error: Could not receive data");
        }
        return message;
    }

}
