package de.tum.i13.server.kv.kvcache;

/**
 * Provides the external interface to interact with an thread save cache.
 */
public abstract class KVCache {

    // max size of the cache
    private final int maxSize;

    /**
     * Initializes the Cache with max size
     *
     * @param size the max size of the cache
     */
    protected KVCache(int size) {
        this.maxSize = size;
    }

    /**
     * Retrieves the value for the key from the cache if present,
     * otherwise (on cache-miss) returns null.
     *
     * @param key the key of the value
     * @return the value or null on cache-miss
     */
    public abstract String get(String key);

    /**
     * Inserts the key-value-pair into th cache.
     * If the cache is full, an element is removed by {@link KVCache#evict()}
     * inorder to make space for the new element.
     *
     * @param key   the key of the element
     * @param value the value of the element
     */
    public abstract void put(String key, String value);

    /**
     * Removes a key-value-pair from cache if this key is present.
     *
     * @param key the key to remove
     */
    public abstract void delete(String key);

    /**
     * Removes an element from the cache to make space for new inserts.
     * Implements the cache resizing policies.
     */
    protected abstract void evict();

    /**
     * Clears all elements from the cache.
     */
    public abstract void clear();

    /**
     * Returns the max size of the cache.
     *
     * @return the max size
     */
    public int getMaxSize() {
        return maxSize;
    }
}
