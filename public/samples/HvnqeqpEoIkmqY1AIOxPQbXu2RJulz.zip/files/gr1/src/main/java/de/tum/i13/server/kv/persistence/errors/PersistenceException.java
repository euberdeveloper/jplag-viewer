package de.tum.i13.server.kv.persistence.errors;

/**
 * Idea is to convert Checked IO exceptions to runtime PersistenceException
 */
public class PersistenceException extends RuntimeException {
    public PersistenceException(String msg) {
        super(msg);
    }

    public PersistenceException(String msg, Throwable err) {
        super(msg, err);
    }
}
