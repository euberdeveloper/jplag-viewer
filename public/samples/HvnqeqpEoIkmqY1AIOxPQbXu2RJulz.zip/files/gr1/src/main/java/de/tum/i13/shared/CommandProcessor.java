package de.tum.i13.shared;

import java.net.InetAddress;
import java.net.InetSocketAddress;

/**
 * Defines how the server handles requests from clients and responds to connect and disconnect operations.
 */
public interface CommandProcessor {

    /**
     * Processes a command and returns the resulting message.
     *
     * @param command the command to execute
     * @return resulting message
     */
    String process(String command);

    /**
     * Handles how the server responds to an accepted connection.
     *
     * @param address       the address of the server
     * @param remoteAddress the address of the client
     * @return resulting message
     */
    String connectionAccepted(InetSocketAddress address, InetSocketAddress remoteAddress);

    /**
     * Handles how the server responds to a closed connection.
     *
     * @param remoteAddress the address of the client
     */
    void connectionClosed(InetAddress remoteAddress);
}
