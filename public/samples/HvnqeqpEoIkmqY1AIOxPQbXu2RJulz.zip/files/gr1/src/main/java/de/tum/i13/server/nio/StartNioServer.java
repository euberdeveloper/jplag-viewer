package de.tum.i13.server.nio;

import de.tum.i13.server.kv.KVCommandProcessor;
import de.tum.i13.server.kv.KVStoreImpl;
import de.tum.i13.server.kv.kvcache.FifoCache;
import de.tum.i13.server.kv.kvcache.KVCache;
import de.tum.i13.server.kv.kvcache.LfuCache;
import de.tum.i13.server.kv.kvcache.LruCache;
import de.tum.i13.server.kv.persistence.DiskPersistence;
import de.tum.i13.server.kv.persistence.LogStructuredDiskPersistence;
import de.tum.i13.server.kv.persistence.errors.PersistenceException;
import de.tum.i13.shared.CommandProcessor;
import de.tum.i13.shared.Config;
import de.tum.i13.shared.Constants;
import de.tum.i13.shared.LogSetup;

import java.io.IOException;
import java.net.BindException;
import java.util.logging.Logger;

import static de.tum.i13.shared.Config.parseCommandlineArgs;
import static de.tum.i13.shared.LogSetup.setupLogging;

public class StartNioServer {

    public static Logger logger = Logger.getLogger(StartNioServer.class.getName());

    public static void main(String[] args) throws IOException {
        Config cfg = parseCommandlineArgs(args);  //Do not change this
        setupLogging(cfg.logfile);
        logger.info("Config: " + cfg.toString());
        // set the desired log level
        LogSetup.changeLogLevel(Constants.LOG_LEVELS.get(cfg.logLevel));
        logger.info("loglevel set to: " + cfg.logLevel);

        logger.info("starting server");

        // init the cache with the desired displacement strategy and max size
        KVCache cache = null;
        switch (cfg.cacheDisplacement) {
            case "FIFO":
                logger.info("initializing FIFO cache");
                cache = new FifoCache(cfg.cacheSize);
                break;
            case "LRU":
                logger.info("initializing LRU cache");
                cache = new LruCache(cfg.cacheSize);
                break;
            case "LFU":
                logger.info("initializing LFU cache");
                cache = new LfuCache(cfg.cacheSize);
                break;
            default:
                logger.info("initializing FIFO cache");
                cache = new FifoCache(cfg.cacheSize);

        }
        DiskPersistence persistence;
        try {
            logger.info("initializing persistent data store");
            persistence = new LogStructuredDiskPersistence(cfg.dataDir.toString());
        } catch (PersistenceException e) {
            logger.throwing(StartNioServer.class.getName(), "main", e);
            System.out.println("ERROR: unable to open key value store file");
            System.exit(-1);
            return;
        }
        // init our command processor
        CommandProcessor kvLogic = new KVCommandProcessor(
                new KVStoreImpl(
                        persistence,
                        cache)
        );
        logger.info("initializing nio server");
        NioServer sn = new NioServer(kvLogic);
        try {
            sn.bindSockets(cfg.listenaddr, cfg.port);
            sn.start();
        } catch (Exception e) {
            logger.throwing(StartNioServer.class.getName(), "main", e);
            if (e instanceof BindException) {
                System.out.println("ERROR: the specified listen address and port is already bound");
            } else if (e instanceof IllegalArgumentException) {
                System.out.println("ERROR: the specified address is invalid or the port is out of range");
            } else {
                System.out.println("ERROR: arbitrary I/O error”");
                e.printStackTrace();
            }
            System.exit(-1);
        }
    }
}
