package de.tum.i13.shared;

import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;
import java.util.HashMap;
import java.util.Map;
import java.util.logging.Level;


/**
 * <h1>Holds all constants used by the KVServer and Client.</h1>
 * The Constants class mainly contains text constants used to display to the user of the program.
 * In addition application protocol specific message contracts are stored here.
 */
public class Constants {
    public static final String TELNET_ENCODING = "ISO-8859-1"; // encoding for telnet
    // the charset used to en- and decode messages send by and to the client
    public static final Charset TELNET_CHARSET = StandardCharsets.ISO_8859_1;
    // the message delimiter indicating the end of a message
    public static final byte[] MESSAGE_DELIMITER = new byte[]{(byte) '\r', (byte) '\n'};
    // all available log levels stored in a convenient way for input validation and user hinting
    public static final Map<String, Level> LOG_LEVELS;

    static {
        LOG_LEVELS = new HashMap<>();
        LOG_LEVELS.put(Level.ALL.getName(), Level.ALL);
        LOG_LEVELS.put(Level.SEVERE.getName(), Level.SEVERE);
        LOG_LEVELS.put(Level.CONFIG.getName(), Level.CONFIG);
        LOG_LEVELS.put(Level.FINE.getName(), Level.FINE);
        LOG_LEVELS.put(Level.FINER.getName(), Level.FINER);
        LOG_LEVELS.put(Level.FINEST.getName(), Level.FINEST);
        LOG_LEVELS.put(Level.INFO.getName(), Level.INFO);
        LOG_LEVELS.put(Level.OFF.getName(), Level.OFF);
        LOG_LEVELS.put(Level.WARNING.getName(), Level.WARNING);
    }

    // definition of all available commands supported by the CLI
    public static final String COMMAND_CONNECT = "connect <address> <port>";
    public static final String COMMAND_PUT = "put <key> <value>";
    public static final String COMMAND_GET = "get <key>";
    public static final String COMMAND_DEL = "del <key>";


    public static final String COMMAND_DISCONNECT = "disconnect";
    public static final String COMMAND_LOG_LEVEL = "logLevel <level>";
    public static final String COMMAND_HELP = "help";
    public static final String COMMAND_QUIT = "quit";
    // definition of the error messages displayed by the CLI
    public static final String ERROR_INVALID_NUMBER_ARGUMENTS = "ERROR: invalid number of arguments, please use the command as follows: %s";
    public static final String ERROR_INVALID_ARGUMENT_PORT = "ERROR: invalid argument <port>, port must be a number";
    public static final String ERROR_PORT_OUT_OF_RANGE = "ERROR: the port needs to be in range of [0, 65535], please check your input";
    public static final String ERROR_UNKNOWN_COMMAND = "ERROR: unknown command, please have a look at the command list below";
    public static final String ERROR_INPUT_EXCEPTION = "ERROR: error reading input, shutting down...";
    public static final String ERROR_RECONNECT = "ERROR: there is already a connection active, please disconnect from your current target first using the command: %s";
    public static final String ERROR_UNKNOWN_HOST = "ERROR: the connection target (%s:%d) is unknown, please check your input";
    public static final String ERROR_OPERATION_PERMITTED = "ERROR: connecting to the target, the operation is permitted";
    public static final String ERROR_I_O_EXCEPTION = "ERROR: an unexpected error occured";
    public static final String ERROR_NO_CONNECTION = "ERROR: no connection established, please connect to a target first using the command: %s";
    public static final String ERROR_INVALID_LOG_LEVEL = "ERROR: invalid log-level specified, please use one of the following: (%s)";
    public static final String ERROR_SOCKET_TIMEOUT = "ERROR: the echo server has not responded in time, please try again";
    // help text displayed through the 'help' command
    public static final String HELP_TEXT = "List of commands:\n\n"
            + "\t\t\t\t" + COMMAND_CONNECT + ": connects to a given kvstore server" + "\n"
            + "\t\t\t\t\t\t" + "<address>: either valid hostname or ip address\n"
            + "\t\t\t\t\t\t" + "<port>: valid port in range of [0, 65535]\n\n"
            + "\t\t\t\t" + COMMAND_DISCONNECT + ": disconnects from the current kvstore server" + "\n\n"
            + "\t\t\t\t" + COMMAND_PUT + ": inserts a key value pair in the kvstore server" + "\n"
            + "\t\t\t\t\t\t" + "<key>: the key of the pair, must not contain whitespace or linebreak, max length 20\n"
            + "\t\t\t\t\t\t" + "<value>: the value of the pair, max length 120kB\n\n"
            + "\t\t\t\t" + COMMAND_GET + ": fetches a key value pair from the kvstore server" + "\n"
            + "\t\t\t\t\t\t" + "<key>: the key of the pair, must not contain whitespace or linebreak, max length 20\n\n"
            + "\t\t\t\t" + COMMAND_DEL + ": deletes a key value pair from the kvstore server" + "\n"
            + "\t\t\t\t\t\t" + "<key>: the key of the pair, must not contain whitespace or linebreak, max length 20\n\n"
            + "\t\t\t\t" + COMMAND_LOG_LEVEL + ": sets the log level of the client" + "\n"
            + "\t\t\t\t\t\t" + "<level>: (" + String.join(" | ", LOG_LEVELS.keySet()) + ")\n\n"
            + "\t\t\t\t" + COMMAND_HELP + ": prints this help text" + "\n\n"
            + "\t\t\t\t" + COMMAND_QUIT + ": quits the application" + "\n";
    // request max size constants
    public static final int MAX_KEY_SIZE = 20;
    public static final int MAX_VALUE_SIZE = 120000;

}




