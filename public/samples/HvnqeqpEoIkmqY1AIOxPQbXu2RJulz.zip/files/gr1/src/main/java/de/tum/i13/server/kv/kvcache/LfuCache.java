package de.tum.i13.server.kv.kvcache;

import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashSet;
import java.util.Map;

/**
 * LFU Cache implementation in O(1)
 *
 * @see <a href="http://dhruvbird.com/lfu.pdf">http://dhruvbird.com/lfu.pdf</a>
 */
public class LfuCache extends KVCache {
    // the cache map used to store temporary cache entries
    HashMap<String, CacheItem> cache;
    // the start of the frequency list ordered from least to most frequent accessed
    FrequencyNode head;

    /**
     * Initializes the Cache with max size
     *
     * @param size the max size of the cache
     */
    public LfuCache(int size) {
        super(size);
        if (size <= 0) {
            throw new IllegalArgumentException("size must be greater zero");
        }
        cache = new HashMap<>();
        head = new FrequencyNode();
    }

    @Override
    public String get(String key) {
        if (key == null) {
            throw new NullPointerException("key must be != null");
        }
        String value;
        synchronized (this) {
            // retrieve the cached element
            CacheItem item = cache.get(key);
            if (item == null) {
                // cache miss
                return null;
            }
            value = item.value;
            increaseFrequency(item, key);
        }
        return value;
    }

    /**
     * Increases the frequency of a given cache item by one
     *
     * @param item the cache item
     * @param key  the key of the item
     */
    private void increaseFrequency(CacheItem item, String key) {
        // check if a frequency node exists that can hold our newly updated frequency
        FrequencyNode currentFreq = item.parent;
        FrequencyNode nextFreq = currentFreq.next;
        if (nextFreq.frequency == 0 || nextFreq.frequency != currentFreq.frequency + 1) {
            // create a new node if no suitable node was found
            nextFreq = new FrequencyNode(currentFreq.frequency + 1, currentFreq, nextFreq);
        }
        // add the cache key to the higher frequency
        nextFreq.addItem(key);
        // save the new frequency node parent of the cached item
        item.parent = nextFreq;
        // remove the cache key from the previous frequency node
        currentFreq.removeItem(key);
        // delete the old frequency node if it is now empty
        if (currentFreq.size() == 0) {
            currentFreq.remove();
        }
    }

    @Override
    public void put(String key, String value) {
        if (key == null || value == null) {
            throw new NullPointerException("key and value must be != null");
        }
        synchronized (this) {
            // check if the cache already contains this key
            // and update its value
            if (cache.containsKey(key)) {
                // no need to evict
                CacheItem item = cache.get(key);
                item.value = value;
                this.cache.put(key, item);
                // increase the frequency on each additional put
                increaseFrequency(item, key);
                return;
            }
        }
        // perform eviction if needed
        evict();
        synchronized (this) {
            // if the key is new insert it to the frequency node with value one
            FrequencyNode freqOne = head.next;
            // check if the node with value one exists, if not create it
            if (freqOne.frequency != 1) {
                freqOne = new FrequencyNode(1, head, freqOne);
            }
            // add the key to the node
            freqOne.addItem(key);
            // insert the cache item into cache
            cache.put(key, new CacheItem(value, freqOne));
        }
    }

    @Override
    public void delete(String key) {
        synchronized (this) {
            // retrieve the cached element
            CacheItem item = cache.get(key);
            if (item == null) {
                // cache miss
                return;
            }
            // remove the item from the frequency list
            item.parent.removeItem(key);
            if (item.parent.size() == 0) {
                // remove the node if needed
                item.parent.remove();
            }
            cache.remove(key);
        }
    }

    @Override
    protected void evict() {
        while (true) {
            synchronized (this) {
                // determine if eviction is needed
                if (cache.size() < this.getMaxSize()) {
                    break;
                }
                // the least frequently used item will always be in the node next to our
                // lists head, so simply look it up
                CacheItem toEvict = cache.remove(head.next.evictKey());
                // check if we clear the node with this removal and remove it as well if needed
                if (toEvict.parent.size() == 0) {
                    toEvict.parent.remove();
                }
            }
        }
    }

    @Override
    public void clear() {
        synchronized (this) {
            // clear the cache
            cache.clear();
            // clear the frequency list
            head.clear();
        }
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        synchronized (this) {
            Iterator<Map.Entry<String, CacheItem>> iter = cache.entrySet().iterator();
            while (iter.hasNext()) {
                Map.Entry<String, CacheItem> entry = iter.next();
                sb.append(entry.getKey());
                sb.append('=').append('"');
                sb.append(entry.getValue().toString());
                sb.append('"');
                if (iter.hasNext()) {
                    sb.append(',').append(' ');
                }
            }
        }
        return sb.toString();
    }

    /**
     * Double linked list to hold cache keys ordered by their frequency.
     */
    private static class FrequencyNode {
        // the frequency of the node
        int frequency;
        // the cache keys of this node
        LinkedHashSet<String> items;
        // previous node
        FrequencyNode prev;
        // next node
        FrequencyNode next;

        /**
         * Initializes the double linked list by creating its head.
         */
        public FrequencyNode() {
            this.frequency = 0;
            this.prev = this;
            this.next = this;
            items = new LinkedHashSet<>();

        }

        /**
         * Creates and inserts a new Node.
         *
         * @param frequency the frequency of the node
         * @param prev      the previous lower frequency
         * @param next      the next higher frequency
         */
        public FrequencyNode(int frequency, FrequencyNode prev, FrequencyNode next) {
            this.frequency = frequency;
            this.prev = prev;
            this.next = next;
            this.prev.next = this;
            this.next.prev = this;
            this.items = new LinkedHashSet<>();
        }

        void remove() {
            if (!hasPrev()) {
                // is head
                throw new IllegalStateException("cant remove head of frequency list");
            } else if (!hasNext()) {
                // is tail
                this.prev.next = this.prev;
            } else {
                // normal remove
                prev.next = next;
                next.prev = prev;
            }
        }

        void addItem(String key) {
            items.add(key);
        }

        void removeItem(String key) {
            items.remove(key);
        }

        String evictKey() {
            if (items.size() > 0) {
                // remove the oldest item if this frequency
                // and return its key
                Iterator<String> it = items.iterator();
                String removed = it.next();
                it.remove();
                return removed;
            } else {
                return null;
            }
        }

        int size() {
            return items == null ? 0 : items.size();
        }

        private boolean hasNext() {
            return next != this;
        }

        private boolean hasPrev() {
            return prev != this;
        }

        public void clear() {
            if (hasNext()) {
                next.clear();
            }
            next = this;
            prev = this;
        }
    }

    /**
     * A cache item to store in a cache map.
     * Also holds a reference to the frequency node it belongs to.
     */
    private static class CacheItem {
        String value;
        FrequencyNode parent;

        public CacheItem(String value, FrequencyNode parent) {
            this.value = value;
            this.parent = parent;
        }

        @Override
        public String toString() {
            return "{ value: " + value + ", parent: " + parent.frequency + " }";
        }
    }
}
