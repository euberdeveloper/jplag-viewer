package de.tum.i13.server.kv.persistence;

import de.tum.i13.server.kv.KVMessage;

/**
 * Changed to return KV Message as the put should specify if the element existed before
 */
public interface DiskPersistence {
    KVMessage get(String key);

    KVMessage put(String key, String value);

    KVMessage delete(String key);
}
