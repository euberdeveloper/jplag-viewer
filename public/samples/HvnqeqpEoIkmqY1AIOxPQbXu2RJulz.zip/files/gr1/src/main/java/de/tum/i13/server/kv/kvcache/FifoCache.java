package de.tum.i13.server.kv.kvcache;

/**
 * This is a FIFO cache configuration of the {@link InsertAccessCache}.
 */
public class FifoCache extends InsertAccessCache {
    /**
     * Initializes the Cache with max size
     * And sets the access order to false to use sorting by insert order.
     *
     * @param size the max size of the cache
     * @see java.util.LinkedHashMap#LinkedHashMap(int, float, boolean)
     */
    public FifoCache(int size) {
        // set the access order to false to achieve FIFO displacement
        super(size, false);
    }
}
