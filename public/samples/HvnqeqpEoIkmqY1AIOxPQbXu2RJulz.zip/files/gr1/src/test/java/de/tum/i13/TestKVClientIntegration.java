package de.tum.i13;

import de.tum.i13.client.kvclient.KVClient;
import de.tum.i13.server.nio.StartNioServer;
import org.junit.jupiter.api.*;

import java.io.File;
import java.io.IOException;
import java.util.concurrent.Callable;

import static org.hamcrest.CoreMatchers.*;
import static org.hamcrest.MatcherAssert.assertThat;


@TestInstance(TestInstance.Lifecycle.PER_CLASS)
@TestMethodOrder(MethodOrderer.OrderAnnotation.class)
public class TestKVClientIntegration {
    private static final Integer port = 5154;

    private static final KVClient client = new KVClient();
    private static Thread server;


    @BeforeAll
    public static void doConnect() throws InterruptedException, IOException {
        File file = new File("data", "log.txt");
        if (file.exists()) {
            file.delete();
        }
        server = new Thread() {
            @Override
            public void run() {
                try {
                    StartNioServer.main(new String[]{"-p", port.toString(), "-s", "LFU", "-c", "10", "-ll", "WARNING"});
                } catch (IOException e) {
                   return;
                }
            }
        };
        server.start(); // started the server
        Thread.sleep(2000);
        assertThat(client.connect("127.0.0.1", port), is(equalTo("Connection to KVStore server established: /127.0.0.1:5154")));
    }

    @AfterAll
    public static void Disconnect() throws IOException, InterruptedException {
        client.disconnect();
        server.interrupt();
    }


    private static String createDataSize(int msgSize) {
        StringBuilder sb = new StringBuilder(msgSize);
        for (int i = 0; i < msgSize; i++) {
            sb.append('a');
        }
        return sb.toString();
    }

    @Test
    @Order(1)
    public void testPut() throws IOException {
        // check normal insert
        assertThat(client.put("test", "test").toString(), equalTo("put_success test"));
    }

    @Test
    @Order(2)
    public void testUpdate() throws IOException {
        // check normal insert
        assertThat(client.put("update", "test").toString(), is(equalTo("put_success update")));
        // check normal update
        assertThat(client.put("update", "test1").toString(), is(equalTo("put_update update")));
    }

    @Test
    @Order(3)
    public void testPutMaxKeySize() throws IOException {
        // check insert max key length
        String hugeData = createDataSize(20);
        assertThat(client.put(hugeData, "test").toString(), is(equalTo("put_success " + hugeData)));
        // check insert key length to big
        hugeData = createDataSize(21);
        String finalHugeData = hugeData;
        assertThat(exceptionOf(() -> client.put(finalHugeData, "test2")), instanceOf(IllegalArgumentException.class));

    }

    @Test
    @Order(4)
    public void testPutMaxValueSize() throws IOException {
        // check insert max value length
        String hugeData = createDataSize(calculateBase64(120000));
        assertThat(client.put("test1", hugeData).toString(), is(equalTo("put_success test1")));
        // check insert value length to big
        hugeData = createDataSize(calculateBase64(120004));
        String finalHugeData = hugeData;
        assertThat(exceptionOf(() -> client.put("test2", finalHugeData)), instanceOf(IllegalArgumentException.class));
    }

    @Test
    @Order(5)
    public void testGet() throws IOException {
        assertThat(client.put("get", "test").toString(), is(equalTo("put_success get")));
        assertThat(client.get("get").toString(), is(equalTo("get_success get test")));
        assertThat(client.put("get", "test_updated").toString(), is(equalTo("put_update get")));
        assertThat(client.get("get").toString(), is(equalTo("get_success get test_updated")));
        assertThat(client.get("get1").toString(), is(equalTo("get_error get1")));
    }

    @Test
    @Order(6)
    public void testGetMaxKeySize() throws IOException {
        // check get max key length
        String hugeData = createDataSize(20);
        assertThat(client.get(hugeData).toString(), is(equalTo("get_success " + hugeData + " test")));
        // check get key length to big
        hugeData = createDataSize(21);
        String finalHugeData = hugeData;
        assertThat(exceptionOf(() -> client.get(finalHugeData)), instanceOf(IllegalArgumentException.class));

    }

    @Test
    @Order(7)
    public void testDelete() throws IOException {
        assertThat(client.put("delete", "test").toString(), is(equalTo("put_success delete")));
        assertThat(client.delete("delete").toString(), is(equalTo("delete_success delete")));
        assertThat(client.get("delete").toString(), is(equalTo("get_error delete")));
        assertThat(client.delete("delete").toString(), is(equalTo("delete_error delete")));
    }

    @Test
    @Order(8)
    public void testDeleteMaxKeySize() throws IOException {
        // check get max key length
        String hugeData = createDataSize(20);
        assertThat(client.delete(hugeData).toString(), is(equalTo("delete_success " + hugeData)));
        // check get key length to big
        hugeData = createDataSize(21);
        String finalHugeData = hugeData;
        assertThat(exceptionOf(() -> client.delete(finalHugeData)), instanceOf(IllegalArgumentException.class));

    }

    @Test
    @Order(8)
    public void testWhitespace() throws IOException {
        // test whitespace in value
        assertThat(client.put("apple123@#", "orange-@+$ test").toString(), is(equalTo("put_success apple123@#")));
        assertThat(client.get("apple123@#").toString(), is(equalTo("get_success apple123@# orange-@+$ test")));
        assertThat(client.delete("apple123@#").toString(), is(equalTo("delete_success apple123@#")));
        assertThat(client.get("apple123@#").toString(), is(equalTo("get_error apple123@#")));
    }

    /**
     * Returns the number of characters to get a message of length desiredCharCount after base64 encoding.
     *
     * @param desiredCharCount  the number of bytes the base64 encoded message should have
     * @return  the number of characters needed to get to the desired size after base64
     */
    public int calculateBase64(int desiredCharCount) {
        return (desiredCharCount*3)/4;
    }


    public static Throwable exceptionOf(Callable<?> callable) {
        try {
            callable.call();
            return null;
        } catch (Throwable t) {
            return t;
        }
    }

}
