package de.tum.i13;

import de.tum.i13.server.kv.kvcache.FifoCache;
import de.tum.i13.server.kv.kvcache.KVCache;
import de.tum.i13.server.kv.kvcache.LfuCache;
import de.tum.i13.server.kv.kvcache.LruCache;
import org.junit.jupiter.api.Test;

import static org.hamcrest.CoreMatchers.equalTo;
import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.MatcherAssert.assertThat;

public class TestKVCache {

    @Test
    public void testFifoCache() {
        KVCache kvCache = new FifoCache(10);
        for (int i = 0; i < 10; i++) {
            kvCache.put(Integer.toString(i), Integer.toString(i));
        }
        for (int i = 0; i < 10; i++) {
            assertThat(kvCache.get(Integer.toString(i)), is(equalTo(Integer.toString(i))));
        }
        // test correct eviction
        kvCache.put("10", "10");
        assertThat(kvCache.get("10"), is(equalTo("10")));
        assertThat(kvCache.get("0"), is(equalTo(null)));
    }

    @Test
    public void testLruCache() {
        KVCache kvCache = new LruCache(10);
        for (int i = 0; i < 10; i++) {
            kvCache.put(Integer.toString(i), Integer.toString(i));
        }
        for (int i = 0; i < 10; i++) {
            assertThat(kvCache.get(Integer.toString(i)), is(equalTo(Integer.toString(i))));
        }
        // test correct eviction
        // set 0 to tail => therefore 1 will be evicted
        kvCache.get("0");
        kvCache.put("10", "10");
        assertThat(kvCache.get("10"), is(equalTo("10")));
        assertThat(kvCache.get("0"), is(equalTo("0")));
        assertThat(kvCache.get("1"), is(equalTo(null)));
    }

    @Test
    public void testLfuCache() {
        KVCache kvCache = new LfuCache(10);
        for (int i = 0; i < 10; i++) {
            kvCache.put(Integer.toString(i), Integer.toString(i));
        }
        for (int i = 0; i < 10; i++) {
            assertThat(kvCache.get(Integer.toString(i)), is(equalTo(Integer.toString(i))));
        }
        // test correct eviction
        // set 0 to tail => therefore 1 will be evicted
        kvCache.get("0");
        kvCache.put("10", "10");
        // set two to tail and increase frequency of 10 to not evict it right away
        kvCache.get("2");
        kvCache.put("10", "10");
        // insert new element => 3 will be evicted
        kvCache.put("11", "11");
        assertThat(kvCache.get("1"), is(equalTo(null)));
        assertThat(kvCache.get("3"), is(equalTo(null)));
        assertThat(kvCache.get("10"), is(equalTo("10")));
        assertThat(kvCache.get("11"), is(equalTo("11")));
    }
}
