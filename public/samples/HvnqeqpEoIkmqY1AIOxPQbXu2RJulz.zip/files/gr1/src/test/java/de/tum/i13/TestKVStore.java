package de.tum.i13;

import de.tum.i13.server.kv.KVMessage;
import de.tum.i13.server.kv.KVMessageImpl;
import de.tum.i13.server.kv.KVStore;
import de.tum.i13.server.kv.KVStoreImpl;
import de.tum.i13.server.kv.kvcache.KVCache;
import de.tum.i13.server.kv.persistence.DiskPersistence;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestInstance;

import static org.hamcrest.CoreMatchers.equalTo;
import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.mockito.Mockito.*;

@TestInstance(TestInstance.Lifecycle.PER_CLASS)
public class TestKVStore {
    static DiskPersistence diskPersistence;
    static KVCache kvCache;
    static KVStore kvStore;

    @BeforeAll
    public static void setUp() {
        diskPersistence = mock(DiskPersistence.class);
        kvCache = mock(KVCache.class);
        for (int i = 0; i < 3; i++) {
            String key = "key" + i;
            String value = "val" + i;
            when(diskPersistence.get(key)).thenReturn(new KVMessageImpl(key, value, KVMessage.StatusType.GET_SUCCESS));
        }
        when(kvCache.get("key2")).thenReturn("val2");
        when(kvCache.get("key0")).thenReturn(null);
        when(kvCache.get("key1")).thenReturn(null);

        doNothing().when(kvCache).put("key3", "val3");
        when(diskPersistence.put("key3", "val3")).thenReturn(new KVMessageImpl("key3", "val3", KVMessage.StatusType.PUT_SUCCESS));

        doNothing().when(kvCache).delete("key4");
        when(diskPersistence.delete("key4")).thenReturn(new KVMessageImpl("key4", null, KVMessage.StatusType.DELETE_SUCCESS));

        kvStore = new KVStoreImpl(diskPersistence, kvCache);
    }

    @Test
    public void testGetNotInCache() {
        KVMessage result = kvStore.get("key1");
        assertThat(KVMessage.StatusType.GET_SUCCESS, is(equalTo(result.getStatus())));
        assertThat("val1", is(equalTo(result.getValue())));

        verify(diskPersistence, times(1)).get("key1");
        verify(kvCache, times(1)).get("key1");
    }

    @Test
    public void testGetInCache() {
        KVMessage result = kvStore.get("key2");
        assertThat(KVMessage.StatusType.GET_SUCCESS, is(equalTo(result.getStatus())));
        assertThat("val2", is(equalTo(result.getValue())));

        verify(diskPersistence, times(0)).get("key2");
        verify(kvCache, times(1)).get("key2");
    }

    @Test
    public void testDelete() {
        KVMessage res = kvStore.delete("key4");
        assertThat("key4", is(equalTo(res.getKey())));

        verify(diskPersistence, times(1)).delete("key4");
        verify(kvCache, times(1)).delete("key4");
    }

    @Test
    public void testPut() {
        KVMessage res = kvStore.put("key3", "val3");
        assertThat("key3", is(equalTo(res.getKey())));

        verify(diskPersistence, times(1)).put("key3", "val3");
        verify(kvCache, times(1)).put("key3", "val3");
    }
}
