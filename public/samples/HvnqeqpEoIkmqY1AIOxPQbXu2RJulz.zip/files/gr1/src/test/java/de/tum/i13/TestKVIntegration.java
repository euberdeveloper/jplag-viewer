package de.tum.i13;

import de.tum.i13.server.nio.StartNioServer;
import org.junit.jupiter.api.*;

import java.io.*;
import java.net.InetSocketAddress;
import java.net.Socket;
import java.time.Duration;
import java.time.Instant;
import java.util.ArrayList;
import java.util.concurrent.BrokenBarrierException;
import java.util.concurrent.CyclicBarrier;

import static org.hamcrest.CoreMatchers.equalTo;
import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.MatcherAssert.assertThat;

@TestInstance(TestInstance.Lifecycle.PER_CLASS)
@TestMethodOrder(MethodOrderer.OrderAnnotation.class)
public class TestKVIntegration {

    private static final Integer port = 5153;
    private static Thread th;
    private static Socket s;

    @BeforeAll
    public static void doConnect() throws InterruptedException, IOException {
        File file = new File("data", "log.txt");
        if (file.exists()) {
            file.delete();
        }
        th = new Thread() {
            @Override
            public void run() {
                try {
                    StartNioServer.main(new String[]{"-p", port.toString(), "-s", "LFU", "-c", "10"}); // , "-ll", "WARNING"
                } catch (IOException e) {
                    return;
                }
            }
        };
        th.start(); // started the server
        Thread.sleep(2000);

        s = new Socket();
        s.connect(new InetSocketAddress("127.0.0.1", port));
        assertThat(readResponse(s), is(equalTo("Connection to KVStore server established: /127.0.0.1:5153")));
    }

    @AfterAll
    public static void doDisconnect() throws IOException {
        s.close();
        th.interrupt();
    }

    private static String doRequest(Socket s, String req) throws IOException {
        PrintWriter output = new PrintWriter(s.getOutputStream());
        BufferedReader input = new BufferedReader(new InputStreamReader(s.getInputStream()));

        output.write(req + "\r\n");
        output.flush();

        String res = input.readLine();
        return res;
    }

    private static String readResponse(Socket s) throws IOException {
        BufferedReader input = new BufferedReader(new InputStreamReader(s.getInputStream()));
        String res = input.readLine();
        return res;
    }

    private static String createDataSize(int msgSize) {
        StringBuilder sb = new StringBuilder(msgSize);
        for (int i = 0; i < msgSize; i++) {
            sb.append('a');
        }
        return sb.toString();
    }

    @Test
    @Order(1)
    public void testPut() throws IOException {
        // check normal insert
        assertThat(doRequest(s, "put test test"), is(equalTo("put_success test")));
    }

    @Test
    @Order(2)
    public void testUpdate() throws IOException {
        // check normal insert
        assertThat(doRequest(s, "put update test"), is(equalTo("put_success update")));
        // check normal update
        assertThat(doRequest(s, "put update test1"), is(equalTo("put_update update")));
    }

    @Test
    @Order(3)
    public void testPutMaxKeySize() throws IOException {
        // check insert max key length
        String hugeData = createDataSize(20);
        assertThat(doRequest(s, "put " + hugeData + " test"), is(equalTo("put_success " + hugeData)));
        // check insert key length to big
        hugeData = createDataSize(21);
        assertThat(doRequest(s, "put " + hugeData + " test2"), is(equalTo("put_error " + hugeData + " test2")));
    }

    @Test
    @Order(4)
    public void testPutMaxValueSize() throws IOException {
        // check insert max value length
        String hugeData = createDataSize(120000);
        assertThat(doRequest(s, "put test1 " + hugeData), is(equalTo("put_success test1")));
        // check insert value length to big
        hugeData = createDataSize(120001);
        assertThat(doRequest(s, "put test2 " + hugeData), is(equalTo("put_error test2 " + hugeData)));
    }

    @Test
    @Order(5)
    public void testGet() throws IOException {
        assertThat(doRequest(s, "put get test"), is(equalTo("put_success get")));
        assertThat(doRequest(s, "get get"), is(equalTo("get_success get test")));
        assertThat(doRequest(s, "put get test_updated"), is(equalTo("put_update get")));
        assertThat(doRequest(s, "get get"), is(equalTo("get_success get test_updated")));
        assertThat(doRequest(s, "get get1"), is(equalTo("get_error get1")));
    }

    @Test
    @Order(6)
    public void testGetMaxKeySize() throws IOException {
        // check get max key length
        String hugeData = createDataSize(20);
        assertThat(doRequest(s, "get " + hugeData), is(equalTo("get_success " + hugeData + " test")));
        // check get key length to big
        hugeData = createDataSize(21);
        assertThat(doRequest(s, "get " + hugeData), is(equalTo("get_error " + hugeData)));
    }

    @Test
    @Order(7)
    public void testDelete() throws IOException {
        assertThat(doRequest(s, "put delete test"), is(equalTo("put_success delete")));
        assertThat(doRequest(s, "delete delete"), is(equalTo("delete_success delete")));
        assertThat(doRequest(s, "get delete"), is(equalTo("get_error delete")));
        assertThat(doRequest(s, "delete delete"), is(equalTo("delete_error delete")));
    }

    @Test
    @Order(8)
    public void testDeleteMaxKeySize() throws IOException {
        // check get max key length
        String hugeData = createDataSize(20);
        assertThat(doRequest(s, "delete " + hugeData), is(equalTo("delete_success " + hugeData)));
        // check get key length to big
        hugeData = createDataSize(21);
        assertThat(doRequest(s, "delete " + hugeData), is(equalTo("delete_error " + hugeData)));
    }

    @Test
    @Order(8)
    public void testWhitespace() throws IOException {
        // test whitespace in value
        assertThat(doRequest(s, "put apple123@# orange-@+$ test"), is(equalTo("put_success apple123@#")));
        assertThat(doRequest(s, "get apple123@#"), is(equalTo("get_success apple123@# orange-@+$ test")));
        assertThat(doRequest(s, "delete apple123@#"), is(equalTo("delete_success apple123@#")));
        assertThat(doRequest(s, "get apple123@#"), is(equalTo("get_error apple123@#")));

    }

    @Test
    @Order(10)
    public void testSequentialProcessing() throws IOException, InterruptedException, BrokenBarrierException {
        final CyclicBarrier gate = new CyclicBarrier(3);
        ArrayList<AsyncAssertion> threads = new ArrayList<>();
        for (int tcnt = 0; tcnt < 2; tcnt++) {
            final int finalTcnt = tcnt;
            threads.add(new AsyncAssertion(new Runnable() {
                @Override
                public void run() {
                    try {
                        Socket s = new Socket();
                        s.connect(new InetSocketAddress("127.0.0.1", port));
                        assertThat(readResponse(s), is(equalTo("Connection to KVStore server established: /127.0.0.1:5153")));
                        if (finalTcnt == 0) {
                            gate.await();
                            Thread.sleep(finalTcnt);
                            assertThat(doRequest(s, "put unique value"), is(equalTo("put_success unique")));
                        } else {
                            gate.await();
                            Thread.sleep(finalTcnt);
                            assertThat(doRequest(s, "put unique value2"), is(equalTo("put_update unique")));
                        }
                        s.close();
                    } catch (Throwable e) {
                        e.printStackTrace();
                        if (e instanceof AssertionError) {
                            try {
                                throw e;
                            } catch (IOException ioException) {
                                ioException.printStackTrace();
                            } catch (InterruptedException interruptedException) {
                                interruptedException.printStackTrace();
                            } catch (BrokenBarrierException brokenBarrierException) {
                                brokenBarrierException.printStackTrace();
                            }
                        }
                    }
                }
            }));
        }
        for (AsyncAssertion t : threads) {
            t.start();
        }
        gate.await();
        for (AsyncAssertion t : threads) {
            t.test();
        }

    }

    static class AsyncAssertion {
        private final Thread thread;
        private AssertionError assertionError;
        private Duration connect;
        private Duration get;
        private Duration put;

        public AsyncAssertion(final Runnable runnable) {
            thread = new Thread(new Runnable() {
                public void run() {
                    try {
                        runnable.run();
                    } catch (AssertionError e) {
                        assertionError = e;
                    }
                }
            });
        }

        public AsyncAssertion(final int finalTcnt, final CyclicBarrier gate) {
            thread = new Thread(new Runnable() {
                @Override
                public void run() {
                    try {
                        Instant start = Instant.now();
                        Socket s = new Socket();
                        s.connect(new InetSocketAddress("127.0.0.1", port));
                        assertThat(readResponse(s), is(equalTo("Connection to KVStore server established: /127.0.0.1:5153")));
                        connect = Duration.between(start, Instant.now());
                        gate.await();
                        start = Instant.now();
                        assertThat(doRequest(s, "put unique" + finalTcnt +" value"), is(equalTo("put_success unique"+ finalTcnt)));
                        put = Duration.between(start, Instant.now());
                        start = Instant.now();
                        assertThat(doRequest(s, "get unique" + finalTcnt), is(equalTo("get_success unique"+ finalTcnt +" value")));
                        get = Duration.between(start, Instant.now());
                        s.close();
                    } catch (Throwable e) {
                        e.printStackTrace();
                        if (e instanceof AssertionError) {
                            assertionError = (AssertionError) e;
                        }
                    }
                }
            });
        }

        public void start() {
            thread.start();
        }

        public void test() throws InterruptedException {
            thread.join();
            if (assertionError != null)
                throw assertionError;
        }

        public Duration getConnect() {
            return connect;
        }

        public Duration getGet() {
            return get;
        }

        public Duration getPut() {
            return put;
        }
    }

}
