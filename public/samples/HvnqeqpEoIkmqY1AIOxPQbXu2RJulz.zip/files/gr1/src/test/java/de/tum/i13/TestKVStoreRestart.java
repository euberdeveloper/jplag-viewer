package de.tum.i13;

import de.tum.i13.server.kv.KVMessage;
import de.tum.i13.server.kv.persistence.DiskPersistence;
import de.tum.i13.server.kv.persistence.LogStructuredDiskPersistence;
import org.junit.jupiter.api.Test;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;

import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.MatcherAssert.assertThat;

public class TestKVStoreRestart {
    private final String folder = "./test-recreate";

    void setup() throws IOException {
        if (!Files.exists(Paths.get(folder)))
            Files.createDirectory(Paths.get(folder));
        LogStructuredDiskPersistence persistence = new LogStructuredDiskPersistence(folder);
        persistence.put("key1", "val1");
        persistence.put("key2", "val2");

        persistence.put("key3", "val3");
        persistence.delete("key3");
        persistence.shutDown();
    }

    void tearDown() {
        File dir = new File(folder);
        File[] contents = dir.listFiles();

        for (File f : contents) {
            f.delete();
        }
        dir.delete();
    }

    @Test
    public void testReadingStructure() throws IOException {
        setup();
        DiskPersistence diskPersistence = new LogStructuredDiskPersistence(folder);

        KVMessage kvMessage1 = diskPersistence.get("key1");
        KVMessage kvMessage2 = diskPersistence.get("key2");

        assertThat(kvMessage1.getStatus(), is(KVMessage.StatusType.GET_SUCCESS));
        assertThat(kvMessage2.getStatus(), is(KVMessage.StatusType.GET_SUCCESS));

        assertThat(kvMessage1.getValue(), is("val1"));
        assertThat(kvMessage2.getValue(), is("val2"));

        KVMessage kvMessage3 = diskPersistence.get("key3");
        assertThat(kvMessage3.getStatus(), is(KVMessage.StatusType.GET_ERROR));

        tearDown();
    }
}
