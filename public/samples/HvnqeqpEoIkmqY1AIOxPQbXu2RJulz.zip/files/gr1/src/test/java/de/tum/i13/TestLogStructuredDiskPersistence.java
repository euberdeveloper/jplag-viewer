package de.tum.i13;

import de.tum.i13.server.kv.KVMessage;
import de.tum.i13.server.kv.persistence.DiskPersistence;
import de.tum.i13.server.kv.persistence.LogStructuredDiskPersistence;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestInstance;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;

import static org.hamcrest.CoreMatchers.equalTo;
import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.MatcherAssert.assertThat;

@TestInstance(TestInstance.Lifecycle.PER_CLASS)
public class TestLogStructuredDiskPersistence {
    static String testFolder = "./test";
    static DiskPersistence diskPersistence;

    @BeforeAll
    public static void removeFile() throws IOException {
        File dir = new File(testFolder);
        if (!dir.exists())
            Files.createDirectory(Paths.get(testFolder));
        diskPersistence = new LogStructuredDiskPersistence(testFolder);
    }

    @AfterAll
    public static void deleteFolder() throws IOException {
        File testDir = new File(testFolder);
        for (File file : testDir.listFiles()) {
            file.delete();
        }
        Files.delete(Paths.get(testFolder));
    }

    @Test
    public void testPutAndGet() {
        diskPersistence.put("key1", "val1");
        diskPersistence.put("key2", "val2");
        diskPersistence.put("key3", "val3");

        KVMessage kvMessage = diskPersistence.get("key2");
        assertThat("val2", is(equalTo(kvMessage.getValue())));
        assertThat("key2", is(equalTo(kvMessage.getKey())));
        assertThat(KVMessage.StatusType.GET_SUCCESS, is(equalTo(kvMessage.getStatus())));
    }

    @Test
    public void testPutAndDelete() {
        diskPersistence.put("keyDel1", "valDel1");
        diskPersistence.put("keyDel2", "valDel2");

        KVMessage kvMessage = diskPersistence.delete("keyDel2");
        assertThat(KVMessage.StatusType.DELETE_SUCCESS, is(equalTo(kvMessage.getStatus())));

        kvMessage = diskPersistence.delete("keyDel2");
        assertThat(KVMessage.StatusType.DELETE_ERROR, is(equalTo(kvMessage.getStatus())));
    }

    @Test
    public void testErrorGetDelete() {
        KVMessage kvMessage = diskPersistence.delete("keyErrDel3");
        assertThat(KVMessage.StatusType.DELETE_ERROR, is(equalTo(kvMessage.getStatus())));

        kvMessage = diskPersistence.get("keyErrDel3");
        assertThat(KVMessage.StatusType.GET_ERROR, is(equalTo(kvMessage.getStatus())));

    }
}
