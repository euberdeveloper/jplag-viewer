package de.tum.i13;

import de.tum.i13.server.kv.KVCommandProcessor;
import de.tum.i13.server.kv.KVMessage;
import de.tum.i13.server.kv.KVMessageImpl;
import de.tum.i13.server.kv.KVStore;
import de.tum.i13.shared.Encode;
import org.junit.jupiter.api.Test;

import static org.hamcrest.CoreMatchers.equalTo;
import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.mockito.Mockito.*;

public class TestKVCommandProcessor {

    @Test
    public void testCorrectProcessingOfPut() {
        KVStore kv = mock(KVStore.class);
        when(kv.put(Encode.encode("key"), Encode.encode("value"))).thenReturn(new KVMessageImpl(Encode.encode("key"), null, KVMessage.StatusType.PUT_SUCCESS));
        when(kv.put(Encode.encode("key2"), Encode.encode("value"))).thenReturn(new KVMessageImpl(Encode.encode("key2"), Encode.encode("value"), KVMessage.StatusType.PUT_ERROR));
        when(kv.put(Encode.encode("key3"), Encode.encode("value"))).thenReturn(new KVMessageImpl(Encode.encode("key3"), null, KVMessage.StatusType.PUT_UPDATE));
        KVCommandProcessor kvcp = new KVCommandProcessor(kv);
        String response = kvcp.process("put key value\r\n");
        verify(kv).put(Encode.encode("key"), Encode.encode("value"));
        assertThat(response, is(equalTo("put_success key\r\n")));
        response = kvcp.process("put key2 value\r\n");
        assertThat(response, is(equalTo("put_error key2 value\r\n")));
        response = kvcp.process("put key3 value\r\n");
        assertThat(response, is(equalTo("put_update key3\r\n")));
    }

    @Test
    public void testCorrectProcessingOfGet() {
        KVStore kv = mock(KVStore.class);
        when(kv.get(Encode.encode("key"))).thenReturn(new KVMessageImpl(Encode.encode("key"), Encode.encode("value"), KVMessage.StatusType.GET_SUCCESS));
        when(kv.get(Encode.encode("key2"))).thenReturn(new KVMessageImpl(Encode.encode("key2"), null, KVMessage.StatusType.GET_ERROR));
        KVCommandProcessor kvcp = new KVCommandProcessor(kv);
        String response = kvcp.process("get key\r\n");
        verify(kv).get(Encode.encode("key"));
        assertThat(response, is(equalTo("get_success key value\r\n")));
        response = kvcp.process("get key2\r\n");
        assertThat(response, is(equalTo("get_error key2\r\n")));
    }

    @Test
    public void testCorrectProcessingOfDelete() {
        KVStore kv = mock(KVStore.class);
        when(kv.delete(Encode.encode("key"))).thenReturn(new KVMessageImpl(Encode.encode("key"), null, KVMessage.StatusType.DELETE_SUCCESS));
        when(kv.delete(Encode.encode("key2"))).thenReturn(new KVMessageImpl(Encode.encode("key2"), null, KVMessage.StatusType.DELETE_ERROR));
        KVCommandProcessor kvcp = new KVCommandProcessor(kv);
        String response = kvcp.process("delete key\r\n");
        verify(kv).delete(Encode.encode("key"));
        assertThat(response, is(equalTo("delete_success key\r\n")));
        response = kvcp.process("delete key2\r\n");
        assertThat(response, is(equalTo("delete_error key2\r\n")));
    }

    @Test
    public void testCorrectProcessingOfAnyOther() {
        KVStore kv = mock(KVStore.class);
        KVCommandProcessor kvcp = new KVCommandProcessor(kv);
        String response = kvcp.process("any_other key value\r\n");
        verify(kv, times(0)).get("key");
        verify(kv, times(0)).delete("key");
        verify(kv, times(0)).put("key", "value");
        assertThat(response, is(equalTo("error unknown request; valid requests are: put key value | get key | delete key\r\n")));
    }
}
