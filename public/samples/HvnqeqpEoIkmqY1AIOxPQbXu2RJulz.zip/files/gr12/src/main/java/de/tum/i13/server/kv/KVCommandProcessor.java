package de.tum.i13.server.kv;

import de.tum.i13.server.kv.KVMessage.StatusType;
import de.tum.i13.shared.CommandProcessor;

import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.util.Arrays;
import java.util.logging.Logger;

public class KVCommandProcessor implements CommandProcessor {
    public static Logger logger = Logger.getLogger(KVCommandProcessor.class.getName());

    private KVStore kvStore;

    public KVCommandProcessor(KVStore kvStore) {
        this.kvStore = kvStore;
    }

    @Override
    public String process(String command) {
        command = command.replaceAll("([\\r\\n])", "");
        String[] commandArray = command.split(" ");
        switch (commandArray[0]) {
            case "put":  return put(commandArray);
            case "get":  return get(commandArray);
            case "delete":  return delete(commandArray);
            default: break;
        }
        logger.warning("error in command " + Arrays.asList(command));
        return ("error unknown command\r\n");
    }

    private String get(String[] command) {
        String answer = "get_error";
        if (command.length == 2) {
            try {
                KVMessage kvMessage = this.kvStore.get(command[1]);
                if (kvMessage.getStatus() == StatusType.GET_SUCCESS) {
                    logger.info("Success retrieving value for key " + command[1]);
                    answer = "get_success " + command[1] + " " + kvMessage.getValue();
                } else {
                    logger.warning("Could not find value for key " + command[1]);
                    answer = "get_error " + command[1];
                }
            } catch (Exception e) {
                logger.warning("error in command " + Arrays.asList(command));
                answer = "get_error " + command[1];
            }
        }
        return answer + "\r\n";
    }

    private String delete(String[] command) {
        String answer = "delete_error";
        if (command.length == 2) {
            try {
                KVMessage kvMessage = this.kvStore.put(command[1], null);
                if (kvMessage.getStatus() == StatusType.DELETE_SUCCESS) {
                    logger.info("Successfully removed entry for key " + command[1]);
                    answer = "delete_success " + command[1];
                } else {
                    logger.warning("Could not delete entry for key " + command[1]);
                    answer = "delete_error " + command[1];
                }
            } catch (Exception e) {
                logger.warning("error in command " + Arrays.asList(command));
                answer = "delete_error " + command[1];
            }
        }
        return answer + "\r\n";
    }

    private String put(String[] command) {
        String answer = "put_error";
        // identify delete case
        if (command.length == 2) {
            return delete(command);
        }
        if (command.length >= 3) {
            String value = String.join(" ", Arrays.copyOfRange(command, 2, command.length));
            try {
                KVMessage kvMessage = this.kvStore.put(command[1], value);
                switch (kvMessage.getStatus()) {
                    case PUT_SUCCESS:
                        logger.info("Successful put for key " + command[1] + " with value " + value);
                        answer = "put_success " + command[1];
                        break;
                    case PUT_UPDATE:
                        logger.info("Successful put_update for key " + command[1] + " with value " + value);
                        answer = "put_update " + command[1];
                        break;
                    default:
                        logger.warning("Could not put for key " + command[1] + " with value " + value);
                        answer = "put_error " + command[1] + " " + value;
                }
            } catch (Exception e) {
                logger.warning("error in command " + Arrays.asList(command));
                answer = "put_error " + command[1] + " " + value;
            }
        }
        return answer + "\r\n";
    }

    @Override
    public String connectionAccepted(InetSocketAddress address, InetSocketAddress remoteAddress) {
        logger.info("new connection: " + remoteAddress.toString());

        return "Connection to MSRG Echo server established: " + address.toString() + "\r\n";
    }

    @Override
    public void connectionClosed(InetAddress remoteAddress) {
        logger.info("connection closed: " + remoteAddress.toString());
    }
}

