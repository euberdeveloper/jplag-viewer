package de.tum.i13.shared;

import de.tum.i13.server.kv.KVStore;
import de.tum.i13.server.kv.caching.FIFOCache;
import de.tum.i13.server.kv.caching.LFUCache;
import de.tum.i13.server.kv.caching.LRUCache;
import picocli.CommandLine;

/**
 * Converter to instantiate the correct caching strategy.
 */
public class CacheTypeConverter implements CommandLine.ITypeConverter<KVStore> {

	private Config cfg;

	public CacheTypeConverter(Config config) {
		super();
		this.cfg = config;
	}

	@Override
	public KVStore convert(String value) throws Exception {
		switch (value) {
		case "FIFO":
			return new FIFOCache(cfg.dataDir, cfg.cacheSize);
		case "LRU":
			return new LRUCache(cfg.dataDir, cfg.cacheSize);
		case "LFU":
			return new LFUCache(cfg.dataDir, cfg.cacheSize);
		default:
			throw new CommandLine.TypeConversionException(
					"Please type a valid cache!");
		}
	}

}
