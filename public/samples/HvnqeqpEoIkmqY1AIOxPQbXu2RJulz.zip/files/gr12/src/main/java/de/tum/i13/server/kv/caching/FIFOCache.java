package de.tum.i13.server.kv.caching;

import de.tum.i13.server.kv.KVDiskWriter;
import de.tum.i13.server.kv.KVMessage;
import de.tum.i13.server.kv.KVMessage.StatusType;
import de.tum.i13.server.kv.KVMessageServer;
import de.tum.i13.server.kv.KVStore;
import java.nio.file.Path;
import java.util.Deque;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.Map;

/**
 * Implementation of the FIFO caching strategy using {@link KVDiskWriter} to load and save data to disk
 */
public class FIFOCache implements KVStore {
  private final int CACHE_SIZE;

  private  KVDiskWriter diskWriter;
  private Map<String, String> cache;
  private Deque<String> keyQueue;


  public FIFOCache(Path dataDir, int cacheSize) {
    this.diskWriter = new KVDiskWriter(dataDir);
    this.cache = new HashMap<>(cacheSize);
    this.CACHE_SIZE = cacheSize;

    keyQueue = new LinkedList<>();
  }

  /**
   * Puts entry in list. On cache miss first added element will be deleted.
   * @param key   the key that identifies the given value.
   * @param value the value that is indexed by the given key.
   * @return see {@link KVDiskWriter} for return message.
   */
  @Override
  public KVMessage put(String key, String value) {
    if(value == null) {
      cache.remove(key);
      keyQueue.remove(key);
      return diskWriter.put(key, null);
    }
    if(cache.containsKey(key)) {
      cache.put(key, value);
      keyQueue.remove(key);
      keyQueue.addFirst(key);
    } else {
      if (CACHE_SIZE == cache.size()) {
        cache.remove(keyQueue.getLast());
        keyQueue.removeLast();
      }
      keyQueue.addFirst(key);
      cache.put(key, value);
    }
    return diskWriter.put(key, value);
  }

  /**
   * Gets entry from list. On cache miss entry is loaded from disk, first added element will be replaced.
   * @param key the key that identifies the value.
   * @return see {@link KVDiskWriter} for return message.
   */
  @Override
  public KVMessage get(String key) {
    if(cache.containsKey(key)) {
      return new KVMessageServer(key, cache.get(key), StatusType.GET_SUCCESS);
    }
    KVMessage returnMessage = diskWriter.get(key);
    if (returnMessage.getStatus() == StatusType.GET_SUCCESS) {
      if (CACHE_SIZE == cache.size()) {
        cache.remove(keyQueue.getLast());
        keyQueue.removeLast();
      }
      keyQueue.addFirst(key);
      cache.put(key, returnMessage.getValue());
    }
    return returnMessage;
  }
}
