package de.tum.i13.shared;

import java.util.logging.Level;

import picocli.CommandLine;

/**
 * Converts input value from command line to {@link Level}
 */
public class LogLevelTypeConverter implements CommandLine.ITypeConverter<Level> {

	@Override
	public Level convert(String value) throws Exception {
		try {
			return Level.parse(value);
		} catch (IllegalArgumentException e) {
			 throw new CommandLine.TypeConversionException("Please type a valid level! Integer value or known level (ALL,INFO..).");
		}
	}

}
