package de.tum.i13.server.kv;

public class KVMessageServer implements KVMessage {

	private String key;
	private String value;
	private StatusType statusType;
	
	public KVMessageServer(String key, String value, StatusType statusType) {
		this.key = key;
		this.value = value;
		this.statusType = statusType;
	}
	
	@Override
	public String getKey() {
		return this.key;
	}
	@Override
	public String getValue() {
		return this.value;
	}

	@Override
	public StatusType getStatus() {
		return this.statusType;
	}
}
