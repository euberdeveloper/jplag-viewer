package de.tum.i13;

import java.io.File;
import java.io.FileOutputStream;
import java.io.ObjectOutputStream;
import java.nio.file.Path;
import java.util.HashMap;

public class SetupTest {
	
	
	public static void clean(Path path) throws Exception {
		FileOutputStream fileOutputStream = new FileOutputStream(new File(path.toFile(), "data"));
		ObjectOutputStream objectOutputStream = new ObjectOutputStream(fileOutputStream);
		objectOutputStream.writeObject(new HashMap<String, String>());
		objectOutputStream.close();
		fileOutputStream.close();
	}

}
