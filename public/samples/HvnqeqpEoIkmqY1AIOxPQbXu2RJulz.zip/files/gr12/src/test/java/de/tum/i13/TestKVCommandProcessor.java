package de.tum.i13;

import de.tum.i13.server.kv.KVCommandProcessor;
import de.tum.i13.server.kv.KVMessage.StatusType;
import de.tum.i13.server.kv.KVMessageServer;
import de.tum.i13.server.kv.KVStore;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;

public class TestKVCommandProcessor {

	KVStore kv;
	KVCommandProcessor kvcp;

	@BeforeEach
	public void setupMock() {
		kv = mock(KVStore.class);
		kvcp = new KVCommandProcessor(kv);
	}

	@Test
	public void correctParsingOfPut() throws Exception {
		String key = "foo";
		String value = "bar";
		Mockito.when(kv.put(key, value)).thenReturn(new KVMessageServer(key, value, StatusType.PUT_SUCCESS));
		kvcp.process("put " + key + " " + value);

		verify(kv).put(key, value);
	}

	@Test
	public void correctEvaluatingOfPut() throws Exception {
		Mockito.when(kv.put("key", "hello")).thenReturn(new KVMessageServer("key", "hello", StatusType.PUT_SUCCESS));
		String resultSucces = kvcp.process("put key hello");

		Mockito.when(kv.put("key", "hello")).thenReturn(new KVMessageServer("key", "hello", StatusType.PUT_UPDATE));
		String resultUpdate = kvcp.process("put key hello");

		Mockito.when(kv.put("key", "hello")).thenReturn(new KVMessageServer("key", "hello", StatusType.PUT_ERROR));
		String resultError = kvcp.process("put key hello");

		assertTrue("put_success key\r\n".equals(resultSucces) && "put_error key hello\r\n".equals(resultError)
				&& "put_update key\r\n".equals(resultUpdate));

	}

	@Test
	public void correctEvaluatingOfGet() throws Exception {
		Mockito.when(kv.get("key")).thenReturn(new KVMessageServer("key", "hello", StatusType.GET_SUCCESS));
		String resultSucces = kvcp.process("get key");

		Mockito.when(kv.get("key")).thenReturn(new KVMessageServer("key", null, StatusType.GET_ERROR));
		String resultError = kvcp.process("get key");

		assertTrue("get_success key hello\r\n".equals(resultSucces) && "get_error key\r\n".equals(resultError));

	}
	
	@Test
	public void correctEvaluatingOfDelete() throws Exception {
		Mockito.when(kv.put("key", null)).thenReturn(new KVMessageServer("key", null, StatusType.DELETE_SUCCESS));
		String resultSucces = kvcp.process("delete key");

		Mockito.when(kv.put("key", null)).thenReturn(new KVMessageServer("key", null, StatusType.DELETE_ERROR));
		String resultError = kvcp.process("delete key");

		assertTrue("delete_success key\r\n".equals(resultSucces) && "delete_error key\r\n".equals(resultError));

	}
}
