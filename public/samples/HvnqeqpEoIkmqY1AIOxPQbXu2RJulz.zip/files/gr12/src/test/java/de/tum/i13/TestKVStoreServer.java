package de.tum.i13;

import static org.junit.jupiter.api.Assertions.assertTrue;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.function.Executable;

import de.tum.i13.server.kv.KVMessage;
import de.tum.i13.server.kv.KVStore;
import de.tum.i13.server.kv.caching.FIFOCache;
import de.tum.i13.server.kv.caching.LFUCache;
import de.tum.i13.server.kv.caching.LRUCache;
import de.tum.i13.server.kv.KVDiskWriter;
import de.tum.i13.server.kv.KVMessage.StatusType;

public class TestKVStoreServer {

	private final static Path STORE_DIR = Paths.get("data/");
	private final static int CACHE_SIZE = 10;
	private List<KVStore> kvStores = Stream.of( //
			new KVDiskWriter(STORE_DIR), //
			new FIFOCache(STORE_DIR, CACHE_SIZE), //
			new LRUCache(STORE_DIR, CACHE_SIZE), //
			new LFUCache(STORE_DIR, CACHE_SIZE)) //
			.collect(Collectors.toList());
	private final static String KEY = "foo";
	private final static String VALUE = "bar";

	@BeforeAll
	public static void setup() {

		if (!Files.exists(STORE_DIR)) {
			try {
				Files.createDirectory(STORE_DIR);
			} catch (IOException e) {
				System.out.println("Could not create directory");
				e.printStackTrace();
				System.exit(-1);
			}
		}

	}

	@Test
	public void insert() throws Exception {
		Collection<Executable> results = new ArrayList<>();

		for (KVStore kvStore : kvStores) {
			KVMessage message = kvStore.put(KEY, VALUE);

			boolean result = message.getKey().equals(KEY) && message.getValue().equals(VALUE)
					&& message.getStatus().equals(StatusType.PUT_SUCCESS);
			results.add(() -> assertTrue(result, kvStore.getClass().toString()));
			SetupTest.clean(STORE_DIR);
		}
	}

	@Test
	public void get() throws Exception {
		Collection<Executable> results = new ArrayList<>();

		for (KVStore kvStore : kvStores) {
			kvStore.put(KEY, VALUE);
			KVMessage message = kvStore.get(KEY);

			boolean result = message.getKey().equals(KEY) && message.getValue().equals(VALUE)
					&& message.getStatus().equals(StatusType.GET_SUCCESS);
			results.add(() -> assertTrue(result, kvStore.getClass().toString()));
			SetupTest.clean(STORE_DIR);
		}

		Assertions.assertAll(results);

	}

	@Test
	public void getError() throws Exception {
		Collection<Executable> results = new ArrayList<>();
		for (KVStore kvStore : kvStores) {
			KVMessage message = kvStore.get(KEY);

			boolean result = message.getKey().equals(KEY) && message.getValue() == null
					&& message.getStatus().equals(StatusType.GET_ERROR);
			results.add(() -> assertTrue(result, kvStore.getClass().toString()));
			SetupTest.clean(STORE_DIR);
		}
		Assertions.assertAll(results);

	}

	@Test
	public void putUpdate() throws Exception {
		Collection<Executable> results = new ArrayList<>();

		for (KVStore kvStore : kvStores) {
			kvStore.put(KEY, VALUE);
			String value = "test";
			KVMessage message = kvStore.put(KEY, value);

			boolean result = message.getKey().equals(KEY) && message.getValue().equals(value)
					&& message.getStatus().equals(StatusType.PUT_UPDATE);

			results.add(() -> assertTrue(result, kvStore.getClass().toString()));
			SetupTest.clean(STORE_DIR);
		}
		Assertions.assertAll(results);
	}

	@Test
	public void delete() throws Exception {
		Collection<Executable> results = new ArrayList<>();

		for (KVStore kvStore : kvStores) {
			kvStore.put(KEY, VALUE);
			KVMessage message = kvStore.put(KEY, null);

			boolean result = message.getKey().equals(KEY) && message.getValue() == null
					&& message.getStatus().equals(StatusType.DELETE_SUCCESS);
			results.add(() -> assertTrue(result, kvStore.getClass().toString()));
			SetupTest.clean(STORE_DIR);
		}
		Assertions.assertAll(results);

	}

	@Test
	public void deleteError() throws Exception {
		Collection<Executable> results = new ArrayList<>();

		for (KVStore kvStore : kvStores) {
			KVMessage message = kvStore.put(KEY, null);

			boolean result = message.getKey().equals(KEY) && message.getValue() == null
					&& message.getStatus().equals(StatusType.DELETE_ERROR);
			results.add(() -> assertTrue(result, kvStore.getClass().toString()));
			SetupTest.clean(STORE_DIR);
		}
		Assertions.assertAll(results);

	}
	
	@Test
	public void getAfterDelete() throws Exception {
		Collection<Executable> results = new ArrayList<>();

		for (KVStore kvStore : kvStores) {
			 kvStore.put(KEY, null);
			 KVMessage message = kvStore.get(KEY);

			boolean result = message.getKey().equals(KEY) && message.getValue() == null
					&& message.getStatus().equals(StatusType.GET_ERROR);
			results.add(() -> assertTrue(result, kvStore.getClass().toString()));
			SetupTest.clean(STORE_DIR);
		}
		Assertions.assertAll(results);

	}

	public void cleanCach() {
		kvStores = Stream.of( //
				new KVDiskWriter(STORE_DIR), //
				new FIFOCache(STORE_DIR, CACHE_SIZE), //
				new LRUCache(STORE_DIR, CACHE_SIZE), //
				new LFUCache(STORE_DIR, CACHE_SIZE)) //
				.collect(Collectors.toList());
	}

}
