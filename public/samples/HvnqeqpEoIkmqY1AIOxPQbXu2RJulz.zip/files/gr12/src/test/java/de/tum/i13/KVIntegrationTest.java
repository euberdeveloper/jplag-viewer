package de.tum.i13;

import de.tum.i13.server.nio.StartSimpleNioServer;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import de.tum.i13.client.ActiveConnection;
import de.tum.i13.client.KVConnectionBuilder;

import java.io.*;
import java.net.InetSocketAddress;
import java.net.Socket;
import java.nio.file.Path;
import java.nio.file.Paths;

import static org.hamcrest.CoreMatchers.*;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.junit.jupiter.api.Assertions.assertEquals;

public class KVIntegrationTest {

	private final static Integer PORT = 5153;
	private final static Path STORE_DIR = Paths.get("data/");
	private final static String LOCALHOST = "127.0.0.1";
	private static Thread server;

	public String doRequest(Socket s, String req) throws IOException {
		PrintWriter output = new PrintWriter(s.getOutputStream());
		BufferedReader input = new BufferedReader(new InputStreamReader(s.getInputStream()));
		input.readLine();

		output.write(req + "\r\n");
		output.flush();

		String res = input.readLine();
		return res;
	}

	public String doRequest(String req) throws IOException {
		Socket s = new Socket();
		s.connect(new InetSocketAddress(LOCALHOST, PORT));
		String res = doRequest(s, req);
		s.close();

		return res;
	}

	@BeforeAll
	public static void startServer() throws Exception {
		server = new Thread(() -> {
			try {
				StartSimpleNioServer.main(new String[] { "-p", PORT.toString() });
			} catch (IOException e) {
				e.printStackTrace();
			}
		});
		server.start(); // started the server

		Thread.sleep(2000);
	}

	@BeforeEach
	public void clean() throws Exception {
		SetupTest.clean(STORE_DIR);
	}

	@Test
	public void smokeTest() throws InterruptedException, IOException {

		Socket s = new Socket();
		s.connect(new InetSocketAddress(LOCALHOST, PORT));
		String command = "put hello test";
		assertThat(doRequest(command), is(equalTo("put_success hello")));
		s.close();

	}

	@Test
	public void enjoyTheEcho() throws IOException, InterruptedException {

		for (int tcnt = 0; tcnt < 2; tcnt++) {
			final int finalTcnt = tcnt;
			new Thread() {
				@Override
				public void run() {
					try {
						Thread.sleep(finalTcnt * 100);
					} catch (InterruptedException e) {
						e.printStackTrace();
					}
					try {
						for (int i = 0; i < 100; i++) {
							Socket s = new Socket();
							s.connect(new InetSocketAddress(LOCALHOST, PORT));
							String command = "put hello " + finalTcnt;
							String[] result = doRequest(command).split(" ");
							String[] feedback = result[0].split("_");
							assertThat(feedback[1], either(equalTo("success")).or(equalTo("update")));
							s.close();
						}
					} catch (Exception e) {
						e.printStackTrace();
					}
				}
			}.start();
		}

		// Assert.assertThat(doRequest("GET table key"), containsString("valuetest"));

		Thread.sleep(5000);
		// th.interrupt();
	}

	@Test
	public void testConnection() throws Exception {
		KVConnectionBuilder connectionBuilder = new KVConnectionBuilder(LOCALHOST, PORT);
		ActiveConnection activeConnection = connectionBuilder.connect();
		String serverAnswer = activeConnection.readline();
		activeConnection.close();

		assertEquals("Connection to MSRG Echo server established: /" + LOCALHOST + ":" + PORT, serverAnswer);

	}

}
