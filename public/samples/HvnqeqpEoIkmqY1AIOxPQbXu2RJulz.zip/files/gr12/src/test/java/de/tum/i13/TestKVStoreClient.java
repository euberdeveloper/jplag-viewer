package de.tum.i13;

import static org.junit.jupiter.api.Assertions.assertEquals;

import de.tum.i13.server.nio.StartSimpleNioServer;
import java.io.IOException;
import java.nio.file.Path;
import java.nio.file.Paths;

import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import de.tum.i13.client.KVStore;

public class TestKVStoreClient {

	private final static Integer PORT = 5153;
	private final static Path STORE_DIR = Paths.get("data/");
	private final static String LOCALHOST = "127.0.0.1";
	private static Thread server;

	@BeforeAll
	public static void startServer() throws Exception {
		server = new Thread(() -> {
			try {
				StartSimpleNioServer.main(new String[] { "-p", PORT.toString() });
			} catch (IOException e) {
				e.printStackTrace();
			}
		});
		server.start(); // started the server

		Thread.sleep(2000);
	}

	@BeforeAll
	public static void clean() throws Exception {
		SetupTest.clean(STORE_DIR);
	}

	public KVStore connect() throws Exception {
		KVStore client = new KVStore();
		String[] commands = { "connect", LOCALHOST, PORT.toString() };
		client.connect(commands);
		return client;
	}

	@Test
	public void testConnect() throws Exception {
		KVStore client = new KVStore();

		String[] commands = { "connect", LOCALHOST, PORT.toString() };
		String answer = client.connect(commands);
		client.disconnect();
		assertEquals("Connection to MSRG Echo server established: /" + LOCALHOST + ":" + PORT, answer);

	}

	@Test
	public void testPutSucces() throws Exception {
		KVStore client = connect();
		String[] commands = { "put", "foo", "bar" };
		String answer = client.putMessage(commands);
		client.disconnect();
		assertEquals("put_success foo", answer);

	}

	@Test
	public void testPutUpdate() throws Exception {
		KVStore client = connect();

		String[] commands = { "put", "test", "content" };
		client.putMessage(commands);

		commands[2] = "test";

		String answer = client.putMessage(commands);
		client.disconnect();

		assertEquals("put_update test", answer);

	}

	@Test
	public void testGetSuccess() throws Exception {
		KVStore client = connect();

		String[] put = { "put", "key", "value" };
		String[] get = { "get", "key" };

		client.putMessage(put);
		String answer = client.getMessage(get);

		client.disconnect();
		assertEquals("get_success key value", answer);

	}

	@Test
	public void testGetError() throws Exception {
		KVStore client = connect();

		String[] get = { "get", "notExist" };

		String answer = client.getMessage(get);

		client.disconnect();
		System.out.println(answer);
		assertEquals("get_error notExist", answer);

	}

	@Test
	public void testDeleteSuccess() throws Exception {
		KVStore client = connect();

		String[] put = { "put", "toDelete", "delete" };
		String[] delete = { "delete", "toDelete" };

		client.putMessage(put);
		String answer = client.putMessage(delete);

		client.disconnect();

		assertEquals("delete_success toDelete", answer);
	}

	@Test
	public void testDeleteError() throws Exception {
		KVStore client = connect();

		String[] delete = { "delete", "none" };
		String answer = client.putMessage(delete);

		client.disconnect();

		assertEquals("delete_error none", answer);
	}

	@Test
	public void testGetAfterDelete() throws Exception {
		KVStore client = connect();

		String[] command = { "delete", "isInCache" };
		client.putMessage(command);
		command[0] = "get";
		String answer = client.getMessage(command);
		client.disconnect();
		assertEquals("get_error isInCache", answer);
	}
	
	@Test
	public void testSendDelimiter() throws Exception{
		KVStore client = connect();
		String[] put = { "put", "dog", "wuff \r\n wuff" };
		String[] get = { "get", "dog" };
		
		client.putMessage(put);
		String answer = client.getMessage(get);
		assertEquals("get_success dog wuff \r\n wuff", answer);
	}

}
