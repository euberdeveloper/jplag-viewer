package de.tum.i13.client;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.Socket;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.logging.Logger;

/**
 *
 * This class establishes connection between database and client.
 *
 * After invoking constructor or public boolean connect(String hostAddress, int
 * port), please invoke also public byte[] receive(), in order to get text
 * answer from database.
 *
 * @author gr4
 *
 */
public class ServerConnector {
	private final static Logger LOGGER = Logger.getLogger(ServerConnector.class.getName());

	private Socket socket;
	private OutputStream output;
	private InputStream input;

	/**
	 * Connects to server and initializes input and output streams. Returns false if
	 * connection could not be established. If connection is already established,
	 * than closes the old connection and makes new connection.
	 *
	 * @param hostAddress: The address of the host server.
	 * @param port: An Integer representing the port, to which the client wishes to
	 *        connect.
	 */
	public boolean connect(String hostAddress, int port) {
		if (isConnected()) {
			LOGGER.info("Old connection is being closed.");
			System.out.println("EchoClient> Closing the current connection and connecting to the new server ...");
			disconnect();
		}

		try {
			LOGGER.info("Creating a new Socket and connecting to server");
			socket = new Socket(hostAddress, port);

			LOGGER.info("Getting input Stream from Socket");
			input = socket.getInputStream();

			LOGGER.info("Getting output Stream from Socket");
			output = socket.getOutputStream();

			return true;

		} catch (IOException e) {
			LOGGER.warning("IO problem in connect method of the DBC class.");
			LOGGER.throwing(ServerConnector.class.getName(), "connect", e);
			return false;
		}
	}

	/**
	 * Disconnects from server-socket and closes input and output streams, if
	 * connection was not closed yet or if no exceptions are thrown.
	 *
	 * Returns false if connection was already closed.
	 */
	public boolean disconnect() {
		try {
			LOGGER.info("Trying to disconnect from socket");

			if (isConnected()) {

				input.close();
				output.close();
				socket.close();

				LOGGER.info("Disconnected from socket");

				return true;
			} else {
				LOGGER.warning("Socket, input or output stream are not available");
				return false;
			}

		} catch (IOException e) {
			System.out.println("EchoClient> Error! Failed to disconnect.");
			LOGGER.warning("IO problem in disconnect method of the DBC class.");
			LOGGER.throwing(ServerConnector.class.getName(), "disconnect", e);
			return false;
		}
	}

	/**
	 * Reads array from input stream and returns array of bytes from input.
	 *
	 * Expects, that input is terminated by this sequence: '\r\n'
	 *
	 * If there is no connection, throws an exception
	 */
	public byte[] receive() {
		if (!isConnected()) {
			LOGGER.warning("socket disconnected");
			disconnect(); // Tear down due to loss of connection or socket
			return null;
		}

		try {
			LOGGER.info("Reading from input");
			ArrayList<Integer> byteStream = new ArrayList<>();

			int ch = input.read();
			while (true) {
				if (ch == 13) {
					byteStream.add(ch);
					ch = input.read();

					if (ch == 10) {

						break;
					}
				} else {
					byteStream.add(ch);
					ch = input.read();
				}
			}

			LOGGER.info("Returning response as byte array");
			byteStream.remove(byteStream.size() - 1);
			return toByteArray(byteStream);
		} catch (IOException e) {
			LOGGER.warning("Failed to send the message, because there is no connection.");
			LOGGER.throwing(ServerConnector.class.getName(), "receive", e);
			System.out.println("EchoClient> Error! Connection lost.");
			e.printStackTrace();
			return null;
		}
	}

	private byte[] toByteArray(ArrayList<Integer> byteStream) {
		byte[] ret = new byte[byteStream.size()];

		for (int i = 0; i < byteStream.size(); i++)
			ret[i] = byteStream.get(i).byteValue();

		return ret;
	}

	/**
	 * Sends array of bytes to output stream.
	 *
	 * Returns true if sending was successful. Returns false if some Exceptions are
	 * thrown or if there is no connection.
	 *
	 * @param data: Data to send as array of bytes. Hase to be terminated by '\r\n'
	 *        sequence.
	 */
	public boolean send(byte[] data) {
		if (!isConnected()) {
			LOGGER.warning("socket disconnected");
			disconnect(); // Tear down due to loss of connection or socket
			return false; // Message cannot be sent
		}

		try {
			LOGGER.info("Sending this array bytes to output stream: " + Arrays.toString(data));
			output.write(data);
			output.flush();

			return true;
		} catch (IOException e) {
			System.out.print("EchoClient> Error! You are not connected to the server.\n");
			LOGGER.warning("IO problem in send method of the DBC class.");
			LOGGER.throwing(ServerConnector.class.getName(), "send", e);
			return false;
		}
	}

	public OutputStream getOutput() {
		return output;
	}

	public InputStream getInput() {
		return input;
	}

	public boolean isConnected() {
		return socket != null && !socket.isClosed() && !socket.isInputShutdown() && !socket.isOutputShutdown();
	}
}
