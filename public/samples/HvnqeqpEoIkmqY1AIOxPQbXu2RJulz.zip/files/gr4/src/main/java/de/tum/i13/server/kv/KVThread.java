package de.tum.i13.server.kv;

import de.tum.i13.shared.CommandProcessor;

import java.io.PrintWriter;
import java.util.LinkedList;
import java.util.Queue;
import java.util.concurrent.locks.ReentrantLock;
import java.util.logging.Logger;

/**
 * This class manages a queue of client commands, to separate the
 * input accepting thread from the command processing thread.
 */
public class KVThread extends Thread {

    private final PrintWriter out;
    private final CommandProcessor cp;
    private final Queue<String> queue = new LinkedList<>();
    private final ReentrantLock lock = new ReentrantLock();
    private static final Logger logger = Logger.getLogger(KVThread.class.getName());

    private boolean terminate = false;

    public KVThread(PrintWriter out, CommandProcessor cp) {
        this.out = out;
        this.cp = cp;
    }

    @Override
    public void run() {
        logger.info("Starting KVThread");
        String next;
        while (!terminate) {
            if ((next = dequeue()) != null) {
                String res = cp.process(next);
                try {
                    out.write(res);
                    out.flush();
                } catch (Exception e) {
                    logger.warning("Unable to send response!");
                }
            }
        }
    }

    /**
     * Enqueues a new command that must be processed.
     *
     * @param command input from a client
     */
    public void enqueue(String command) {
        lock.lock();
        try {
            queue.add(command);
        } catch(Exception e) {
            logger.warning("Exception thrown while trying to enqueue command");
        } finally {
            lock.unlock();
        }
    }

    /**
     * Dequeues the next command that must be processed.
     *
     * @return input from a client
     */
    private String dequeue() {
        String command = null;

        lock.lock();
        try {
            if (!queue.isEmpty())
                command = queue.remove();
        } catch(Exception e) {
            logger.warning("Exception thrown while trying to dequeue command");
        } finally {
            lock.unlock();
        }

        return command;
    }

    public void setTerminate(boolean terminate) {
        this.terminate = terminate;
    }
}
