package de.tum.i13.server.kv;

import de.tum.i13.shared.CommandProcessor;

import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.util.concurrent.locks.ReentrantLock;
import java.util.logging.Logger;

/**
 * This class is used to process commands received from a client and react to
 * connections being accepted or closed.
 */
public class KVCommandProcessor implements CommandProcessor {
	private final String DELIMITER = "\r\n"; // message delimiter for server replies
	private final KVStore kvStore;
	private static final ReentrantLock lock = new ReentrantLock();
	private static final Logger logger = Logger.getLogger(KVCommandProcessor.class.getName());

	public KVCommandProcessor(KVStore kvStore) {
		this.kvStore = kvStore;
	}

	/**
	 * Processes a command and calls the corresponding KVStore methods
	 *
	 * @param command the command which was received from a client
	 * @return server reply to the client
	 */
	@Override
	public String process(String command) {
		logger.info("received command: " + command.trim());

		String[] tokens = command.trim().split("\\s+");

		if (tokens.length == 0) {
			logger.warning("empty request");
			return "error empty request" + DELIMITER;
		}

		switch (tokens[0]) {
		case "put":
			return processPut(tokens) + DELIMITER;
		case "get":
			return processGet(tokens) + DELIMITER;
		case "delete":
			return processDelete(tokens) + DELIMITER;
		default:
			logger.warning("unsupported request");
			return "error unsupported request" + DELIMITER;
		}
	}

	/**
	 * Replies to an accepted connection to a new client
	 *
	 * @param address       server address
	 * @param remoteAddress client address
	 * @return welcome message to the client
	 */
	@Override
	public String connectionAccepted(InetSocketAddress address, InetSocketAddress remoteAddress) {
		logger.info("new connection: " + remoteAddress.toString());

		return "Connection to persistent storage server established: " + address.toString() + DELIMITER;
	}

	/**
	 * Logs info about closed connections
	 *
	 * @param address client address
	 */
	@Override
	public void connectionClosed(InetAddress address) {
		logger.info("connection closed: " + address.toString());
	}

	/**
	 * Called when the server shuts down
	 */
	public void shutdown() {
		logger.info("shutdown");
		lock.lock();
		try {
			kvStore.shutdown();
		} catch (Exception e) {
			logger.warning("Could not successfully shut down or write the updates in cache to the file.");
		} finally {
			lock.unlock();
		}
	}

	/**
	 * Processes put command calls
	 *
	 * @param args command split into tokens
	 * @return server reply to the client
	 */
	private String processPut(String[] args) {
		if (args.length < 3) {
			logger.warning("wrong number of arguments");
			return "error wrong number of arguments";
		}

		StringBuilder value = new StringBuilder(args[2]);
		for (int i = 3; i < args.length; i++) {
			value.append(" ").append(args[i]);
		}

		lock.lock();
		try {
			// kvMessage contains information about the success of the put call
			KVMessage kvMessage = kvStore.put(args[1], value.toString());

            switch (kvMessage.getStatus()) {
                case PUT_SUCCESS:
                    return "put_success " + kvMessage.getKey();
                case PUT_UPDATE:
                    return "put_update " + kvMessage.getKey();
                case PUT_ERROR:
                    return "put_error " + kvMessage.getKey() + " " + kvMessage.getValue();
                default:
                    logger.info(String.valueOf(kvMessage.getStatus()));
                    throw new Exception();
            }
        } catch (Exception e) {
            logger.warning("kvStore.put throws exception");

            return "put_error " + args[1] + " " + value.toString();
        } finally {
			lock.unlock();
		}
    }

	/**
	 * Processes get command calls
	 *
	 * @param args command split into tokens
	 * @return server reply to the client
	 */
	private String processGet(String[] args) {
		if (args.length != 2) {
			logger.warning("wrong number of arguments");
			return "error wrong number of arguments";
		}

		lock.lock();
		try {
			// kvMessage contains information about the success of the get call
			KVMessage kvMessage = kvStore.get(args[1]);

			switch (kvMessage.getStatus()) {
			case GET_SUCCESS:
				return "get_success " + kvMessage.getKey() + " " + kvMessage.getValue();
			case GET_ERROR:
				return "get_error " + kvMessage.getKey();
			default:
				throw new Exception();
			}
		} catch (Exception e) {
			logger.warning("kvStore.get throws exception");
			return "get_error " + args[1];
		} finally {
			lock.unlock();
		}
	}

	/**
	 * Processes delete command calls
	 *
	 * @param args command split into tokens
	 * @return server reply to the client
	 */
	private String processDelete(String[] args) {
		if (args.length != 2) {
			logger.warning("wrong number of arguments");
			return "error wrong number of arguments";
		}

		lock.lock();
		try {
			// kvMessage contains information about the success of the delete call
			KVMessage kvMessage = kvStore.delete(args[1]);

			switch (kvMessage.getStatus()) {
			case DELETE_SUCCESS:
				return "delete_success " + kvMessage.getKey();
			case DELETE_ERROR:
				return "delete_error " + kvMessage.getKey();
			default:
				throw new Exception();
			}
		} catch (Exception e) {
			logger.warning("kvStore.put throws exception while deleting value");
			return "delete_error " + args[1];
		} finally {
			lock.unlock();
		}
	}
}
