package de.tum.i13.server.threadperconnection;

import de.tum.i13.server.kv.KVThread;
import de.tum.i13.shared.CommandProcessor;
import de.tum.i13.shared.Constants;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.net.InetSocketAddress;
import java.net.Socket;
import java.util.logging.Level;
import java.util.logging.Logger;

public class ConnectionHandleThread extends Thread {
    static Logger logger = Logger.getLogger(ConnectionHandleThread.class.getName());
    private CommandProcessor cp;
    private Socket clientSocket;

    public ConnectionHandleThread(CommandProcessor commandProcessor, Socket clientSocket) {
        this.cp = commandProcessor;
        this.clientSocket = clientSocket;
    }

    @Override
    public void run() {
        logger.log(Level.ALL,"Starting new Thread with port: " + clientSocket.getLocalPort() + " and address: " + clientSocket.getLocalSocketAddress());
        try {
            BufferedReader in = new BufferedReader(new InputStreamReader(clientSocket.getInputStream(), Constants.TELNET_ENCODING));
            PrintWriter out = new PrintWriter(new OutputStreamWriter(clientSocket.getOutputStream(), Constants.TELNET_ENCODING));

            //writes a welcome message to a newly connected client
            InetSocketAddress local = new InetSocketAddress(clientSocket.getLocalAddress(), clientSocket.getLocalPort());
            InetSocketAddress remote = new InetSocketAddress(clientSocket.getInetAddress(), clientSocket.getPort());
            out.write(cp.connectionAccepted(local, remote));
            out.flush();

            KVThread kvThread = new KVThread(out, cp);
            kvThread.start();

            String firstLine;
            while ((firstLine = in.readLine()) != null) {
                /*
                uses a new thread to process the input,
                separating the input thread from the processing thread.
                 */
                kvThread.enqueue(firstLine);
            }

            kvThread.setTerminate(true);
        } catch(Exception ex) {
            logger.warning("Connection lost!");
            logger.log(Level.ALL, ex.toString());
        }
        cp.connectionClosed(clientSocket.getInetAddress());
    }
}
