package de.tum.i13.server.nio;

import de.tum.i13.server.kv.*;
import de.tum.i13.shared.Config;
import de.tum.i13.shared.LogSetup;

import java.io.IOException;
import java.util.logging.LogManager;
import java.util.logging.Logger;

import static de.tum.i13.shared.Config.parseCommandlineArgs;
import static de.tum.i13.shared.LogSetup.setupLogging;

public class StartSimpleNioServer {

    public static Logger logger = Logger.getLogger(StartSimpleNioServer.class.getName());

    private static final String HELP_MESSAGE = "This server is a key-value-store. The following flags are supported:\n"
            + "-p   Sets the port of the server\n"
            + "-a   Which address the server should listen to, default is 127.0.0.1\n"
            + "-b   Bootstrap broker\n"
            + "-d   Directory for files in which the key-value pairs will be stored\n"
            + "-l   Relative path of the logfile\n"
            + "-ll  Log level\n"
            + "-c   Size of the cache\n"
            + "-s   Cache displacement strategy, FIFO, LRU, LFU\n"
            + "-h   Displays the help message\n\n"
            + "Possible queries to the server are:\n"
            + "put <key> <value>    Sends a key value pair to the server\n"
            + "get <key>            Gets the value of a key\n"
            + "delete <key>         Deletes a value\n";

    public static void main(String[] args) throws IOException {
        Config cfg = parseCommandlineArgs(args);  //Do not change this
        setupLogging(cfg.logfile);
        logger.info("Config: " + cfg.toString());

        logger.info("starting server");

        //Creates the CommandProcessor with requested strategy
        KVStore kvStore;
        switch (cfg.strategy) {
            case "FIFO":
                kvStore = new FIFO(cfg);
                break;
            case "LFU":
                kvStore = new LFU(cfg);
                break;
            case "LRU":
                kvStore = new LRU(cfg);
                break;
            default:
                System.out.println("Error: Unsupported strategy! FIFO is used by default!");
                kvStore = new FIFO(cfg);
                break;
        }
        KVCommandProcessor logic = new KVCommandProcessor(kvStore);

        Runtime.getRuntime().addShutdownHook(new Thread() {
            @Override
            public void run() {
                logic.shutdown();
            }
        });

        //prints the help message and terminates
        if (cfg.usagehelp) {
            System.out.println(HELP_MESSAGE);
            return;
        }

        //sets the logLevel
        Logger logger = LogManager.getLogManager().getLogger("");
        LogSetup.logLevel(cfg.level, logger);

        SimpleNioServer sn = new SimpleNioServer(logic);
        sn.bindSockets(cfg.listenaddr, cfg.port);
        sn.start();
    }
}
