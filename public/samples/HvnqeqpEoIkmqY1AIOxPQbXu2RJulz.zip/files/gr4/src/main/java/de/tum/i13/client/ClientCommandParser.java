package de.tum.i13.client;

import java.util.logging.Logger;

import de.tum.i13.server.kv.KVStore;
import de.tum.i13.server.kv.KVStoreImpl;

/**
 * The Parser class is used by the shell to parse the user input, recognize the
 * intended command and call the corresponding method.
 *
 * @author gr4
 */
public class ClientCommandParser {

	private static final Logger LOGGER = Logger.getLogger(ClientCommandParser.class.getName());
	private boolean terminated = false;
	private ClientCommands commands = new ClientCommands();
	private KVCommands kv = new KVCommands();

	/**
	 * Splits the user input into tokens, identifies what command is executed and
	 * calls the corresponding methods
	 *
	 * @param line input of the console
	 */
	public void parse(String line) {

		String[] tokens = line.trim().split("\\s+");

		switch (tokens[0]) {
		case "connect":
			parseConnect(tokens);
			break;
		case "disconnect":
			kv.disconnect();
			break;
		// case "send":
		// parseSend(tokens);
		// break;
		case "logLevel":
			parseLogLevel(tokens);
			break;
		case "help":
			if (tokens.length <= 1)
				commands.help();
			else
				commands.help(tokens[1]);
			break;
		case "quit":
			kv.quit();
			terminated = true;
			break;
		case "put":
			parsePut(tokens);
			break;
		case "get":
			parseGet(tokens);
			break;
		// case "delete":
		// parseDelete(tokens);
		// break;
		default:
			commands.miscellaneous();
			break;
		}
	}

	/**
	 * Parses the input of the console and executes the connect command
	 *
	 * @param args input of the console split into an array of tokens
	 */
	private void parseConnect(String[] args) {
		// the connect command needs two arguments: address and port
		if (args.length <= 2) {
			LOGGER.warning("User didn't enter required address and port arguments.");
			System.out.println("EchoClient> Error! connect needs address and port arguments!");
			return;
		}

		// the port argument must be parsed to integer and might throw a
		// NumberFormatException
		try {
			String address = args[1];
			int port = Integer.parseInt(args[2]);

			kv.connect(address, port);
		} catch (NumberFormatException nfe) {
			LOGGER.warning("Entered port argument is not an integer.");
			System.out.println("EchoClient> Error! The port argument must be an integer!");
		}
	}

	/**
	 * Parses the input of the console and executes the send command
	 *
	 * @param args input of the console split into an array of tokens
	 */
	private void parseSend(String[] args) {
		// the send command needs a message argument
		if (args.length <= 1) {
			LOGGER.warning("User didn't enter required message argument.");
			System.out.println("EchoClient> Error! send needs a message argument!");
			return;
		}

		/*
		 * the tokens need to be recombined to build the message the server expects the
		 * message to end with "\r\n"
		 */
		StringBuilder message = new StringBuilder(args[1]);
		for (int i = 2; i < args.length; i++) {
			message.append(" ").append(args[i]);
		}
		message.append("\r\n");

		kv.send(message.toString());
	}

	/**
	 * Parses the input of the console and executes the logLevel command
	 *
	 * @param args input of the console split into an array of tokens
	 */
	private void parseLogLevel(String[] args) {
		// the logLevel command needs a level argument
		if (args.length <= 1) {
			LOGGER.warning("User didn't enter required level argument.");
			System.out.println("EchoClient> Error! logLevel needs a level argument!");
			return;
		}

		String level = args[1].toUpperCase();

		commands.logLevel(level);
	}

	/**
	 * extracts the key and the value from the input of the put command and sends
	 * them to the ClientCommands class for further processing.
	 * 
	 * @param args input of the console split into an array of tokens
	 */
	private void parsePut(String[] args) {
		if (args.length <= 1) { // Put command needs a key and a value; however, the value can be null
			LOGGER.warning("User didn't enter required key-value argument.");
			System.out.println("EchoClient> Error! put needs a key and a value argument!");
			return;
		}

		if(args.length == 2) {//Delete the value 
			LOGGER.info("Delete the value to the key " + args[1]);
			kv.put(args[1], null);
			return;
		}
		
		// Everything after the key is the value
		StringBuilder value = new StringBuilder(args[2]);

		for (int i = 3; i < args.length; i++) {
			value.append(" ").append(args[i]);
		}

		LOGGER.info(
				"The put command has been executed with the key " + args[1] + " and the value: " + value.toString());
		kv.put(args[1], value.toString());

	}

	/**
	 * extracts the key from the input and invokes the get method of the
	 * ClientCommands class for further processing
	 * 
	 * @param args input of the console split into an array of tokens
	 */
	private void parseGet(String[] args) {
		if (args.length <= 1) { //get needs a key argument 
			LOGGER.warning("User didn't enter required get argument.");
			System.out.println("EchoClient> Error! get needs a key argument!");
			return;
		}
		
		LOGGER.info("Get command has been executed with the key: " + args[1]);
		
		kv.get(args[1]);
	}

	/*
	 * 
	 * private void parseDelete(String[] args) { if (args.length <= 1) {
	 * LOGGER.warning("User didn't enter required get argument.");
	 * System.out.println("EchoClient> Error! get needs a key argument!"); return; }
	 * commands.put(args[1], null); }
	 */

	/**
	 * Returns true if the shell was terminated by the quit command, false otherwise
	 *
	 * @return true if quit command has been executed
	 */
	public boolean isTerminated() {
		return terminated;
	}
}
