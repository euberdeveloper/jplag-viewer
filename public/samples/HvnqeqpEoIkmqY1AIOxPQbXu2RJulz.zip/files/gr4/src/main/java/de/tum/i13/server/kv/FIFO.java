package de.tum.i13.server.kv;

import de.tum.i13.server.kv.KVMessage.StatusType;
import de.tum.i13.shared.Config;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.logging.Logger;

/**
 * 
 * @author user gr4
 *
 */
public class FIFO implements KVStore {
	static Logger logger = Logger.getLogger(FIFO.class.getName());

	/*
	 * HashMap stores key value pairs for fast look ups LinkedList enables
	 * addressing the first element in the list easily. It also enables an easy
	 * deletion without the need for an index shift. Moreover, new elements are
	 * added at the back of the list.
	 * 
	 */

	private HashMap<String, String> keyValue;
	private LinkedList<String> keys;

	private int limit;
	private KVStore store;

	public FIFO(Config cfg) {
		limit = cfg.size;
		store = new KVStoreImpl(cfg);
		keyValue = new HashMap<String, String>(limit);
		keys = new LinkedList<String>();
		logger.info("FIFO initialized.");
	}

	@Override
	public KVMessage get(String key) throws Exception {
		logger.info("get " + key + " executed");
		String value = null;
		KVMessage kv = null;

		// key-value pair is in cache
		if (keyValue.containsKey(key)) {
			logger.info("key in cache");
			value = keyValue.get(key);
			kv = new KVMessageImpl(key, value, StatusType.GET_SUCCESS);
		}

		else {
			logger.info("key NOT in cache.");

			// Look up the key-value pair in the database
			kv = store.get(key);

			if (kv == null) {
				logger.warning("key not found.");
				return new KVMessageImpl(null, null, StatusType.GET_ERROR);
			}
			/*
			 * Cache is full and the new entries cannot be loaded onto the cache. The first
			 * element (added first) should be written to the database and the new entry
			 * should be added at the very end.
			 */
			if (keyValue.size() == limit) {
				KVMessage msg = writeToDisk();
				if (msg.getStatus().equals(StatusType.PUT_ERROR))
					logger.warning("Could not successfully write the first key value pair to disk.");

				value = kv.getValue();
				// Add the new entry
				writeToCache(key, value);
			}
		}
		logger.info("key: " + key + " " + "value: " + value);
		return kv;
	}

	public void shutdown() throws Exception {
		if(keyValue.isEmpty())
			return;
		
		if (keys != null && keyValue != null && !keys.isEmpty()) {
			logger.info("Shutting down...");
			for (int i = 0; i < keyValue.size(); i++) {
				store.put(keys.getFirst(), keyValue.get(keys.getFirst()));
				keys.remove();
			}
		}
	}

	@Override
	public KVMessage put(String key, String value) throws Exception {
		if (value == null)
			return this.delete(key);

		KVMessage kv = null;
		if (keyValue.containsKey(key)) {
			keyValue.put(key, value);
			kv = new KVMessageImpl(key, value, StatusType.PUT_UPDATE);
		}

		else {
			// Value in Store -> write to cache -> update
			if (store.get(key).getStatus().equals(StatusType.GET_SUCCESS)) {
				kv = new KVMessageImpl(key, value, StatusType.PUT_UPDATE);
			}

			// Cache is full. The new value must be written cache.
			if (keyValue.size() == limit) {
				KVMessage msg = writeToDisk();
				if (msg.getStatus().equals(StatusType.PUT_ERROR)) {
					logger.warning("Could not successfully write the first key value pair onto the disk.");
					// return new KVMessageImpl(key, value, StatusType.PUT_ERROR);
				}
			}

			// Writes the new value in cache.
			writeToCache(key, value);

			// The value is new
			if (kv == null)
				kv = new KVMessageImpl(key, value, StatusType.PUT_SUCCESS);
		}
		logger.info("There are " + keyValue.size() + " elements in cache.");
		return kv;
	}

	@Override
	public KVMessage delete(String key) throws Exception {
		logger.info("deleting " + key);
		if (!keys.isEmpty())
			logger.info("old first element: " + keys.getFirst() + " old last element: " + keys.getLast());
		if (keys.isEmpty())
			logger.info("There are " + keyValue.size() + " elements in tha cache");

		KVMessage kv1 = null;
		KVMessage kv2 = null;

		if (keyValue.containsKey(key)) {
			kv1 = new KVMessageImpl(key, keyValue.get(key), StatusType.DELETE_SUCCESS);
			keyValue.remove(key);
			keys.remove(key);
		}

		kv2 = store.put(key, null);

		if (!keys.isEmpty()) {
			logger.info("test");
			logger.info("new first element: " + keys.getFirst() + " new last element: " + keys.getLast());
		
		}if (keys.isEmpty())
			logger.info("There are " + keyValue.size() + " elements in tha cache");

		if (kv2 == null && kv1 == null)
			return new KVMessageImpl(key, null, StatusType.DELETE_ERROR);
		if (kv1 == null && kv2 != null)
			return kv2;
		else
			return kv1;

	}

	/**
	 * 
	 * Removes the first element from the cache and adds it to the disk.
	 * 
	 * @return KVMessage reporting the status of writing to the disk.
	 * @throws Exception if put failed
	 */
	private KVMessage writeToDisk() throws Exception {
		logger.info("Cache is full.");
		if (!keys.isEmpty())
			logger.info("old first element: " + keys.getFirst() + " old last element: " + keys.getLast());
		// Extract the oldest entry
		String firstKey = keys.getFirst();
		String firstValue = keyValue.get(firstKey);

		// put the first value pair onto the disk
		KVMessage msg = store.put(firstKey, firstValue);

		// Remove the first entry
		keyValue.remove(firstKey);
		keys.remove(); // removes the first element
		logger.info("Wrote " + msg.getKey() + " " + msg.getValue() + " to the disk. Status is: " + msg.getStatus());
		if (!keys.isEmpty())
			logger.info("new first element: " + keys.getFirst() + " new last element: " + keys.getLast());
		return msg;
	}

	/**
	 * Writes the key value pair into the cache.
	 *
	 * @param key   the key that identifies the given value.
	 * @param value the value that is indexed by the given key.
	 */
	private void writeToCache(String key, String value) {
		logger.info("Writing " + key + " for the first time in cache.");
		keyValue.put(key, value);
		keys.add(key);
		if (!keys.isEmpty())
			logger.info("first element: " + keys.getFirst() + " last element: " + keys.getLast());
	}

}
