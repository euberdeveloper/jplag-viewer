package de.tum.i13.server.kv;

import de.tum.i13.server.kv.KVMessage.StatusType;
import de.tum.i13.shared.Config;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.logging.Logger;

/**
 * This class implements the LRU displacement method.
 * 
 * @author gr4
 *
 */
public class LRU implements KVStore {
	static Logger logger = Logger.getLogger(LRU.class.getName());

	/*
	 * To ensure a look up in O(1) a hash is needed. To find and address the least
	 * and the most recently used key a pointer on each of them is needed. To ensure
	 * put and removed in O(1) a double linked list is needed.
	 */
	private DoubleLinkedListItem leastRecentlyUsed; // pointer on the last item which will be displaced
	private DoubleLinkedListItem mostRecentlyUsed; // pointer on the first item
	private HashMap<String, DoubleLinkedListItem> keyValue; // maps keys to a list object containing keys and values
	private int limit;
	private KVStore store;

	public LRU(Config cfg) {
		limit = cfg.size;
		keyValue = new HashMap<String, DoubleLinkedListItem>(limit);
		// leastRecentlyUsed = mostRecentlyUsed = new DoubleLinkedListItem(null, null,
		// null, null);
		leastRecentlyUsed = mostRecentlyUsed = null;
		store = new KVStoreImpl(cfg);
		logger.info("LRU initialized.");
	}

	@Override
	public KVMessage get(String key) throws Exception {
		String value = null;
		KVMessage kv = null;

		if (keyValue.containsKey(key)) {

			value = keyValue.get(key).getValue(); // Read value directly from cache
			if (!key.equals(mostRecentlyUsed.getKey())) { // Update is needed
				update(key);
			}
			logger.info("Key " + key + " is in the cache with " + value);
			kv = new KVMessageImpl(key, value, StatusType.GET_SUCCESS);
		}

		else {
			// read value from disk
			kv = store.get(key);
			if (kv == null || kv.getValue() == null)
				return new KVMessageImpl(key, null, StatusType.GET_ERROR);

			/*
			 * The new key should be added to the disk. If the cache is full then the least
			 * frequently used key is written to the disk.
			 */
			if (keyValue.size() == limit) {
				writeToDisk();
			}

			writeToCache(kv.getKey(), kv.getValue());
		}

		return kv;
	}

	/**
	 * Writes every item in cache onto the disk
	 */
	public void shutdown() throws Exception {

		if (mostRecentlyUsed == null || keyValue.isEmpty())
			return;

		DoubleLinkedListItem current = mostRecentlyUsed;

		while (current.getNext() != null) {
			store.put(current.getKey(), current.getValue());
			current = current.getNext();
		}
		store.put(current.getKey(), current.getValue());
	}

	@Override
	public KVMessage put(String key, String value) throws Exception {
		if (value == null)
			return this.delete(key);

		KVMessage kv = null;

		if (keyValue.containsKey(key)) {// update
			logger.info("Key " + key + "is already contained in the cache and has the value "
					+ keyValue.get(key).getValue());
			keyValue.get(key).setValue(value);
			if (!key.equals(mostRecentlyUsed.getKey())) {
				this.update(key);
			}
			logger.info("Key " + key + " has been updated to " + keyValue.get(key).getValue());
			kv = new KVMessageImpl(key, value, StatusType.PUT_UPDATE);

			logger.info("MRU: " + mostRecentlyUsed.getKey() + " ,LRU: " + leastRecentlyUsed.getKey());
		}

		else {
			KVMessage storedKey = store.get(key);
			// Value in Store -> write to cache -> update
			if (storedKey.getStatus().equals(StatusType.GET_SUCCESS) && storedKey.getValue() != null) {
				logger.info(
						"Key " + key + " is already contained on the disk and has the value " + storedKey.getValue());
				kv = new KVMessageImpl(key, value, StatusType.PUT_UPDATE);
			}

			// Cache is full. The new value must be written cache.
			if (keyValue.size() == limit) {
				KVMessage msg = writeToDisk();
				if (msg.getStatus().equals(StatusType.PUT_ERROR)) {
					logger.warning("Could not successfully write the first key value pair onto the disk.");
					// return new KVMessageImpl(key, value, StatusType.PUT_ERROR);
				}
			}

			// Writes the new value in cache.
			writeToCache(key, value);

			// The value is new
			if (kv == null) {
				kv = new KVMessageImpl(key, value, StatusType.PUT_SUCCESS);
				logger.info("Key " + key + " is new.");
			} else
				logger.info("Key " + key + " has been updated to " + keyValue.get(key).getValue());
		}
		return kv;
	}

	/**
	 * Updates the value of a currently existing key, updates the most recently used
	 * key to this key
	 * 
	 * @param key whose position is to be updated in the data structure
	 */
	private void update(String key) {

		if (keyValue.containsKey(key)) {
			DoubleLinkedListItem current = keyValue.get(key);
			DoubleLinkedListItem newNext = keyValue.get(key).getNext();
			DoubleLinkedListItem newPrev = keyValue.get(key).getPrevious();

			// If at the right-most, we update LRU
			if (key.equals(leastRecentlyUsed.getKey())) {
				newPrev.setNext(null);
				leastRecentlyUsed = newPrev;
			}

			// If we are in the middle, we need to update the keys before and after our
			// key
			else {
				newPrev.setNext(newNext);
				newNext.setPrevious(newPrev);
			}

			// Move key to the MRU

			current.setNext(mostRecentlyUsed);
			current.setPrevious(null);
			mostRecentlyUsed.setPrevious(current);
			mostRecentlyUsed = current;
		}

		logger.info("MRU: " + mostRecentlyUsed.getKey() + " ,LRU: " + leastRecentlyUsed.getKey());
	}

	/**
	 * Extracts the least recently used key value pair and writes it onto the disk
	 * and deletes it from the cache
	 * 
	 * @return KVMessage containing the status of the operation
	 * @throws Exception
	 */
	private KVMessage writeToDisk() throws Exception {

		if (leastRecentlyUsed != null && leastRecentlyUsed.getKey() != null) {
			String leastRecUsedKey = leastRecentlyUsed.getKey();
			String leastRecUsedVal = leastRecentlyUsed.getValue();
			keyValue.remove(leastRecUsedKey);

			logger.info("Wrting " + leastRecUsedKey + " onto disk.");

			leastRecentlyUsed = leastRecentlyUsed.getPrevious();
			leastRecentlyUsed.setNext(null);

			logger.info("MRU: " + mostRecentlyUsed.getKey() + " ,LRU: " + leastRecentlyUsed.getKey());

			// put in the last value pair onto the disk
			return store.put(leastRecUsedKey, leastRecUsedVal);
		} else
			return new KVMessageImpl(null, null, StatusType.PUT_ERROR);
	}

	@Override
	public KVMessage delete(String key) throws Exception {
		logger.info("delete executed.");
		KVMessage kv1 = null;
		KVMessage kv2 = null;
		String value = null;

		logger.info(keyValue.size() + " elements in the cache");

		if (keyValue.containsKey(key)) {
			value = keyValue.get(key).getValue();
			DoubleLinkedListItem item = keyValue.get(key);
			logger.info("next: " + item.getNext() + " prev" + item.getPrevious());

			if (item.getNext() != null && item.getPrevious() != null) {
				item.previous.setNext(item.getNext());
				item.next.setPrevious(item.getPrevious());
				logger.info("MRU: " + mostRecentlyUsed.getKey() + " ,LRU: " + leastRecentlyUsed.getKey());
			} else if (item.getNext() == null && item.getPrevious() != null) {
				leastRecentlyUsed = item.getPrevious();
				leastRecentlyUsed.setNext(null);
				logger.info("MRU: " + mostRecentlyUsed.getKey() + " ,LRU: " + leastRecentlyUsed.getKey());

			} else if (item.getNext() != null && item.getPrevious() == null) {
				mostRecentlyUsed = item.getNext();
				mostRecentlyUsed.setPrevious(null);
				logger.info("MRU: " + mostRecentlyUsed.getKey() + " ,LRU: " + leastRecentlyUsed.getKey());
			} else {
				leastRecentlyUsed = mostRecentlyUsed = null;
				logger.info("MRU: " + mostRecentlyUsed + " ,LRU: " + leastRecentlyUsed);
			}
			keyValue.remove(key);
			kv1 = new KVMessageImpl(key, value, StatusType.DELETE_SUCCESS);
		}

		kv2 = store.put(key, null);

		if (kv2 == null && kv1 == null)
			return new KVMessageImpl(key, null, StatusType.DELETE_ERROR);
		if (kv1 == null && kv2 != null)
			return kv2;
		else
			return kv1;
	}

	/**
	 * Writes the key value pair onto the cache and updates the most recently used
	 * key to this key which is now written into the cache.
	 * 
	 * @param key   a string value
	 * @param value a string value
	 */
	private void writeToCache(String key, String value) {
		DoubleLinkedListItem newItem = new DoubleLinkedListItem(key, value, null, null);

		if (mostRecentlyUsed != null && mostRecentlyUsed.getKey() != null) { // at least one element in the cache
			logger.info("old MRU: " + mostRecentlyUsed.getKey() + " , old LRU: " + this.leastRecentlyUsed.getKey());
			newItem.setNext(mostRecentlyUsed);
			mostRecentlyUsed.setPrevious(newItem);
			keyValue.put(key, newItem);
			mostRecentlyUsed = newItem;
		} else {
			keyValue.put(key, newItem);
			logger.info("old MRU: " + "null" + " , old LRU: null");
			leastRecentlyUsed = mostRecentlyUsed = newItem;
		}
		logger.info("new MRU: " + mostRecentlyUsed.getKey() + " , new LRU: " + leastRecentlyUsed.getKey());
		logger.info("There are " + keyValue.size() + " elements in cache.");
	}

	/**
	 * 
	 * This class implements a double linked list with pointers for the previous and
	 * the next element. This helps to perform deletes and updates in
	 * 
	 * @author gr4
	 *
	 */
	private class DoubleLinkedListItem {
		private String key;
		private String value;
		private DoubleLinkedListItem next;
		private DoubleLinkedListItem previous;

		public DoubleLinkedListItem(String key, String value, DoubleLinkedListItem previous,
				DoubleLinkedListItem next) {
			this.previous = previous;
			this.next = next;
			this.key = key;
			this.value = value;
		}

		public String getKey() {
			return key;
		}

		public void setKey(String key) {
			this.key = key;
		}

		public String getValue() {
			return value;
		}

		public void setValue(String value) {
			this.value = value;
		}

		public DoubleLinkedListItem getNext() {
			return next;
		}

		public void setNext(DoubleLinkedListItem next) {
			this.next = next;
		}

		public DoubleLinkedListItem getPrevious() {
			return previous;
		}

		public void setPrevious(DoubleLinkedListItem previous) {
			this.previous = previous;
		}
	}
}
