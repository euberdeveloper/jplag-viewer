package de.tum.i13.shared;

import java.io.UnsupportedEncodingException;
import java.util.Base64;

/**
 * This class decodes and encode Strings to byte array and vice versa
 * 
 * @author gr4
 *
 */
public class Encoder {

	/**
	 * Decodes a byte array into a string in ISO8859-1
	 * 
	 * @param msg : a byte array
	 * @return the string representation of the byte array using the TELNET ENCODING
	 * @throws UnsupportedEncodingException
	 */
	public static String byteToISO88591(byte[] msg) throws UnsupportedEncodingException {
		return new String(msg, Constants.TELNET_ENCODING);
	}

	/**
	 * Encode a string in ISO8859-1 into a byte array
	 * 
	 * @param msg: a string
	 * @return the byte array representation of the string message msg using the
	 *         TELNET ENCODING
	 * @throws UnsupportedEncodingException
	 */
	public static byte[] iso88591ToByte(String msg) throws UnsupportedEncodingException {
		return msg.getBytes(Constants.TELNET_ENCODING);
	}

	/**
	 * Encodes from a string to a byte array in Base64
	 * 
	 * @param msg: a string
	 * @return the byte array representation of the string message msg using the
	 *         Base64 ENCODING
	 */
	public static byte[] base64ToByte(String msg) {
		return Base64.getEncoder().encode(msg.getBytes());
	}

	/**
	 * Encodes from a byte array in Base64 to a string
	 * 
	 * @param msg: a byte array in Base64
	 * @return the string representation of the byte array using the Base64 ENCODING
	 */
	public static String byteToBase64(byte[] msg) {
		return new String(Base64.getDecoder().decode(msg));
	}

	/**
	 * Encodes from a string in Base64 to a string 
	 * 
	 * @param msg : a string in Base64
	 * @return the string representation of the message
	 */
	public static String base64ToString(String msg) {
		return new String(Base64.getDecoder().decode(msg));
	}

	/**
	 * Encodes from a string to a string in Base64
	 * 
	 * @param msg : a string 
	 * @return the string representation of the message using Base64 ENCODING
	 */
	public static String stringToBase64(String msg) {
		return Base64.getEncoder().encodeToString(msg.getBytes());
	}

}
