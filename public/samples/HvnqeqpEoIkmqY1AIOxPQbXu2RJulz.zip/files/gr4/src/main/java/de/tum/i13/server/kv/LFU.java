package de.tum.i13.server.kv;

import de.tum.i13.server.kv.KVMessage.StatusType;
import de.tum.i13.shared.Config;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;
import java.util.logging.Logger;

/**
 * This class implements the LFU cache displacement strategy.
 * 
 * If a GET-request by a client causes a cache miss, the respective key-value
 * pair is looked-up on disk and transferred to the cache. If the cache is
 * already full, the least frequently used tuple is displaced to disk.
 * 
 * If a PUT-request by a client is received by the server and the cash is
 * already full, then again the least frequently used tuple is displaced.
 * 
 * 
 * @author gr4
 *
 */
public class LFU implements KVStore {

	static Logger logger = Logger.getLogger(LFU.class.getName());

	/*
	 * To ensure a look up in O(1) a hash is needed. To find and address the least
	 * and the most frequently used key a container for the frequency is needed. A
	 * bigger number means a higher frequency. The element with the least frequency
	 * must be written into the disk.
	 */
	private HashMap<String, String> keyValue;
	private HashMap<String, Integer> keyFrequency;
	private HashMap<Integer, LinkedHashSet<String>> frequencyKey;

	private int limit;
	private KVStore store;

	public LFU(Config cfg) {
		limit = cfg.size;
		store = new KVStoreImpl(cfg);

		keyValue = new HashMap<String, String>(limit);
		keyFrequency = new HashMap<String, Integer>(limit);
		frequencyKey = new HashMap<Integer, LinkedHashSet<String>>(limit);
		frequencyKey.put(0, new LinkedHashSet<String>());
		logger.info("LFU initialized.");
	}

	@Override
	public KVMessage get(String key) throws Exception {
		KVMessage kv = null;
		String value = null;

		if (keyValue.containsKey(key)) {
			value = keyValue.get(key);
			logger.info("Before update: Key: " + key + " Value: " + value + "Frequency: " + keyFrequency.get(key));
			updateFrequency(key); // Accessing the key increases the usage.
			logger.info("After update: Key: " + key + " Value: " + value + "Frequency: " + keyFrequency.get(key));
			kv = new KVMessageImpl(key, value, StatusType.GET_SUCCESS);
		}

		else {

			// read value from disk
			kv = store.get(key);

			if (keyValue.size() != limit && kv != null && kv.getValue() != null) {
				writeToCache(key, kv.getValue());
			}

			else if (kv == null || kv.getValue() == null) {
				logger.warning("Key could not be found.");
				return new KVMessageImpl(key, null, StatusType.GET_ERROR);
			} else {

				// write the least frequently used element to the disk
				writeToDisk();

				// write new element to cache
				writeToCache(key, kv.getValue());
			}
		}

		return kv;
	}

	@Override
	public void shutdown() throws Exception {

		if (!keyValue.isEmpty()) {
			for (String key : keyValue.keySet()) {
				store.put(key, keyValue.get(key));
			}
		}
	}

	@Override
	public KVMessage put(String key, String value) throws Exception {
		if (value == null)
			return this.delete(key);

		KVMessage kv = null;

		// Value in cache -> Update
		if (keyValue.containsKey(key)) {
			logger.info("Key " + key + " is already contained in cache with value " + keyValue.get(key));
			keyValue.put(key, value);
			logger.info("Key " + key + " was updated. New value is " + keyValue.get(key));
			updateFrequency(key);
			kv = new KVMessageImpl(key, value, StatusType.PUT_UPDATE);
		}

		else {
			// Value in Store -> write to cache -> update
			KVMessage storedKey = store.get(key);
			if (storedKey.getStatus().equals(StatusType.GET_SUCCESS) && storedKey.getValue() != null) {
				kv = new KVMessageImpl(key, value, StatusType.PUT_UPDATE);
				logger.info("Key " + key + " is already contained in disk with value " + storedKey.getValue());
			}

			// Cache is full. The new value must be written cache.
			if (keyValue.size() == limit) {
				KVMessage msg = writeToDisk();
				if (msg.getStatus().equals(StatusType.PUT_ERROR)) {
					logger.warning("Could not successfully write the first key value pair onto the disk.");
					// return new KVMessageImpl(key, value, StatusType.PUT_ERROR);
				}
			}

			// Writes the new value in cache.
			writeToCache(key, value);

			// The value is new
			if (kv == null) {
				kv = new KVMessageImpl(key, value, StatusType.PUT_SUCCESS);
				logger.info("Key " + key + " is new.");
			}
		}
		return kv;

	}

	@Override
	public KVMessage delete(String key) throws Exception {
		KVMessage kv1 = null;
		KVMessage kv2 = null;
		String value;

		if (keyValue.containsKey(key)) {
			value = keyValue.get(key);
			keyValue.remove(key);
			int freq = keyFrequency.get(key);
			keyFrequency.remove(key);
			frequencyKey.remove(freq);
			kv1 = new KVMessageImpl(key, value, StatusType.DELETE_SUCCESS);
		}

		kv2 = store.put(key, null);

		if (kv2 == null && kv1 == null)
			return new KVMessageImpl(key, null, StatusType.DELETE_ERROR);
		if (kv1 == null && kv2 != null)
			return kv2;
		else
			return kv1;
	}

	/**
	 * Increases the frequency by 1
	 * 
	 * @param key The key which was just used, hence its frequency needs to be updated
	 */
	private void updateFrequency(String key) {
		int freq = keyFrequency.get(key);
		logger.info(key + " had frequency " + freq);
		keyFrequency.put(key, freq + 1);

		if (frequencyKey.containsKey(freq)) {
			logger.info("Key " + key + " is already contained. Removed the old frequency.");
			frequencyKey.get(freq).remove(key);
			if (frequencyKey.get(freq).isEmpty()) {
				frequencyKey.remove(freq);
				logger.info("There are no elements left in cache with frequency " + freq);
			}
		}

		if (frequencyKey.get(freq + 1) != null) {
			frequencyKey.get(freq + 1).add(key);
			logger.info("There is at least one more element with frequency " + freq + 1);
		}

		else {
			frequencyKey.put(freq + 1, new LinkedHashSet<String>());
			frequencyKey.get(freq + 1).add(key);
		}

		logger.info(key + " has now frequency " + keyFrequency.get(key));
	}

	/**
	 * Writes the Key Value pair on the cache for the first time. Sets their
	 * frequency to 0.
	 * 
	 * @param key
	 * @param value
	 */
	private void writeToCache(String key, String value) {
		logger.info("writing " + key + " " + value + " to cache.");
		if (frequencyKey.get(0) == null)
			frequencyKey.put(0, new LinkedHashSet<String>());
		keyValue.put(key, value);
		keyFrequency.put(key, 0);
		frequencyKey.get(0).add(key);
		logger.info(
				"Key " + key + " was successfully added to cache and now has the frequency " + keyFrequency.get(key));
	}

	/**
	 * Writes the least frequently used key onto the disk.
	 * 
	 * @return The KVMessage containing the state of this put request.
	 * @throws Exception
	 */
	private KVMessage writeToDisk() throws Exception {

		for (int freq : frequencyKey.keySet())
			logger.info("Contained frequencies: " + freq + ", ");

		int leastFreq = Collections.min(frequencyKey.keySet()); // The frequency of the key that has been used least
																// frequently
		logger.info("min frequency: " + leastFreq);

		String leastUsedKey = (String) frequencyKey.get(leastFreq).toArray()[0];
		String leastUsedValue = keyValue.get(leastUsedKey);

		logger.info("Putting key: " + leastUsedKey + " ,and value: " + leastUsedValue + " and the frequency "
				+ keyFrequency.get(leastUsedKey) + " onto the disk.");
		frequencyKey.get(leastFreq).remove(leastUsedKey);

		if (frequencyKey.get(leastFreq).isEmpty()) {
			frequencyKey.remove(leastFreq);
			logger.info("There are no elements left in cache with frequency " + leastFreq);
		}

		keyValue.remove(leastUsedKey);
		keyFrequency.remove(leastUsedKey);

		return store.put(leastUsedKey, leastUsedValue);
	}

}
