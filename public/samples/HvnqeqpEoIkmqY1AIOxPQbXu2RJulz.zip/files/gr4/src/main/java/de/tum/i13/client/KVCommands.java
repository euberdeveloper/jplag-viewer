package de.tum.i13.client;

import java.io.UnsupportedEncodingException;
import java.util.logging.Logger;

import de.tum.i13.shared.Encoder;

/**
 * This class implements the Key-Value logic
 * @author gr4
 *
 */
public class KVCommands {
	private static final Logger LOGGER = Logger.getLogger(KVCommands.class.getName());
	private final ServerConnector connector = new ServerConnector(); // Controls a socket-based communication

	/**
	 * Connects the client to the server and creates an output to notify the user
	 * about the status of the connection.
	 *
	 * @param hostAddress: The address of the host server.
	 * @param port:        An Integer representing the port, to which the client
	 *                     wishes to connect.
	 */
	public void connect(String hostAddress, int port) {

		LOGGER.info("Connect command executed.");
		if (port < 0 || port > 65535) {// invalid port
			LOGGER.warning("Port " + port + " is out of range.");
			System.out.println("EchoClient> Error! Invalid port.");
			return;
		}

		if (connector.connect(hostAddress, port)) { // tries to connect to the server
			LOGGER.info("Connecting to server: " + hostAddress + port);
			try {
				byte[] confirmationMessageInBytes = connector.receive();
				LOGGER.info("Confirmation message received.");
				if (confirmationMessageInBytes != null) {
					String confirmationMessage = Encoder.byteToISO88591(confirmationMessageInBytes);
					System.out.println("EchoClient> " + confirmationMessage); // Successful connection
				} else {
					LOGGER.info("Error in connection. The confirmation got lost.");
					System.out.println("EchoClient> Error! connection lost.");
				}
			} catch (UnsupportedEncodingException e) {
				LOGGER.warning("There seems to be a problem with encoding byte[] to String.");
				e.printStackTrace();
				System.out.println("EchoClient> Error! could not encode echo reply.");
			}

		} else
			System.out.println("EchoClient> Error: Failed to connect."); // The connection could not be established.
	}

	/**
	 * Tries to disconnect from the echo server. It also notifies the user about the
	 * status of the disconnection.
	 */
	public void disconnect() {
		LOGGER.info("Disconnect command executed.");
		if (connector.disconnect()) {
			LOGGER.info("Disconnecting from server");
			System.out.println("EchoClient> You have been successfully disconnected from the server.");
		} else
			System.out.println("EchoClient>  Error: You are not connected.");
	}

	/**
	 * Tears down the active connection to the server and exits the program
	 * execution.
	 */
	public void quit() {
		LOGGER.info("quit command executed.");
		if (connector.isConnected())
			connector.disconnect();
		System.out.println("EchoClient> You quit the program.");
	}

	/**
	 * The command send will send a message to an echo server and display the
	 * server's response.
	 *
	 * @param text: A String, which will be sent to the echo server.
	 */
	public void send(String text) {
		LOGGER.info("send command executed.");
		// Encode according to ISO-8859-1
		try {

			byte[] messageInBytes = Encoder.iso88591ToByte(text);
			if (messageInBytes.length > 128000) {
				LOGGER.warning("Message too big.");
				System.out.println("EchoClient> Error! Message too large.");
				return;
			}

			// Send the message
			if (connector.send(messageInBytes)) {

				// Echo Reply
				byte[] echoReplyInBytes = connector.receive();

				if (echoReplyInBytes == null) { // Empty response
					LOGGER.warning("Could not receive echo reply because the client is not connected.");
					System.out.println("EchoClient> Error: You are not connected.");
					return;
				}

				if (echoReplyInBytes.length > 128000) { // 128KB
					LOGGER.warning("Message too big.");
					return;
				}

				// Encode according to ISO-8859-1
				String echoReply = Encoder.byteToISO88591(echoReplyInBytes);
				LOGGER.info("Echo reply has been encoded in String.");
				System.out.println("EchoClient> " + echoReply);
			} else {
				LOGGER.warning("Failed to send the message.");
				System.out.println("EchoClient> Error! could not sent the message.");
			}
		} catch (UnsupportedEncodingException e) {
			e.printStackTrace();
			LOGGER.warning("There seems to be a problem with encoding.");
			System.out.println("EchoClient> Error! Wrong message format.");
		}
	}
	
	/**
	 * Checks syntax and sends the get key request to the communication module. It
	 * will also print the server response.
	 * 
	 * @param key: A string value max. length 20 B
	 */
	public void get(String key) {

		try {
			if (key == null || key.equals("") || key.equals(" ")) {
				// Invalid key
				LOGGER.warning("Inserted invalid key.");
				System.out.println("EchoClient> The key " + key + " is invalid.");
				return;
			}

			if (key.getBytes().length > 20) { // Key too large
				LOGGER.warning("Inserted invalid key.");
				System.out.println("EchoClient> The key " + key + " is too large.");
				return;
			}

			String request = "get " + key + "\r\n";
			LOGGER.info("Request to be sent: " + request);

			byte[] getRequestInBytes = Encoder.iso88591ToByte(request); //TELNET ENCODING
			
			if (connector.send(getRequestInBytes)) {

				// Echo Reply
				byte[] valueInBytes = connector.receive();

				if (valueInBytes == null) { // Empty response
					LOGGER.warning(
							"Could not receive reply due to the connection loss or because the value does not exist.");
					System.out.println("EchoClient> Error! Value could not be found.");
					return;
				}

				if (valueInBytes.length > 120000) { // 120KB
					LOGGER.warning("Message too big.");
					return;
				}


				// Decode according to ISO-8859-1
				String valueInBase64 = Encoder.byteToISO88591(valueInBytes);
				LOGGER.info("Value accoring to Base64: " + valueInBase64);
				
				//Decode according to Base64
				String value = decodeReply(valueInBase64);
						
				LOGGER.info("Value has been encoded in String: " + value);
				System.out.println("EchoClient> " + value);
			} else {
				LOGGER.warning("Failed to send the request.");
				System.out.println("EchoClient> Error! could not sent the request.");
			}
		} catch (UnsupportedEncodingException e) {
			e.printStackTrace();
			LOGGER.warning("There seems to be a problem with encoding.");
			System.out.println("EchoClient> Error! Wrong message format.");
			return;
		}

	}

	/**
	 * Puts the key-value pair into the storage after doing the required syntax
	 * checks.
	 * 
	 * @param key:   a String key max 20B
	 * @param value: a String value associated with the key max 120kB
	 */
	public void put(String key, String value) {
		try {
			if (key == null || key.equals("") || key.equals(" ")) {
				// Invalid key
				LOGGER.warning("Inserted invalid key.");
				System.out.println("EchoClient> The key " + key + " is invalid.");
				return;
			}

			if (key.getBytes().length > 20) { // Key too large
				LOGGER.warning("Inserted invalid key.");
				System.out.println("EchoClient> The key " + key + " is too large.");
				return;
			}

			else if (value != null && value.getBytes().length > 120000) { // Value too large
				LOGGER.warning("Inserted invalid value.");
				System.out.println("EchoClient> The value " + value + " is too large.");
				return;
			}
			
			String request;
			
			if (value == null) //delete request
				request = "delete " + key + "\r\n";
				
			else {
				LOGGER.info("Request to be sent before any encoding: put " + key + " " + value);

				// Put request with value encoded in Base64
				request = "put " + key + " " + Encoder.stringToBase64(value) + "\r\n";
				LOGGER.info("The request has been encoded to Base64 string: " + request);
			}
			
			//Encode in ISO88591 
			byte[] requestInBytes = Encoder.iso88591ToByte(request);

			if (connector.send(requestInBytes)) {

				// Echo Reply
				byte[] responseInBytes = connector.receive();

				if (responseInBytes == null) { // Empty response
					LOGGER.warning("Could not receive reply due to the connection loss.");
					System.out.println("EchoClient> ERROR ");
					return;
				}
				
				//Decode from ISO88591
				String responseInBase64 = Encoder.byteToISO88591(responseInBytes);
				LOGGER.info("The response has been decoded from byte [] to string using ISO88591: " + responseInBase64.toString());
				//Decode from Base64
				String response = decodeReply(responseInBase64);
				LOGGER.info("The response has been decoded from Base64: " + response);
				
				System.out.println("EchoClient> " + response);
			} else {
				LOGGER.warning("Failed to send the request.");
				System.out.println("EchoClient> Error! could not sent the request.");
			}
		} catch (UnsupportedEncodingException e) {
			e.printStackTrace();
			LOGGER.warning("There seems to be a problem with encoding.");
			System.out.println("EchoClient> Error! Wrong message format.");
		}
	}

	/**
	 * Decodes the value of the server reply.
	 *
	 * @param reply: server reply
	 * @return decoded server reply
	 */
	private String decodeReply(String reply) {
		if (reply == null )
			return null;

		String[] tokens = reply.trim().split("\\s+");

		if (tokens.length == 0)
			return "";

		if ((tokens[0].equals("put_error") || tokens[0].equals("get_success")) && tokens.length >= 3) {
			StringBuilder encodedValue = new StringBuilder(tokens[2]);
			for (int i = 3; i < tokens.length; i++) {
				encodedValue.append(" ").append(tokens[i]);
			}
			String decodedValue = Encoder.base64ToString(encodedValue.toString());
			return tokens[0] + " " + tokens[1] + " " + decodedValue;
		} else {
			return reply;
		}
	}
}
