package de.tum.i13.server.kv;

import de.tum.i13.shared.Config;

import java.io.*;
import java.util.logging.Logger;

public class KVStoreImpl implements KVStore {
	private static final Logger LOGGER = Logger.getLogger(KVStoreImpl.class.getName());
	private final String fileName;

	public KVStoreImpl(Config cfg) {
		fileName = cfg.dataDir + "store.txt";
		try {
			File f = new File(fileName);
			if (!f.exists()) {
				if (f.createNewFile()) {
					LOGGER.info("Created file: " + f.getName());
				} else
					LOGGER.info("Could not create file");
			} else
				LOGGER.info("File already exists");

		} catch (IOException e) {
			LOGGER.warning("Error!");
			e.printStackTrace();
		}
	}

	/**
	 * Inserts key and value to database
	 *
	 * @param  key   is representing key for database entry
	 * @param  value is representing value for database entry
	 * @return KVMessage with value set that was inserted or null if insertion
	 *         failed
	 *
	 */
	@Override
	public KVMessage put(String key, String value) throws Exception {
		if (key == null) {
			LOGGER.warning("Key is null, it is not supported.");
			return new KVMessageImpl(null, null, KVMessage.StatusType.PUT_ERROR);
		} else if (value == null) {
			LOGGER.info("Value is null.");
			if (get(key).getStatus() == KVMessage.StatusType.GET_ERROR) {
				LOGGER.warning("Entry with: " + key + " is not founded in database and value is null.");
				return new KVMessageImpl(key, null, KVMessage.StatusType.DELETE_ERROR);
			}

			else
				return updateDelete(key, null, true);
		} else if (key.getBytes().length > 20 || value.getBytes().length > 120000) {
			LOGGER.warning("key " + key + " or value " + value + " too large.");
			return new KVMessageImpl(key, value, KVMessage.StatusType.PUT_ERROR);
		} else if (get(key).getStatus() == KVMessage.StatusType.GET_SUCCESS) {
			return updateDelete(key, value, false);
		}

		try {
			FileWriter fw = new FileWriter(fileName, true);
			BufferedWriter bw = new BufferedWriter(fw);
			PrintWriter out = new PrintWriter(bw);

			out.println(key + ":" + value);
			out.flush();
			bw.flush();
			fw.flush();
			out.close();
			bw.close();
			fw.close();
		} catch (IOException e) {
			LOGGER.warning("Exception by closing FileWriter, BufferedWriter or PrintWriter is thrown");
			return new KVMessageImpl(key, value, KVMessage.StatusType.PUT_ERROR);
		}

		return new KVMessageImpl(key, value, KVMessage.StatusType.PUT_SUCCESS);
	}

	/**
 * Deletes entry from database
	 *
	 * @param  key is representing key for database entry
	 * @return KVMessage with value set to null and status DELETE_ERROR if exception is thrown or with status
	 * 		   delete_success if the entry was successfully deleted. If key does not exist returns delete_error
	 */
	@Override
	public KVMessage delete(String key) {
		try {
			return updateDelete(key, null, true);
		} catch (Exception e) {
			return new KVMessageImpl(key, null, KVMessage.StatusType.DELETE_ERROR);
		}
	}

	/**
	 * This methode is coping a file line by line and searching for key. If isDeleteOp is set than it inserts a value
	 * with the specified key. Also creates a temporary file(filename + _) and deletes this file at exit.
	 *
	 * @param  key identifier for value entry
	 * @param  value new value for entry with key
	 * @param  isDeleteOp specifies if this operation is an delete operation
	 * @return KVMessage with value and status PUT_UPDATE if it was an update operation, or with DELETE_SUCCESS status
	 * 		   in case of delete operation
	 */
	private KVMessage updateDelete(String key, String value, boolean isDeleteOp) throws Exception {
		LOGGER.info("Update call received with key:" + key + ", value: " + value + ", is delete operation: " + isDeleteOp);
		String newFileName = fileName + "_";

		FileWriter fw = new FileWriter(newFileName, true);
		BufferedReader br = new BufferedReader(new FileReader(fileName));

		BufferedWriter bw = new BufferedWriter(fw);
		PrintWriter out = new PrintWriter(bw);

		boolean deleted = false;

		String line;
		String[] lineAsArray;
		while ((line = br.readLine()) != null) {
			lineAsArray = line.split(":");
			if(lineAsArray.length == 2 && lineAsArray[0].equals(key)) {
				if(!isDeleteOp) {
					out.println(key + ":" + value);
					bw.flush();
					out.flush();
				} else deleted = true;
			} else {
				out.println(line);
				bw.flush();
				out.flush();
			}
		}

		LOGGER.info("Closing all Writers/Readers...");
		out.flush();
		bw.flush();
		fw.flush();
		out.close();
		bw.close();
		fw.close();
		br.close();
		LOGGER.info("All Writers/Readers are closed and data is flushed");

		renameFiles(newFileName);

		if (isDeleteOp && !deleted)
			return new KVMessageImpl(key, value, KVMessage.StatusType.DELETE_ERROR);
		else
			return new KVMessageImpl(key, value, isDeleteOp ? KVMessage.StatusType.DELETE_SUCCESS : KVMessage.StatusType.PUT_UPDATE);
	}

	/**
	 * Renames files. File must exist
	 *
	  @param newFileName name  of the temporary file
	 */
	private void renameFiles(String newFileName) {
		File file =  new File(fileName);
		if(file.delete()) {
			LOGGER.info(" Old file deleted successfully");
			File file1 = new File(newFileName);
			File file2 =  new File(fileName);
			if(file1.renameTo(file2)) {
				LOGGER.info("Old file renamed successfully");
			} else {
				LOGGER.info("Failed to renamed back");
			}
		} else {
			LOGGER.info("Failed to delete the old file");
		}
	}

	@Override
	public KVMessage get(String key) {
		LOGGER.info("Received get request with key: " + key);
		if(key.getBytes().length > 20) {
			LOGGER.warning("Key is too long");
			return new KVMessageImpl(key, null, KVMessage.StatusType.GET_ERROR);
		}

		try (BufferedReader br = new BufferedReader(new FileReader(fileName))) {
			String line;
			String[] lineAsArray;
			LOGGER.info("Starting read from database");
			while ((line = br.readLine()) != null) {
				lineAsArray = line.split(":");
				if(lineAsArray.length == 2 && lineAsArray[0].equals(key)) {
					LOGGER.info("Key is found, value is: " + lineAsArray[1]);
					return new KVMessageImpl(key, lineAsArray[1], KVMessage.StatusType.GET_SUCCESS);
				}
			}
		} catch (Exception e) {
			LOGGER.warning("Exception is thrown");
			return new KVMessageImpl(key, null, KVMessage.StatusType.GET_ERROR);
		}

		return new KVMessageImpl(key, null, KVMessage.StatusType.GET_ERROR);
	}

	/**
	 * Called when the server shuts down
	 */
	@Override
	public void shutdown() {
		LOGGER.info("Shutdown is called on KVStoreImpl");
	}
}
