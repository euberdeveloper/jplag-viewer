package de.tum.i13.server.threadperconnection;

import de.tum.i13.server.kv.*;
import de.tum.i13.shared.Config;
import de.tum.i13.shared.LogSetup;

import java.io.*;
import java.net.InetSocketAddress;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.logging.LogManager;
import java.util.logging.Logger;

import static de.tum.i13.shared.Config.parseCommandlineArgs;
import static de.tum.i13.shared.LogSetup.setupLogging;

/**
 * Created by chris on 09.01.15.
 */
public class Main {

    private static final Logger logger = Logger.getLogger(Main.class.getName());

    private static final String HELP_MESSAGE = "This server is a key-value-store. The following flags are supported:\n"
            + "-p   Sets the port of the server\n"
            + "-a   Which address the server should listen to, default is 127.0.0.1\n"
            + "-b   Bootstrap broker\n"
            + "-d   Directory for files in which the key-value pairs will be stored\n"
            + "-l   Relative path of the logfile\n"
            + "-ll  Log level\n"
            + "-c   Size of the cache\n"
            + "-s   Cache displacement strategy, FIFO, LRU, LFU\n"
            + "-h   Displays the help message\n\n"
            + "Possible queries to the server are:\n"
            + "put <key> <value>    Sends a key value pair to the server\n"
            + "get <key>            Gets the value of a key\n"
            + "delete <key>         Deletes a value\n";

    public static void main(String[] args) {
        Config cfg = parseCommandlineArgs(args);  //Do not change this
        setupLogging(cfg.logfile);

        ServerSocket helpSocket = null;
        try {
            helpSocket = new ServerSocket();
        } catch (IOException e) {
            System.out.println("Unable to open a socket");
            return;
        }
        final ServerSocket serverSocket = helpSocket;

        //Creates the CommandProcessor with requested strategy
        KVStore kvStore;
        switch (cfg.strategy) {
            case "FIFO":
                kvStore = new FIFO(cfg);
                break;
            case "LFU":
                kvStore = new LFU(cfg);
                break;
            case "LRU":
                kvStore = new LRU(cfg);
                break;
            default:
                System.out.println("Error: Unsupported strategy! FIFO is used by default!");
                kvStore = new FIFO(cfg);
                break;
        }
        KVCommandProcessor logic = new KVCommandProcessor(kvStore);

        Runtime.getRuntime().addShutdownHook(new Thread() {
            @Override
            public void run() {
                System.out.println("Closing thread per connection kv server");
                try {
                    serverSocket.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
                logic.shutdown();
            }
        });

        //prints the help message and terminates
        if (cfg.usagehelp) {
            System.out.println(HELP_MESSAGE);
            return;
        }

        //bind to localhost only
        try {
            serverSocket.bind(new InetSocketAddress(cfg.listenaddr, cfg.port));
        } catch (IOException e) {
            System.out.println("Unable to bind server socket");
            return;
        }

        //sets the logLevel
        Logger logger = LogManager.getLogManager().getLogger("");
        LogSetup.logLevel(cfg.level, logger);

        while (true) {
            try {
                Socket clientSocket = serverSocket.accept();

                //When we accept a connection, we start a new Thread for this connection
                Thread th = new ConnectionHandleThread(logic, clientSocket);
                th.start();
            } catch (Exception e) {
                Main.logger.warning("Failed accepting client connection");
            }
        }
    }
}
