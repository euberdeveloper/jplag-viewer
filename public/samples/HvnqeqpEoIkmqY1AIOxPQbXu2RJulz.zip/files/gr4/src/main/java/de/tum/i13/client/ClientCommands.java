package de.tum.i13.client;

import java.io.IOException;
import java.io.UnsupportedEncodingException;
import de.tum.i13.shared.Constants;
import de.tum.i13.shared.Encoder;

import java.util.logging.Handler;
import java.util.logging.Level;
import java.util.logging.LogManager;
import java.util.logging.Logger;

/**
 * The different functionalities of the echo client application are specified in
 * this class. The class Parser uses the helper class Commands to execute user's
 * command requests.
 * 
 * @author gr4
 */
public class ClientCommands {

	private static final Logger LOGGER = Logger.getLogger(ClientCommands.class.getName());

	/**
	 * Provides a list of acceptable commands
	 */
	public void help() {
		LOGGER.info("Help command executed.");
		System.out.println(
				"The echo client is used to connect to a key-value server. Please refer to the following available commands:");
		System.out.println("connect <host> <port>:   Establishes a TCP connection to the specified address.");
		System.out.println("disconnect:              Disconnects from a server.");
		System.out.println("help <command>:          Shows the application and the syntax of <command>.");
		System.out.println("logLevel <level>:        Sets the logger to the specified log level. ");
		System.out.println("quit:                    Tears down the active connection to the server.");
		//System.out.println("send <message>:          Sends a text message to the echo server. ");
		System.out.println(
				"put <key> <value>:       Inserts, updates or deletes a key a value pair in the storage server.");
		System.out
				.println("get <key>:               Retrieves the value for the given key from the storage server.");
	}

	/**
	 * Provides for each command its syntax and purpose.
	 * 
	 * @param command: A string representing the command, for which more detail is
	 *                 wished.
	 */
	public void help(String command) {
		LOGGER.info("Help command executed.");
		System.out.print("EchoClient> ");

		switch (command) {
		case "connect":
			System.out.println("connect <host> <port>:   Establishes a TCP connection to the specified address. "
					+ "In case of success a confirmation is displayed.");
			break;
		case "disconnect":
			System.out.println(
					"disconnect:   Disconnects from a server. " + "In case of success a confirmation is displayed.");
			break;
		case "help":
			System.out.println("help:   Shows the intended usage of the client application and"
					+ " describes its set of commands.");
			System.out.println("help <command>:  Shows the application and the syntax of <command>.");
			break;
		case "logLevel":
			System.out.println("logLevel <level>:   Sets the logger to the specified log level. "
					+ "In case of success a confirmation is displayed.");
			break;
		case "quit":
			System.out.println(
					"quit:   Tears down the active connection to the server and" + " exits the program execution.");
			break;
		/*case "send":
			System.out.println(
					"send <message>:   Sends a text message to the echo server. " + "Recives the same message back.");
			break;*/
		default:
			System.out.println("Error! Command cannot be resolved.");
			System.out.println(
					"The echo client is used to connect to a key-value server. Please refer to the following available commands:");
			System.out.println("connect <host> <port>:   Establishes a TCP connection to the specified address.");
			System.out.println("disconnect:              Disconnects from a server.");
			System.out.println("help <command>:          Shows the application and the syntax of <command>.");
			System.out.println("logLevel <level>:        Sets the logger to the specified log level. ");
			System.out.println("quit:                    Tears down the active connection to the server.");
			// System.out.println("send <message>: Sends a text message to the echo server.
			// ");
			System.out.println(
					"put <key> <value>:       Inserts, updates or deletes a key a value pair in the storage server.");
			System.out
					.println("get <key>:               Retrieves the value for the given key from the storage server.");
			System.out.println();
			break;
		}
	}

	/**
	 * Sets the log level to level and prints out a confirmation message.
	 * 
	 * @param level: The new log level
	 */
	public void logLevel(String level) {
		Logger newLogger = LogManager.getLogManager().getLogger("");
		String prevLevel = Logger.getLogger("").getLevel().getName();

		// Set the log level
		switch (level) {
		case "ALL":
			newLogger.setLevel(Level.ALL);
			break;
		case "OFF":
			newLogger.setLevel(Level.OFF);
			break;
		case "SEVERE":
			newLogger.setLevel(Level.SEVERE);
			break;
		case "WARNING":
			newLogger.setLevel(Level.WARNING);
			break;
		case "INFO":
			newLogger.setLevel(Level.INFO);
			break;
		case "CONFIG":
			newLogger.setLevel(Level.CONFIG);
			break;
		case "FINE":
			newLogger.setLevel(Level.FINE);
			break;
		case "FINER":
			newLogger.setLevel(Level.FINER);
			break;
		case "FINEST":
			newLogger.setLevel(Level.FINEST);
			break;
		default:
			LOGGER.warning("Invalid level argument.");
			System.out.println("EchoClient> Error: " + level + " is not a valid log level.");
			return;
		}
		// Set up handler level
		for (Handler handler : newLogger.getHandlers()) {
			handler.setLevel(newLogger.getLevel());
		}

		System.out.println("EchoClient> loglevel set from " + prevLevel + " to " + level.toUpperCase());
	}

	/**
	 * Creates an output, when the command is undefined.
	 */
	public void miscellaneous() {
		LOGGER.info("Undefined command executed.");
		System.out.print("EchoClient> ");
		System.out.println("Error! Command cannot be resolved.");
		System.out.println(
				"The echo client is used to connect to a key-value server. Please refer to the following available commands:");
		System.out.println("connect <host> <port>:   Establishes a TCP connection to the specified address.");
		System.out.println("disconnect:              Disconnects from a server.");
		System.out.println("help <command>:          Shows the application and the syntax of <command>.");
		System.out.println("logLevel <level>:        Sets the logger to the specified log level. ");
		System.out.println("quit:                    Tears down the active connection to the server.");
		// System.out.println("send <message>: Sends a text message to the echo server.
		// ");
		System.out.println(
				"put <key> <value>:       Inserts, updates or deletes a key a value pair in the storage server.");
		System.out.println("get <key>:               Retrieves the value for the given key from the storage server.");
	}
}
