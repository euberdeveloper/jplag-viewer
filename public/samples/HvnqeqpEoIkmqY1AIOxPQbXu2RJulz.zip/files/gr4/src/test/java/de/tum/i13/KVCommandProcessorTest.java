package de.tum.i13;

import de.tum.i13.server.kv.KVCommandProcessor;
import de.tum.i13.server.kv.KVMessage;
import de.tum.i13.server.kv.KVMessageImpl;
import de.tum.i13.server.kv.KVStore;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.*;

public class KVCommandProcessorTest {
    private static KVCommandProcessor kvcp;

    @BeforeAll
    static void setUp() throws Exception  {
        KVStore kv = mock(KVStore.class);
        kvcp = new KVCommandProcessor(kv);

        when(kv.get("key")).thenReturn(new KVMessageImpl("key", "value", KVMessage.StatusType.GET_SUCCESS));
        when(kv.get("test")).thenReturn(new KVMessageImpl("test", "valuetest", KVMessage.StatusType.GET_SUCCESS));
        when(kv.get("noSuchKey")).thenReturn(new KVMessageImpl("noSuchKey", null, KVMessage.StatusType.GET_ERROR));

        when(kv.put("key", "value")).thenReturn(new KVMessageImpl("key", "value", KVMessage.StatusType.PUT_SUCCESS));
        when(kv.put("keyUpd", "valueUpd")).thenReturn(new KVMessageImpl("keyUpd", "valueUpd", KVMessage.StatusType.PUT_UPDATE));
        when(kv.put("keyErr", "valueErr")).thenReturn(new KVMessageImpl("keyErr", null, KVMessage.StatusType.PUT_ERROR));

        when(kv.delete("key")).thenReturn(new KVMessageImpl("key", "value", KVMessage.StatusType.DELETE_SUCCESS));
        when(kv.delete("noSuchKey")).thenReturn(new KVMessageImpl("noSuchKey", null, KVMessage.StatusType.GET_ERROR));
    }

    @Test
    public void testCorrectResponseCP() {
        assertEquals(kvcp.process("put key value"), "put_success key\r\n");
        assertEquals(kvcp.process("put keyUpd valueUpd"), "put_update keyUpd\r\n");
        assertEquals(kvcp.process("put keyErr valueErr"), "put_error keyErr null\r\n");

        assertEquals(kvcp.process("get key"), "get_success key value\r\n");
        assertEquals(kvcp.process("get test"), "get_success test valuetest\r\n");
        assertEquals(kvcp.process("get noSuchKey"), "get_error noSuchKey\r\n");

        assertEquals(kvcp.process("delete key"), "delete_success key\r\n");
        assertEquals(kvcp.process("delete noSuchKey"), "delete_error noSuchKey\r\n");
    }
}
