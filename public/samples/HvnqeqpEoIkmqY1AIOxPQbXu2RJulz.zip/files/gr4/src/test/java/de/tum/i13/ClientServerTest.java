package de.tum.i13;

import de.tum.i13.client.KVCommands;
import de.tum.i13.client.ServerConnector;
import de.tum.i13.server.threadperconnection.Main;
import org.junit.jupiter.api.*;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.PrintStream;

import static org.junit.jupiter.api.Assertions.*;

@TestMethodOrder(MethodOrderer.OrderAnnotation.class)
public class ClientServerTest {
	private static Integer port;
	private static KVCommands kvCommands;
	private static String response = "";

	private final String DELIMITER = "\r\n";
	private static final ByteArrayOutputStream outputStreamCaptor = new ByteArrayOutputStream();

	@BeforeAll
	public static void setUp() throws InterruptedException {
		port = 5154;
		Thread th = new Thread(() -> {
			Main.main(new String[] { "-p", port.toString() });
		});
		th.start(); // started server
		Thread.sleep(2000);

		kvCommands = new KVCommands();
		System.setOut(new PrintStream(outputStreamCaptor));
	}

	@Test
	@Order(1)
	public void testCorrectResponseCP() {
		kvCommands.connect("127.0.0.1", port);
		response += "EchoClient> Connection to persistent storage server established: /127.0.0.1:" + port + DELIMITER;
		assertEquals(response, outputStreamCaptor.toString());
	}

	@Test
	@Order(2)
	public void testOperations() {
		kvCommands.send(("put test:D§§§/&%ataK&1ey123%$ value" + DELIMITER));
		String out = outputStreamCaptor.toString();

		// if data was already written to database coincidentally
		if (out.contains("put_update"))
			response += "EchoClient> put_update test:D§§§/&%ataK&1ey123%$" + DELIMITER;
		else if (out.contains("put_success"))
			response += "EchoClient> put_success test:D§§§/&%ataK&1ey123%$" + DELIMITER;
		else
			fail();

		try {
			assertEquals(response, outputStreamCaptor.toString());
		} catch (AssertionError e) {
			response += "Unable to bind server socket\r\n";
			assertEquals(response, outputStreamCaptor.toString());
		}

		kvCommands.send(("delete test:D§§§/&%ataK&1ey123%$" + DELIMITER));
		response += "EchoClient> delete_success test:D§§§/&%ataK&1ey123%$" + DELIMITER;
		assertEquals(response, outputStreamCaptor.toString());

		kvCommands.send(("get test:D§§§/&%ataK&1ey123%$" + DELIMITER));
		response += "EchoClient> get_error test:D§§§/&%ataK&1ey123%$" + DELIMITER;
		assertEquals(response, outputStreamCaptor.toString());

		kvCommands.send(("put test:D§§§/&%ataK&1ey123%$ eins" + DELIMITER));
		String response2 = response + "EchoClient> put_update test:D§§§/&%ataK&1ey123%$" + DELIMITER;
		response += "EchoClient> put_success test:D§§§/&%ataK&1ey123%$" + DELIMITER;

		// again 2 possibilities: this data is new to database or was already updated by
		// another test
		if (response2.equals(outputStreamCaptor.toString())) {
			response = response2;
			assertTrue(true);
		} else if (response.equals(outputStreamCaptor.toString())) {
			assertTrue(true);
		} else {
			fail();
		}

		kvCommands.send(("get test:D§§§/&%ataK&1ey123%$" + DELIMITER));
		response += "EchoClient> get_success test:D§§§/&%ataK&1ey123%$ eins" + DELIMITER;
		assertEquals(response, outputStreamCaptor.toString());

		kvCommands.disconnect(); // disconnect
	}
}
