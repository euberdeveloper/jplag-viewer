package de.tum.i13;

import de.tum.i13.server.threadperconnection.Main;
import org.junit.jupiter.api.*;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.InetSocketAddress;
import java.net.Socket;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

/**
 * Here we test if server is responding in the right way to api calls. It is essential to test server because it is
 * one of the most important parts of our implementation. This test case describes the most common pattern of
 * server usage.
 *
 * First we test if connection was established and if the welcome message is send as response. Than we write, retrieve,
 * delete and overwrite some data into database. After this tests we test if our server still threading safe, by invoking multiple
 * socket connection and reading/writing data.
 *
 * There is check of put_success || put_update in some cases. It is not necessary, because test is meant to run just once.
 * But if we run test for several times and dont clean the database, than is cloud lead that data is already in database and we
 * need to check if it was put_update.
 *
 * */
@TestMethodOrder(MethodOrderer.OrderAnnotation.class)
public class ServerImplTest {
    private static Integer port;
    private static Socket s;

    @BeforeAll
    public static void setUp() throws IOException, InterruptedException {
        port = 5153;
        Thread th = new Thread(() -> {
            Main.main(new String[]{"-p", port.toString(), "-s", "LFU"});
        });
        th.start(); // started the server
        Thread.sleep(2000);

        s = new Socket();
        s.connect(new InetSocketAddress("127.0.0.1", port)); // connect but only after start of server
    }

    @Test
    @Order(1)
    public void testServerStartResponse() throws IOException {
        assertEquals(
                "Connection to persistent storage server established: /127.0.0.1:" + port,
                readFromLineInput(s)
        );
    }

    @Test
    @Order(2)
    public void testPutGetUpdate() throws IOException {
        String response = doRequest(s, "put tes:!§&(!\":1:t3 test33");
        assertTrue(response.equals("put_success tes:!§&(!\":1:t3") || response.equals("put_update tes:!§&(!\":1:t3"));

        assertEquals("get_success tes:!§&(!\":1:t3 test33", doRequest(s, "get tes:!§&(!\":1:t3"));

        assertEquals("put_update tes:!§&(!\":1:t3", doRequest(s, "put tes:!§&(!\":1:t3 newTest3Value"));
    }

    @Test
    @Order(3)
    public void testDel() throws IOException {
        // write data to database. If some tests have already written this key to database, then we have to test that
        // data was updated. Anyway for this test case we delete this data
        String initResponse = doRequest(s, "put testdel testdel");
        assertTrue(initResponse.equals("put_success testdel") || initResponse.equals("put_update testdel"));

        // test that data is actually written to database
        assertEquals("get_success testdel testdel", doRequest(s, "get testdel"));

        // test data is deleted
        assertEquals("delete_success testdel", doRequest(s, "delete testdel"));

        // test data is not in memory anymore
        assertEquals("get_error testdel", doRequest(s, "get testdel"));

        // write another data to database
        assertEquals("put_success testdel", doRequest(s, "put testdel testdel"));

        // update data in database
        assertEquals("put_update testdel", doRequest(s, "put testdel updt"));

        // test that data has new value
        assertEquals("get_success testdel updt", doRequest(s, "get testdel"));

        // delete data again
        assertEquals("delete_success testdel", doRequest(s, "delete testdel"));

        // test that we receive delete_error
        assertEquals("delete_error testdel", doRequest(s, "delete testdel"));
    }

    private String doRequest(Socket s, String req) throws IOException {
        PrintWriter output = new PrintWriter(s.getOutputStream());
        BufferedReader input = new BufferedReader(new InputStreamReader(s.getInputStream()));

        output.write(req + "\r\n");
        output.flush();

        return input.readLine();
    }

    private String readFromLineInput(Socket s) throws IOException {
        BufferedReader input = new BufferedReader(new InputStreamReader(s.getInputStream()));

        return input.readLine();
    }
}