package de.tum.i13;

import de.tum.i13.server.threadperconnection.Main;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.InetSocketAddress;
import java.net.Socket;
import java.util.ArrayList;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

/**
 * In this tests we test if our server still threading safe, by invoking multiple
 * socket connection and reading/writing data in our database. It is also one the most important tests, because it is
 * common way how database-server is gonna be used.
 * */
public class ServerMultipleClientsTest {
    private static Integer port;

    @BeforeAll
    public static void setUp() {
        port = 5153;
        Thread th = new Thread(() -> {
            Main.main(new String[]{"-p", port.toString(), "-s", "LRU"});
        });
        th.start(); // started the server
    }

    @Test
    public void testServerStartResponse() throws InterruptedException {
        ArrayList<Thread> threads = new ArrayList<>();
        int i;
        for(i = 0; i < 20; i++) {
            int finalI = i;
            Thread th = new Thread(() -> {
                try {
                    Socket s = new Socket();
                    s.connect(new InetSocketAddress("127.0.0.1", port));

                    String value = "test" + finalI;
                    String command = "put "+ value + " " + value;

                    String resp = readFromLineInput(s);

                    assertEquals("Connection to persistent storage server established: /127.0.0.1:" + port, resp);
                    assertTrue(doRequest(s, command).equals("put_success " + value) || doRequest(s, command).equals("put_update " + value));
                    s.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            });
            threads.add(th);
        }

        // start threads
        for(Thread th : threads) {
            th.start();
        }

        // wait for threads
        for(Thread th : threads) {
            th.join();
        }
    }

    @Test
    public void testCRUDWithThreading() throws InterruptedException {
        ArrayList<Thread> threads = new ArrayList<>();
        int i;
        for(i = 0; i < 20; i++) {
            int finalI = i;
            Thread th = new Thread(() -> {
                try {
                    Socket s = new Socket();
                    s.connect(new InetSocketAddress("127.0.0.1", port));

                    String value = "test" + finalI;
                    String put = "put "+ value + " " + value;
                    String get = "get " + value;

                    String resp = readFromLineInput(s);

                    assertEquals("Connection to persistent storage server established: /127.0.0.1:" + port, resp);
                    assertTrue(doRequest(s, put).equals("put_success " + value) || doRequest(s, put).equals("put_update " + value));
                    assertEquals("get_success " + value + " " + value, doRequest(s, get));
                    assertEquals("delete_success " + value, doRequest(s, "delete " + value));
                    assertEquals("delete_error " + value, doRequest(s, "delete " + value));
                    s.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            });
            threads.add(th);
        }

        // start threads
        for(Thread th : threads) {
            th.start();
        }

        // wait for threads
        for(Thread th : threads) {
            th.join();
        }
    }

    private String doRequest(Socket s, String req) throws IOException {
        PrintWriter output = new PrintWriter(s.getOutputStream());
        BufferedReader input = new BufferedReader(new InputStreamReader(s.getInputStream()));

        output.write(req + "\r\n");
        output.flush();

        return input.readLine();
    }

    private String readFromLineInput(Socket s) throws IOException {
        BufferedReader input = new BufferedReader(new InputStreamReader(s.getInputStream()));

        return input.readLine();
    }
}