package de.tum.i13;

import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;

import java.io.*;
import java.net.InetSocketAddress;
import java.net.Socket;

import static org.hamcrest.CoreMatchers.*;
import static org.hamcrest.MatcherAssert.assertThat;

public class KVIntegrationTest {

    public static Integer port = 5153;

    @BeforeAll
    static void setUp() throws InterruptedException {
        Thread th = new Thread() {
            @Override
            public void run() {
                de.tum.i13.server.threadperconnection.Main.main(new String[]{"-p", port.toString()});
            }
        };
        th.start(); // started the server
        Thread.sleep(2000);
    }

    public String doRequest(Socket s, String req) throws IOException {
        PrintWriter output = new PrintWriter(s.getOutputStream());
        BufferedReader input = new BufferedReader(new InputStreamReader(s.getInputStream()));

        output.write(req + "\r\n");
        output.flush();

        return input.readLine();
    }

    public String doRequest(String req) throws IOException {
        Socket s = new Socket();
        s.connect(new InetSocketAddress("127.0.0.1", port));
        String res = doRequest(s, req);
        s.close();

        return res;
    }

    @Test
    public void smokeTest() throws InterruptedException, IOException {
        Socket s = new Socket();
        s.connect(new InetSocketAddress("127.0.0.1", port));
        assertThat(
                readFromLineInput(s),
                is(equalTo("Connection to persistent storage server established: /127.0.0.1:5153"))
        );
        s.close();

    }

    @Test
    public void enjoyTheEcho() throws IOException, InterruptedException {
        for (int tcnt = 0; tcnt < 2; tcnt++){
            final int finalTcnt = tcnt;
            new Thread(){
                @Override
                public void run() {
                    try {
                        Thread.sleep(finalTcnt * 100);
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                    try {
                        for(int i = 0; i < 100; i++) {
                            Socket s = new Socket();
                            s.connect(new InetSocketAddress("127.0.0.1", port));
                            String command = "put key valuetest";
                            assertThat(
                                    readFromLineInput(s),
                                    is(equalTo("Connection to persistent storage server established: /127.0.0.1:5153"))
                            );

                            doRequest(command);
                            s.close();
                        }
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }
            }.start();
        }

        Thread.sleep(5000);
    }

    private String readFromLineInput(Socket s) throws IOException {
        BufferedReader input = new BufferedReader(new InputStreamReader(s.getInputStream()));

        return input.readLine();
    }
}
