package de.tum.i13;

import de.tum.i13.server.kv.KVCommandProcessor;
import de.tum.i13.server.kv.KVMessage;
import de.tum.i13.server.kv.KVMessage.StatusType;
import de.tum.i13.server.kv.KVMessageImpl;
import de.tum.i13.server.kv.KVStore;
import de.tum.i13.server.kv.KVStoreImpl;
import de.tum.i13.server.kv.caching.FIFO;

import org.junit.jupiter.api.Test;

import static org.mockito.Mockito.*;

public class TestKVCommandProcessor {

    @Test
    public void correctParsingOfPut() throws Exception {

        KVStore kv = mock(KVStore.class);
        KVCommandProcessor kvcp = new KVCommandProcessor(kv);
        
        KVMessage kvm=new KVMessageImpl();
        kvm.setKey("key");
        kvm.setStatus(StatusType.PUT_SUCCESS);
        when(kv.put("key", "hello")).thenReturn(kvm);
        
        kvcp.process("put key hello");
        verify(kv).put("key", "hello");
    }
    
    @Test
    public void correctParsingOfGet() throws Exception {

        KVStore kv = mock(KVStore.class);
        KVCommandProcessor kvcp = new KVCommandProcessor(kv);
        
        KVMessage kvm=new KVMessageImpl();
        kvm.setKey("key");
        kvm.setStatus(StatusType.GET_SUCCESS);
        when(kv.get("key")).thenReturn(kvm);
        
        kvcp.process("get key");
        verify(kv).get("key");
    }
    
    @Test
    public void correctParsingOfDelete() throws Exception {

        KVStore kv = mock(KVStore.class);
        KVCommandProcessor kvcp = new KVCommandProcessor(kv);
        
        KVMessage kvm=new KVMessageImpl();
        kvm.setKey("key");
        kvm.setStatus(StatusType.DELETE_SUCCESS);
        when(kv.delete("key")).thenReturn(kvm);
        
        kvcp.process("put key");
        verify(kv).delete("key");
    }

}
