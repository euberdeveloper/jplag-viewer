package de.tum.i13;

import static org.junit.jupiter.api.Assertions.*;

import java.nio.file.Paths;

import org.junit.jupiter.api.Test;

import de.tum.i13.server.kv.caching.FIFO;
import de.tum.i13.server.kv.caching.LFU;
import de.tum.i13.server.kv.caching.LRU;

class SortingTest {
	

	@Test
	public void testFIFO() {
		FIFO test = new FIFO(5,Paths.get("data\\kvStorage.txt"));
		test.add("1", "a");
		test.add("2", "b");
		test.add("3", "c");
		assertEquals("1: a  2: b  3: c  ",test.toString());

		test.add("4", "d");
		test.add("5", "e");
		test.add("6", "f");
		test.add("7", "g");
		assertEquals("3: c  4: d  5: e  6: f  7: g  ",test.toString());

		assertEquals(test.get("5"), "e");
		test.remove("5");
		assertEquals(test.get("5"), null);

		assertEquals( "3: c  4: d  6: f  7: g  ",test.toString());
	}

/*	@Test
	public void testLFU() {
		LFU test = new LFU(5,Paths.get("data\\TestDir"));
		test.add("1", "a");
		test.add("2", "b");
		test.add("3", "c");
		test.get("2");
		test.get("2");
		test.get("2");
		test.get("3");
		assertEquals( 
				"Count: 3  2  b\n" + 
				"Count: 1  3  c\n" + 
				"Count: 0  1  a\n",test.toString());
		test.add("4", "d");
		test.add("5", "e");
		test.get("5");
		assertEquals(
				"Count: 3  2  b\n"+
				"Count: 1  5  e\n"+
				"Count: 1  3  c\n"+
				"Count: 0  1  a\n"+
				"Count: 0  4  d\n",test.toString());
		test.get("5");
		test.add("6", "f");		//1 a should be deleted
		test.add("6", "f");
		test.add("6", "f");

		assertEquals( 
				"Count: 3  2  b\n" + 
				"Count: 2  5  e\n" + 
				"Count: 1  3  c\n" + 
				"Count: 0  1  a\n" + 
				"Count: 0  6  f\n",test.toString());
	}*/
	
	@Test
	public void testLRU() {
        LRU  test = new LRU(5,Paths.get("data\\TestDir"));
        test.add("1", "llo");
        test.add("2", "he");
        test.add("3", "bye");
        assertEquals("1: llo  2: he  3: bye  ",test.toString());
        test.get("1");
        assertEquals("2: he  3: bye  1: llo  ",test.toString());
        test.add("4", "bye");
        test.add("5", "bye");
        test.add("6", "bye");
        test.add("7", "he");
        assertEquals("1: llo  4: bye  5: bye  6: bye  7: he  ",test.toString());
        test.remove("6");
		assertEquals("1: llo  4: bye  5: bye  7: he  ",test.toString());
    }

}