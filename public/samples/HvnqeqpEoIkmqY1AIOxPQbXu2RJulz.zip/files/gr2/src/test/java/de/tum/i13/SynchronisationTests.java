package de.tum.i13;


import de.tum.i13.server.threadperconnection.Main;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.io.*;
import java.net.InetSocketAddress;
import java.net.Socket;

import static org.hamcrest.CoreMatchers.*;
import static org.hamcrest.MatcherAssert.assertThat;

public class SynchronisationTests {

    public static Integer port = 5153;

    public String doRequest(Socket s, String req) throws IOException {
        PrintWriter output = new PrintWriter(s.getOutputStream());
        BufferedReader input = new BufferedReader(new InputStreamReader(s.getInputStream()));
        System.out.println("From Server > "+input.readLine());
        output.write(req + "\r\n");
        output.flush();

        String res = input.readLine();
        return res;
    }

    public String doRequest(String req) throws IOException {
        Socket s = new Socket();
        s.connect(new InetSocketAddress("127.0.0.1", port));
        String res = doRequest(s, req);
        s.close();

        return res;
    }

    public String [] doRequest(Socket []s, String []req) throws IOException {
        String res []= new String[s.length];
        PrintWriter [] out =  new PrintWriter[s.length];
        BufferedReader []in = new BufferedReader[s.length];
        for (int i = 0; i < s.length; i++){
            out[i] = new PrintWriter(s[i].getOutputStream());
            in [i] = new BufferedReader(new InputStreamReader(s[i].getInputStream()));
            System.out.println("From Server > "+in[i].readLine());
        }

        for (int i = 0; i < s.length; i++){
            out[i].write(req[i] + "\r\n");
            out[i].flush();
        }
        for (int i = 0; i < s.length; i++){
            res [i]= in[i].readLine();
        }
        for (int i = 0; i < s.length; i++){
            in[i].close();
            out[i].close();
            s[i].close();
        }
        return res;
    }

    public void activate(Socket[] sockets) throws IOException {
        PrintWriter[] printWriters = new PrintWriter[sockets.length];
        BufferedReader[] bufferedReaders = new BufferedReader[sockets.length];
        for (int i= 0; i < sockets.length; i++){
            printWriters[i] = new PrintWriter(sockets[i].getOutputStream());
            bufferedReaders[i] = new BufferedReader(new InputStreamReader(sockets[i].getInputStream()));
        }
    }

    /**
     * Creates and initialises a kvStorage Server which  will be used in the following testcases
     * The server will have a cache of size 3, all other parameters are the default value.
     */
    @BeforeAll
    public static void initialiseServer()   {
        System.out.println("Initialising Database-Server started.");

        Thread th = new Thread(() -> {
            try {
                Main.main(new String[]{"-p", port.toString(),"-d","data/TestDir"});
            } catch (IOException e) {
                e.printStackTrace();
            }
        });
        th.start(); // started the server

    }



    /**
     * Initialises th database to insure equal conditions for every new Test Run.
     */
    @BeforeEach
    public void initialiseDatabase() throws IOException {
        System.out.println("Initialising Database started.");


        Socket s = new Socket();
        s.connect(new InetSocketAddress("127.0.0.1", port));


        //delete all inserted key-Value-Pairs
        for (int i = 0; i < 5; i++) {
            doRequest("put syncTest"+i);
        }
        //doRequest("put NonExistentKey1");
        //doRequest("put NonExistentKey2");

        s.close();
        System.out.println("Initialising Database finished. The test is going to run: ");
        port = 5153;
    }


    @Test
    public void syncTest() throws IOException{
        String [] command = {"put syncTest1 def", "put  ", "put syncTest2 hallo", "put syncTest3 oldValue","put syncTest3 neu", "put syncTest4 neu2"};
        String [] res = {"put_success syncTest1", "put_error ", "put_success syncTest2","put_success syncTest3", "put_update syncTest3", "put_success syncTest4"};

        initialiseDatabase();
        Socket[]sockets = new Socket[command.length];
        for (int i = 0; i < command.length; i++){
            sockets[i] = new Socket();
            sockets[i].connect(new InetSocketAddress("127.0.0.1", port));
        }
        activate(sockets);


        assertThat(doRequest(sockets, command), is(equalTo(res)));

    }


    @Test
    public void extendendSyncTest() throws IOException{
        doRequest("delete syncTest0");
        String [] command = {"put syncTest0 def",
                "put syncTest0 defNew",
                "put syncTest0 defNewer",
                "put syncTest0 defNewest",
                "put syncTest0 defalsoquiteNew",
                "put syncTest0 defquiteNewest"
        };
        String [] res = {"put_success syncTest0",
                "put_update syncTest0",
                "put_update syncTest0",
                "put_update syncTest0",
                "put_update syncTest0",
                "put_update syncTest0",

        };

        initialiseDatabase();
        Socket[]sockets = new Socket[command.length];
        for (int i = 0; i < command.length; i++){
            sockets[i] = new Socket();
            sockets[i].connect(new InetSocketAddress("127.0.0.1", port));
        }
        activate(sockets);


        assertThat(doRequest(sockets, command), is(equalTo(res)));
    }


}
