package de.tum.i13;


import de.tum.i13.shared.Config;
import org.junit.jupiter.api.Test;

import static de.tum.i13.shared.Config.parseCommandlineArgs;
import static org.junit.jupiter.api.Assertions.assertEquals;

import java.net.InetSocketAddress;
import java.nio.file.Paths;



public class CommandTests {

    /**
     * Tests if all default parameters are correct
     */
    @Test
    public void cfgDefaultTest(){
        Config cfg = parseCommandlineArgs(new String[]{});
        assertEquals( 5153,cfg.port);
        assertEquals( "127.0.0.1",cfg.listenaddr);
        assertEquals( InetSocketAddress.createUnresolved("clouddatabases.i13.in.tum.de",5153), cfg.bootstrap);
        assertEquals(Paths.get("data/"),cfg.dataDir);
        assertEquals( Paths.get("echo.log"), cfg.logfile);
        assertEquals( "ALL",cfg.logLevel);
        assertEquals( 1024, cfg.cacheSize);
        assertEquals( "DEFAULTFIFO",cfg.cacheStrategy);
        assertEquals( false,cfg.usagehelp);
    }

    /**
     * Tests whether a custom value can be assigned with the -p commandline parameter
     */
    @Test
    public void cfgMinusPTest(){
        Config cfg = parseCommandlineArgs(new String[]{"-p","8000"});
        assertEquals( 8000,cfg.port);
    }

    /**
     * Tests whether a custom value can be assigned with the -a commandline parameter
     */
    @Test
    public void cfgMinusATest(){
        Config cfg = parseCommandlineArgs(new String[]{"-a","192.168.0.1"});
        assertEquals( "192.168.0.1",cfg.listenaddr);
    }



    /**
     * Tests whether a custom value can be assigned with the -d commandline parameter
     */
    @Test
    public void cfgMinusDTest(){
        Config cfg = parseCommandlineArgs(new String[]{"-d","data/testFile.txt"});
        assertEquals( Paths.get("data/testFile.txt"),cfg.dataDir);
    }



    /**
     * Tests whether a custom value can be assigned with the -l commandline parameter
     */
    @Test
    public void cfgMinusLTest(){
        Config cfg = parseCommandlineArgs(new String[]{"-l","data/testFile.txt"});
        assertEquals( Paths.get("data/testFile.txt"),cfg.logfile);
    }

    /**
     * Tests whether a custom value can be assigned with the -ll commandline parameter
     */
    @Test
    public void cfgMinusLLTest(){
        Config cfg = parseCommandlineArgs(new String[]{"-ll","FINEST"});
        assertEquals( "FINEST",cfg.logLevel);
    }

    /**
     * Tests whether a custom value can be assigned with the -c commandline parameter
     */
    @Test
    public void cfgMinusCTest(){
        Config cfg = parseCommandlineArgs(new String[]{"-c","2048"});
        assertEquals( 2048,cfg.cacheSize);
    }

    /**
     * Tests whether a custom value can be assigned with the -s commandline parameter
     */
    @Test
    public void cfgMinusSTest(){
        Config cfg = parseCommandlineArgs(new String[]{"-s","LRU"});
        assertEquals( "LRU",cfg.cacheStrategy);
    }


    /**
     * Tests whether true can be assigned with the -h commandline parameter
     */
    @Test
    public void cfgMinusHTestTrue(){
        Config cfg = parseCommandlineArgs(new String[]{"-h"});
        assertEquals( true,cfg.usagehelp);
    }
}