package de.tum.i13;


import de.tum.i13.server.threadperconnection.Main;

import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.io.*;
import java.net.InetSocketAddress;
import java.net.Socket;

import static org.hamcrest.CoreMatchers.*;
import static org.hamcrest.MatcherAssert.assertThat;



public class KVIntegrationTestLFU {

    public static Integer port = 5153;

    public String doRequest(Socket s, String req) throws IOException {
        PrintWriter output = new PrintWriter(s.getOutputStream());
        BufferedReader input = new BufferedReader(new InputStreamReader(s.getInputStream()));
        input.readLine();
        output.write(req + "\r\n");
        output.flush();

        String res = input.readLine();
        return res;
    }

    public String doRequest(String req) throws IOException {
        Socket s = new Socket();
        s.connect(new InetSocketAddress("127.0.0.1", port));
        String res = doRequest(s, req);
        s.close();

        return res;
    }

    /**
     * Creates and initialises a kvStorage Server which  will be used in the following testcases
     * The server will have a cache of size 3, all other parameters are the default value.
     */
    @BeforeAll
    public static void initialiseServer()   {
        System.out.println("Initialising Database-Server started.");

        Thread th = new Thread(() -> {
            try {
                Main.main(new String[]{"-p", port.toString(), "-c","3","-d","data/TestDir","-s","LFU"});
            } catch (IOException e) {
                e.printStackTrace();
            }
        });
        th.start(); // started the server

    }



    /**
     * Initialises the database to insure equal conditions for every new Test Run.
     * Every test can run independently with consistent output.
     */
    @BeforeEach
    public void initialiseDatabase() throws IOException {
        System.out.println("Initialising Database started.");


        Socket s = new Socket();
        s.connect(new InetSocketAddress("127.0.0.1", port));


        //delete all inserted key-Value-Pairs
        for (int i = 0; i < 10; i++) {
            doRequest("put KVIntegrationTest"+i);
        }
        doRequest("put NonExistentKey1");
        doRequest("put NonExistentKey2");
        doRequest("delete apple123@#");
        s.close();
        System.out.println("Initialising Database finished. The test is going to run: ");
        port = 5153;
    }




    /**
     * Simple Test for the basic functionality of the KV Server
     * 6 Key-Value Pairs get stored and afterwards fetched.
     * @throws IOException
     */
    @Test
    public void simplePutGetTest() throws IOException {

        Socket s = new Socket();
        s.connect(new InetSocketAddress("127.0.0.1", port));


        assertThat(doRequest("put KVIntegrationTest4 Hello"), is(equalTo("put_success KVIntegrationTest4")));
        assertThat(doRequest("put KVIntegrationTest5 Hello"), is(equalTo("put_success KVIntegrationTest5")));
        assertThat(doRequest("put KVIntegrationTest6 Hello"), is(equalTo("put_success KVIntegrationTest6")));
        assertThat(doRequest("put KVIntegrationTest7 Hello"), is(equalTo("put_success KVIntegrationTest7")));
        assertThat(doRequest("put KVIntegrationTest8 Hello"), is(equalTo("put_success KVIntegrationTest8")));
        assertThat(doRequest("put KVIntegrationTest9 Hello"), is(equalTo("put_success KVIntegrationTest9")));
        assertThat(doRequest("get KVIntegrationTest4"), is(equalTo("get_success KVIntegrationTest4 Hello")));
        assertThat(doRequest("get KVIntegrationTest5"), is(equalTo("get_success KVIntegrationTest5 Hello")));
        assertThat(doRequest("get KVIntegrationTest6"), is(equalTo("get_success KVIntegrationTest6 Hello")));
        assertThat(doRequest("get KVIntegrationTest7"), is(equalTo("get_success KVIntegrationTest7 Hello")));
        assertThat(doRequest("get KVIntegrationTest8"), is(equalTo("get_success KVIntegrationTest8 Hello")));
        assertThat(doRequest("get KVIntegrationTest9"), is(equalTo("get_success KVIntegrationTest9 Hello")));

        s.close();
    }


    /**
     * tests whether an Key value Pair is correctly updated when the put command is called twice with the same key.
     */
    @Test
    public void updatePutUpdateTest() throws IOException {
        Socket s = new Socket();
        s.connect(new InetSocketAddress("127.0.0.1", port));

        assertThat(doRequest("put KVIntegrationTest1 Hello"), is(equalTo("put_success KVIntegrationTest1")));
        assertThat(doRequest("get KVIntegrationTest1"), is(equalTo("get_success KVIntegrationTest1 Hello")));
        assertThat(doRequest("put KVIntegrationTest1 newValue for the key KVIntegrationTest1"), is(equalTo("put_update KVIntegrationTest1")));
        assertThat(doRequest("get KVIntegrationTest1"), is(equalTo("get_success KVIntegrationTest1 newValue for the key KVIntegrationTest1")));

        s.close();
    }

    /**
     * Tests different edge cases with the commands put and get.
     */
    @Test
    public void edgeCasePutGetTest() throws IOException {

        Socket s = new Socket();
        s.connect(new InetSocketAddress("127.0.0.1", port));


        assertThat(doRequest("get   apple123@#"), is(equalTo("get_error ")));
        assertThat(doRequest("get  apple123@#  "), is(equalTo("get_error ")));
        assertThat(doRequest("get apple123@#  "), is(equalTo("get_error apple123@#")));
        assertThat(doRequest("get apple123@# "), is(equalTo("get_error apple123@#")));
        assertThat(doRequest("get apple123@#"), is(equalTo("get_error apple123@#")));

        //space as value inserted
        assertThat(doRequest("put KVIntegrationTest1  "), is(equalTo("put_success KVIntegrationTest1")));
        //space as key
        assertThat(doRequest("put   Hello"), is(equalTo("put_error ")));
        //no key (double space after "put")
        assertThat(doRequest("put  Hello"), is(equalTo("put_error ")));
        //Value with spaces
        assertThat(doRequest("put KVIntegrationTest2 Longer value with spaces."), is(equalTo("put_success KVIntegrationTest2")));

        //Nothing after the put command
        assertThat(doRequest("get apple123@#      "), is(equalTo("get_error apple123@#")));
        //Nothing after the put command
        assertThat(doRequest("get"), is(equalTo("get_error ")));
        //No key inserted
        assertThat(doRequest("get "), is(equalTo("get_error ")));
        //space as key
        assertThat(doRequest("get  "), is(equalTo("get_error ")));
        //key with spaces
        assertThat(doRequest("get Key with spaces."), is(equalTo("get_error Key")));
        //key with spaces
        assertThat(doRequest("get KVIntegrationTestLongerthan20charkey"), is(equalTo("get_error ")));
        //get non existent key
        assertThat(doRequest("get NonExistentKey"), is(equalTo("get_error NonExistentKey")));

        //Delete Test
        doRequest("put KVIntegrationTest0 value");
        doRequest("put KVIntegrationTest1 value");
        //No value inserted (one space)-> should delete the key-Value-Pair
        assertThat(doRequest("put KVIntegrationTest0 "), is(equalTo("delete_success KVIntegrationTest0")));
        //No value inserted (no space)-> should delete the key-Value-Pair
        assertThat(doRequest("put KVIntegrationTest1"), is(equalTo("delete_success KVIntegrationTest1")));
        //get non existent key (no space)
        assertThat(doRequest("put NonExistentKey1"), is(equalTo("delete_error NonExistentKey1")));
        //get non existent key (one space)
        assertThat(doRequest("put NonExistentKey2 "), is(equalTo("delete_error NonExistentKey2")));
        //key with spaces
        assertThat(doRequest("put KVIntegrationTestLongerthan20charkey"), is(equalTo("put_error ")));

        s.close();
    }

    /**
     * Ensures the functionality of the basic commands put, get and delete with 6 different basic key-Value-Pairs
     */
    @Test
    public void simplePutDeleteTest() throws IOException {

        Socket s = new Socket();
        s.connect(new InetSocketAddress("127.0.0.1", port));

        //insert basic Key-Value-Pairs
        assertThat(doRequest("put KVIntegrationTest4 Hello"), is(equalTo("put_success KVIntegrationTest4")));
        assertThat(doRequest("put KVIntegrationTest5 Hello"), is(equalTo("put_success KVIntegrationTest5")));
        assertThat(doRequest("put KVIntegrationTest6 Hello"), is(equalTo("put_success KVIntegrationTest6")));
        assertThat(doRequest("put KVIntegrationTest7 Hello"), is(equalTo("put_success KVIntegrationTest7")));
        assertThat(doRequest("put KVIntegrationTest8 Hello"), is(equalTo("put_success KVIntegrationTest8")));
        assertThat(doRequest("put KVIntegrationTest9 Hello"), is(equalTo("put_success KVIntegrationTest9")));



        //get Every inserted key-Value-Pair
        assertThat(doRequest("get KVIntegrationTest4"), is(equalTo("get_success KVIntegrationTest4 Hello")));
        assertThat(doRequest("get KVIntegrationTest5"), is(equalTo("get_success KVIntegrationTest5 Hello")));
        assertThat(doRequest("get KVIntegrationTest6"), is(equalTo("get_success KVIntegrationTest6 Hello")));
        assertThat(doRequest("get KVIntegrationTest7"), is(equalTo("get_success KVIntegrationTest7 Hello")));
        assertThat(doRequest("get KVIntegrationTest8"), is(equalTo("get_success KVIntegrationTest8 Hello")));
        assertThat(doRequest("get KVIntegrationTest9"), is(equalTo("get_success KVIntegrationTest9 Hello")));


        //update Value not in cache
        assertThat(doRequest("put KVIntegrationTest9 newValue for the Key-Value-Pair"), is(equalTo("put_update KVIntegrationTest9")));
        //updates the key value pairs with a new Value
        assertThat(doRequest("put KVIntegrationTest4 newValue for the Key-Value-Pair"), is(equalTo("put_update KVIntegrationTest4")));
        assertThat(doRequest("put KVIntegrationTest5 newValue for the Key-Value-Pair"), is(equalTo("put_update KVIntegrationTest5")));
        assertThat(doRequest("put KVIntegrationTest6 newValue for the Key-Value-Pair"), is(equalTo("put_update KVIntegrationTest6")));
        assertThat(doRequest("put KVIntegrationTest7 newValue for the Key-Value-Pair"), is(equalTo("put_update KVIntegrationTest7")));
        assertThat(doRequest("put KVIntegrationTest8 newValue for the Key-Value-Pair"), is(equalTo("put_update KVIntegrationTest8")));


        //try to delete Every inserted key-Value-Pair to check if they were actually deleted
        assertThat(doRequest("put KVIntegrationTest4"), is(equalTo("delete_success KVIntegrationTest4")));
        assertThat(doRequest("put KVIntegrationTest5"), is(equalTo("delete_success KVIntegrationTest5")));
        assertThat(doRequest("put KVIntegrationTest6"), is(equalTo("delete_success KVIntegrationTest6")));
        assertThat(doRequest("put KVIntegrationTest7"), is(equalTo("delete_success KVIntegrationTest7")));
        assertThat(doRequest("put KVIntegrationTest8"), is(equalTo("delete_success KVIntegrationTest8")));
        assertThat(doRequest("put KVIntegrationTest9"), is(equalTo("delete_success KVIntegrationTest9")));

        ///get Every inserted key-Value-Pair after it was deleted
        assertThat(doRequest("get KVIntegrationTest4"), is(equalTo("get_error KVIntegrationTest4")));
        assertThat(doRequest("get KVIntegrationTest5"), is(equalTo("get_error KVIntegrationTest5")));
        assertThat(doRequest("get KVIntegrationTest6"), is(equalTo("get_error KVIntegrationTest6")));
        assertThat(doRequest("get KVIntegrationTest7"), is(equalTo("get_error KVIntegrationTest7")));
        assertThat(doRequest("get KVIntegrationTest8"), is(equalTo("get_error KVIntegrationTest8")));
        assertThat(doRequest("get KVIntegrationTest9"), is(equalTo("get_error KVIntegrationTest9")));

        s.close();
    }



    /**
     * Ensures that elements can be deleted no mater if they are stored in the cache, the storage itself or both.
     */
    @Test
    public void deleteCacheStorageTest() throws IOException {

        Socket s = new Socket();
        s.connect(new InetSocketAddress("127.0.0.1", port));

        //Warning: cache has Size of 3!
        //insert basic Key-Value-Pairs
        assertThat(doRequest("put KVIntegrationTest3 Hello"), is(equalTo("put_success KVIntegrationTest3")));
        assertThat(doRequest("put KVIntegrationTest4 Hello"), is(equalTo("put_success KVIntegrationTest4")));
        assertThat(doRequest("put KVIntegrationTest5 Hello"), is(equalTo("put_success KVIntegrationTest5")));
        assertThat(doRequest("put KVIntegrationTest6 Hello"), is(equalTo("put_success KVIntegrationTest6")));
        assertThat(doRequest("put KVIntegrationTest7 Hello"), is(equalTo("put_success KVIntegrationTest7")));
        assertThat(doRequest("put KVIntegrationTest8 Hello"), is(equalTo("put_success KVIntegrationTest8")));


        //Element is only stored in the cache
        assertThat(doRequest("put KVIntegrationTest8"), is(equalTo("delete_success KVIntegrationTest8")));
        //Element is not stored in the cache
        assertThat(doRequest("put KVIntegrationTest3 "), is(equalTo("delete_success KVIntegrationTest3")));
        //element is stored in the cache and the file
        doRequest("get KVIntegrationTest4");
        assertThat(doRequest("put KVIntegrationTest4 "), is(equalTo("delete_success KVIntegrationTest4")));

        //ensure that pairs are deleted:
        assertThat(doRequest("get KVIntegrationTest3"), is(equalTo("get_error KVIntegrationTest3")));
        assertThat(doRequest("get KVIntegrationTest8"), is(equalTo("get_error KVIntegrationTest8")));
        assertThat(doRequest("get KVIntegrationTest4"), is(equalTo("get_error KVIntegrationTest4")));
        s.close();
    }


    /**
     * Ensures that elements can be deleted no mater if they are stored in the cache, the storage itself or both.
     */
    @Test
    public void getCacheStorageTest() throws IOException {

        Socket s = new Socket();
        s.connect(new InetSocketAddress("127.0.0.1", port));

        //Warning: cache has Size of 3!
        //insert basic Key-Value-Pairs
        assertThat(doRequest("put KVIntegrationTest3 Hello"), is(equalTo("put_success KVIntegrationTest3")));
        assertThat(doRequest("put KVIntegrationTest4 Hello"), is(equalTo("put_success KVIntegrationTest4")));
        assertThat(doRequest("put KVIntegrationTest5 Hello"), is(equalTo("put_success KVIntegrationTest5")));
        assertThat(doRequest("put KVIntegrationTest6 Hello"), is(equalTo("put_success KVIntegrationTest6")));
        assertThat(doRequest("put KVIntegrationTest7 Hello"), is(equalTo("put_success KVIntegrationTest7")));
        assertThat(doRequest("put KVIntegrationTest8 Hello"), is(equalTo("put_success KVIntegrationTest8")));


        //Element is only stored in the cache
        assertThat(doRequest("get KVIntegrationTest8"), is(equalTo("get_success KVIntegrationTest8 Hello")));
        //Element is not stored in the cache
        assertThat(doRequest("get KVIntegrationTest3 "), is(equalTo("get_success KVIntegrationTest3 Hello")));
        //element is stored in the cache and the file
        doRequest("get KVIntegrationTest4");
        assertThat(doRequest("get KVIntegrationTest4 "), is(equalTo("get_success KVIntegrationTest4 Hello")));

        s.close();
    }
}

