package de.tum.i13.server.kv.caching;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.nio.file.Path;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Scanner;
import java.util.logging.LogManager;
import java.util.logging.Logger;

/**
 * uses functionalities of LinkedHashMap (which is an ordered HashMap)
 */
public class FIFO implements SortingStrategie {

	private final int maxCacheSize;
	private File file;
	private Logger logger;

	LinkedHashMap<String, String> map;

	public FIFO(int cacheSize, Path dirPath) {
		maxCacheSize = cacheSize;
		logger = LogManager.getLogManager().getLogger("");

		file = new File(dirPath + "\\kvStorage.txt");
		if (!file.exists() || file.isDirectory()) {
			try {
				file.createNewFile();
			} catch (IOException e) {
				logger.log(logger.getLevel(), "FIFO, File_ERROR" + dirPath + "kvStorage");
				e.printStackTrace();
			}
			logger.log(logger.getLevel(), "New File created: " + dirPath + "kvStorage");
		} else {
			logger.log(logger.getLevel(), "File already exists");
		}

		map = new LinkedHashMap<String, String>(maxCacheSize) {

			/**
			 * removes oldest entry if map bigger than maxCacheSize (Returns true than)
			 * 
			 * @param eldest
			 * @return boolean
			 */
			@Override
			protected boolean removeEldestEntry(Map.Entry<String, String> eldest) {
				if (size() > maxCacheSize) {
					try {
						if (getInStore(eldest.getKey()) != null) {
							deleteInStore(eldest.getKey());
						}
						putInStore(eldest.getKey(), eldest.getValue());
					} catch (Exception e) {
						e.printStackTrace();
					}
					return true;
				}
				return false;
			}

			public synchronized void putInStore(String key, String value) throws Exception {
				BufferedWriter writer = new BufferedWriter(new FileWriter(file, true));
				writer.append(key + " " + value + " <EndOfValue> ");
				writer.flush();
				writer.close();
			}

			public synchronized String getInStore(String key) throws Exception {
				String in = fileToString();
				String[] split = in.split(" <EndOfValue> ");

				if (in.length() != 0)
					for (int i = 0; i < split.length; i++)
						if (split[i].substring(0, split[i].indexOf(" ")).equals(key))
							return split[i].substring(split[i].indexOf(" ") + 1, split[i].length());

				return null;

			}

			public synchronized void deleteInStore(String key) throws Exception {
				String result = fileToString().replaceAll(key + " " + getInStore(key) + " <EndOfValue> ", "");
				BufferedWriter writer = new BufferedWriter(new FileWriter(file));
				writer.append(result);
				writer.flush();
				writer.close();
			}

			public synchronized String fileToString() throws Exception {
				String input = null;
				Scanner sc = new Scanner(file);
				StringBuffer sb = new StringBuffer();
				while (sc.hasNextLine()) {
					input = sc.nextLine();
					sb.append(input);
				}
				return sb.toString();
			}

		};
	}

	@Override
	public synchronized void remove(String key) {
		map.remove(key);
	}

	@Override
	public synchronized LinkedHashMap<String, String> maintainList() {
		return map;
	}

	@Override
	public synchronized void add(String key, String value) {
		map.put(key, value);
	}

	@Override
	public synchronized String get(String key) {
		return map.get(key);
	}

	@Override
	public String toString() {
		StringBuilder stringBuilder = new StringBuilder();
		for (Map.Entry<String, String> entry : map.entrySet()) {
			stringBuilder.append(String.format("%s: %s  ", entry.getKey(), entry.getValue()));
		}
		return stringBuilder.toString();
	}


}
