package de.tum.i13.server.kv;

import de.tum.i13.shared.CommandProcessor;
import de.tum.i13.shared.LogSetup;

import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.LogManager;
import java.util.logging.Logger;

import static de.tum.i13.shared.Constants.HELP_MESSAGE;
import static de.tum.i13.shared.Constants.extended_HELP_MESSAGE;

public class KVCommandProcessor implements CommandProcessor {
    private final Logger logger;
    private KVStore kvStore;
    private int connectedClients;

    /**
     * KVCommandProcessor is the bridge between the Client communication and the actual Storage Module.
     *
     * @param kvStore The KVStore instance which is used by the server -> same Instance for every Client.
     */
    public KVCommandProcessor(KVStore kvStore) {
        this.kvStore = kvStore;
        logger = LogManager.getLogManager().getLogger("");      //Include this line in every class to enable Logging
        connectedClients = 0;
    }

    /**
     * Command gets analyzed and the corresponding methods to execute the command will be called.
     *
     * @param line Whole command which was send by the client
     * @return A String containing the answer for the client. Doesn't need to be changed, can be send.
     */
    @Override
    public String process(String line) {
        String[] command = line.split(" ");
        String retValue = testInput(line, command);

        if (retValue != null)
            return retValue;

        switch (command[0]) {
            case "put":
                if (command.length == 2 && (line.charAt(line.length() - 2) != ' ' || line.charAt(line.length() - 1) != ' '))  //Min 2 spaces -> Spaces must bes saved as the Value
                {
                    retValue = deleteInit(command);
                } else if (command.length >= 2) {
                    retValue = putInit(command, line);
                } else {
                    retValue = "put_error ";
                }
                break;
            case "get":
                retValue = getInit(command);
                break;
            case "delete":
                retValue = deleteInit(command);
                break;
            default:
                logger.log(logger.getLevel(), "Error: Unknown command: " + command[0] + " in the input: " + line);
                return "Unknown command; " +HELP_MESSAGE;
        }
        logger.log(logger.getLevel(), retValue);
        return retValue;
    }

    /**
     * Tests whether the input has the correct format:
     * Key without spaces
     * key with max. 20 chars
     *
     * @param line    The input which was received from the client
     * @param command The input from the client, separated at spaces.
     * @return null if String is in the correct format, otherwise the answer for the client
     */
    private String testInput(String line, String[] command) {
        if (line.indexOf("  ") == command[0].length() || command.length <= 1)//no key was entered -> return an error message
        {
            logger.log(logger.getLevel(), "Key contained spaces.");
            if (command[0].equals("put"))
                return "put_error ";
            else if (command[0].equals("get"))
                return "get_error ";
            else
                return "key_error";
        }
        if (command.length >= 2 && command[1].length() > 20) {
            logger.log(logger.getLevel(), "Key is too long: max 20Bytes.");
            if (command[0].equals("put"))
                return "put_error ";
            else if (command[0].equals("get"))
                return "get_error ";
            else
                return "key_error";
        }
        return null;
    }


    /**
     * decluters the methode "process()" and delegates a put command to the KVStore and selects the correct response
     *
     * @param command String, which was entered in order to insert or update the Key-Value pair.
     * @param line    Entered command String from the user
     * @return String consisting of the statusMessage and the <key> and in case of an error also the value
     */
    private String putInit(String[] command, String line) {
        try {
            String data = line.substring(line.indexOf(" ", line.indexOf(" ") + 1) + 1);
            KVMessage myMessage = kvStore.put(command[1], data);
            if (myMessage.getStatus().equals(KVMessage.StatusType.PUT_SUCCESS)) {
                return "put_success " + command[1];
            } else if (myMessage.getStatus().equals(KVMessage.StatusType.PUT_UPDATE)) {
                return "put_update " + command[1];
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return "put_error " + command[1] + " " + line;
    }


    /**
     * decluters the methode "process()" and delegates the get command to the KVStore and selects the correct response
     *
     * @param command String, which was entered in order to get the Key-Value pair
     * @return String consisting of the statusMessage and the <key> and in case of an error also the value
     */
    private String getInit(String[] command) {
        if (command.length < 2)
            return "get_error ";
        if (command.length > 2)
            return "get_error " + command[1] + "";
        try {
            KVMessage myMessage = kvStore.get(command[1]);
            if (myMessage.getStatus().equals(KVMessage.StatusType.GET_SUCCESS)) {
                return "get_success " + command[1] + " " + myMessage.getValue() ;
            } else {
                return "get_error " + command[1] ;
            }
        } catch (Exception e) {
            e.printStackTrace();
            return "get_error " + command[1] ;
        }
    }


    /**
     * decluters the methode "process()" and delegates the delete command to the KVStore and selects the correct response
     *
     * @param command String, which was entered in order to delete the Key-Value pair
     * @return String consisting of the statusMessage and the <key> and in case of an error also the value
     */
    private String deleteInit(String[] command) {
        try {
            if (kvStore.delete(command[1]).getStatus().equals(KVMessage.StatusType.DELETE_SUCCESS)) {
                return "delete_success " + command[1];
            } else {
                return "delete_error " + command[1];
            }
        } catch (Exception e) {
            e.printStackTrace();
            return "delete_error " + command[1] ;
        }
    }

    /**
     * Inits the communication tho the KVStore
     *
     * @return
     */
    @Override
    public String connectionAccepted() {
        connectedClients++;
        return null;
    }

    /**
     * Closes the connection with this client.
     * If no client is connected to the server afterwards, the server saves the cache.
     * @return
     */
    @Override
    public void connectionClosed() {
        connectedClients--;
        if (connectedClients <= 0) {
            try {
                if (kvStore.saveCache().getStatus().equals(KVMessage.StatusType.END_SUCCESS)) {
                    logger.log(logger.getLevel(), "Cache Successfully saved.");
                }
                else{
                    logger.log(logger.getLevel(), "Error: Cache could not be saved.");
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        }


    }
}
