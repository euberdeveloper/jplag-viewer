package de.tum.i13.shared;

public class Constants {
	public static final String TELNET_ENCODING = "ISO-8859-1"; // encoding for telnet
	public static final String HELP_MESSAGE="Help: "
			+" put key value: saves key value"
			+" get key: returns <value>"
			+" delete key: deletes key value"
	+" Any incalid command";

	public static final String extended_HELP_MESSAGE="Help:" +
			" connect address port: Tries to establish a TCP- connection to the storage server based on the given server address and the port number of the storage service."
			+" disconnect Tries to disconnect from the connected server."
			+" put key value Inserts a key-value pair into the storage server data structures. Updates (overwrites) the current value with the given value if the server already contains the specified key. Deletes the entry for the given key if <value> equals null."
			+" logLevel level Sets the logger to the specified level."
			+" help shows this help text"
			+" quit Tears down the active connection to the server and exits the program."
			+" anything else Any unrecognized input in the context of this application.";


}
