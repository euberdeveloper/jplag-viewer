package de.tum.i13.client;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.SocketException;
import java.rmi.ConnectException;
import java.rmi.UnknownHostException;

/**
 * Offers a command line based client to communicate with the KV-Storage Server
 */
public class Milestone1Main {
    /**
     * Reads the user input and calls the corresponding methods in the client.
     * @param args Commandline Parameters as described in the config File.
     * @throws IOException
     */
    public static void main(String[] args) throws IOException {
        BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));
        ActiveConnection activeConnection = null;
        for(;;) {
            System.out.print("EchoClient> ");
            String line = reader.readLine();
            String[] command = line.split(" ");

            switch (command[0]) {
                case "connect": activeConnection = buildconnection(command); break;
               // case "delete": sendmessage(activeConnection,("put"+line.substring(line.indexOf(" "),line.length()))); break;
                case "put":
                case "get": sendmessage(activeConnection,line); break;
                case "disconnect": closeConnection(activeConnection); break;
                case "help": printHelp(); break;
                case "quit": printEchoLine("Application exit!"); closeConnection(activeConnection);return;
                default: sendmessage(activeConnection,line);
            }
        }
    }


    /**
     * Prints a help text to the command line to explain every possible command to the user.
     */
    private static void printHelp() {
        System.out.println("Available commands:");
        System.out.println("connect <address> <port> - Tries to establish a TCP- connection to the echo server based on the given server address and the port number of the echo service.");
        System.out.println("get <key> - Tries to get the corresponding value to the given key from the storage Server. The key must not contain the space character");
        System.out.println("put <key> <value>- Tries to put the given key and value in the storage Server. If an entry with the same key already exists, the value will be updated.");
        System.out.println("disconnect - Tries to disconnect from the connected server.");
        System.out.println("logLevel <level> - Sets the logger to the specified log level (ALL | DEBUG | INFO | WARN | ERROR | FATAL | OFF)");
        System.out.println("help - Display this help");
        System.out.println("quit - Tears down the active connection to the server and exits the program execution.");
    }

    /**
     * Prints the massage msg to the commandline and adds the necessary prefix.
     * @param msg massage for the server.
     */
    private static void printEchoLine(String msg) {
        System.out.println("EchoClient> " + msg);
    }

    /**
     * Signals the Server that this connection will be closed and afterwards closses the connection.
     * @param activeConnection Connection to the KV-server.
     */
    private static void closeConnection(ActiveConnection activeConnection) {
        if(activeConnection != null) {
            try {
                activeConnection.write("quit");
                activeConnection.close();
            } catch (UnknownHostException e){
                printEchoLine("Host is unknown");
            } catch(SocketException e){
                printEchoLine("Problem connecting to socket.");
            } catch(Exception e) {
                printEchoLine("Exception:" + e.toString());
            }
        }
    }


    /**
     * Sends a custom message to the kv-server
     * @param activeConnection Connection to the KV-server.
     * @param line message which will be send to the server.
     */
    private static void sendmessage(ActiveConnection activeConnection, String line) {
        if(activeConnection == null) {
            printEchoLine("Error! Not connected!");
            return;
        }
        int firstSpace = line.indexOf(" ");
        if(firstSpace == -1 || firstSpace + 1 >= line.length()) {
            printEchoLine("Error! Nothing to send!");
            return;
        }


        activeConnection.write(line);

        try {
            printEchoLine(activeConnection.readline());
        } catch (IOException e) {
            printEchoLine("Error! Not connected!");
        }
    }


    /**
     * establishes a connection to the give IP-Address(command[1]) and Port(command[2])
     * @param command user input reduced to individula words without the spaces.
     * @return the active connection to a server if successfully, otherwise null.
     */
    private static ActiveConnection buildconnection(String[] command) {
        if(command.length == 3){
            try {
                EchoConnectionBuilder kvcb = new EchoConnectionBuilder(command[1], Integer.parseInt(command[2]));
                ActiveConnection ac = kvcb.connect();
                String confirmation = ac.readline();
                printEchoLine(confirmation);
                return ac;
            } catch (UnknownHostException e){
                printEchoLine("Host is unknown");
            } catch(SocketException e){
                printEchoLine("Problem connecting to socket.");
            }catch(ConnectException e){
                printEchoLine("Problem connecting to server. Is it running?");
            } catch(NumberFormatException e){
                printEchoLine("Port number should be an integer");
            } catch(IllegalArgumentException e){
                printEchoLine("The port number is too big");
            } catch(Exception e) {
                printEchoLine("Exception:" + e.toString());
            }
        }
        return null;
    }
}
