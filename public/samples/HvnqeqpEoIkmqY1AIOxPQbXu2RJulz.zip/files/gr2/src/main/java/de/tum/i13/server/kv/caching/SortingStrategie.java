package de.tum.i13.server.kv.caching;


import java.util.LinkedHashMap;
import java.util.Set;


/**
 * Interface used to implement different strategies
 */
public interface SortingStrategie {

    /**
     * Removes element linked to key
     * @param key
     */
    void remove(String key);

    /**
     * maintains the strategy after the the element with key k was used
     * only changes the corresponding parameter in the list
     */
    LinkedHashMap <String, String> maintainList();

    /**
     * Adds k, v pair to cache
     * @param key
     * @param value
     */
     void add(String key, String value);

    /**
     * Returns value to given key
     * @param key
     * @return value
     */
     String get(String key);


}
