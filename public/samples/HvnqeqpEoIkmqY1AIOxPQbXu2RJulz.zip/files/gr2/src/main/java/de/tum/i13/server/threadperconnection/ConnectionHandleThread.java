package de.tum.i13.server.threadperconnection;

import de.tum.i13.shared.CommandProcessor;
import de.tum.i13.shared.Constants;
import de.tum.i13.shared.LogSetup;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.io.UnsupportedEncodingException;
import java.math.BigInteger;
import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.net.Socket;
import java.util.logging.LogManager;
import java.util.logging.Logger;

public class ConnectionHandleThread extends Thread {
	private final CommandProcessor cp;
	private final Socket clientSocket;
	private final Logger myLogger;
	private final InetAddress clientAddress;

	public ConnectionHandleThread(CommandProcessor commandProcessor, Socket clientSocket) {
		this.cp = commandProcessor;
		this.clientSocket = clientSocket;
		this.clientAddress = clientSocket.getInetAddress();
		myLogger = LogManager.getLogManager().getLogger(""); // Include this line in every class to enable Logging

	}

	@Override
	public void run() {
		try {
			cp.connectionAccepted();
			myLogger.log(myLogger.getLevel(), "ConnectionHandleThread with " + clientAddress.getHostAddress()
					+ " started. Waiting for a message.");
			BufferedReader in = new BufferedReader(
					new InputStreamReader(clientSocket.getInputStream(), Constants.TELNET_ENCODING));
			PrintWriter out = new PrintWriter(
					new OutputStreamWriter(clientSocket.getOutputStream(), Constants.TELNET_ENCODING));
			out.write("Connection to kvServer established.\r\n");
			out.flush();
			String firstLine;
			while ((firstLine = in.readLine()) != null) {
				myLogger.log(myLogger.getLevel(), "Message from the Client: " + firstLine);
				if (firstLine.startsWith("quit")) {
					in.close();
					out.close();
					break;
				}
				String res = "";
				try {
					res = cp.process(firstLine);
				} catch (Exception e) {
					myLogger.log(myLogger.getLevel(), e.toString());

				}
				myLogger.log(myLogger.getLevel(), "Answer for the client: " + res);

				out.write(res + "\r\n");
				out.flush();
			}
		} catch (Exception ex) {
			ex.printStackTrace();
		} finally {
			myLogger.log(myLogger.getLevel(), "Client terminated, connection will be closed.");
			cp.connectionClosed();
		}
	}
}
