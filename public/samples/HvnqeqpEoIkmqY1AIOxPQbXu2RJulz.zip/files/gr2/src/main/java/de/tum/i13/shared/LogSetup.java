package de.tum.i13.shared;

import java.io.IOException;
import java.nio.file.Path;
import java.util.logging.*;

public class LogSetup {

    /**
     * Sets up the logManager with the given parameters. Afterwards the logging can be used in every class
     * after calling: Logger logger = LogManager.getLogManager().getLogger("");
     * @param logfile specifies where the log-Output will be stored.
     * @param logLevel Loglevel in String format, must be converted into an actual Level.
     */
    public static void setupLogging(Path logfile, String logLevel) {
        Logger logger = LogManager.getLogManager().getLogger("");
        System.setProperty("java.util.logging.SimpleFormatter.format",
                "%1$tY-%1$tm-%1$td %1$tH:%1$tM:%1$tS.%1$tL %4$-7s [%3$s] %5$s %6$s%n");


        FileHandler fileHandler = null;
        try {
            fileHandler = new FileHandler(logfile.getFileName().toString(), true);
        } catch (IOException e) {
            e.printStackTrace();
        }
        fileHandler.setFormatter(new SimpleFormatter());
        logger.addHandler(fileHandler);

        Level myLevel=evaluateLogLevel(logLevel);
        for (Handler h : logger.getHandlers()) {
            h.setLevel(myLevel);
        }
        logger.setLevel(myLevel); //we want log everything

    }

    public static Level evaluateLogLevel(String input) {
        Level newLevel=null;
        if (input.endsWith("FINE")) {
            newLevel = Level.FINE;
        } else if (input.endsWith("ALL")) {
            newLevel = Level.ALL;
        } else if (input.endsWith("CONFIG")) {
            newLevel = Level.CONFIG;
        } else if (input.endsWith("FINEST")) {
            newLevel = Level.FINEST;
        } else if (input.endsWith("INFO")) {
            newLevel = Level.INFO;
        } else if (input.endsWith("OFF")) {
            newLevel = Level.OFF;
        } else if (input.endsWith("SEVERE")) {
            newLevel = Level.SEVERE;
        } else if (input.endsWith("WARNING")) {
            newLevel = Level.WARNING;
        } else {
            newLevel=Level.ALL;
        }
        return newLevel;
    }
}