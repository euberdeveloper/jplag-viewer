package de.tum.i13.server.kv.caching;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Scanner;
import java.util.logging.LogManager;
import java.util.logging.Logger;

/**
 * uses an array of LFUCount objects to implement strategy
 */
public class LFU implements SortingStrategie{

    /**
     * is used to have an array containing the count of uses and a CacheElement in the Class LFU
     */
    private class LFUCount{

        private CacheElement element;
        private int count;

        public LFUCount (CacheElement element, int count){
            this.count= count;
            this.element = element;
        }
    }

    private final int maxCacheSize;
    private File file;
    private Logger logger;
    private int numElements;
    private LFUCount [] cache;

    public LFU (int maxCacheSize, Path dirPath){
        maxCacheSize = maxCacheSize;
        logger = LogManager.getLogManager().getLogger("");

        file = new File(dirPath + "\\kvStorage.txt");
        if (!file.exists() || file.isDirectory()) {
            try {
                file.createNewFile();
            } catch (IOException e) {
                logger.log(logger.getLevel(), "FIFO, File_ERROR" + dirPath + "kvStorage");
                e.printStackTrace();
            }
            logger.log(logger.getLevel(), "New File created: " + dirPath + "kvStorage");
        } else {
            logger.log(logger.getLevel(), "File already exists");
        }


        this.maxCacheSize = maxCacheSize;
        cache = new LFUCount[maxCacheSize];
        numElements = 0;
    }



    public synchronized void putInStore(String key, String value) throws Exception {
        BufferedWriter writer = new BufferedWriter(new FileWriter(file, true));
        writer.append(key + " " + value + " <EndOfValue> ");
        writer.flush();
        writer.close();
    }

    public synchronized String getInStore(String key) throws Exception {
        String in = fileToString();
        String[] split = in.split(" <EndOfValue> ");

        if (in.length() != 0)
            for (int i = 0; i < split.length; i++)
                if (split[i].substring(0, split[i].indexOf(" ")).equals(key))
                    return split[i].substring(split[i].indexOf(" ") + 1, split[i].length());

        return null;

    }

    public synchronized void deleteInStore(String key) throws Exception {
        String result = fileToString().replaceAll(key + " " + getInStore(key) + " <EndOfValue> ", "");
        BufferedWriter writer = new BufferedWriter(new FileWriter(file));
        writer.append(result);
        writer.flush();
        writer.close();
    }

    public synchronized String fileToString() throws Exception {
        String input = null;
        Scanner sc = new Scanner(file);
        StringBuffer sb = new StringBuffer();
        while (sc.hasNextLine()) {
            input = sc.nextLine();
            sb.append(input);
        }
        return sb.toString();
    }


    @Override
    public synchronized void remove(String key) {
        for (int i = 0; i < cache.length; i++){
            if (cache[i].element.getKey().equals(key)){
                for (int j = i; j<numElements-1; j++){
                    cache[j] = cache [j+1];
                    if (j == numElements -1){
                        cache [j+1] = null;
                    }
                }
                if (numElements > 0)
                    numElements = numElements -1;
            }
        }
    }


    @Override
    public synchronized LinkedHashMap<String, String> maintainList() {
        LinkedHashMap <String, String> map = new LinkedHashMap<>(maxCacheSize);
        int i = 0;
        while (i < numElements&&cache[i]!=null){
            map.put(cache[i].element.getKey(), cache[i].element.getValue());
            i++;
        }
        return map;
    }


    @Override
    public synchronized void add(String key, String value) {
        if (numElements == 0){
            cache[0] = new LFUCount(new CacheElement(key, value),0);
            numElements++;
            return;
        }
        for (int i = 0; i < numElements; i++){
            if (cache[i].element.getKey().equals(key)){
                cache[i].element.setValue(value);
                cache[i].count++;
                sort();
                return;
            }
        }
        for (int i = 0; i < numElements; i++){
            if (cache[i].count == 0){
                addFirst(new LFUCount(new CacheElement(key, value),0), i);
                if(numElements != maxCacheSize){
                    numElements++;
                }
                return;
            }
        }
        if(numElements != maxCacheSize){
            cache[numElements] = new LFUCount(new CacheElement(key, value),0);
            numElements++;
            return;
        }

        cache[numElements-1] = new LFUCount(new CacheElement(key, value),0);

    }

    private void sort(){
        for (int i = 0; i < numElements; i++){
            for (int j =numElements-1; j > i+1; j--){
                if (cache[j].count > cache[j-1].count){
                    LFUCount temp = cache[j-1];
                    cache[j-1] = cache[j];
                    cache[j] = temp;
                }
            }
        }
    }

    private void addFirst(LFUCount lfuCount, int first){
        LFUCount firstCache = cache[first];
        cache[first] = lfuCount;
        LFUCount temp = firstCache;
        for (int i = first; i < numElements; i++){
            if (numElements == 1){
                temp = cache[i+1];
                cache[i+1] = firstCache;
                return;
            }
            else if (i+2 == cache.length && numElements == maxCacheSize){
                if (i == first){
                    try {
                        if (getInStore(firstCache.element.getKey()) != null) {
                            deleteInStore(firstCache.element.getKey());
                        }
                        putInStore(firstCache.element.getKey(), cache[i].element.getValue());
                        return;
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }else {
                    try {
                        if (getInStore(cache[i+1].element.getKey()) != null) {
                            deleteInStore(cache[i+1].element.getKey());
                        }
                        putInStore(cache[i+1].element.getKey(), cache[i+1].element.getValue());
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                    cache[i+1]= temp;
                    return;

                }
            }else{
                LFUCount temp2 = cache[i+1];
                cache[i+1] = temp;
                temp = temp2;
                if(i +1 == numElements){
                    return;
                }

            }
        }
    }

    @Override
    public synchronized String get(String key) {

        for (int i = 0; i < numElements; i++){
            if (cache[i].element.getKey().equals(key)){
                cache[i].count = cache[i].count +1;
                int j = i;
                while (j != 0 && cache[j-1].count<=cache[j].count){
                    LFUCount temp = cache[j];
                    cache[j] = cache[j-1];
                    cache[j-1] = temp;
                    j--;
                }
                return cache[i].element.getValue();
            }
        }
        try {
            if(getInStore(key)!= null){
                add(key, getInStore(key));
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }


    @Override
    public String toString() {
        String output = "";
        for (int i = 0; i < numElements; i++) {
            output = output + "Count: " + cache[i].count + "  " + cache[i].element.getKey() + "  " + cache[i].element.getValue() + "\n";
        }
        return output;
    }

   /* public static void main (String []args){
        LFU test = new LFU(3, Paths.get("data/testFile.txt"));
        String output = "";
        test.add("4","4");
        test.add("5","5");
        test.add("6","6");
        test.add("7","7");
        test.add("8","8");
        test.add("9","9");
        for (int i = 0; i < test.numElements; i++) {
            output = output + "Count: " + test.cache[i].count + "  " + test.cache[i].element.getKey() + "  " + test.cache[i].element.getValue() + "\n";
        }
        output = output + "\nNow get: \n";

        test.get("4");
        test.get("5");
        test.get("7");
        test.get("8");
        test.get("9");
        test.get("6");

        for (int i = 0; i < test.numElements; i++) {
            output = output + "Count: " + test.cache[i].count + "  " + test.cache[i].element.getKey() + "  " + test.cache[i].element.getValue() + "\n";
        }
        System.out.println(output);

    }*/

}
