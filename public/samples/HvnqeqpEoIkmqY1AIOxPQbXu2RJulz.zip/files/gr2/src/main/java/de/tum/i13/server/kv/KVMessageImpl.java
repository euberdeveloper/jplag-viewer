package de.tum.i13.server.kv;

import de.tum.i13.server.kv.KVMessage.StatusType;

public class KVMessageImpl implements KVMessage{
	private StatusType statustype;
	private String key;
	private String value;

	public KVMessageImpl() {
	}

	@Override
	public String getKey() {
		return key;
	}

	@Override
	public String getValue() {
		return value;
	}

	@Override
	public StatusType getStatus() {
		return statustype;
	}

	@Override
	public void setKey(String key) {
		this.key = key;
	}

	@Override
	public void setValue(String value) {
		this.value = value;
	}

	@Override
	public void setStatus(StatusType statustype) {
		this.statustype=statustype;
	}
}
