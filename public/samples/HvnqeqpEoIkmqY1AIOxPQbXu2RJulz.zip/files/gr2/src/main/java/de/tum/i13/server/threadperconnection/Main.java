package de.tum.i13.server.threadperconnection;

import de.tum.i13.server.echo.EchoLogic;
import java.nio.file.Path;
import de.tum.i13.server.kv.KVCommandProcessor;
import de.tum.i13.server.kv.KVStore;
import de.tum.i13.server.kv.KVStoreImpl;
import de.tum.i13.server.kv.caching.FIFO;
import de.tum.i13.server.kv.caching.LFU;
import de.tum.i13.server.kv.caching.LRU;
import de.tum.i13.server.kv.caching.SortingStrategie;
import de.tum.i13.shared.CommandProcessor;
import de.tum.i13.shared.Config;

import java.io.*;
import java.net.BindException;
import java.net.InetSocketAddress;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.logging.Level;
import java.util.logging.LogManager;
import java.util.logging.Logger;

import static de.tum.i13.shared.Config.parseCommandlineArgs;
import static de.tum.i13.shared.Constants.HELP_MESSAGE;
import static de.tum.i13.shared.LogSetup.setupLogging;

/**
 * Created by chris on 09.01.15.
 */
public class Main {

	/**
	 * Main Methode of the Server. It will initialise the server and will afterwards
	 * accept client connections and delegates the client communication to a
	 * ConnectionHandleThread.
	 *
	 * @param args List of Parameters for the server. Explanation can be found in
	 *             the config file.
	 * @throws IOException
	 */
	public static void main(String[] args) throws IOException {
		Config cfg = parseCommandlineArgs(args); // Do not change this

		// Setup Logging capabilities
		setupLogging(cfg.logfile, cfg.logLevel);
		Logger logger = LogManager.getLogManager().getLogger("");
		logger.log(logger.getLevel(), "Loglevel: " + logger.getLevel());


		//displays HelpText if correcto commandline parameter is set
		if(cfg.usagehelp){
			System.out.println(HELP_MESSAGE);//todo print help text from commandline info
			return;	//terminates in order to start the server with the right parameters
		}
		// setupCachning
		SortingStrategie cacheStrategy = setupCachingStrategie(cfg.cacheSize, cfg.cacheStrategy, logger, cfg.dataDir);

		// check for correct path
		Path p = cfg.dataDir;
		if (p.endsWith("/")) {
			p.subpath(0, p.toString().length() - 1);
		}

		// setup processing logic
		KVStore kvstore = new KVStoreImpl(cacheStrategy, p);
		CommandProcessor logic = new KVCommandProcessor(kvstore);

		// creates and binds the Server
		final ServerSocket serverSocket = new ServerSocket();
		try {
			serverSocket.bind(new InetSocketAddress(cfg.listenaddr, cfg.port));
		} catch (java.net.BindException e) {
			logger.log(logger.getLevel(), "Port is already in use.");
		} catch (Exception e) {
			// logger.log(logger.getLevel(), "Port was already in Use. Server is going to
			// run correctly.");
		}
		logger.log(logger.getLevel(), "Server Socket Created");

		// Frees the socket in case the server crashes
		Runtime.getRuntime().addShutdownHook(new Thread() {
			@Override
			public void run() {
				logger.log(logger.getLevel(), "Closing thread per connection kv server");
				try {
					serverSocket.close();
					logger.log(logger.getLevel(), "Database-Server successfully closed.");

				} catch (IOException e) {
					logger.log(logger.getLevel(), e.toString());

				} finally {
					try {
						kvstore.saveCache();
						System.exit(0);
					} catch (Exception e) {
						logger.log(logger.getLevel(), "Error: cache could not have been saved.");
						e.printStackTrace();
					}
				}
			}
		});
		logger.log(logger.getLevel(), cfg.toString());
		handleConnections(logic, serverSocket,logger);

	}

	private static SortingStrategie setupCachingStrategie(int cacheSize, String chacheString, Logger logger,
			Path path) {
		SortingStrategie cacheStrategie;
		String logText = "";
		if (chacheString.equals("FIFO")) {
			cacheStrategie = new FIFO(cacheSize, path);
			logText = "Caching Strategy: FIFO";
        } else if (chacheString.equals("LRU")) {
            cacheStrategie = new LRU(cacheSize,path);
            logText = "Caching Strategy: LRU";
        } else if (chacheString.equals("LFU")) {
            cacheStrategie = new LFU(cacheSize,path);
            logText = "Caching Strategy: LFU";
		} else if (chacheString.equals("DEFAULTFIFO")) {
			cacheStrategie = new FIFO(cacheSize, path);
			logText = "No Caching Strategy entered: Default caching Strategy FIFO will be used.";
		} else {
			cacheStrategie = new FIFO(cacheSize, path);
			logText = "Invalid Caching Strategy entered. (Valid Options: FIFO, LRU and LFU) Default caching Strategy FIFO will be used.";
		}

		return cacheStrategie;
	}

	private static void handleConnections(CommandProcessor logic, ServerSocket serverSocket,Logger logger) {
		while (true) {
			Socket clientSocket=null;
			try {
				clientSocket = serverSocket.accept();
			} catch (IOException e) {
				//logger.log(logger.getLevel(), "Error in Main.class: SocketException");
			}
			// When we accept a connection, we start a new Thread for this connection
			if(clientSocket!=null) {
			Thread th = new ConnectionHandleThread(logic, clientSocket);
			th.start();
			}
		}
	}
}
