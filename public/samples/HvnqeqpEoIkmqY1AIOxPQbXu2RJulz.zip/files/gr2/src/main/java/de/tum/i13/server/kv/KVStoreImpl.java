package de.tum.i13.server.kv;


import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;

import java.io.IOException;
import java.nio.file.Path;
import java.util.Arrays;
import java.util.Scanner;
import java.util.Set;
import java.util.logging.LogManager;
import java.util.logging.Logger;

import de.tum.i13.server.kv.caching.FIFO;
import de.tum.i13.server.kv.caching.SortingStrategie;

public class KVStoreImpl implements KVStore {

	private final SortingStrategie sortingStrategie;
	private final File file;
	private final Logger logger;

	public KVStoreImpl(SortingStrategie sortingStrategie, Path dirPath) throws IOException {
		this.sortingStrategie = sortingStrategie;
		logger = LogManager.getLogManager().getLogger(""); // Include this line in every class to enable Logging

		file = new File(dirPath + "\\kvStorage.txt");
		if (!file.exists() || file.isDirectory()) {
			file.createNewFile();
			logger.log(logger.getLevel(), "New File created: " + dirPath + "kvStorage");
		} else {
			logger.log(logger.getLevel(), "File already exists");
		}
	}

	@Override
	public synchronized KVMessage put(String key, String value) {
		KVMessage kv = new KVMessageImpl();
		try {
			if (lookUpCache(key)) { // im cache enthalten
				sortingStrategie.add(key, value);
				kv.setStatus(KVMessage.StatusType.PUT_UPDATE);
				return kv;
			} else { // nicht im cache enthalten
				if (getInStore(key) != null) {
					kv.setStatus(KVMessage.StatusType.PUT_UPDATE);
				} else {
					kv.setStatus(KVMessage.StatusType.PUT_SUCCESS);
				}
				sortingStrategie.add(key, value);
				kv.setKey(key);
				return kv;
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		kv.setStatus(KVMessage.StatusType.PUT_ERROR);
		kv.setKey(key);
		return kv;
	}

	@Override
	public synchronized KVMessage get(String key) throws Exception {
		KVMessage kv = new KVMessageImpl();
		if (lookUpCache(key)) { // cache durchsuchen
			kv.setValue(sortingStrategie.get(key));
			kv.setStatus(KVMessage.StatusType.GET_SUCCESS);
			kv.setKey(key);
			return kv;
		} else { // Store durchsuchen
			try {
				String s = getInStore(key);
				if (s != null) {
					kv.setValue(s);
					kv.setStatus(KVMessage.StatusType.GET_SUCCESS);
					kv.setKey(key);
					return kv;
				}
			} catch (Exception e) {
				e.printStackTrace();
			} // GET_Error
			kv.setStatus(KVMessage.StatusType.GET_ERROR);
			kv.setKey(key);
			kv.setValue("");
			return kv;
		}
	}

	@Override
	public synchronized KVMessage delete(String key) throws Exception {
		KVMessage kv = new KVMessageImpl(); // Delete in Store
		String value = getInStore(key);
		if (value != null) {
			deleteInStore(key);
			kv.setStatus(KVMessage.StatusType.DELETE_SUCCESS);
			kv.setKey(key);
			if (lookUpCache(key)) { // Delete in cache
				logger.log(logger.getLevel(), key + " was in the cache.");
				sortingStrategie.remove(key);
			}
			return kv;
		} else {
			if (lookUpCache(key)) { // Delete in cache
				logger.log(logger.getLevel(), key + " was in the cache.");
				sortingStrategie.remove(key);
				kv.setStatus(KVMessage.StatusType.DELETE_SUCCESS);
				kv.setKey(key);
			} else {
				kv.setStatus(KVMessage.StatusType.DELETE_ERROR);
				kv.setKey(key);
			}
		}
		return kv;
	}

	@Override
	public KVMessage saveCache() throws Exception {
		logger.log(logger.getLevel(), "Saving cache to the persistent storage.");
		KVMessage kv = new KVMessageImpl();
		try {
			Set<String> keys = sortingStrategie.maintainList().keySet();
			for (String k : keys) {
				deleteInStore(k);
				putInStore(k, sortingStrategie.maintainList().get(k));
			}
			kv.setStatus(KVMessage.StatusType.SAVE_SUCCESS);
			return kv;
		} catch (Exception e) {
			e.printStackTrace();
		}
		kv.setStatus(KVMessage.StatusType.SAVE_ERROR);
		return kv;
	}

	@Override
	public boolean lookUpCache(String key) {
		if (sortingStrategie.get(key) != null) {// im cache enthalten
			return true;
		} else { // nicht im cache enthalten
			return false;
		}
	}


	@Override
	public synchronized String getInStore(String key) throws Exception {
		String in = fileToString();
		String[] split = in.split(" <EndOfValue> ");

		if (in.length() != 0)
			for (int i = 0; i < split.length; i++)
				if (split[i].substring(0, split[i].indexOf(" ")).equals(key))
					return split[i].substring(split[i].indexOf(" ") + 1, split[i].length());

		return null;

	}

	@Override
	public synchronized void deleteInStore(String key) throws Exception {
		String result = fileToString().replaceAll(key + " " + getInStore(key) + " <EndOfValue> ", "");
		BufferedWriter writer = new BufferedWriter(new FileWriter(file));
		writer.append(result);
		writer.flush();
		writer.close();
	}

	@Override
	public synchronized void putInStore(String key, String value) throws Exception {
		BufferedWriter writer = new BufferedWriter(new FileWriter(file, true));
		writer.append(key + " " + value + " <EndOfValue> ");
		writer.flush();
		writer.close();
	}

	@Override
	public synchronized String fileToString() throws Exception {
		String input = null;
		Scanner sc = new Scanner(file);
		StringBuffer sb = new StringBuffer();
		while (sc.hasNextLine()) {
			input = sc.nextLine();
			sb.append(input);
		}
		return sb.toString();
	}

}