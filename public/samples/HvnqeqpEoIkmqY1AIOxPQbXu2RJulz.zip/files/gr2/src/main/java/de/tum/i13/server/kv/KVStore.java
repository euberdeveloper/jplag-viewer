package de.tum.i13.server.kv;

import java.io.IOException;

public interface KVStore {

	/**
	 * Inserts a key-value pair into the KVServer.
	 *
	 * @param key   the key that identifies the given value.
	 * @param value the value that is indexed by the given key.
	 * @return Message "PUT_SUCCESS", "PUT_ERROR"
	 * @throws Exception if put command cannot be executed (e.g. not connected to
	 *                   any KV server).
	 */
	public KVMessage put(String key, String value) throws Exception;

	/**
	 * Retrieves the value for a given key from the KVServer.
	 *
	 * @param key the key that identifies the value.
	 * @return StatusType
	 * @throws Exception if get command cannot be executed (e.g. not connected to
	 *                   any KV server).
	 */
	public KVMessage get(String key) throws Exception;

	/**
	 * Deletes the Key-Value-Pair for a given key from the KVServer.
	 *
	 * @param key the key that identifies the value.
	 * @return Message "DELETE_SUCCESS", "DELETE_ERROR"
	 * @throws Exception if delete command cannot be executed (e.g. not connected to
	 *                   any KV server).
	 */
	public KVMessage delete(String key) throws Exception;

	/**
	 * Saves Cache in JSON File.
	 *
	 * @param unsaved Cache.
	 * @return Message "SAVE_SUCCESS", "SAVE_ERROR"
	 * @throws Exception if saveCache methode cannot be executed (e.g. not connected
	 *                   to any KV server).
	 */
	public KVMessage saveCache() throws Exception;

	/**
	 * Is object in cache?
	 *
	 * @return boolean
	 */
	public boolean lookUpCache(String key);

	/**
	 * get value out of store
	 * 
	 * @return boolean
	 */
	public String getInStore(String key) throws Exception;

	/**
	 * delete value out of store
	 * 
	 * @return boolean
	 */
	public void deleteInStore(String key) throws Exception;

	/**
	 * put value in store
	 * 
	 * @return boolean
	 */
	public void putInStore(String key, String value) throws Exception;

	/**
	 * convert file to String
	 * 
	 * @return boolean
	 */
	public String fileToString() throws Exception;

}
