package de.tum.i13.client;

/** The CLIRunner main class (program entry point). */
public class CLIRunner {
  private static ClientCLI cli;

  /**
   * The entry point of the application.
   *
   * @param args input arguments
   */
  public static void main(String[] args) {
    cli = new ClientCLI();
    cli.start();
  }
}
