package de.tum.i13.shared;

import java.io.File;
import java.io.IOException;
import java.util.logging.FileHandler;
import java.util.logging.Handler;
import java.util.logging.Level;
import java.util.logging.LogManager;
import java.util.logging.Logger;
import java.util.logging.SimpleFormatter;

/** The type Log setup. */
public class LogSetup {

  /**
   * Sets log level.
   *
   * @param s the s
   */
  public static void setupLogLevel(String s) {
    try {
      Level l = Level.parse(s);
      Logger logger = LogManager.getLogManager().getLogger("");
      for (Handler h : logger.getHandlers()) {
        h.setLevel(l);
      }
      logger.setLevel(l); // we want log everything
    } catch (IllegalArgumentException e) {
      System.out.println(
          "Undefined Log Level please provide correct log level ALL, NONE, FINE, SEVERE etc.");
    }
  }

  /**
   * Sets logging.
   *
   * @param logfile the logfile
   */
  public static void setupLogging(String logfile) {
    Logger logger = LogManager.getLogManager().getLogger("");

    System.setProperty(
        "java.util.logging.SimpleFormatter.format",
        "%1$tY-%1$tm-%1$td %1$tH:%1$tM:%1$tS.%1$tL %4$-7s [%3$s] %5$s %6$s%n");

    File dirs = new File(logfile).getParentFile();
    if (dirs != null) {
      //noinspection ResultOfMethodCallIgnored
      dirs.mkdirs();
    }

    // Remove all current handlers.
    for (Handler h : logger.getHandlers()) {
      logger.removeHandler(h);
    }
    FileHandler fileHandler = null;
    try {
      fileHandler = new FileHandler(logfile, true);
    } catch (IOException e) {
      e.printStackTrace();
    }
    if (fileHandler != null) {
      fileHandler.setFormatter(new SimpleFormatter());
    }
    logger.addHandler(fileHandler);

    for (Handler h : logger.getHandlers()) {
      h.setLevel(Level.ALL);
    }
    logger.setLevel(Level.ALL); // we want log everything
  }
}
