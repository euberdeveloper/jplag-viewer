package de.tum.i13.server.kv.fileManagement;

import de.tum.i13.server.kv.KVMessage;
import de.tum.i13.server.kv.KVMessage.StatusType;
import de.tum.i13.server.kv.Message;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Arrays;
import java.util.logging.Logger;

/** The type Kv file manager. */
public class KVFileManager {
  private final String dir;
  private final Logger logger;

  /**
   * Instantiates a new Kv file manager.
   *
   * @param dataDir the data dir
   */
  public KVFileManager(String dataDir) {
    dir = dataDir;
    logger = Logger.getLogger(getClass().getSimpleName());
  }

  /**
   * Get kv message.
   *
   * @param key the key
   * @return the kv message
   */
  public synchronized KVMessage get(String key) {
    // Get file name : first letter of key encoded in base64 followed by .txt extension
    String fileName = hash(key);
    // Instantiate file object
    File f = new File(dir, fileName);
    try {
      // Read file line by line until no more lines remain
      BufferedReader fileReader = new BufferedReader(new FileReader(f));
      String line;
      while ((line = fileReader.readLine()) != null) {
        String[] keyVal = getKeyVal(line);
        // If key and line key match -> return value in message
        if (key.equals(keyVal[0])) {
          fileReader.close();
          logger.info("Successful GET: " + key);
          return new Message(key, keyVal[1], StatusType.GET_SUCCESS);
        }
      }
      fileReader.close();
      // No matches found return null in GET_ERROR message
      logger.info("Failed GET: " + key + " doesn't exist.");
      return new Message(key, null, StatusType.GET_ERROR);
    } catch (FileNotFoundException e) {
      // No file found return null in GET_ERROR message
      logger.info("Failed GET: " + key + " doesn't exist.");
      return new Message(key, null, StatusType.GET_ERROR);
    } catch (IOException e) {
      // Error occurred while retrieving the data
      logger.info("Failed GET: " + key + " doesn't exist.");
      logger.severe("IO error: " + e.getMessage() + " : " + Arrays.toString(e.getStackTrace()));
      return new Message(key, null, StatusType.GET_ERROR);
    }
  }

  /**
   * Put kv message.
   *
   * @param key the key
   * @param val the val
   * @return the kv message
   */
  public synchronized KVMessage put(String key, String val) {
    // Get file name : first letter of key encoded in base64 followed by .txt extension
    String fileName = hash(key);
    // Instantiate file object
    File f = new File(dir, fileName);
    try {
      // Read whole file -> append/upsert key value where appropriate -> write whole file
      BufferedReader fileReader = new BufferedReader(new FileReader(f));
      StringBuilder inputBuffer = new StringBuilder();
      String line;
      boolean found = false;
      String fValue = null;
      line = fileReader.readLine();
      while (line != null) {
        String[] keyVal = getKeyVal(line);
        if (key.equals(keyVal[0])) {
          // If key and line key match -> replace line
          line = key + " " + val;
          found = true;
          fValue = keyVal[1];
        }
        inputBuffer.append(line);
        line = fileReader.readLine();
        if (line != null) {
          inputBuffer.append('\n');
        } else {
          break;
        }
      }
      fileReader.close();
      StatusType type = StatusType.PUT_UPDATE;
      if (!found) {
        // Change status to success if no matching key found
        type = StatusType.PUT_SUCCESS;
        if (inputBuffer.length() != 0) {
          inputBuffer.append('\n');
        }
        inputBuffer.append(key).append(" ").append(val);
      } else if (fValue != null && fValue.equals(val)) {
        return new Message(key, val, type);
      }
      // write the new string with the replaced line OVER the same file
      FileOutputStream fileOut = new FileOutputStream(f);
      fileOut.write(inputBuffer.toString().getBytes());
      fileOut.close();
      logger.info("Successful PUT: " + key);
      return new Message(key, val, type);
    } catch (FileNotFoundException e) {
      try {
        FileWriter newFile = new FileWriter(f);
        newFile.write(key + " " + val);
        newFile.close();
        logger.info("Successful PUT: " + key);
        return new Message(key, val, StatusType.PUT_SUCCESS);
      } catch (IOException e2) {
        logger.info("Failed PUT: " + key);
        logger.severe("IO error: " + e2.getMessage() + " : " + Arrays.toString(e2.getStackTrace()));
        return new Message(key, val, StatusType.PUT_ERROR);
      }
    } catch (IOException e) {
      logger.info("Failed PUT: " + key);
      logger.severe("IO error: " + e.getMessage() + " : " + Arrays.toString(e.getStackTrace()));
      return new Message(key, val, StatusType.PUT_ERROR);
    }
  }

  /**
   * Delete kv message.
   *
   * @param key the key
   * @return the kv message
   */
  public synchronized KVMessage delete(String key) {
    // Get file name : first letter of key encoded in base64 followed by .txt extension
    String fileName = hash(key);
    // Instantiate file object
    File f = new File(dir, fileName);
    try {
      BufferedReader fileReader = new BufferedReader(new FileReader(f));
      StringBuilder inputBuffer = new StringBuilder();
      String line;
      boolean found = false;
      line = fileReader.readLine();
      while (line != null) {
        String[] keyVal = getKeyVal(line);
        if (!key.equals(keyVal[0])) {
          inputBuffer.append(line);
          line = fileReader.readLine();
          if (line != null) {
            inputBuffer.append('\n');
          } else {
            break;
          }
        } else {
          found = true;
          line = fileReader.readLine();
          if (line == null) {
            break;
          }
        }
      }
      fileReader.close();
      // write the new string with the replaced line OVER the same file
      FileOutputStream fileOut = new FileOutputStream(f);
      fileOut.write(inputBuffer.toString().getBytes());
      fileOut.close();
      if (found) {
        logger.info("Successful DELETE: " + key);
        return new Message(key, null, StatusType.DELETE_SUCCESS);
      } else {
        logger.info("Failed DELETE: " + key);
        return new Message(key, null, StatusType.DELETE_ERROR);
      }
    } catch (FileNotFoundException e) {
      // No problem. :D
      logger.info("Failed DELETE: " + key);
      return new Message(key, null, StatusType.DELETE_ERROR);
    } catch (IOException e) {
      logger.info("Failed DELETE: " + key);
      logger.severe("IO error: " + e.getMessage() + " : " + Arrays.toString(e.getStackTrace()));
      return new Message(key, null, StatusType.DELETE_ERROR);
    }
  }

  private String[] getKeyVal(String line) {
    return line.split(" ", 2);
  }

  private String hash(String key) {
    int hash = key.hashCode() % 31;
    return (hash < 0 ? hash + 31 : hash) + ".txt";
  }
}
