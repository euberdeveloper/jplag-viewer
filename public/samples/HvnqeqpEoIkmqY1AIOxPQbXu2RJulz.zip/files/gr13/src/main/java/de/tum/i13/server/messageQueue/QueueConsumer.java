package de.tum.i13.server.messageQueue;

import de.tum.i13.server.kv.FileKVStore;
import de.tum.i13.server.kv.KVCommandProcessor;
import de.tum.i13.server.kv.fileManagement.KVFileManager;
import de.tum.i13.server.serverCommand.Command;
import de.tum.i13.shared.CommandProcessor;
import de.tum.i13.shared.Config;
import de.tum.i13.shared.Constants;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.net.Socket;
import java.util.Arrays;
import java.util.logging.Logger;

/** The type Queue consumer. */
public class QueueConsumer extends Thread {

  private MessageQueue queue;
  private CommandProcessor commandProcessor;
  private final Logger logger;

  /**
   * Instantiates a new Queue consumer.
   *
   * @param queue the queue
   * @param cfg the cfg
   */
  public QueueConsumer(MessageQueue queue, Config cfg) {
    this.queue = queue;

    KVFileManager fileManager = new KVFileManager(cfg.dataDir.toString());

    FileKVStore fileKVStore = new FileKVStore(cfg.cacheSize, cfg.cacheStrategy, fileManager);

    commandProcessor = new KVCommandProcessor(fileKVStore);

    logger = Logger.getLogger(getClass().getSimpleName());
  }

  @Override
  public void run() {
    PrintWriter out;
    while (true) {

      try {

        Command command = queue.take();
        // process command
        String res = commandProcessor.process(command.getCommand());
        // send response back
        Socket clientSocket = command.getCommandOwner();

        out =
            new PrintWriter(
                new OutputStreamWriter(clientSocket.getOutputStream(), Constants.TELNET_ENCODING));
        out.print(res + "\r\n");
        out.flush();
      } catch (InterruptedException e) {
        logger.severe(
            "Interrupted Exception " + e.getMessage() + " : " + Arrays.toString(e.getStackTrace()));

      } catch (IOException e) {
        logger.severe("IO Error " + e.getMessage() + " : " + Arrays.toString(e.getStackTrace()));
      } catch (Exception e) {
        logger.severe(
            "unknown error " + e.getMessage() + " : " + Arrays.toString(e.getStackTrace()));
      }
    }
  }
}
