package de.tum.i13.server.kv.cache.cacheStrategy;

import de.tum.i13.server.kv.cache.CacheableKey;

/** The type Lru key option. */
public class LRUKeyOption extends KeyOption {

  private Long accessDate;

  /**
   * Instantiates a new Lru key option.
   *
   * @param key the key
   */
  public LRUKeyOption(CacheableKey key) {
    super(key);
    accessDate = System.nanoTime();
  }

  @Override
  public String toString() {
    return "LRUCacheable{" + "accessDate=" + accessDate + '}';
  }

  public void adjustKeyCriteria() {
    this.setAccessDate(System.nanoTime());
  }

  /**
   * Gets access date.
   *
   * @return the access date
   */
  public long getAccessDate() {
    return accessDate;
  }

  /**
   * Sets access date.
   *
   * @param accessDate the access date
   */
  public void setAccessDate(long accessDate) {
    this.accessDate = accessDate;
  }

  @Override
  public int compareTo(KeyOption o) {
    LRUKeyOption tmp = (LRUKeyOption) o;
    int verdict = accessDate.compareTo(tmp.getAccessDate());
    if (verdict == 0)
      return this.getCacheableKey().getKey().compareTo(o.getCacheableKey().getKey());

    return verdict;
  }
}
