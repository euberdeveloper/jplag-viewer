package de.tum.i13.server.kv.cache.cacheStrategy;

import de.tum.i13.server.kv.cache.CacheableKey;

/** The type Key option. */
public abstract class KeyOption implements Comparable<KeyOption> {

  private CacheableKey cacheableKey;

  /**
   * Instantiates a new Key option.
   *
   * @param cacheableKey the cacheable key
   */
  public KeyOption(CacheableKey cacheableKey) {
    this.cacheableKey = cacheableKey;
  }

  /**
   * Gets cacheable key.
   *
   * @return the cacheable key
   */
  public CacheableKey getCacheableKey() {
    return cacheableKey;
  }

  /**
   * Sets cacheable key.
   *
   * @param cacheableKey the cacheable key
   */
  public void setCacheableKey(CacheableKey cacheableKey) {
    this.cacheableKey = cacheableKey;
  }

  /** Adjust key criteria. */
  public abstract void adjustKeyCriteria();
}
