package de.tum.i13.server.kv;

/** The interface Kv message. */
public interface KVMessage {

  /** The enum Status type. */
  public enum StatusType {
    /** Get status type. */
    GET, /* Get - request */
    /** Get error status type. */
    GET_ERROR, /* requested tuple (i.e. value) not found */
    /** Get success status type. */
    GET_SUCCESS, /* requested tuple (i.e. value) found */
    /** Put status type. */
    PUT, /* Put - request */
    /** Put success status type. */
    PUT_SUCCESS, /* Put - request successful, tuple inserted */
    /** Put update status type. */
    PUT_UPDATE, /* Put - request successful, i.e. value updated */
    /** Put error status type. */
    PUT_ERROR, /* Put - request not successful */
    /** Delete status type. */
    DELETE, /* Delete - request */
    /** Delete success status type. */
    DELETE_SUCCESS, /* Delete - request successful */
    /** The Delete error. */
    DELETE_ERROR /* Delete - request successful */
  }

  /**
   * Gets key.
   *
   * @return the key that is associated with this message, null if not key is associated.
   */
  public String getKey();

  /**
   * Gets value.
   *
   * @return the value that is associated with this message, null if not value is associated.
   */
  public String getValue();

  /**
   * Gets status.
   *
   * @return a status string that is used to identify request types, response types and error types
   *     associated to the message.
   */
  public StatusType getStatus();
}
