package de.tum.i13.server.kv;

import de.tum.i13.server.kv.cache.CacheManager;
import de.tum.i13.server.kv.fileManagement.KVFileManager;

/** The type File kv store. */
public class FileKVStore implements KVStore {
  /** The Cache manager. */
  CacheManager cacheManager;

  /**
   * Instantiates a new File kv store.
   *
   * @param cacheSize the cache size
   * @param cacheStrategy the cache strategy
   * @param fileManager the file manager
   */
  public FileKVStore(int cacheSize, String cacheStrategy, KVFileManager fileManager) {
    this.cacheManager = new CacheManager(cacheStrategy, cacheSize, fileManager);
  }

  /**
   * Gets cache manager.
   *
   * @return the cache manager
   */
  public CacheManager getCacheManager() {
    return cacheManager;
  }

  @Override
  public KVMessage put(String key, String value) {
    return cacheManager.put(key, value);
  }

  @Override
  public KVMessage get(String key) {
    return cacheManager.get(key);
  }

  public KVMessage delete(String key) {
    return cacheManager.delete(key);
  }
}
