package de.tum.i13.server.threadperconnection;

import de.tum.i13.server.messageQueue.MessageQueue;
import de.tum.i13.server.serverCommand.Command;
import de.tum.i13.shared.Constants;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.net.Socket;
import java.net.SocketException;
import java.util.Arrays;
import java.util.logging.Logger;

/** The type Connection handle thread. */
public class ConnectionHandleThread extends Thread {
  private MessageQueue commandQueue;
  private Socket clientSocket;
  // private LinkedBlockingQueue<Command> commands;

  /**
   * Instantiates a new Connection handle thread.
   *
   * @param clientSocket the client socket
   * @param commandQueue the command queue
   */
  public ConnectionHandleThread(Socket clientSocket, MessageQueue commandQueue) {
    this.commandQueue = commandQueue;
    this.clientSocket = clientSocket;
  }

  /**
   * Accept connection.
   *
   * @throws IOException the io exception
   */
  public void acceptConnection() throws IOException {
    PrintWriter out =
        new PrintWriter(
            new OutputStreamWriter(clientSocket.getOutputStream(), Constants.TELNET_ENCODING));
    out.print(
        "Connection to MSRG KV server established: "
            + clientSocket.getInetAddress().getHostAddress()
            + "\r\n");
    out.flush();
  }

  @Override
  public void run() {
    Logger logger = Logger.getLogger(getClass().getSimpleName());
    logger.info("client connected " + clientSocket.getInetAddress().toString());
    System.out.println("client connected");
    BufferedReader in;
    try {
      in =
          new BufferedReader(
              new InputStreamReader(clientSocket.getInputStream(), Constants.TELNET_ENCODING));

      acceptConnection();
      String firstLine;
      while ((firstLine = in.readLine()) != null) {
        logger.info("Received command: [" + firstLine + "]");
        commandQueue.put(new Command(firstLine, this.clientSocket));
      }
      // close buffered reader
      in.close();
    } catch (SocketException e) {
      System.out.println("client disconnected");
      logger.severe(
          "Client disconnected -> Exception: "
              + e.getMessage()
              + " : "
              + Arrays.toString(e.getStackTrace()));

    } catch (IOException e) {
      logger.severe(
          "IO Error -> Exception:  " + e.getMessage() + " : " + Arrays.toString(e.getStackTrace()));

    } catch (Exception e) {
      logger.severe(
          "Unknown Error ->Exception: "
              + e.getMessage()
              + " : "
              + Arrays.toString(e.getStackTrace()));
    } finally {
      // close connections
      try {
        clientSocket.close();
        logger.info("closing client connection");
        System.out.println("closing client connection");
      } catch (IOException e) {
        System.out.println("error closing client connection");
        logger.info("Error: closing client connection");
        logger.severe(
            "Unknown Error ->Exception: "
                + e.getMessage()
                + " : "
                + Arrays.toString(e.getStackTrace()));
      }
    }
  }

  // @Override
  //  public void run() {
  //    try {
  //      BufferedReader in = new BufferedReader(
  //          new InputStreamReader(clientSocket.getInputStream(), Constants.TELNET_ENCODING));
  //      PrintWriter out = new PrintWriter(
  //          new OutputStreamWriter(clientSocket.getOutputStream(), Constants.TELNET_ENCODING));
  //
  //      String firstLine;
  //      while ((firstLine = in.readLine()) != null) {
  //        commands.add(firstLine);
  //        execute();
  ////        String res = cp.process(firstLine);
  ////        out.write(res);
  ////        out.flush();
  //      }
  //    } catch (Exception ex) {
  //      ex.printStackTrace();
  //    }
  //  }

  //  public void start(LinkedBlockingQueue<String> commands) {
  //    try {
  //      PrintWriter out = new PrintWriter(
  //          new OutputStreamWriter(clientSocket.getOutputStream(), Constants.TELNET_ENCODING));
  //      while (!commands.isEmpty()) {
  //        //String res = cp.process(commands.take());
  //        String res = commands.take();
  //        out.write(res);
  //        out.flush();
  //      }
  //    } catch (Exception ex) {
  //      ex.printStackTrace();
  //    }
  //
  //  }

}
