package de.tum.i13.server.kv.cache.cacheStrategy;

import de.tum.i13.server.kv.cache.CacheableKey;

/** The type Fifo key option. */
public class FIFOKeyOption extends KeyOption {
  private int idx;

  @Override
  public String toString() {
    return "FIFOCacheable{" + "idx=" + idx + '}';
  }

  /**
   * Instantiates a new Fifo key option.
   *
   * @param key the key
   * @param idx the idx
   */
  public FIFOKeyOption(CacheableKey key, int idx) {
    super(key);
    this.idx = idx;
  }

  @Override
  public int compareTo(KeyOption o) {
    FIFOKeyOption tmp = (FIFOKeyOption) o;
    if (idx == tmp.idx)
      return this.getCacheableKey().getKey().compareTo(o.getCacheableKey().getKey());
    return idx - tmp.idx;
  }

  @Override
  public void adjustKeyCriteria() {
    // FIFO does not have a criteria
  }
}
