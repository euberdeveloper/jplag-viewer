package de.tum.i13.server.messageQueue;

import de.tum.i13.server.serverCommand.Command;
import java.util.concurrent.LinkedBlockingQueue;

/** The type Message queue. */
public class MessageQueue {
  private LinkedBlockingQueue<Command> commands;

  /** Instantiates a new Message queue. */
  public MessageQueue() {
    this.commands = new LinkedBlockingQueue<>();
  }

  /**
   * Gets commands.
   *
   * @return the commands
   */
  public LinkedBlockingQueue<Command> getCommands() {
    return commands;
  }

  /**
   * Sets commands.
   *
   * @param commands the commands
   */
  public void setCommands(LinkedBlockingQueue<Command> commands) {
    this.commands = commands;
  }

  /**
   * Put.
   *
   * @param c the c
   * @throws InterruptedException the interrupted exception
   */
  public void put(Command c) throws InterruptedException {
    this.commands.put(c);
  }

  /**
   * Take command.
   *
   * @return the command
   * @throws InterruptedException the interrupted exception
   */
  public Command take() throws InterruptedException {
    return this.commands.take();
  }

  /**
   * Is empty boolean.
   *
   * @return the boolean
   */
  public boolean isEmpty() {
    return (this.commands.isEmpty());
  }
}
