package de.tum.i13.server.kv.cache.cacheStrategy;

import de.tum.i13.server.kv.cache.CacheableKey;

/** The type Lfu key option. */
public class LFUKeyOption extends KeyOption {

  private int freq;

  /**
   * Instantiates a new Lfu key option.
   *
   * @param key the key
   */
  public LFUKeyOption(CacheableKey key) {
    super(key);
    freq = 0;
  }

  @Override
  public String toString() {
    return "LFUCacheable{" +this.getCacheableKey().getKey()+", "+ "freq=" + freq + '}';
  }

  public void adjustKeyCriteria() {
    this.setFreq(getFreq() + 1);
  }

  /**
   * Gets freq.
   *
   * @return the freq
   */
  public int getFreq() {
    return freq;
  }

  /**
   * Sets freq.
   *
   * @param freq the freq
   */
  public void setFreq(int freq) {
    this.freq = freq;
  }

  @Override
  public int compareTo(KeyOption o) {
    LFUKeyOption tmp = (LFUKeyOption) o;
    if (freq == tmp.getFreq())
      return this.getCacheableKey().getKey().compareTo(o.getCacheableKey().getKey());

    return getFreq() - tmp.getFreq();
  }
}
