package de.tum.i13.server.kv.cache;

import de.tum.i13.server.kv.cache.cacheStrategy.KeyOption;
import java.util.Objects;

/** The type Cacheable key. */
public class CacheableKey {

  private String key;
  private KeyOption options;

  /**
   * Instantiates a new Cacheable key.
   *
   * @param key the key
   * @param options the options
   */
  public CacheableKey(String key, KeyOption options) {
    this.key = key;
    this.options = options;
  }

  /**
   * Instantiates a new Cacheable key.
   *
   * @param key the key
   */
  public CacheableKey(String key) {
    this.key = key;
  }

  /**
   * Gets key.
   *
   * @return the key
   */
  public String getKey() {
    return key;
  }

  /**
   * Sets key.
   *
   * @param key the key
   */
  public void setKey(String key) {
    this.key = key;
  }

  /**
   * Gets options.
   *
   * @return the options
   */
  public KeyOption getOptions() {
    return options;
  }

  /**
   * Sets options.
   *
   * @param options the options
   */
  public void setOptions(KeyOption options) {
    this.options = options;
  }

  @Override
  public String toString() {
    return "CacheableKey{" +
        "key='" + key + '\'' +
        ", options=" + options +
        '}';
  }

  // we check equality by equating keys only
  @Override
  public boolean equals(Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    CacheableKey that = (CacheableKey) o;
    return Objects.equals(key, that.key);
  }

  // we check equality by equating keys only

  @Override
  public int hashCode() {
    return Objects.hash(key);
  }
}
