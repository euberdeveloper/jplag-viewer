package de.tum.i13.server.kv;

import de.tum.i13.server.kv.KVMessage.StatusType;
import de.tum.i13.shared.CommandProcessor;
import de.tum.i13.shared.Constants;
import java.util.Arrays;
import java.util.logging.Logger;

/** The type Kv command processor. */
public class KVCommandProcessor implements CommandProcessor {
  private KVStore kvStore;

  private final Logger logger;

  /**
   * Instantiates a new Kv command processor.
   *
   * @param kvStore the kv store
   */
  public KVCommandProcessor(KVStore kvStore) {
    this.kvStore = kvStore;
    logger = Logger.getLogger(getClass().getSimpleName());
  }

  private String[] checkMessage(String command) {
    //
    if (command.length() < 2) {
      throw new IllegalArgumentException(" unknown command");
    }
    // server can take split limit up to 3
    String[] args = command.split(" ", 3);
    //    System.out.println(Arrays.toString(args));
    // unknown command
    if (args.length < 2) {
      throw new IllegalArgumentException(" unknown command");
    }
    //    String cmd = args[0];
    String key = args[1];
    String value = args.length >= 3 ? args[2] : "";
    // check message size compliant
    if (key.length() <= 20 && value.length() <= 120 * 1024) {
      return args;
    } else {
      throw new IllegalArgumentException(" key or value size is too big");
    }
  }

  @Override
  public String process(String command) {
    // split < 3 times for get, delete and 3 times for put
    String response;
    KVMessage reply;
    try {
      String[] commandArgs = checkMessage(command);
      switch (commandArgs[0]) {
        case "put":
          if (commandArgs.length == 3) {

            // check if value is null call delete

            reply = this.kvStore.put(commandArgs[1], commandArgs[2]);

            response = parseKVResponse(reply);
          } else {
            response = Constants.SERVER_ERROR_MESSAGE;
          }
          break;
        case "get":
          reply = this.kvStore.get(commandArgs[1]);
          response = parseKVResponse(reply);
          break;
        case "delete":
          reply = this.kvStore.delete(commandArgs[1]);
          response = parseKVResponse(reply);
          break;
        default:
          logger.info("unknown command received");
          return Constants.SERVER_ERROR_MESSAGE;
      }

      return response;
    } catch (IllegalArgumentException e) {
      logger.severe(
          "IO Error -> Exception:  " + e.getMessage() + " : " + Arrays.toString(e.getStackTrace()));
      return Constants.SERVER_ERROR_MESSAGE;
    } catch (Exception e) {
      logger.severe(
          "IO Error -> Exception:  " + e.getMessage() + " : " + Arrays.toString(e.getStackTrace()));
      return "unknown Error";
    }
  }

  private String parseKVResponse(KVMessage message) {
    String value = "";
    if (message.getStatus() == StatusType.PUT_ERROR
        || message.getStatus() == StatusType.GET_SUCCESS) value = " " + message.getValue();

    return message.getStatus().toString().toLowerCase() + " " + message.getKey() + value;
  }
}
