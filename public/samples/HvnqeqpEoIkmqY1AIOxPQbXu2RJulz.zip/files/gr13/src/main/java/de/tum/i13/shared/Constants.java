package de.tum.i13.shared;

/** The type Constants. */
public class Constants {
  /** The constant TELNET_ENCODING. */
  public static final String TELNET_ENCODING = "ISO-8859-1"; // encoding for telnet

  /** The constant CLIENT_HELP. */
  public static final String CLIENT_HELP =
      "\n connect <address> <port>: establish a connection"
          + " \n disconnect: disconnect an established connection"
          + " \n send <message>: to send a message"
          + " \n logLevel <level>: to set the logger to the specified log level"
          + " \n help: show help info"
          + "\n put <key> <value>: save key value pair value to server"
          + " \n get <key>: get saved value from server"
          + " \n delete <key>: delete value corresponding to key from server"
          + " \n quit: to teardown the active connection to the server and exits the program execution";

  /** The constant SERVER_HELP. */
  public static final String SERVER_HELP =
      "\n API: put <key> <value>: save value for specific key"
          + " \n get <key>: return saved value for key if exist"
          + "\n delete <key>: remove certain value corresponding to key \n"
          + " CLI parameters:\n"
          + " \n -p: Sets the port of the server"
          + " \n -a: Which address the server should listen to, default is 127.0.0.1"
          + " \n -b: Bootstrap broker (Used by the client as the first broker to connect to and all other brokers to bootstrap)"
          + " \n -d: Directory for files (Put here the files you need to persist the data (server file system)"
          + " \n -l: Relative path of the logfile"
          + " \n -ll: Log level"
          + " \n -c: Size of the cache"
          + " \n -s: Cache displacement strategy, FIFO, LRU, LFU,"
          + " \n -h: Displays help";

  /** The constant SERVER_ERROR_MESSAGE. */
  public static final String SERVER_ERROR_MESSAGE =
      "error :Server  supports -> "
          + " put <key> <value>|"
          + "get <key>|"
          + "delete <key>"
          + "  -> [key or value are too big, key should not be more than 20 bytes and value should be less than 120 KB]";
}
