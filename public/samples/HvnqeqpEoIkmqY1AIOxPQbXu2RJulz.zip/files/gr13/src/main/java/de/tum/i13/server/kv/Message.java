package de.tum.i13.server.kv;

/** The type Message. */
public class Message implements KVMessage {

  /** The Key. */
  String key;

  /** The Value. */
  String value;

  /** The Status. */
  StatusType status;

  /**
   * Instantiates a new Message.
   *
   * @param key the key
   * @param value the value
   * @param status the status
   */
  public Message(String key, String value, StatusType status) {
    this.key = key;
    this.value = value;
    this.status = status;
  }

  @Override
  public boolean equals(Object m) {
    if (m == null) return false;
    if (!(m instanceof Message)) return false;
    Message m1 = (Message) m;
    boolean sameNull = this.value == null && m1.value == null;
    boolean sameNotNull = this.value != null && this.value.equals(m1.value);
    boolean sameValue = sameNotNull || sameNull;
    return (this.key.equals(m1.key) && sameValue && this.status == m1.status);
  }

  @Override
  public String toString() {
    return "Message{"
        + "key='"
        + key
        + '\''
        + ", value='"
        + value
        + '\''
        + ", status="
        + status
        + '}';
  }

  @Override
  public String getKey() {
    return key;
  }

  @Override
  public String getValue() {
    return value;
  }

  @Override
  public StatusType getStatus() throws IllegalArgumentException {
    return status;
  }
}
