package de.tum.i13.server.kv.fileManagement;

import java.util.Base64;

/** The type Base 64 encoder decoder. */
public class Base64EncoderDecoder {
  /**
   * Encode string string.
   *
   * @param s the s
   * @return the string
   */
  public String encodeString(String s) {
    return Base64.getEncoder().encodeToString(s.getBytes());
  }

  /**
   * Decode string string.
   *
   * @param s the s
   * @return the string
   */
  public String decodeString(String s) {
    return new String(Base64.getDecoder().decode(s.getBytes()));
  }

  /**
   * Hash string.
   *
   * @param s the s
   * @return the string
   */
  public String hash(String s) {
    return encodeChar(s.charAt(0));
  }

  /**
   * Encode char string.
   *
   * @param c the c
   * @return the string
   */
  public String encodeChar(char c) {
    String s = "" + c;
    return Base64.getEncoder().encodeToString(s.getBytes());
  }
}
