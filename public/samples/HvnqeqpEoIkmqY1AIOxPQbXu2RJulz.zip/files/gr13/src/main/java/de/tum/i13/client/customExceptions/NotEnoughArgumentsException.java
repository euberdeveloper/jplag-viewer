package de.tum.i13.client.customExceptions;

/** The type Not enough arguments exception. */
public class NotEnoughArgumentsException extends Exception {

  /**
   * Instantiates a new Not enough arguments exception.
   *
   * @param message the message
   */
  public NotEnoughArgumentsException(String message) {
    super(message);
  }
}
