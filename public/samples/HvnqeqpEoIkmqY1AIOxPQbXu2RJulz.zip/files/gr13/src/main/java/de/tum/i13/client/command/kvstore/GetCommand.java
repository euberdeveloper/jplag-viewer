package de.tum.i13.client.command.kvstore;

import de.tum.i13.client.ClientCLI;
import de.tum.i13.client.ClientLib;
import de.tum.i13.client.customExceptions.NotEnoughArgumentsException;
import java.io.IOException;
import java.util.logging.Logger;

/** The type Get command. */
public class GetCommand extends KVCommand {

  /**
   * Instantiates a new Send command.
   *
   * @param clientCLI active CLI instance
   * @param client client
   * @param logger logger for logging errors and info
   * @param numArgs number of arguments provided
   * @param ignoreSpace boolean for ignoring whitespace
   */
  public GetCommand(
      ClientCLI clientCLI, ClientLib client, Logger logger, int numArgs, boolean ignoreSpace) {
    super(clientCLI, client, logger, numArgs, ignoreSpace);
  }

  /**
   * Sends the string `message` to the server, and then waits for a reply which it prints back out
   * to the user.
   *
   * @param key message sent by the user
   * @throws IOException io exception
   */
  public void get(String key) throws IOException {

    sendMessageToServer("get", key);
    String response = new String(client.receive());
    parseServerResponse(response);
  }

  public void process(String[] arguments)
      throws NotEnoughArgumentsException, IllegalArgumentException, IOException {
    this.verifyArgsNo(arguments);
    this.get(arguments[0]);
  }
}
