package de.tum.i13.client.command.kvstore;

import de.tum.i13.client.ClientCLI;
import de.tum.i13.client.ClientLib;
import de.tum.i13.client.command.Command;
import de.tum.i13.client.encoderDecoder.EncoderDecoder;
import java.io.IOException;
import java.util.logging.Logger;

/** The type Kv command. */
public abstract class KVCommand extends Command {

  /**
   * Instantiates a new Command.
   *
   * @param clientCLI active CLI instance
   * @param client client
   * @param logger logger for logging errors and info
   * @param numArgs number of arguments provided
   * @param ignoreSpace boolean for ignoring whitespace
   */
  public KVCommand(
      ClientCLI clientCLI, ClientLib client, Logger logger, int numArgs, boolean ignoreSpace) {
    super(clientCLI, client, logger, numArgs, ignoreSpace);
  }

  /**
   * Send message to server. message contains key -> encode key then send
   *
   * @param verb the verb
   * @param key the key
   * @throws IOException the io exception
   */
  public void sendMessageToServer(String verb, String key) throws IOException {
    String fullMessage = encodeMessage(verb + " " + key) + clientCLI.DELIMITER;
    client.send(fullMessage.getBytes());
  }

  /**
   * Send message to server. message contains key and value pair -> encode key and value then send
   *
   * @param verb the verb
   * @param key the key
   * @param value the value
   * @throws IOException the io exception
   */
  public void sendMessageToServer(String verb, String key, String value) throws IOException {
    String fullMessage = encodeMessage(verb + " " + key + " " + value) + clientCLI.DELIMITER;
    client.send(fullMessage.getBytes());
  }
  /**
   * Parse server response. decode server response
   *
   * @param response the response
   */
  public void parseServerResponse(String response) {
    try {
      // remove /r/n
      response = response.substring(0, response.length() - 2);
      String result = decodeMessage(response);
      logger.fine(result);
      clientCLI.messageCLI(result, true);
    } catch (IndexOutOfBoundsException | IllegalArgumentException e) {
      logger.fine("server responded with unknown format:" + response);
      clientCLI.messageCLI(response, true);
    }
  }

  /**
   * Decode message string.
   *
   * @param message the message
   * @return the string
   * @throws IllegalArgumentException the illegal argument exception
   */
  private static String decodeMessage(String message) throws IllegalArgumentException {
    String items[] = message.split(" ", 3);

    // if get success the value is decoded
    String result = items[0] + " " + EncoderDecoder.decodeString(items[1]);
    if (items.length == 3) {
      // decode value if present
      result += " " + EncoderDecoder.decodeString(items[2]);
    }
    return result;
  }

  /**
   * Encode message string.
   *
   * @param message the message
   * @return the string
   * @throws IllegalArgumentException the illegal argument exception
   */
  private static String encodeMessage(String message) throws IllegalArgumentException {
    String[] items = message.split(" ", 3);

    // if get success the value is decoded
    String result = items[0] + " " + EncoderDecoder.encodeString(items[1]);
    if (items.length == 3) {
      // decode value if present
      result += " " + EncoderDecoder.encodeString(items[2]);
    }
    return result;
  }
}
