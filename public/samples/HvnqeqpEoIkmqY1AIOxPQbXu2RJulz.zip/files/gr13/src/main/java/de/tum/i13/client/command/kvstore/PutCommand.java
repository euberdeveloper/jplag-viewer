package de.tum.i13.client.command.kvstore;

import de.tum.i13.client.ClientCLI;
import de.tum.i13.client.ClientLib;
import de.tum.i13.client.customExceptions.NotEnoughArgumentsException;
import java.io.IOException;
import java.util.logging.Logger;

/** The type Put command. */
public class PutCommand extends KVCommand {

  /**
   * Instantiates a new Send command.
   *
   * @param clientCLI active CLI instance
   * @param client client
   * @param logger logger for logging errors and info
   * @param numArgs number of arguments provided
   * @param ignoreSpace boolean for ignoring whitespace
   */
  public PutCommand(
      ClientCLI clientCLI, ClientLib client, Logger logger, int numArgs, boolean ignoreSpace) {
    super(clientCLI, client, logger, numArgs, ignoreSpace);
  }

  /**
   * Sends the string `message` to the server, and then waits for a reply which it prints back out
   * to the user.
   *
   * @param key message sent by the user
   * @param value message sent by the user
   * @throws IOException io exception
   */
  public void put(String key, String value) throws IOException {

    this.sendMessageToServer("put", key, value);
    String response = new String(client.receive());
    logger.fine(response);
    parseServerResponse(response);
  }

  public void process(String[] arguments)
      throws NotEnoughArgumentsException, IllegalArgumentException, IOException {
    this.verifyArgsNo(arguments);
    this.put(arguments[0], arguments[1]);
  }
}
