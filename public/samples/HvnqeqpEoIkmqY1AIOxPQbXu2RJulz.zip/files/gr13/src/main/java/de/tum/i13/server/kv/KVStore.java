package de.tum.i13.server.kv;

/** The interface Kv store. */
public interface KVStore {

  /**
   * Inserts a key-value pair into the KVServer.
   *
   * @param key the key that identifies the given value.
   * @param value the value that is indexed by the given key.
   * @return a message that confirms the insertion of the tuple or an error.
   */
  public KVMessage put(String key, String value);

  /**
   * Retrieves the value for a given key from the KVServer.
   *
   * @param key the key that identifies the value.
   * @return the value, which is indexed by the given key.
   */
  public KVMessage get(String key);

  /**
   * Delete kv message.
   *
   * @param key the key
   * @return the kv message
   */
  public KVMessage delete(String key);
}
