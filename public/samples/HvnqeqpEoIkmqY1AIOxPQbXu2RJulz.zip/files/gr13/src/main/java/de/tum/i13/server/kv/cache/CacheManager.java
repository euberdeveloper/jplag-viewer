package de.tum.i13.server.kv.cache;

import de.tum.i13.server.kv.KVMessage;
import de.tum.i13.server.kv.KVMessage.StatusType;
import de.tum.i13.server.kv.Message;
import de.tum.i13.server.kv.cache.cacheStrategy.FIFOKeyOption;
import de.tum.i13.server.kv.cache.cacheStrategy.KeyOption;
import de.tum.i13.server.kv.cache.cacheStrategy.LFUKeyOption;
import de.tum.i13.server.kv.cache.cacheStrategy.LRUKeyOption;
import de.tum.i13.server.kv.fileManagement.KVFileManager;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentSkipListSet;
import java.util.logging.Logger;

/** The type Cache manager. */
public class CacheManager {

  //  private CacheOrganizer cacheParams;
  private final String strategy;

  private ConcurrentHashMap<CacheableKey, String> cache;
  private ConcurrentSkipListSet<KeyOption> cacheOptions;
  private ConcurrentHashMap<String, CacheableKey> keysToCacheables;
  private final int maxCacheSize;

  private final KVFileManager fileManager;

  private final Logger logger;

  /**
   * Instantiates a new Cache manager.
   *
   * @param strategy the strategy
   * @param maxCacheSize the max cache size
   * @param fileManager the file manager
   */
  public CacheManager(String strategy, int maxCacheSize, KVFileManager fileManager) {

    this.strategy = strategy;
    this.maxCacheSize = maxCacheSize;
    this.fileManager = fileManager;

    clearCache();

    logger = Logger.getLogger(getClass().getSimpleName());
    logger.info("cache strategy set to " + strategy);

    // add write what's inside cache to disk
    Runtime.getRuntime()
        .addShutdownHook(
            new Thread(
                () -> {
                  System.out.println("Writing cache to file");
                  logger.info(" writing to cache to file");
                  writeCacheToDisk();
                }));
  }

  /**
   * Gets cache.
   *
   * @return the cache
   */
  public ConcurrentHashMap<CacheableKey, String> getCache() {
    return cache;
  }

  /**
   * Gets keys to cacheables.
   *
   * @return the keys to cacheables
   */
  public ConcurrentHashMap<String, CacheableKey> getKeysToCacheables() {
    return keysToCacheables;
  }

  private void setOptions(CacheableKey key) {
    KeyOption option;

    switch (strategy) {
      case "LRU":
        option = new LRUKeyOption(key);
        break;
      case "LFU":
        option = new LFUKeyOption(key);
        break;

      default: // case for FIFO or default value
        option = new FIFOKeyOption(key, cache.size());
    }
    key.setOptions(option);
  }

  private void insertNewKeyToCache(String key, String value) {
    CacheableKey k = new CacheableKey(key);
    setOptions(k);
    // key not in cache
    if (this.isFull()) {
      // cache full offload to disk
      displaceCache();
    }

    updateKeyInCache(k, value);
  }

  private void updateKeyInCache(CacheableKey k, String value) {
    updateOptionsSet(k.getOptions());
    keysToCacheables.put(k.getKey(), k);
    cache.put(k, value);
  }

  /**
   * Put kv message.
   *
   * @param key the key
   * @param value the value
   * @return the kv message
   */
  public synchronized KVMessage put(String key, String value) {
    CacheableKey k = keysToCacheables.get(key);
    KVMessage returnMessage;
    if (k == null) {

      logger.info("key not in cache");
      // this is a new key
      // remove last element from cache according to policy if size will exceed

      // insert new key into cache attributes
      insertNewKeyToCache(key, value);
      // check file manager
      KVMessage messageInFile = fileManager.get(key);

      if (messageInFile.getStatus() == StatusType.GET_SUCCESS) {
        returnMessage = new Message(key, value, StatusType.PUT_UPDATE);

      } else {
        returnMessage = new Message(key, value, StatusType.PUT_SUCCESS);
      }
    } else {
      // key in cache
      updateKeyInCache(k, value);
      returnMessage = new Message(key, value, StatusType.PUT_UPDATE);
    }

    return returnMessage;
  }

  /** Clear cache. */
  public synchronized void clearCache() {
    cache = new ConcurrentHashMap<>();
    keysToCacheables = new ConcurrentHashMap<>();
    cacheOptions = new ConcurrentSkipListSet<>();
  }

  /**
   * Update options treeSet structure when updating map when a key is accessed
   *
   * @param k the k
   */
  private synchronized void updateOptionsSet(KeyOption k) {
    cacheOptions.remove(k);
    k.adjustKeyCriteria();
    cacheOptions.add(k);
  }
  /**
   * Is full boolean.
   *
   * @return the boolean
   */
  public boolean isFull() {
    return this.cache.size() == this.maxCacheSize;
  }

  /** Displace cache. */
  public synchronized void displaceCache() {
    logger.info("cache full, cache displacement will occur.");
    if (cache.size() > 0) {

      KeyOption option = cacheOptions.pollFirst();
      if (option != null) {
        // offload data to cache
        String key = option.getCacheableKey().getKey();
        String value = this.cache.get(option.getCacheableKey());
        // check here fileManager error in  put
        fileManager.put(key, value);
        // end offload data to cache
        this.cache.remove(option.getCacheableKey());
        keysToCacheables.remove(option.getCacheableKey().getKey());
      }
    }
  }

  /**
   * Get kv message.
   *
   * @param key the key
   * @return the kv message
   */
  public synchronized KVMessage get(String key) {
    // calls the put function above
    CacheableKey wanted = keysToCacheables.get(key);
    // remove first
    if (wanted != null && cache.containsKey(wanted)) {

      updateOptionsSet(wanted.getOptions());
      return new Message(key, cache.get(wanted), StatusType.GET_SUCCESS);
    } else {
      logger.info("key not in cache");
      KVMessage message = fileManager.get(key);
      // no exception thrown means key found
      if (message.getStatus() == StatusType.GET_SUCCESS) {
        // put key in cache
        insertNewKeyToCache(message.getKey(), message.getValue());
      }
      return message;
    }
  }

  /**
   * Delete kv message.
   *
   * @param key the key
   * @return the kv message
   */
  public synchronized KVMessage delete(String key) {
    CacheableKey k = keysToCacheables.get(key);
    boolean keyFound = false;
    if (fileManager.get(key).getStatus() == StatusType.GET_SUCCESS) {
      keyFound = true;
      KVMessage fileManagerResponse = fileManager.delete(key);
      if (fileManagerResponse.getStatus() == StatusType.DELETE_ERROR) {
        // error occurred in deletion
        return fileManagerResponse;
      }
    }
    if (k != null) {
      keyFound = true;
      cacheOptions.remove(k.getOptions());
      keysToCacheables.remove(key);
      cache.remove(k);
    }

    return new Message(key, null, keyFound ? StatusType.DELETE_SUCCESS : StatusType.DELETE_ERROR);
  }

  /** Write cache to disk. */
  public synchronized void writeCacheToDisk() {
    while (!cache.isEmpty()) {
      displaceCache();
    }
  }
}
