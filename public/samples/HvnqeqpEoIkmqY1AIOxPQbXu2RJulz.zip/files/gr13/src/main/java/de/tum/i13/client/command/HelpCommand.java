package de.tum.i13.client.command;

import de.tum.i13.client.ClientCLI;
import de.tum.i13.client.ClientLib;
import de.tum.i13.client.customExceptions.NotEnoughArgumentsException;
import de.tum.i13.shared.Constants;
import java.util.logging.Logger;

/** The type Log level command. */
public class HelpCommand extends Command {
  private final String HELP_INFO = Constants.CLIENT_HELP;

  /**
   * Instantiates a new Help command.
   *
   * @param clientCLI active CLI instance
   * @param client client
   * @param logger logger for logging errors and info
   * @param numArgs number of arguments provided
   * @param ignoreSpace boolean for ignoring whitespace
   */
  public HelpCommand(
      ClientCLI clientCLI, ClientLib client, Logger logger, int numArgs, boolean ignoreSpace) {
    super(clientCLI, client, logger, numArgs, ignoreSpace);
  }

  public void process(String[] arguments)
      throws NotEnoughArgumentsException, IllegalArgumentException {

    this.verifyArgsNo(arguments);
    logger.info(HELP_INFO);
    clientCLI.messageCLI(HELP_INFO, true);
  }
}
