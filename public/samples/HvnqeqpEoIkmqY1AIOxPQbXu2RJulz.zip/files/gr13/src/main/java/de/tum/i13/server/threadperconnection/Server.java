package de.tum.i13.server.threadperconnection;

import de.tum.i13.server.messageQueue.MessageQueue;
import de.tum.i13.server.messageQueue.QueueConsumer;
import de.tum.i13.shared.Config;
import java.io.IOException;
import java.net.InetSocketAddress;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.logging.Logger;

/** Created by chris on 09.01.15. */
public class Server {
  private final ServerSocket serverSocket;
  private final Config CFG;
  private final MessageQueue commandQueue;

  private Logger logger;

  /**
   * Gets server socket.
   *
   * @return the server socket
   */
  public ServerSocket getServerSocket() {
    return serverSocket;
  }

  /**
   * Instantiates a new Server.
   *
   * @param cfg the cfg
   * @throws IOException the io exception
   */
  public Server(Config cfg) throws IOException {
    serverSocket = new ServerSocket();
    CFG = cfg;
    logger = Logger.getLogger("Server");
    // make new global queue should contain <clientID, command>
    commandQueue = new MessageQueue();
  }

  /**
   * Init.
   *
   * @throws IOException the io exception
   */
  public void init() throws IOException {
    Runtime.getRuntime()
        .addShutdownHook(
            new Thread() {
              @Override
              public void run() {
                System.out.println("Closing thread per connection kv server");
                logger.info("Shutting down server");
                try {
                  serverSocket.close();
                } catch (IOException e) {
                  e.printStackTrace();
                }
              }
            });

    // bind to localhost only
    serverSocket.bind(new InetSocketAddress(CFG.listenaddr, CFG.port));
    System.out.println("Socket bound");
    logger.info("Socket bound");

    // Replace with your Key value server logic.
    // If you use multithreading you need locking

    // runs in a separate thread to consume the queue
    Thread commandConsumer = new QueueConsumer(commandQueue, CFG);
    commandConsumer.start();
  }

  /**
   * Start.
   *
   * @throws IOException the io exception
   */
  public void start() throws IOException {
    System.out.println(
        "server started: accepting connections on " + CFG.listenaddr + " " + CFG.port);
    logger.info("server started: accepting connections on " + CFG.listenaddr + " " + CFG.port);
    while (true) {
      Socket clientSocket = serverSocket.accept();
      // When we accept a connection, we start a new Thread for this connection
      Thread th = new ConnectionHandleThread(clientSocket, commandQueue);
      th.start();
    }
  }
}
