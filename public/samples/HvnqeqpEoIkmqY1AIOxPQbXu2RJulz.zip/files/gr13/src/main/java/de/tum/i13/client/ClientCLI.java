package de.tum.i13.client;

import static de.tum.i13.shared.LogSetup.setupLogging;

import de.tum.i13.client.command.Command;
import de.tum.i13.client.command.ConnectCommand;
import de.tum.i13.client.command.DisconnectCommand;
import de.tum.i13.client.command.HelpCommand;
import de.tum.i13.client.command.LogLevelCommand;
import de.tum.i13.client.command.QuitCommand;
import de.tum.i13.client.command.SendCommand;
import de.tum.i13.client.command.kvstore.DeleteCommand;
import de.tum.i13.client.command.kvstore.GetCommand;
import de.tum.i13.client.command.kvstore.PutCommand;
import de.tum.i13.client.customExceptions.NotEnoughArgumentsException;
import java.io.IOException;
import java.io.PrintWriter;
import java.net.SocketTimeoutException;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;
import java.util.NoSuchElementException;
import java.util.Scanner;
import java.util.logging.Logger;

/** The type Client cli. */
public class ClientCLI {
  /** Delimiter accepted by client CLI. */
  public final String DELIMITER = "\r\n";

  private final Scanner SC = new Scanner(System.in);
  private final PrintWriter PW = new PrintWriter(System.out);
  private final Logger logger;
  /** variable to determine the state of the CLI. */
  boolean quit;

  private Map<String, Command> commands;

  /**
   * Gets commands.
   *
   * @return the commands
   */
  public Map<String, Command> getCommands() {
    return commands;
  }

  /** Instantiates a new Client cli. */
  public ClientCLI() {
    ClientLib client = new ClientLib(10000);
    quit = false;
    logger = Logger.getLogger(getClass().getSimpleName());
    // init commands in a map
    commands = new HashMap<>();
    commands.put("connect", new ConnectCommand(this, client, logger, 2, false));
    commands.put("disconnect", new DisconnectCommand(this, client, logger, 0, false));
    commands.put("logLevel", new LogLevelCommand(this, client, logger, 1, false));
    commands.put("send", new SendCommand(this, client, logger, 1, true));
    commands.put("help", new HelpCommand(this, client, logger, 0, false));
    commands.put("quit", new QuitCommand(this, client, logger, 0, false));
    commands.put("put", new PutCommand(this, client, logger, 2, true));
    commands.put("get", new GetCommand(this, client, logger, 1, false));
    commands.put("delete", new DeleteCommand(this, client, logger, 1, false));
  }

  /**
   * messageCLI: prints a message to the console
   *
   * @param msg message to be printed to the client
   * @param hasDelimiter determine whether we should add message delimiter or not
   */
  public void messageCLI(String msg, boolean hasDelimiter) {
    PW.print("Client> " + msg + (hasDelimiter ? this.DELIMITER : ""));
    PW.flush();
  }

  /**
   * Split arguments into a list of strings
   *
   * @param limit number of params supported by the client
   * @param args the args
   * @param ignoreSpaces the ignore spaces
   * @return string [ ] list of arguments
   */
  public String[] splitArgs(int limit, String args, boolean ignoreSpaces) {
    if (args == null || args.equals("")) return new String[0];
    if (ignoreSpaces) { // if command ignore spaces all parse according to the command limit
      return args.split("\\s+", limit);
    } else {
      return args.split("\\s+");
    }
  }

  /** Stop the CLI from running */
  public void stop() {
    this.quit = true;
  }

  /** Start CLI */
  public void start() {
    // disable logger spamming console
    setupLogging("logs/client.log");

    Runtime.getRuntime()
        .addShutdownHook(
            new Thread(
                () -> {
                  try {
                    commands.get("quit").process(new String[0]);
                    PW.close();
                    SC.close();
                    logger.info("Shutting down client");
                  } catch (NotEnoughArgumentsException | IOException e) {
                    e.printStackTrace();
                  }
                }));

    logger.info("Creating a new Socket");
    String userIn;
    try {

      while (!quit) {
        messageCLI("", false);
        userIn = SC.nextLine();
        if (userIn == null) {
          break;
        }
        try {
          // split user input to 2
          String[] split = userIn.split(" ", 2);
          String command = split[0];
          String arguments = split.length > 1 ? split[1] : null;
          String[] argumentList;
          if (commands.containsKey(command)) {
            Command c = commands.get(command);
            argumentList = this.splitArgs(c.getNumArgs(), arguments, c.isSpaceIgnored());
            c.process(argumentList);

          } else {
            logger.info("Unknown command");
            messageCLI("unknown Command", true);
            Command c = commands.get("help");
            argumentList = this.splitArgs(c.getNumArgs(), null, c.isSpaceIgnored());
            c.process(argumentList);
          }

        } catch (SocketTimeoutException e) {

          messageCLI("Message timed out", true);
          logger.severe(e.getClass().getSimpleName() + " - " + Arrays.toString(e.getStackTrace()));

        } catch (NotEnoughArgumentsException e) {

          messageCLI("Invalid number of args," + e.getMessage() + ", refer to <help>", true);
          logger.severe("," + Arrays.toString(e.getStackTrace()));

        } catch (IllegalArgumentException e) {

          messageCLI("Invalid Argument," + e.getMessage() + ", refer to  <help>", true);
          logger.severe("Invalid Argument value," + Arrays.toString(e.getStackTrace()));

        } catch (SecurityException e) {

          messageCLI("Security Error: " + e.getMessage(), true);
          logger.severe(
              "Error:" + e.getClass().getSimpleName() + Arrays.toString(e.getStackTrace()));

        } catch (IOException e) {

          messageCLI("Error Sending message or establishing connection: " + e.getMessage(), true);
          logger.severe(
              "Error:" + e.getClass().getSimpleName() + Arrays.toString(e.getStackTrace()));

        } catch (Exception e) {

          messageCLI("Unknown Error:" + e.getMessage(), true);
          logger.throwing(ClientCLI.class.getName(), "main", e);
        }
      }

    } catch (NoSuchElementException e) {
      logger.severe(
          "Client CLI empty:" + e.getClass().getSimpleName() + Arrays.toString(e.getStackTrace()));
    } catch (Exception e) {
      messageCLI("Unknown Error:" + e.getMessage(), true);
      logger.throwing(ClientCLI.class.getName(), "main", e);
    }
  }
}
