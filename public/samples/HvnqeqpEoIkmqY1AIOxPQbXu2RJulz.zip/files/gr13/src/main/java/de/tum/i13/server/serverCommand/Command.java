package de.tum.i13.server.serverCommand;

import java.net.Socket;

/** The type Command. */
public class Command {
  private Socket commandOwner;
  private String command;

  /**
   * Instantiates a new Command.
   *
   * @param command the command
   * @param commandOwner the command owner
   */
  public Command(String command, Socket commandOwner) {
    this.command = command;
    this.commandOwner = commandOwner;
  }

  /**
   * Gets command owner.
   *
   * @return the command owner
   */
  public Socket getCommandOwner() {
    return commandOwner;
  }

  /**
   * Sets command owner.
   *
   * @param commandOwner the command owner
   */
  public void setCommandOwner(Socket commandOwner) {
    this.commandOwner = commandOwner;
  }

  /**
   * Gets command.
   *
   * @return the command
   */
  public String getCommand() {
    return command;
  }

  /**
   * Sets command.
   *
   * @param command the command
   */
  public void setCommand(String command) {
    this.command = command;
  }
}
