package de.tum.i13.client.encoderDecoder;

import java.util.Base64;

/** The type Encoder decoder. */
public class EncoderDecoder {

//  /**
//   * Decode message string.
//   *
//   * @param message the message
//   * @return the string
//   * @throws IllegalArgumentException the illegal argument exception
//   */
//  public static String decodeMessage(String message) throws IllegalArgumentException {
//    String items[] = message.split(" ", 3);
//
//    // if get success the value is decoded
//    String result = items[0] + " " + EncoderDecoder.decodeString(items[1]);
//    if (items.length == 3) {
//      // decode value if present
//      result += " " + decodeString(items[2]);
//    }
//    return result;
//  }
//
//  /**
//   * Encode message string.
//   *
//   * @param message the message
//   * @return the string
//   * @throws IllegalArgumentException the illegal argument exception
//   */
//  public static String encodeMessage(String message) throws IllegalArgumentException {
//    String items[] = message.split(" ", 3);
//
//    // if get success the value is decoded
//    String result = items[0] + " " + EncoderDecoder.encodeString(items[1]);
//    if (items.length == 3) {
//      // decode value if present
//      result += " " + encodeString(items[2]);
//    }
//    return result;
//  }

  public static String decodeString(String s) throws IllegalArgumentException {
    return new String(Base64.getDecoder().decode(s.getBytes()));
  }

  public static String encodeString(String s) throws IllegalArgumentException {
    return Base64.getEncoder().encodeToString(s.getBytes());
  }
}
