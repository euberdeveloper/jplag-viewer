package de.tum.i13.client.command;

import de.tum.i13.client.ClientCLI;
import de.tum.i13.client.ClientLib;
import de.tum.i13.client.customExceptions.NotEnoughArgumentsException;
import java.util.logging.Level;
import java.util.logging.Logger;

/** The type Log level command. */
public class LogLevelCommand extends Command {

  /**
   * Instantiates a new Log level command.
   *
   * @param clientCLI active CLI instance
   * @param client client
   * @param logger logger for logging errors and info
   * @param numArgs number of arguments provided
   * @param ignoreSpace boolean for ignoring whitespace
   */
  public LogLevelCommand(
      ClientCLI clientCLI, ClientLib client, Logger logger, int numArgs, boolean ignoreSpace) {
    super(clientCLI, client, logger, numArgs, ignoreSpace);
  }

  /**
   * Changes the logger's minimum logging level.
   *
   * @param newLevel level to be set
   * @throws IllegalArgumentException illegal argument exception
   */
  public void logLevel(Level newLevel) throws IllegalArgumentException {
    Level oldLevel = logger.getLevel();
    if (oldLevel == newLevel) {
      logger.info("Logger level is already set to this value");
      clientCLI.messageCLI("Logger level is already set to this value", true);
    } else {
      logger.setLevel(newLevel);
      String oldName = oldLevel != null ? oldLevel.getName() : "None";
      clientCLI.messageCLI("Logger level set from " + oldName + " to " + newLevel.getName(), true);
      logger.info("Logger level set from " + oldName + " to " + newLevel.getName());
    }
  }

  public void process(String[] arguments)
      throws NotEnoughArgumentsException, IllegalArgumentException, SecurityException {

    this.verifyArgsNo(arguments);
    Level newLevel = Level.parse(arguments[0]);
    this.logLevel(newLevel);
  }
}
