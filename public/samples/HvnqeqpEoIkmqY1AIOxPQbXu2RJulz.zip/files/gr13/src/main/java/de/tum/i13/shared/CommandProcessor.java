package de.tum.i13.shared;

/** The interface Command processor. */
public interface CommandProcessor {

  /**
   * Process string.
   *
   * @param command the command
   * @return the string
   */
  String process(String command);
}
