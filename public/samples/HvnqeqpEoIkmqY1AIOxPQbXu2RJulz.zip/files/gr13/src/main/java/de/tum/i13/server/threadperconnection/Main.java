package de.tum.i13.server.threadperconnection;

import static de.tum.i13.shared.Config.parseCommandlineArgs;
import static de.tum.i13.shared.LogSetup.setupLogLevel;
import static de.tum.i13.shared.LogSetup.setupLogging;

import de.tum.i13.shared.Config;
import de.tum.i13.shared.Constants;
import java.io.IOException;
import java.net.SocketException;
import java.util.Arrays;
import java.util.logging.Logger;

/** The type Main. */
public class Main {
  /**
   * The entry point of application.
   *
   * @param args the input arguments
   */
  public static void main(String[] args) {
    Config cfg = parseCommandlineArgs(args); // Do not change this
    // Check for help flag in config object
    if (cfg.usagehelp) {
      System.out.println(Constants.SERVER_HELP);
      System.exit(0);
    }
    // Setup and initialize logger
    setupLogging(cfg.logfile.toString());
    setupLogLevel(cfg.logLevel);
    Logger logger = Logger.getLogger("Main");
    try {
      Server server = new Server(cfg);
      server.init();
      server.start();
    } catch (SocketException e) {
      System.out.println(e.getMessage());
      logger.severe(
          "Server Socket closed " + e.getMessage() + " " + Arrays.toString(e.getStackTrace()));
    } catch (IOException e) {
      System.out.println("Server failed to start: " + e.getMessage());
      logger.severe(
          "Failed to start server. " + e.getMessage() + " " + Arrays.toString(e.getStackTrace()));
      e.printStackTrace();
    }
  }
}
