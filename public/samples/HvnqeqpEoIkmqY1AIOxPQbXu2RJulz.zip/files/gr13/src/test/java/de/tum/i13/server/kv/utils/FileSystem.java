package de.tum.i13.server.kv.utils;

import de.tum.i13.server.kv.cache.CacheManager;
import java.io.File;

public class FileSystem {
  public static void cleanTestData(CacheManager cm) {
    if (cm != null) {
      cm.clearCache();
    }
    File f = new File("testData/");
    if (f.exists()) {
      for (File data : f.listFiles()) {
        //noinspection ResultOfMethodCallIgnored
        data.delete();
      }
    }
    //noinspection ResultOfMethodCallIgnored
    f.mkdir();
  }
}
