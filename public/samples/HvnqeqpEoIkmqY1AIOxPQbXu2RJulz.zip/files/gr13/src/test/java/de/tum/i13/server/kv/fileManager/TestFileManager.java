package de.tum.i13.server.kv.fileManager;

import static de.tum.i13.server.kv.utils.FileSystem.cleanTestData;
import static org.junit.jupiter.api.Assertions.assertAll;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;

import de.tum.i13.server.kv.Message;
import de.tum.i13.server.kv.fileManagement.KVFileManager;
import java.io.File;
import java.util.Arrays;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.MethodOrderer.OrderAnnotation;
import org.junit.jupiter.api.Order;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestMethodOrder;

import static de.tum.i13.server.kv.utils.SampleMessage.getError;
import static de.tum.i13.server.kv.utils.SampleMessage.getSuccess;
import static de.tum.i13.server.kv.utils.SampleMessage.putUpdate;
import static de.tum.i13.server.kv.utils.SampleMessage.putSuccess;
import static de.tum.i13.server.kv.utils.SampleMessage.deleteError;
import static de.tum.i13.server.kv.utils.SampleMessage.deleteSuccess;

@TestMethodOrder(OrderAnnotation.class)
public class TestFileManager {
  private KVFileManager fm = new KVFileManager("testData/");

  @BeforeEach
  public void runBefore() {
    cleanTestData(null);
  }

  @Test
  @Order(1)
  @DisplayName("Get for non-existent key")
  public void testGetEmpty() {
    Message res = (Message) fm.get("a");
    assertEquals(getError("a"), res);
  }

  @Test
  @Order(2)
  @DisplayName("Put for single item")
  public void testPutSingleItem() {
    Message res = (Message) fm.put("1", "1");
    assertEquals(putSuccess("1", "1"), res);
  }

  @Test
  @Order(3)
  @DisplayName("Get for single item")
  public void testGetSingleItem() {
    fm.put("1", "1");
    Message res = (Message) fm.get("1");
    assertEquals(getSuccess("1", "1"), res);
  }

  @Test
  @Order(4)
  @DisplayName("Put and update for single item")
  public void testPutUpdateSingleItem() {
    Message res1 = (Message) fm.put("1", "1");
    Message res2 = (Message) fm.put("1", "2");
    assertAll(
        () -> assertEquals(putSuccess("1", "1"), res1),
        () -> assertEquals(putUpdate("1", "2"), res2));
  }

  @Test
  @Order(5)
  @DisplayName("Delete for non-existent key")
  public void testDeleteEmpty() {
    Message res = (Message) fm.delete("1");
    assertEquals(deleteError("1"), res);
  }

  @Test
  @Order(6)
  @DisplayName("Delete for single item")
  public void testDeleteSingleItem() {
    fm.put("1", "1");
    Message res = (Message) fm.delete("1");
    assertEquals(deleteSuccess("1"), res);
  }

  @Test
  @Order(7)
  @DisplayName("Put for multiple items")
  public void testPutMultiItem() {
    fm.put("1", "1"); // File 18
    fm.put("2", "2"); // File 19
    fm.put("o", "3"); // File 18
    File[] files = new File("testData/").listFiles();
    String filesString = Arrays.toString(files);
    assertAll(
        () -> assertTrue(filesString.contains("18.txt")),
        () -> assertTrue(filesString.contains("19.txt")),
        () -> assertFalse(filesString.contains("20.txt")),
        () -> assertTrue(files.length == 2));
  }
}
