package de.tum.i13.server.kv.cache.cacheStrategy;

import static de.tum.i13.server.kv.utils.FileSystem.cleanTestData;
import static org.junit.jupiter.api.Assertions.assertAll;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import de.tum.i13.server.kv.cache.CacheManager;
import de.tum.i13.server.kv.cache.CacheableKey;
import de.tum.i13.server.kv.fileManagement.KVFileManager;
import de.tum.i13.server.kv.utils.SampleMessage;
import java.util.concurrent.ConcurrentHashMap;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.MethodOrderer.OrderAnnotation;
import org.junit.jupiter.api.Order;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestMethodOrder;

@TestMethodOrder(OrderAnnotation.class)
public class TestCacheLRU {

  KVFileManager fm = mock(KVFileManager.class);
  CacheManager cm = new CacheManager("LRU", 2, fm);
  ConcurrentHashMap<String, CacheableKey> keys;
  ConcurrentHashMap<CacheableKey, String> vals;

  @BeforeEach
  public void runBefore() {
    cleanTestData(cm);
    keys = cm.getKeysToCacheables();
    vals = cm.getCache();
  }

  @Test
  @Order(1)
  @DisplayName("Get for non-existent key")
  public void testGetEmpty() {
    CacheableKey cacheHit = keys.get("a");
    assertNull(cacheHit);
  }

  @Test
  @Order(2)
  @DisplayName("Put for single item")
  public void testPutSingleItem() {
    when(fm.get("someKey")).thenReturn(SampleMessage.getError("someVal"));
    cm.put("someKey", "someVal");
    String cacheHit = vals.get(keys.get("someKey"));
    assertEquals(cacheHit, "someVal");
  }

  @Test
  @Order(3)
  @DisplayName("Delete for single item")
  public void testDeleteSingleItem() {
    when(fm.get("someKey")).thenReturn(SampleMessage.getSuccess("someKey", "someVal"));
    when(fm.delete("someKey")).thenReturn(SampleMessage.deleteSuccess("someKey"));
    cm.put("someKey", "someVal");
    cm.delete("someKey");
    verify(fm).delete("someKey");
    CacheableKey cacheHit = keys.get("someKey");
    assertNull(cacheHit);
  }

  @Test
  @Order(4)
  @DisplayName("Cache strategy should hit")
  public void testLRUShouldHit() throws Exception {
    when(fm.get("1")).thenReturn(SampleMessage.getError("1"));

    when(fm.get("2")).thenReturn(SampleMessage.getError("2"));

    when(fm.get("3")).thenReturn(SampleMessage.getError("3"));


    cm.put("1", "1"); // Insert 1 -- cache should have 1
    when(fm.get("1")).thenReturn(SampleMessage.getSuccess("1","1"));

    cm.put("2", "2"); // Insert 2 -- cache should have 1 and 2
    when(fm.get("2")).thenReturn(SampleMessage.getSuccess("2","2"));

    cm.put("1", "3"); // Update 1 -- cache should have 1 and 2
    when(fm.get("1")).thenReturn(SampleMessage.getSuccess("1","3"));
    cm.get("1");
    cm.put("3", "4"); // Insert 3 -- cache should have 1 and 3
    verify(fm).put("2", "2"); // 2 displaced out of the cache
    assertAll(
        () -> assertEquals("3", vals.get(keys.get("1"))),
        () -> assertEquals("4", vals.get(keys.get("3"))));
  }

  @Test
  @Order(5)
  @DisplayName("Cache strategy should miss")
  public void testLRUShouldMiss() {

    when(fm.get("1")).thenReturn(SampleMessage.getError("1"));

    when(fm.get("2")).thenReturn(SampleMessage.getError("2"));

    when(fm.get("3")).thenReturn(SampleMessage.getError("3"));

    when(fm.get("4")).thenReturn(SampleMessage.getError("4"));

    cm.put("1", "1"); // Insert 1 -- cache should have 1

    cm.put("2", "2"); // Insert 2 -- cache should have 1 and 2

    cm.get("1"); // 1 is more recent than 2
    cm.put("3", "4"); // Insert 3 -- cache should have 1 and 3
    verify(fm).put("2", "2"); // 2 displaced out of the cache

    assertAll(() -> assertNull(keys.get("2")), () -> assertNull(keys.get("2")));
  }

}
