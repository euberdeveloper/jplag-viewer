package de.tum.i13.server.kv.utils;

import de.tum.i13.server.kv.KVMessage.StatusType;
import de.tum.i13.server.kv.Message;

public class SampleMessage {
  public static Message getError(String key) {
    return new Message(key, null, StatusType.GET_ERROR);
  }

  public static Message getSuccess(String key, String val) {
    return new Message(key, val, StatusType.GET_SUCCESS);
  }

  public static Message putError(String key, String val) {
    return new Message(key, val, StatusType.PUT_ERROR);
  }

  public static Message putSuccess(String key, String val) {
    return new Message(key, val, StatusType.PUT_SUCCESS);
  }

  public static Message putUpdate(String key, String val) {
    return new Message(key, val, StatusType.PUT_UPDATE);
  }

  public static Message deleteError(String key) {
    return new Message(key, null, StatusType.DELETE_ERROR);
  }

  public static Message deleteSuccess(String key) {
    return new Message(key, null, StatusType.DELETE_SUCCESS);
  }
}
