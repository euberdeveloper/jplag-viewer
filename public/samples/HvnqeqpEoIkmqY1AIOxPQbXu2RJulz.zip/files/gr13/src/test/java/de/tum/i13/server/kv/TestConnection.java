package de.tum.i13.server.kv;

import static de.tum.i13.shared.Config.parseCommandlineArgs;
import static org.junit.jupiter.api.Assertions.assertAll;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

import de.tum.i13.client.ClientCLI;
import de.tum.i13.client.command.Command;
import de.tum.i13.client.customExceptions.NotEnoughArgumentsException;
import de.tum.i13.server.threadperconnection.Server;
import de.tum.i13.shared.Config;
import java.io.IOException;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

public class TestConnection {
  private static Config cfg;
  private static Server s;
  private static Thread t;

  @BeforeAll
  public static void startServer() throws IOException {
    // Get Config
    cfg = parseCommandlineArgs(new String[0]);
    // Start server
    s = new Server(cfg);
    s.init();
    t = new Thread(
        () -> {
          try {
            s.start();
          } catch (IOException e) {
            e.printStackTrace();
          }
        });
    t.start();
  }

  @Test
  @DisplayName("Establish client-server connection")
  public void testConnectDisconnect() throws IOException, NotEnoughArgumentsException {
    // Start Client
    ClientCLI c = new ClientCLI();
    // Connection request
    String[] args = {"127.0.0.1", "5153"};
    Command cmd = c.getCommands().get("connect");
    cmd.process(args);
    // Connection variables
    String connectedHost = cmd.getClient().getHost();
    int connectedPort = cmd.getClient().getPort();
    boolean connected = cmd.getClient().isConnected();
    // Disconnection Request
    Command cmd2 = c.getCommands().get("disconnect");
    cmd2.process(new String[0]);
    // Disconnection variables
    boolean disconnected = !cmd2.getClient().isConnected();
    // Test if connection is established
    assertAll(
        () -> assertEquals(cfg.listenaddr, connectedHost),
        () -> assertEquals(cfg.port, connectedPort),
        () -> assertTrue(connected, "Client connected"),
        () -> assertTrue(disconnected, "Client disconnected"));
  }

  @AfterAll
  public static void stopServer() {
    t.interrupt();
  }
}
