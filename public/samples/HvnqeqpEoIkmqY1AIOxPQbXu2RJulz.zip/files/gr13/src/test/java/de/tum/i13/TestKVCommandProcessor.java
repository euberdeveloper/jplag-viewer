package de.tum.i13;

import de.tum.i13.server.kv.FileKVStore;
import de.tum.i13.server.kv.KVCommandProcessor;
import de.tum.i13.server.kv.KVStore;
import de.tum.i13.server.kv.Message;
import de.tum.i13.server.kv.fileManagement.KVFileManager;
import java.io.File;
import java.util.Arrays;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Order;
import org.junit.jupiter.api.Test;

import static de.tum.i13.server.kv.utils.FileSystem.cleanTestData;
import static de.tum.i13.server.kv.utils.SampleMessage.deleteError;
import static de.tum.i13.server.kv.utils.SampleMessage.deleteSuccess;
import static de.tum.i13.server.kv.utils.SampleMessage.getError;
import static de.tum.i13.server.kv.utils.SampleMessage.getSuccess;
import static de.tum.i13.server.kv.utils.SampleMessage.putSuccess;
import static de.tum.i13.server.kv.utils.SampleMessage.putUpdate;
import static org.junit.jupiter.api.Assertions.assertAll;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;

public class TestKVCommandProcessor {
  private KVFileManager fm = new KVFileManager("testData/");
  private FileKVStore kvs = new FileKVStore(2, "FIFO", fm);
  private KVCommandProcessor kvcp = new KVCommandProcessor(kvs);

  @BeforeEach
  public void runBefore() {
    cleanTestData(kvs.getCacheManager());
  }

  @Test
  @Order(1)
  @DisplayName("Get for non-existent key")
  public void testGetEmpty() {
    String res = kvcp.process("get a");
    assertEquals("get_error a", res);
  }

  @Test
  @Order(2)
  @DisplayName("Put for single item")
  public void testPutSingleItem() {
    String res = kvcp.process("put 1 1");
    assertEquals("put_success 1", res);
  }

  @Test
  @Order(3)
  @DisplayName("Get for single item")
  public void testGetSingleItem() {
    kvcp.process("put 1 1");
    String res = kvcp.process("get 1");
    assertEquals("get_success 1 1", res);
  }

  @Test
  @Order(4)
  @DisplayName("Put and update for single item")
  public void testPutUpdateSingleItem() {
    String res1 = kvcp.process("put 1 1");
    String res2 = kvcp.process("put 1 2");
    assertAll(
        () -> assertEquals("put_success 1", res1),
        () -> assertEquals("put_update 1", res2));
  }

  @Test
  @Order(5)
  @DisplayName("Delete for non-existent key")
  public void testDeleteEmpty() {
    String res = kvcp.process("delete 1");
    assertEquals("delete_error 1", res);
  }

  @Test
  @Order(6)
  @DisplayName("Delete for single item")
  public void testDeleteSingleItem() {
    kvcp.process("put 1 1");
    String res = kvcp.process("delete 1");
    assertEquals("delete_success 1", res);
  }
}
