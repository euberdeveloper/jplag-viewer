package de.tum.i13.client.command.kvstore;

import static org.junit.jupiter.api.Assertions.assertEquals;

import de.tum.i13.client.ClientCLI;
import de.tum.i13.client.customExceptions.NotEnoughArgumentsException;
import de.tum.i13.shared.Constants;
import java.io.BufferedReader;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.PrintStream;
import java.io.PrintWriter;
import java.net.InetSocketAddress;
import java.net.ServerSocket;
import java.net.Socket;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.MethodOrderer.OrderAnnotation;
import org.junit.jupiter.api.Order;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestMethodOrder;

@TestMethodOrder(OrderAnnotation.class)
public class TestKVCommand {
  private static ClientCLI client;
  private static ServerSocket serverSocket;
  private static Thread serverThread;

  private static final ByteArrayOutputStream outContent = new ByteArrayOutputStream();
  private static final PrintStream originalOut = System.out;

  @BeforeAll
  public static void startServer() throws IOException, NotEnoughArgumentsException {
    // Set output stream
    System.setOut(new PrintStream(outContent));
    // Start server
    serverSocket = new ServerSocket();
    serverSocket.bind(new InetSocketAddress("127.0.0.1", 7128));
    // Server functions
    serverThread =
        new Thread(
            () -> {
              try {
                Socket clientSocket = serverSocket.accept();
                BufferedReader in =
                    new BufferedReader(
                        new InputStreamReader(
                            clientSocket.getInputStream(), Constants.TELNET_ENCODING));
                PrintWriter out =
                    new PrintWriter(
                        new OutputStreamWriter(
                            clientSocket.getOutputStream(), Constants.TELNET_ENCODING));
                out.write("Connection established\r\n");
                out.flush();
                in.readLine();
                out.write("delete_success c29tZUtleQ==\r\n");
                out.flush();
                in.readLine();
                out.write("get_success c29tZUtleQ== c29tZVZhbA==\r\n");
                out.flush();
                in.readLine();
                out.write("put_success c29tZUtleQ==\r\n");
                out.flush();
              } catch (IOException e) {
                e.printStackTrace();
              }
            });
    serverThread.start();
    // Start client and connect
    client = new ClientCLI();
    String[] args = {"127.0.0.1", "7128"};
    client.getCommands().get("connect").process(args);
  }

  @BeforeEach
  public void flush() throws IOException {
    outContent.reset();
  }

  @Test
  @Order(1)
  @DisplayName("Delete a key")
  public void testDeleteCommand() throws NotEnoughArgumentsException, IOException {
    String[] args = {"someKey"};
    client.getCommands().get("delete").process(args);
    assertEquals("Client> delete_success someKey\r\n", outContent.toString());
  }

  @Test
  @Order(2)
  @DisplayName("Get a key")
  public void testGetCommand() throws NotEnoughArgumentsException, IOException {
    String[] args = {"someKey"};
    client.getCommands().get("get").process(args);
    assertEquals("Client> get_success someKey someVal\r\n", outContent.toString());
  }

  @Test
  @Order(3)
  @DisplayName("Put a key")
  public void testPutCommand() throws NotEnoughArgumentsException, IOException {
    String[] args = {"someKey", "someVal"};
    client.getCommands().get("put").process(args);
    assertEquals("Client> put_success someKey\r\n", outContent.toString());
  }

  @AfterAll
  public static void closeServer() {
    // Revert output stream to stdout
    System.setOut(originalOut);
    // Close server
    serverThread.interrupt();
  }
}
