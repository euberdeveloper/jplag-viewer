package de.tum.i13.server.kv;

import static de.tum.i13.server.kv.utils.FileSystem.cleanTestData;
import static de.tum.i13.server.kv.utils.SampleMessage.deleteError;
import static de.tum.i13.server.kv.utils.SampleMessage.deleteSuccess;
import static de.tum.i13.server.kv.utils.SampleMessage.getError;
import static de.tum.i13.server.kv.utils.SampleMessage.getSuccess;
import static de.tum.i13.server.kv.utils.SampleMessage.putSuccess;
import static de.tum.i13.server.kv.utils.SampleMessage.putUpdate;
import static org.junit.jupiter.api.Assertions.assertAll;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import de.tum.i13.server.kv.fileManagement.KVFileManager;
import de.tum.i13.server.kv.utils.SampleMessage;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.MethodOrderer.OrderAnnotation;
import org.junit.jupiter.api.Order;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestMethodOrder;

@TestMethodOrder(OrderAnnotation.class)
public class TestFileKVStore {
  KVFileManager fm = mock(KVFileManager.class);
  // Strategy doesn't matter here since cache misses will go to fm anyway.
  FileKVStore fs = new FileKVStore(2, "FIFO", fm);

  @BeforeEach
  public void runBefore() {
    cleanTestData(fs.getCacheManager());
  }

  @Test
  @Order(1)
  public void testGetEmpty() throws Exception {
    when(fm.get("a")).thenReturn(SampleMessage.getError("a"));
    KVMessage res = fs.get("a");
    verify(fm).get("a");
    assertEquals(getError("a"), res);
  }

  @Test
  @Order(2)
  @DisplayName("Put for single item")
  public void testPutSingleItem() {
    // check if item was already there to update or put
    when(fm.get("1")).thenReturn(SampleMessage.getError("1"));
    KVMessage res = fs.put("1", "1");
    assertEquals(putSuccess("1", "1"), res);
  }

  @Test
  @Order(3)
  @DisplayName("Get for single item")
  public void testGetSingleItem() {
    when(fm.get("a")).thenReturn(SampleMessage.getSuccess("a", "b"));

    KVMessage res = fs.get("a");
    verify(fm).get("a"); // check method is called once in get and once when we put into cache

    assertEquals(getSuccess("a", "b"), res);
  }

  @Test
  @Order(4)
  @DisplayName("Put and update for single item")
  public void testPutUpdateSingleItem() {

    when(fm.get("1")).thenReturn(SampleMessage.getError("1"));
    KVMessage res1 = fs.put("1", "1");
    when(fm.get("1")).thenReturn(SampleMessage.getSuccess("1", "1"));
    KVMessage res2 = fs.put("1", "2");

    assertAll(
        () -> assertEquals(putSuccess("1", "1"), res1),
        () -> assertEquals(putUpdate("1", "2"), res2));
  }

  @Test
  @Order(5)
  @DisplayName("Delete for non-existent key")
  public void testDeleteEmpty() {
    when(fm.get("1")).thenReturn(SampleMessage.getError("1"));

    KVMessage res = fs.delete("1");
    assertEquals(deleteError("1"), res);
  }

  @Test
  @Order(6)
  @DisplayName("Delete for single item")
  public void testDeleteSingleItem() {
    when(fm.delete("1")).thenReturn(SampleMessage.deleteSuccess("1"));
    when(fm.get("1")).thenReturn(SampleMessage.getSuccess("1", "1"));

    KVMessage res = fs.delete("1");
    verify(fm).delete("1");
    assertEquals(deleteSuccess("1"), res);
  }
}
